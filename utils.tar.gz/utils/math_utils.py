import copy

import numpy as np
from subdivision_planner.src.common import types
from subdivision_planner.src.common.types import FS_DV, FS_DA, FS_SV, FS_SA
from subdivision_planner.src.data_structures.frenet_serret_frame import FrenetSerret2DFrame
from shapely.geometry import Polygon
from typing import Tuple, Optional, Union
from functools import lru_cache

from subdivision_planner.src.data_structures.ifrenet_serret_frame import IFrenetSerret2DFrame

MARGIN_EPS = 1e-2


class RigidTransform2D:
    def __init__(self, rotation: (np.ndarray, float), translation: np.ndarray):
        # rotation is float -> it represents the rotation angle in radians
        if isinstance(rotation, (float, np.float, np.float32)):
            self.rotation_matrix = np.array([[np.cos(rotation), -np.sin(rotation)],
                                             [np.sin(rotation), np.cos(rotation)]])
        elif isinstance(rotation, np.ndarray) and \
                rotation.shape == (2, 2) and \
                np.linalg.norm(np.dot(rotation, rotation.T) - np.eye(2)) < 1e-5:
            self.rotation_matrix = rotation
        else:
            raise ValueError("Got erroneous rotation data (not rotation matrix and not angle): {}".format(rotation))

        assert translation.shape == (2,)
        self.translation: np.ndarray = translation.copy()

    def transform(self, input: np.ndarray) -> np.ndarray:
        """
        Transforms input vector
        :param input: input vector to be transformed, has to be 2 element size
        :return: transformed vector
        """
        assert input.shape == (2,) or (input.ndim == 2 and input.shape[1] == 2)
        if input.shape == (2,):
            return self.transform(input[None, :])
        elif input.ndim == 2 and input.shape[1] == 2:
            return self.rotation_matrix.dot(input.T).T + self.translation[None, :]

    def invert(self) -> 'RigidTransform2D':
        return RigidTransform2D(rotation=self.rotation_matrix.T,
                                translation=-self.rotation_matrix.T.dot(self.translation))

    def to_matrix(self) -> np.ndarray:
        """
        :return: 3x3 matrix that can transform homogeneous coordinated vectors
        """
        matrix = np.eye(3)
        matrix[:2, :2] = self.rotation_matrix
        matrix[:2, -1] = self.translation

        return matrix

    def compose(self, transform: 'RigidTransform2D') -> 'RigidTransform2D':
        """
        Composes this transform on top of the input transform. this means that the input transform will be first in
        order when applying this transform on a vector
        :param transform: rigid transform to compose on top of
        :return: RigidTransform2D
        """
        return RigidTransform2D(rotation=self.rotation_matrix.dot(transform.rotation_matrix),
                                translation=self.rotation_matrix.dot(transform.translation) + self.translation)

    @property
    def rotation_angle(self):
        """
        :return: compute rotation angle in radians
        """
        return -np.arcsin(self.rotation_matrix[0, 1])

    def __repr__(self):
        return "rotation: {:.2f} (rad), translation: ({:.2f}, {:.2f})".format(self.rotation_angle,
                                                                              self.translation[0],
                                                                              self.translation[1])


class NumpySerializable:
    def numpy(self):
        data = []
        for prop in self.get_numpy_order():
            data.append(np.array(getattr(self, prop[0]), ndmin=1))
        return np.concatenate(data)

    @classmethod
    def get_numpy_order(cls):
        raise NotImplementedError()

    @classmethod
    def np_indices(cls, attribute_name: str):
        """
        Get numpy indices of a specific
        :param attribute_name:
        :return:
        """
        start_idx = 0
        for prop in cls.get_numpy_order():
            if prop[0] == attribute_name:
                return list(range(start_idx, start_idx + prop[1]))
            start_idx += prop[1]


class Rectangle(NumpySerializable):
    def __init__(self,
                 location: (Tuple[float, float], np.ndarray),
                 size: (Tuple[float, float], np.ndarray),
                 orientation: float):
        """
        :param location: location of object in cartesian coordinates
        :param size: size of object with zero orientation
        :param orientation: angle of orientation in radians (zero angle means size[0] will be along axis 0,
                size[1] along axis 1)
        """
        self.location: np.ndarray = np.array(location)
        self.size: np.ndarray = np.array(size)
        self.orientation: float = orientation

        self._corners = None
        self._rigid_transform = None
        self._polygon = None

    @property
    def rigid_transform(self) -> RigidTransform2D:
        """
        :return: Rigid transform that corresponds to the location and orientation of the obstacle
        """
        if self._rigid_transform is None:
            self._rigid_transform = RigidTransform2D(rotation=self.orientation, translation=self.location)

        return self._rigid_transform

    @property
    def polygon(self) -> Polygon:
        """
        :return: shapely Polygon object of this rectangle
        """
        if self._polygon is None:
            self._polygon = Polygon(self.corners.tolist())

        return self._polygon

    @property
    def corners(self) -> np.ndarray:
        """
        :return: 4x2 array with the corners of the obstacle in its rows
        """
        if self._corners is None:
            axis_aligned_corners = np.array([[0.5, 0.5],
                                             [0.5, -0.5],
                                             [-0.5, -0.5],
                                             [-0.5, 0.5]]) * self.size[None, :]
            self._corners = self.rigid_transform.transform(axis_aligned_corners)

        return self._corners

    def distance_to_rect(self, other: 'Rectangle') -> float:
        """
        Distance to another rectangle
        :param other:
        :return:
        """
        return self.polygon.distance(other.polygon)

    @classmethod
    def get_numpy_order(cls):
        return ('location', 2), ('size', 2), ('orientation', 1)


@lru_cache(maxsize=512)
def cstate_to_fstate(frenet_frame: IFrenetSerret2DFrame, cstate: tuple, is_d_dot: bool = True):
    return frenet_frame.cstate_to_fstate(cstate=np.array(cstate), is_d_dot=is_d_dot)


# @lru_cache(maxsize=512)
def fstate_dtag_to_fstate_ddot(fstate: Union[tuple, np.ndarray]) -> np.ndarray:
    # Calculate derivatives of d w.r.t s:
    fstate = np.array(fstate)

    s_v = fstate[FS_SV]
    s_a = fstate[FS_SA]
    d_tag = fstate[FS_DV]
    d_tagtag = fstate[FS_DA]

    d_dot = d_tag * s_v
    d_dotdot = d_tag * s_a + d_tagtag * (s_v ** 2)

    fstate[FS_DV] = d_dot
    fstate[FS_DA] = d_dotdot
    return fstate


# @lru_cache(maxsize=512)
def fstate_to_fstate_dtag(fstate: Union[tuple, np.ndarray], frenet_frame: FrenetSerret2DFrame, cstate: Optional[tuple]) -> np.ndarray:
    # Calculate derivatives of d w.r.t s:
    fstate = np.array(fstate)
    if cstate is None:
        cstate = frenet_frame.fstate_to_cstate(fstate=fstate)
    else:
        cstate = np.array(cstate)

    theta_x, k_x = cstate[types.C_YAW], cstate[types.C_K]

    a_r, T_r, N_r, k_r, k_r_tag = frenet_frame._taylor_interp(s=np.array([fstate[types.FS_SX]]))

    d_x = fstate[types.FS_DX]
    radius_ratio = 1 - k_r * d_x
    theta_r = np.arctan2(T_r[..., types.C_Y], T_r[..., types.C_X])
    delta_theta = theta_x - theta_r
    tan_delta_theta = np.tan(delta_theta)
    cos_delta_theta = np.cos(delta_theta)
    d_tag = radius_ratio * tan_delta_theta
    d_tagtag = -(k_r_tag * d_x + k_r * d_tag) * tan_delta_theta + \
               radius_ratio / (cos_delta_theta * cos_delta_theta) * (k_x * radius_ratio / cos_delta_theta - k_r)
    new_fstate = fstate.copy()
    new_fstate[types.FS_DV] = d_tag
    new_fstate[types.FS_DA] = d_tagtag
    return new_fstate


def points_to_line_distance(points: np.ndarray, line: np.ndarray) -> float:
    x = points[:, 0]
    y = points[:, 1]
    a = line[:, 0]
    b = line[:, 1]
    c = line[:, 2]
    return abs(a * x + b * y + c) / np.sqrt(a * a + b * b)


def get_closest_distance_points(
        points1: np.ndarray,
        points2: np.ndarray,
        max_distance: float = np.inf
) -> Tuple[np.ndarray, np.ndarray]:
    """
    For each point in points1 return the closest distance to point in points2 and the corresponding index
    :param points1: Nx2 cartesian points
    :param points2: Mx2 cartesian points
    :param max_distance: The maximal distance expected
    :return:
    Two vectors:
        1. Nx1 vector of distances where the ith element is min(points1[i] - p) for p in points2
        2. Nx1 vector of indices where the ith element is argmin(points1[i] - p) for p in points2
    """

    d = np.linalg.norm(points1[:, None] - points2[None, :], axis=-1)

    distance_mask = d > max_distance
    d[distance_mask] = np.inf

    argmin = np.argmin(d, axis=1)

    min_distances = d[np.arange(d.shape[0]), argmin]

    return min_distances, argmin


def distance_points_to_line_strip(
        points: np.ndarray,
        line_strip_points: np.ndarray,
        max_distance: float = np.inf
) -> [np.ndarray, np.ndarray]:
    """
    For each point in points return the closest distance to one of the segments in line_strip_points
    :param points: Nx2 cartesian points
    :param line_strip_points: Mx2 cartesian points which are the vertices of the line strip
    :param max_distance: The maximal distance expected
    :return: Nx1 vector of distances where the ith element is shortest distance between the ith point to the line strip
             Nx1 vector of indices of line_strip_points closest to each point of points
    """

    assert line_strip_points.shape[0] > 1 and line_strip_points.shape[1] == 2, f'Bad shape of line_stip_points: {line_strip_points.shape}'
    assert points.shape[0] > 0 and points.shape[1] == 2, f'Bad shape of points: {points.shape}'

    # Vector between two consecutive vertices in the line strip (M-1 x 2)
    ab = line_strip_points[1:] - line_strip_points[:-1]

    # Vector between end point of each segment to point in points NxMx2
    bp = points[:, None] - line_strip_points[None, 1:]

    # Dot product between direction of the segment with the vector from end point of segment to point (NxM-1)
    ab_dot_bp = np.sum((bp * ab[None, :]), axis=-1)
    # If both vectors are in the same direction - point must be located after the end point of the segment
    out_of_segment_front_mask = ab_dot_bp > MARGIN_EPS

    # Vector between start point of each segment to point in points NxMx2
    ap = points[:, None] - line_strip_points[None, :-1]

    # Dot product between direction of the segment with the vector from start point of segment to point (NxM-1)
    ab_dot_ap = np.sum((ap * ab[None, :]), axis=-1)
    # If vectors are in opposite direction - point must be located before the start point of the segment
    out_of_segment_back_mask = ab_dot_ap < -MARGIN_EPS

    invalid_mask = out_of_segment_front_mask | out_of_segment_back_mask  # (NxM-1)

    length_ab = np.linalg.norm(ab, axis=1)  # M-1x1

    # Cross product in 2d is the area of trapezoid == length of base * height => cross/length of base == distance to base
    cross_val = np.cross(ab, ap, axisa=1, axisb=2)  # NxM-1

    distances = np.abs(cross_val) / length_ab
    distances[invalid_mask] = np.inf

    argmin_ab_idxs = np.argmin(distances, axis=1)

    points_idxs = np.arange(points.shape[0])
    distances_vec = distances[points_idxs, argmin_ab_idxs]
    closest_strip_idxs = argmin_ab_idxs + (ab_dot_ap[points_idxs, argmin_ab_idxs] > -ab_dot_bp[points_idxs, argmin_ab_idxs])
    #distances_vec = np.min(distances, axis=1)

    distance_mask = distances_vec > max_distance

    invalid_points_mask = np.isinf(distances_vec) | distance_mask
    if np.any(invalid_points_mask):
        """
        Handle edge cases were points can't be projected on any segment.
        Assign the minimum distance to any of points along the line strip
        """
        distances_of_invalid_points, argmin = get_closest_distance_points(
            points1=points[invalid_points_mask],
            points2=line_strip_points
        )

        distances_vec[invalid_points_mask] = distances_of_invalid_points
        closest_strip_idxs[invalid_points_mask] = argmin

    return distances_vec, closest_strip_idxs


def distance_path_points_to_line_strip(
        path_points: np.ndarray,
        line_strip_points: np.ndarray,
        max_distance: float = np.inf
) -> [np.ndarray, np.ndarray]:
    """
    Same as @distance_points_to_line_strip but assuming the points in path_points arranged as a sequence
    """

    assert line_strip_points.shape[0] > 1 and line_strip_points.shape[1] == 2, f'Bad shape of line_stip_points: {line_strip_points.shape}'
    assert path_points.shape[0] > 0 and path_points.shape[1] == 2, f'Bad shape of points: {path_points.shape}'

    max_length_points_per_iter = 200

    all_sub_distances = list()
    all_sub_closest_strip_idxs = list()
    for i in range(0, path_points.shape[0], max_length_points_per_iter):

        first_and_last_points = path_points[[i, min(i + max_length_points_per_iter, path_points.shape[0] - 1)], :]

        # get the indices of the matching subset in the line strip
        _, indx = get_closest_distance_points(
            points1=first_and_last_points,
            points2=line_strip_points,
            max_distance=max_distance
        )

        assert indx[0] <= indx[1], f'Invalid path points of line strip were given. indx[0]={indx[0]}, indx[1]={indx[1]}, ' \
            f'line_strip_points={line_strip_points}, \nfirst_and_last_points={first_and_last_points}, max_distance={max_distance}'

        start_index = max(0, indx[0] - 1)
        end_index = min(line_strip_points.shape[0], indx[1] + 2)

        curr_sub_distances, curr_sub_closest_strip_idxs = distance_points_to_line_strip(
            points=path_points[i:i + max_length_points_per_iter, :],
            line_strip_points=line_strip_points[start_index:end_index, :],
            max_distance=max_distance
        )

        all_sub_distances.append(curr_sub_distances)
        all_sub_closest_strip_idxs.append(curr_sub_closest_strip_idxs + start_index)

    distances_vec = np.hstack(all_sub_distances)
    closest_strip_idxs = np.hstack(all_sub_closest_strip_idxs)

    return distances_vec, closest_strip_idxs


def get_lines_coeffs(cstates: np.ndarray,
                     heading: np.ndarray,
                     right_offset: np.ndarray,
                     left_offset: np.ndarray):
    normal = np.c_[-np.sin(heading), np.cos(heading)]
    tangent = np.c_[np.cos(heading), np.sin(heading)]
    right_points = cstates[:, :2] + normal * right_offset
    left_points = cstates[:, :2] - normal * left_offset
    points = np.concatenate([right_points, left_points], axis=0)
    a = -np.repeat(tangent[:, 1], 2, axis=0)
    b = np.repeat(tangent[:, 0], 2, axis=0)
    c = - points[:, 0] * a - points[:, 1] * b
    return a, b, c


def boxes_distance(box1_cstates: np.array, box1_sizes: np.array, box2_cstates: np.array, box2_sizes: np.array) -> np.array:
    """
    calculate Euclidean distances between ego and objects boxes for N times
    :param box1_cstates: 2D array Nx3 of ego states with columns: x, y, yaw
    :param box1_sizes: array Nx2 of ego sizes
    :param box2_cstates: 2D array Nx3 of objects' states with columns: x, y, yaw
    :param box2_sizes: array Nx2 of objects' sizes
    :return: array of distances between ego and objects for N times
    """
    pos1 = box1_cstates[:, :2]
    pos2 = box2_cstates[:, :2]

    yaw1 = box1_cstates[:, 2]
    yaw2 = box2_cstates[:, 2]
    sin1, cos1 = np.sin(yaw1), np.cos(yaw1)
    sin2, cos2 = np.sin(yaw2), np.cos(yaw2)

    # distances from ego boxes to objects' corners
    dist1 = boxes_distance_sq_directed(pos1, sin1, cos1, box1_sizes, pos2, sin2, cos2, box2_sizes)
    # distances from objects boxes to ego corners
    dist2 = boxes_distance_sq_directed(pos2, sin2, cos2, box2_sizes, pos1, sin1, cos1, box1_sizes)
    return np.sqrt(np.minimum(dist1, dist2))


def boxes_distance_sq_directed(pos1: np.array, sin1: np.array, cos1: np.array, size1: np.array,
                               pos2: np.array, sin2: np.array, cos2: np.array, size2: np.array) -> np.array:
    """
    Calculate squared distance between rectangle 1 (given by pos1, sin1, cos1, size1) and corners of rectangle 2.
    Algorithm:
        1. Move both rectangles, such that rect 1 center is located at the origin
        2. Rotate center of rect 2 by yaw of rectangle 1, such that rect 1 is aligned to the global axes
        3. Create corners of rect 2
        4. Find distances from the corners of rect 2 to rect 1.
    :param pos1: array of rect 1 centers
    :param sin1: array of rect 1 sin(yaw)
    :param cos1: array of rect 1 cos(yaw)
    :param size1: array of sizes of rect 1
    :param pos2: array of rect 2 centers
    :param sin2: array of rect 2 sin(yaw)
    :param cos2: array of rect 2 cos(yaw)
    :param size2: array of sizes of rect 2
    :return: array of squared distances between rect 1 and corners of rect 2
    """
    assert pos1.shape[0] == sin1.shape[0]
    assert pos1.shape[0] == cos1.shape[0]
    assert pos1.shape[0] == size1.shape[0]
    assert pos1.shape[0] == pos2.shape[0]
    assert pos1.shape[0] == sin2.shape[0]
    assert pos1.shape[0] == cos2.shape[0]
    assert pos1.shape[0] == size2.shape[0]
    assert pos1.shape[1] == 2
    assert pos2.shape[1] == 2

    sin12 = cos1 * sin2 - sin1 * cos2  # sin(yaw2 - yaw1)
    cos12 = cos1 * cos2 + sin1 * sin2  # cos(yaw2 - yaw1)
    half_size1_x, half_size1_y = 0.5 * size1[:, 0], 0.5 * size1[:, 1]
    half_size2_x, half_size2_y = 0.5 * size2[:, 0], 0.5 * size2[:, 1]

    # make the 1st object to be the rotation center
    rel_pos = pos2 - pos1
    rel_x, rel_y = rel_pos[:, 0], rel_pos[:, 1]

    # rotate objects' centers around ego, such that ego will be aligned to the axes
    rot_x, rot_y = rel_x * cos1 + rel_y * sin1, -rel_x * sin1 + rel_y * cos1

    # calculate the rotated corners of rect2; after rotation yaw of rect2 is yaw2 - yaw1
    # X coordinates of the corners & box centers
    xcos, ysin = half_size2_x * cos12, half_size2_y * sin12
    corner_x = np.concatenate(
        (rot_x, rot_x + xcos - ysin, rot_x + xcos + ysin, rot_x - xcos - ysin, rot_x - xcos + ysin))
    rad_x = np.concatenate((half_size1_x, half_size1_x, half_size1_x, half_size1_x, half_size1_x))
    dist_x = np.maximum(0, np.abs(corner_x) - rad_x)

    # Y coordinates of the corners & box centers
    ycos, xsin = half_size2_y * cos12, half_size2_x * sin12
    corner_y = np.concatenate(
        (rot_y, rot_y + ycos + xsin, rot_y - ycos + xsin, rot_y + ycos - xsin, rot_y - ycos - xsin))
    rad_y = np.concatenate((half_size1_y, half_size1_y, half_size1_y, half_size1_y, half_size1_y))
    dist_y = np.maximum(0, np.abs(corner_y) - rad_y)

    # calculate distance from the corners to the aligned rectangle
    corner_dist = dist_x * dist_x + dist_y * dist_y
    return np.min(corner_dist.reshape(5, -1), axis=0)


def boxes_inside(boxes1_locations: np.ndarray, boxes1_sizes: np.ndarray,
                 boxes2_locations: np.ndarray, boxes2_sizes: np.ndarray,
                 threshold: float):
    """
    Calculates distance between pairs of boxes. Distance is between corners of boxes in first array and edges of
    boxes in second array
    :param boxes1_locations: center locations of one set of boxes of size (Nx2)
    :param boxes1_sizes: sizes of one set of boxes (length, width) of size (Nx2)
    :param boxes2_locations: center locations of second set of boxes of size (Nx2)
    :param boxes2_sizes: sizes of second set of boxes (length, width) of size (Nx2)
    :return: distance between pairs of boxes of size (N,)
    """
    boxes_num = boxes1_locations.shape[0]
    # No boxes, we return empty list
    if boxes_num == 0:
        return np.array([])

    # Calculate signed distance to between boxes pairs
    distances = boxes_signed_distance_directed(boxes1_locations=boxes1_locations,
                                               boxes1_sizes=boxes1_sizes,
                                               boxes2_locations=boxes2_locations,
                                               boxes2_sizes=boxes2_sizes)

    # Check if maximal distance to edges is below requested threshold
    return np.max(distances, axis=(0, 1)) < threshold


def boxes_signed_distance_directed(boxes1_locations: np.ndarray, boxes1_sizes: np.ndarray,
                                   boxes2_locations: np.ndarray, boxes2_sizes: np.ndarray):
    """
    Calculates distance between pairs of boxes. Distance is between corners of boxes in first array and edges of
    boxes in second array
    :param boxes1_locations: center locations of one set of boxes of size (Nx2)
    :param boxes1_sizes: sizes of one set of boxes (length, width) of size (Nx2)
    :param boxes2_locations: center locations of second set of boxes of size (Nx2)
    :param boxes2_sizes: sizes of second set of boxes (length, width) of size (Nx2)
    :return: distance between pairs of boxes of size (N,)
    """
    assert boxes2_locations.shape[0] == boxes2_sizes.shape[0]
    assert boxes1_locations.shape[0] == boxes2_locations.shape[0] == boxes2_sizes.shape[0]
    assert boxes1_sizes.shape[0] == boxes1_locations.shape[0] == boxes2_locations.shape[0] == boxes2_sizes.shape[0]
    assert boxes1_sizes.shape[1] == boxes2_sizes.shape[1] == 2
    assert boxes2_locations.shape[1] == boxes1_locations.shape[1] == 3

    boxes_num = boxes1_locations.shape[0]
    # No boxes, we return empty list
    if boxes_num == 0:
        return np.array([])

    # Get corners of both sets of boxes
    corners_1 = get_boxes_corners(boxes1_locations, boxes1_sizes)
    corners_2 = get_boxes_corners(boxes2_locations, boxes2_sizes)
    # Reshape to have the first axis as the axis of corners
    corners_1 = corners_1.reshape(4, boxes_num, 2)
    corners_2 = corners_2.reshape(4, boxes_num, 2)

    # roll corners so that instead of corners of order [0, 1, 2, 3] we have [3, 0, 1, 2]
    corners_2_rolled = np.roll(a=corners_2, shift=1, axis=0)

    corners_1_to_box_2_edges = corners_1[:, None, ...] - corners_2[None, ...]  # corners1 x corners2 x num boxes x 2

    # Calculate the vector of each edge of the second boxes
    edges_2 = corners_2_rolled - corners_2

    # Calculate the cross product between the vectors leading from box corners to edges and edges
    cross_product = corners_1_to_box_2_edges[..., 0] * edges_2[None, ..., 1] - \
                    corners_1_to_box_2_edges[..., 1] * edges_2[None, ..., 0]  # corners1 x edges2 x num boxes

    # Normalize cross product by edges size to get distance from edge
    distances = cross_product / np.linalg.norm(edges_2, axis=-1)[None, ...]

    return distances


def get_boxes_corners(cstates: np.ndarray, sizes: np.ndarray):
    """
    Per ctates - return all corners as numpy array [N*4 x 2]
    :param cstates:
    :return:
    """
    num = 4
    axis_aligned_corners = get_axis_aligned_corners(sizes)

    # Add vehicle corners to cstate
    yaws = cstates[:, types.C_YAW]
    c = np.tile(np.cos(yaws), num)
    s = np.tile(np.sin(yaws), num)
    x_transformer = np.vstack([c, -s]).T
    y_transformer = np.vstack([s, c]).T

    def rotate_vec(vec):
        x_new = np.sum(x_transformer * vec, axis=1)
        y_new = np.sum(y_transformer * vec, axis=1)
        return np.vstack([x_new, y_new]).T

    ego_rotated_corners = rotate_vec(axis_aligned_corners)
    corners = ego_rotated_corners + np.tile(cstates[:, [types.C_X, types.C_Y]], (num, 1))
    return corners


def get_axis_aligned_corners(sizes):
    normalized_size = np.array([[0.5, 0.5],
                                [0.5, -0.5],
                                [-0.5, -0.5],
                                [-0.5, 0.5]])
    assert sizes.shape[1] == 2
    return np.repeat(normalized_size, sizes.shape[0], axis=0) * np.tile(sizes, (4, 1))


def verify_trajectory_consistency(cstates: np.ndarray, dt: float) -> bool:
    """
    Verifies the trajectory given in cartesian coordinates makes sense and all the coordinates are aligned with each other
    :param cstates: samples of the trajectory with a resolution of dt
    :param dt: time difference between the states
    :return: True if the trajectory is consistent
    """
    forward_cstates = predict_cstates_forward(cstates=cstates, dt=dt)
    diff = forward_cstates[:-1] - cstates[1:]

    # The following lines calculate the difference in the velocity vector between each trajectory point and the
    # prediction in that time of its preceding point. The velocity vector's magnitude equals to the cartesian velocity
    # and it's direction is the yaw. v = |C_V|*e^(1j*C_YAW). In negligible negative velocities (next to a stop) there
    # could be a jump of pi radians in the calculated yaw. This should not be considered inconsistent since it
    # corresponds to a very small displacement in space due to negligible negative velocities.
    forward_velocity_vector = forward_cstates[:, types.C_V]*np.exp(1j*forward_cstates[:, types.C_YAW])
    velocity_vector = cstates[:, types.C_V]*np.exp(1j*cstates[:, types.C_YAW])
    velocity_vector_diff = forward_velocity_vector[:-1] - velocity_vector[1:]

    # The following assertions verify there isn't an excessive difference ON TOP of what the trajectory already
    # corresponds to
    waypoint_distance = np.linalg.norm(diff[:, [types.C_X, types.C_Y]], axis=1)

    is_consistent_loc = np.max(waypoint_distance) < 2 * dt
    is_consistent_vel_vector = np.max(np.abs(velocity_vector_diff)) < 1. * dt
    return is_consistent_loc and is_consistent_vel_vector


def predict_cstates_forward(cstates: np.ndarray, dt: float) -> np.ndarray:
    """
    Projects a numpy array of cartesian states forward in time
    :param cstates: numpy array of shape Nx6 of cartesian states to project forward in time
    :param dt: time by which to forward in time (float)
    :return: numpy array of shape Nx6 corresponding to future cartesian states
    """
    assert cstates.ndim == 2 and cstates.shape[1] == types.CRT_LEN, \
        f"Problematic dimensions in cstates, expected (Nx{types.CRT_LEN}), got {cstates.shape}"
    loc = cstates[:, [types.C_X, types.C_Y]].copy()
    yaw = cstates[:, [types.C_YAW]].copy()
    v = cstates[:, [types.C_V]].copy()
    a = cstates[:, [types.C_A]].copy()
    k = cstates[:, [types.C_K]].copy()

    new_yaw = yaw + k * v * dt

    direction = np.concatenate((np.cos(yaw), np.sin(yaw)), axis=1)
    new_v = v + a * dt
    new_loc = loc + (v * dt + a * dt * dt / 2) * direction

    return np.concatenate((new_loc, new_yaw, new_v, a, k), axis=1)


def predict_fstate_forward(fstates: types.FrenetStates2D, times: np.ndarray, target_sa: float, sj: float,
                           in_place: False) -> types.FrenetStates2D:
    """
    Projects a frenet state forward in time, in 2 parts:
    1. Constant longitudinal jerk until reaching target acceleration
    2. Constant acceleration
    :param fstates: numpy array of shape Nx6 of frenet states to project forward in time
    :param times: times corresponding to fstates
    :param target_sa: target longitudinal acceleration
    :param sj: longitudinal jerk to apply until target_sa
    :param in_place: If True then fstates is modified in-place, otherwise a new array is allocated
    :return: numpy array of shape Nx6 corresponding to future frenet states
    """
    assert fstates.ndim == 2 and fstates.shape[1] == types.FS_2D_LEN, \
        f"Problematic dimensions in fstate, expected (Nx{types.FS_2D_LEN}), got {fstates.shape}"
    assert fstates.shape[0] == times.shape[0], \
        f"Incorrect shape, fstates and times must have the same length, got {fstates.shape[0]} != {times.shape[0]}"

    relative_times = times - times[0]

    sx = fstates[0, types.FS_SX]
    sv = fstates[0, types.FS_SV]
    sa = fstates[0, types.FS_SA]

    predicted_fstates = fstates if in_place else copy.deepcopy(fstates)

    # time to reach target_sa at constant jerk sj
    target_t = (target_sa - sa) / sj
    assert target_t >= 0., f"Inconsistent jerk sign ({sj}) and target sa ({target_sa}) with initial sa ({sa})"
    target_idx = np.abs(relative_times - target_t).argmin() + 1

    part_1_times = relative_times[: target_idx]
    predicted_fstates[: target_idx, types.FS_SA] = sa + sj * part_1_times
    predicted_fstates[: target_idx, types.FS_SV] = sv + sa * part_1_times + sj * part_1_times ** 2 / 2.
    predicted_fstates[: target_idx, types.FS_SX] = sx + sv * part_1_times + sa * part_1_times ** 2 / 2. + sj * part_1_times ** 3 / 6.

    # constant acceleration
    part_2_times = relative_times[target_idx:] - relative_times[target_idx - 1]
    target_sx = predicted_fstates[target_idx - 1, types.FS_SX]
    target_sv = predicted_fstates[target_idx - 1, types.FS_SV]
    target_sa = predicted_fstates[target_idx - 1, types.FS_SA]

    predicted_fstates[target_idx:, types.FS_SA] = target_sa
    predicted_fstates[target_idx:, types.FS_SV] = target_sv + target_sa * part_2_times
    predicted_fstates[target_idx:, types.FS_SX] = target_sx + target_sv * part_2_times + target_sa * part_2_times ** 2 / 2.

    return predicted_fstates


def calculate_cars_corner_closest_to_lane_center(cars_fstates: np.array, cars_sizes: np.array) -> np.array:
    """
    For each car calculate ONE corner closest to the lane center.
    :param cars_fstates:
    :param cars_sizes:
    :return: array of corners' Frenet states, of the same shape as cars_fstates
    """
    dx, dv, sv = cars_fstates[:, [types.FS_DX, types.FS_DV, types.FS_SV]].T

    headings = np.arctan2(dv, sv + 1e-3)
    cos = np.cos(headings)
    sin = np.sin(headings)

    # calculate which car corner is closest to the lane center: side_d>0 means left, side_s>0 means front
    # side_s and side_d are relative to the car rather than to the lane
    l, w = 0.5 * cars_sizes.T
    side_d = np.sign(-dx * cos + 1e-6)
    side_s = np.sign(-dx * sin + 1e-6)
    l *= side_s
    w *= side_d

    # rotate (l, w) around (0, 0) by yaw > 0 and obtain (l_r, w_r), where l_r <= l, w_r >= w.
    # multiply (l_r, w_r) by (side_s, side_d) to calculate the corner's offset
    corner_fstates = np.copy(cars_fstates)
    corner_fstates[:, [types.FS_SX, types.FS_DX]] += np.c_[l * cos - w * sin, w * cos + l * sin]
    return corner_fstates


def are_lines_overlapping(primary_lines: np.ndarray, secondary_lines: np.ndarray) -> bool:
    """
    This method checks whether any primary line overlaps with any secondary line. Here, lines are 1D and are defined as a start and end
    position. A primary line is overlapping a secondary line if one of the following are true:
        1. secondary line start <=   primary line start <= secondary line end
        2. secondary line start <=   primary line end   <= secondary line end
        3.   primary line start <= secondary line start <= primary line end
        4.   primary line start <= secondary line end   <= primary line end
    Notably, this method does not check whether any primary line overlaps another primary line or whether any secondary line overlaps
    another secondary line. The check can be time-based, meaning that information regarding a line at multiple timestamps can be
    provided. If this is done, the same number of timestamps must be provided for every line. Below is an example showing proper
    dimensions and the values in the order that they will be checked below. To be clear, the start and end values are displayed adjacent
    to one another for brevity, but each is checked separately against the lower and upper bounds.

        a = np.array([[[2, 3], [2.5, 3.5]],         b = np.array([[[0, 1], [0.5, 1.5]],         so a has dimensions 2 x 2 x 2 and
                      [[6, 7], [6.5, 7.5]]])                      [[4, 5], [4.5, 5.5]],            b has dimensions 3 x 2 x 2
                                                                  [[8, 9], [8.5, 9.5]]])

        Lower Bound         Start       End         Upper Bound
            2.0       <=     0.0        1.0     <=      3.0
            2.5              0.5        1.5             3.5
            6.0              0.0        1.0             7.0
            6.5              0.5        1.5             7.5
            2.0              4.0        5.0             3.0
            2.5              4.5        5.5             3.5
            6.0              4.0        5.0             7.0
            6.5              4.5        5.5             7.5
            2.0              8.0        9.0             3.0
            2.5              8.5        9.5             3.5
            6.0              8.0        9.0             7.0
            6.5              8.5        9.5             7.5
            0.0              2.0        3.0             1.0
            0.5              2.5        3.5             1.5
            4.0              2.0        3.0             5.0
            4.5              2.5        3.5             5.5
            8.0              2.0        3.0             9.0
            8.5              2.5        3.5             9.5
            0.0              6.0        7.0             1.0
            0.5              6.5        7.5             1.5
            4.0              6.0        7.0             5.0
            4.5              6.5        7.5             5.5
            8.0              6.0        7.0             9.0
            8.5              6.5        7.5             9.5

    :param primary_lines: NumPy array with dimensions M x N x 2 where M represents M lines, N represents N frames for the same line
                          (e.g. a line at multiple timestamps), and 2 is for a line definition, which consists of start and end positions
                          as the first and second elements, respectively. Every start must be less than the end. Note that the second
                          dimension, N, is the same for both primary and secondary line arrays. This means that every line must have the
                          same number of frames or timestamps provided, as the lines are compared at each timestamp individually.
    :param secondary_lines: NumPy array with dimensions P x N x 2 where P represents P lines, N represents N frames for the the same line
                            (e.g. a line at multiple timestamps), and 2 is for a line definition, which consists of start and end positions
                            as the first and second elements, respectively. Every start must be less than the end. Note that the second
                            dimension, N, is the same for both primary and secondary line arrays. This means that every line must have the
                            same number of frames or timestamps provided, as the lines are compared at each timestamp individually.
    :return: True if any primary line overlaps any secondary line and False otherwise
    """
    # Verify input array dimensions
    assert primary_lines.ndim == secondary_lines.ndim == 3, \
        f"Array dimensions are incorrect. Each array should be 3D, but " \
            f"primary_lines.ndim={primary_lines.ndim}, secondary_lines.ndim={secondary_lines.ndim}."

    assert primary_lines.shape[1] == secondary_lines.shape[1], \
        f"Array dimensions are incorrect. The second dimension of each array should be equal, but " \
            f"primary_lines.shape[1]={primary_lines.shape[1]}, secondary_lines.shape[1]={secondary_lines.shape[1]}."

    assert primary_lines.shape[2] == secondary_lines.shape[2] == 2, \
        f"Array dimensions are incorrect. The third dimension of each array should be equal to two, but " \
            f"primary_lines.shape[2]={primary_lines.shape[2]}, secondary_lines.shape[2]={secondary_lines.shape[2]}."

    # Verify that each line's start is less than the end
    assert np.all(primary_lines[:, :, 0] < primary_lines[:, :, 1]), \
        f"The start of all primary lines ({primary_lines[:, :, 0].reshape(-1)}) are not less than the ends " \
            f"({primary_lines[:, :, 1].reshape(-1)})."

    assert np.all(secondary_lines[:, :, 0] < secondary_lines[:, :, 1]), \
        f"The start of all secondary lines ({secondary_lines[:, :, 0].reshape(-1)}) are not less than the ends " \
            f"({secondary_lines[:, :, 1].reshape(-1)})."

    # Create 1D arrays for lower and upper bounds and start and end positions. We repeat the primary and secondary line start and end
    # positions by the number of secondary and primary lines, respectively, because we need to check every primary line against every
    # secondary line and every secondary line against every primary line.
    lower_bound = np.hstack((np.tile(primary_lines[:, :, 0].reshape(-1), len(secondary_lines)),
                             np.tile(secondary_lines[:, :, 0].reshape(-1), len(primary_lines))))
    upper_bound = np.hstack((np.tile(primary_lines[:, :, 1].reshape(-1), len(secondary_lines)),
                             np.tile(secondary_lines[:, :, 1].reshape(-1), len(primary_lines))))

    start = np.hstack((np.repeat(secondary_lines[:, :, 0], len(primary_lines), axis=0).reshape(-1),
                       np.repeat(primary_lines[:, :, 0], len(secondary_lines), axis=0).reshape(-1)))
    end = np.hstack((np.repeat(secondary_lines[:, :, 1], len(primary_lines), axis=0).reshape(-1),
                     np.repeat(primary_lines[:, :, 1], len(secondary_lines), axis=0).reshape(-1)))

    # Check whether any start or end positions are within the bounds
    start_violation = (lower_bound <= start) & (start <= upper_bound)
    end_violation = (lower_bound <= end) & (end <= upper_bound)

    if any(start_violation) or any(end_violation):
        return True
    else:
        return False


def rotate_around_point(x: np.ndarray, y: np.ndarray, yaw: float, origin: Tuple[float, float] = (0., 0.), use_rad=True) -> \
        Tuple[np.ndarray, np.ndarray]:
    """
    Rotate points around a given point.
    :param x: x values
    :param y: y values
    :param yaw: yaw to rotate points by.
    :param origin: point to rotate around
    :param use_rad: True if yaw is radians, else it's in degrees.
    :return rotated points.
    """

    radians = yaw if use_rad else np.deg2rad(yaw)
    offset_x, offset_y = origin
    adjusted_x = (x - offset_x)
    adjusted_y = (y - offset_y)
    cos_rad = np.cos(radians)
    sin_rad = np.sin(radians)
    qx = offset_x + cos_rad * adjusted_x - sin_rad * adjusted_y
    qy = offset_y + sin_rad * adjusted_x + cos_rad * adjusted_y

    return qx, qy