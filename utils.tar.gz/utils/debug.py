import logging
import os
import pickle
import sys
from logging import Logger, INFO, DEBUG

from rte.python.logger.AV_logger import AV_Logger

exception_dir = os.path.expanduser("~/exceptions/")

# Change this to see more/less log levels
default_log_level = INFO


def block_print():
    sys.stdout = open(os.devnull, 'w')


def enable_print():
    sys.stdout = sys.__stdout__


def log(logger: Logger, name: str, frame_id: int, msg: str, level: int):
    logger.log(level=level,
               msg="{} Frame #{}: {}".format(name, frame_id, msg),
               exc_info=level == logging.ERROR)


def get_logger(name: str = None) -> Logger:
    logger = AV_Logger.get_logger(name or __name__)
    logger.setLevel(default_log_level)
    return logger


def save_to_pickle(d):
    if not os.path.isdir(exception_dir):
        os.makedirs(exception_dir)
    with open(os.path.join(exception_dir, "exception.pkl"), 'wb') as f:
        pickle.dump(d, f)
    print("dumped")


def load_from_pickle():
    with open(os.path.join(exception_dir, "exception.pkl"), 'rb') as f:
        return pickle.load(f)