from typing import List, Optional, Tuple, Union

from subdivision_planner.src.mdp.iaction_spec import IMDPActionSpec
from subdivision_planner.src.mdp.mdp_node import MDPNode
from subdivision_planner.src.mdp.werling.action_spec import GeneratedWerlingActionSpec, WerlingMDPActionSpec
from subdivision_planner.src.mdp.werling.component_spec import WerlingComponentSpec
from subdivision_planner.src.mdp.werling.debug_probe import ActionDebugProbe, ActionValidityCheck, ComponentDebugProbe, \
    ComponentValidityCheck
from subdivision_planner.src.mdp.werling.validator_return import ValidatorReturn
from subdivision_planner.src.mdp.werling.validator_returns import Valid
from subdivision_planner.src.mdp.werling.failure_mode import FailureMode
from subdivision_planner.src.mdp.werling.failure_mode import ComponentIsValidNotRun, WerlingLongitudinalComponentValidatorsNotRun, NoActionGeneratedFromValidComponents


def get_action_spec_trials(action_spec: IMDPActionSpec) -> Tuple[Optional[List[ComponentValidityCheck]],
                                                                 Optional[List[ComponentValidityCheck]],
                                                                 Optional[List[ActionValidityCheck]]]:
    """
    Get validator results after components and actions have been reset and revaldiated
    :param action_spec:
    :return: longitudinal_trials, lateral_trials, action_trials
             Returns None, None, None if action revalidation fails
    """
    assert isinstance(action_spec, (WerlingMDPActionSpec, GeneratedWerlingActionSpec))

    # set debug probes and call necessary reset methods
    longitudinal_component_debug_probe = ComponentDebugProbe()
    longitudinal_component_validator = action_spec.longitudinal_component_spec.validator
    longitudinal_component_validator.set_debug_probe(longitudinal_component_debug_probe)
    action_spec.longitudinal_component_spec.reset(validator=longitudinal_component_validator)
    longitudinal_component_trials = longitudinal_component_debug_probe.trials

    lateral_component_debug_probe = ComponentDebugProbe()
    lateral_component_validator = action_spec.lateral_component_spec.validator
    lateral_component_validator.set_debug_probe(lateral_component_debug_probe)
    action_spec.lateral_component_spec.reset(validator=lateral_component_validator)
    lateral_component_trials = lateral_component_debug_probe.trials

    action_debug_probe = ActionDebugProbe()
    action_validator = action_spec.validator
    action_validator.set_debug_probe(debug_probe=action_debug_probe)
    action_spec.reset(validator=action_validator)
    action_trials = action_debug_probe.trials

    _ = action_spec.action
    return longitudinal_component_trials, lateral_component_trials, action_trials


def most_frequent(list_of_failure_modes: List[Union[ValidatorReturn, FailureMode]]) \
        -> Union[FailureMode, ValidatorReturn]:
    """
    :param list_of_failure_modes: List of failed validators
    :return: return the most frequent ValidatorReturn in the input list.
    """
    hist = {}
    for fm in list_of_failure_modes:
        if fm.__class__.__name__ not in hist:
            hist[fm] = 0
        hist[fm] += 1
    return max(hist, key=hist.get)


def determine_action_spec_failure_reason(action_spec: IMDPActionSpec) -> Union[FailureMode, ValidatorReturn]:
    """
    returns the validation results given action_spec.
    :param action_spec: examined action spec
    :return: ValidatorResult instance specifying the validation process failure reason.
    """

    longitudinal_component_trials, lateral_component_trials, action_trials = get_action_spec_trials(action_spec)

    # return failure reason if one is recorded in the trials
    for component_trials in [longitudinal_component_trials, lateral_component_trials]:
        if component_trials:
            relevant_goal_check = component_trials[-1].goal_checks[-1]
            if not relevant_goal_check.result:
                return relevant_goal_check.validator_return

            # If the motion_plan_checks list is empty but the goal_checks list is not, that means we exited in between calling
            # is_goal_state_valid and is_valid. Return a corresponding failure reason.

            if component_trials[-1].motion_plan_checks:
                relevant_motion_plan_check = component_trials[-1].motion_plan_checks[-1]
            else:
                return ComponentIsValidNotRun(ComponentIsValidNotRun.__class__.__name__)

            if not relevant_motion_plan_check.result:
                return relevant_motion_plan_check.validator_return

    if action_trials:
        relevant_validity_check = action_trials[-1].validity_checks[-1]
        if not relevant_validity_check.result:
            return relevant_validity_check.validator_return

    # determine failure reason based on one not being recorded in trials
    if isinstance(action_spec, WerlingMDPActionSpec):
        if not longitudinal_component_trials and isinstance(action_spec.longitudinal_component_spec,
                                                            WerlingComponentSpec):
            return WerlingLongitudinalComponentValidatorsNotRun(WerlingLongitudinalComponentValidatorsNotRun.__class__.__name__)

        elif not action_trials:
            return NoActionGeneratedFromValidComponents(NoActionGeneratedFromValidComponents.__class__.__name__)
        # If we reach here, an action spec is valid even though all action specs are supposed to be invalid. This can happen when a valid
        # action can be found from the root node but it leads to a node where all actions are invalid. During a search, this is accounted for
        # during backup, and the action spec will be invalidated at the root node. However, when we're validating action specs here, we are
        # not doing this.
    return Valid("all validators ok")


def get_root_failure_reason(root_node: MDPNode, ) -> List[Tuple[Optional[WerlingMDPActionSpec], Union[ValidatorReturn, FailureMode]]]:
    """
    Perform analysis to root node and return the failed action specs with corresponding validation returns.
    The methods re-generate the action specs and actions while saving the validator-returns using a debug probe.
    :param root_node: the "empty action" failed search root node.
    :return: a list of pairs - each pair consist of an action-spec and a failed validator-return.
    """
    root_node_action_specs = root_node.action_specs
    invalid_action_specs_and_reasons = []
    # is_root_state_valid = is_state_valid(root_node)

    # If action specs are invalid, determine why.
    for i, action_spec in enumerate(root_node_action_specs):
        if not action_spec.is_action_valid:
            invalid_action_specs_and_reasons.append((action_spec, determine_action_spec_failure_reason(action_spec)))
    return invalid_action_specs_and_reasons
