from typing import Tuple, Callable

from direct.gui.DirectGui import OnscreenText, DirectSlider
from direct.showbase.ShowBase import LPoint3f, TextNode
from panda3d.core import NodePath
from subdivision_planner.src.utils.visualization.visualization import IGuiElement, VisualizationBackend


class SliderGuiElement(IGuiElement):
    def __init__(self,
                 name: str = "default_slider",
                 range: Tuple[int, int] = (0, 100),
                 value: int = 50,
                 page_size: int = 1,
                 use_keyboard: bool = False,
                 is_integer: bool = True,
                 value_to_text_fun: Callable = None):
        """
        This element is a slider
        :param name: Name of the slider, should be unique. When getting data from the visualization this will be used as
                                    key
        :param range: Tuple of two integers that are the minimum and maximum values for the slider value
        :param value: initial value of the slider
        :param page_size: when pressing left or right, page size is used to determine how many values the slider will
                                    move
        :param use_keyboard: if True keyboard will be used to control this slider - left and right arrows
        :param is_integer: if True the output value property will be converted to int
        :param value_to_text_fun: Function to convert the value of the slider to text, if is not None, a textbox will be
                                    added to show the result of that function.
        """
        self._name = name
        self._range = range
        self._value = value
        self._page_size = page_size
        self._use_keyboard = use_keyboard
        self._is_integer = is_integer
        self._value_to_text_fun = value_to_text_fun

        self._node_path = None
        self._text_node = None

    @property
    def name(self) -> str:
        return self._name

    def get_node_path(self, vis: VisualizationBackend) -> NodePath:
        if not self._node_path:
            self._node_path = DirectSlider(range=self._range, value=self._value, pageSize=self._page_size)

            if self._value_to_text_fun:
                self._text_node = OnscreenText(text="", pos=(0., +0.1), scale=0.1, fg=(1., 1., 1., 1.), bg=(0., 0., 0., 0.5))
                self._text_node.setDecal(True)
                self._text_node.reparentTo(self._node_path)

            self.on_update_aspect_ratio(vis)

        return self._node_path

    def on_updated_value(self, vis: VisualizationBackend):
        """
        Update the attached text node according to the value
        """
        if self._value_to_text_fun is not None:
            try:
                description = self._value_to_text_fun(value=self.value)
            except Exception as e:
                print(str(e))
                description = "description failed"
            self._text_node.setText(f"{description}")

    def update_gui(self, vis: 'VisualizationBackend'):
        def step_left():
            self._node_path['value'] = max(self._node_path['value'] - self._page_size, self._range[0])

        def step_right():
            self._node_path['value'] = min(self._node_path['value'] + self._page_size, self._range[1])

        if vis._buttons_state['arrow_left']:
            step_left()

        elif vis._buttons_state['arrow_right']:
            step_right()

    def on_update_aspect_ratio(self, vis: VisualizationBackend):
        """
        Rescale the element
        """
        aspect_ratio = vis.get_aspect_ratio()
        if aspect_ratio < 1:
            self._node_path.setPos(LPoint3f(0, 0, -0.9 / aspect_ratio))
            self._node_path.setScale(0.9)
        else:
            self._node_path.setPos(LPoint3f(0, 0, -0.9))

    @property
    def value(self):
        """
        :return: the index to which the slider is set
        """
        value = self._node_path['value']
        if self._is_integer:
            value = int(value)
        return value


class TextBoxGuiElement(IGuiElement):
    """
    This class implements a text box gui element. This is useful as a gui element and not as a render element since most
    of the time we want text to be located on top of the screen like part of the gui and not as part of the world we're
    rendering.
    The text and position can be modified using UpdateTextBox command.
    """
    def __init__(self, name, pos: Tuple[float, float], text: str, color: Tuple[float, float, float, float] = (1., 1., 1., 1.)):
        """
        :param name: identifier for this element, to be used later for changing its values
        :param pos: position on screen in aspect2d coordinates:
                    for aspect_ratio < 1
                        X: +-1
                        Y: +-1/aspect_ratio
                    for aspect ratio > 1
                        X: +-apsect_ratio
                        Y: +-1
        :param text: text to be written in the box
        :param color: color of the foreground
        """
        super().__init__()
        self._text = text
        self._pos = pos
        self._name = name
        self._color = color

        self._node_path = None

    @property
    def name(self) -> str:
        return self._name

    def on_updated_value(self, vis: 'VisualizationBackend'):
        pass

    def on_update_aspect_ratio(self, vis: 'VisualizationBackend'):
        self._node_path.setScale(25 / min(vis.win.getXSize(), vis.win.getYSize()))
        aspect_ratio = vis.get_aspect_ratio()
        if aspect_ratio < 1:
            self._node_path.setPos(self._pos[0], self._pos[1] / aspect_ratio)
        else:
            self._node_path.setPos(self._pos[0] * aspect_ratio, self._pos[1])

    @property
    def value(self):
        return self._node_path['text']

    def update_gui(self, vis: 'VisualizationBackend'):
        pass

    def get_node_path(self, vis: 'VisualizationBackend') -> NodePath:
        if self._node_path is None:
            self._node_path = OnscreenText(text=self._text,
                                           pos=self._pos,
                                           fg=self._color,
                                           bg=(0., 0., 0., 0.5),
                                           align=TextNode.ALeft,
                                           wordwrap=10.)
            self._node_path.setDecal(True)
            self.on_update_aspect_ratio(vis)

        return self._node_path

    def update_text(self, text: str):
        """
        Updates the text of the text box
        :param text: updated text
        """
        self._text = text
        if self._node_path is not None:
            self._node_path.setText(self._text)

    def update_pos(self, pos: Tuple[float, float]):
        """
        Updates the position of the text box, in aspect2d coordinates (see description in constructor)
        :param pos: position in aspect2d coordinates
        """
        self._pos = pos
        if self._node_path is not None:
            self._node_path.setPos(LPoint3f(0, 0, -0.9))
