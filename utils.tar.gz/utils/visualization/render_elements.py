from enum import Enum
from typing import Tuple, List

import numpy as np
from direct.showbase.ShowBase import Geom, TextNode, TransparencyAttrib
from panda3d.core import NodePath, GeomNode, GeomVertexFormat, GeomVertexData, \
    GeomVertexWriter, GeomTristrips, BoundingBox, GeomLinestrips, GeomPoints, GeomPrimitive
from subdivision_planner.src.utils.visualization.visualization import BaseRenderElement


class ParentRenderElement(BaseRenderElement):
    def __init__(self, element_list: List[BaseRenderElement]):
        super().__init__()
        self.element_list = element_list

    def can_be_updated_from(self, render_element: 'BaseRenderElement'):
        """
        This function returns true if we can update self using <render_element>
        :param render_element:
        :return:
        """

        if not isinstance(render_element, self.__class__):
            return False

        return all(local_element.can_be_updated_from(other_element)
                   for local_element, other_element in zip(self.element_list, render_element.element_list))

    def update_from(self, render_element: 'ParentRenderElement') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        for local_element, other_element in zip(self.element_list, render_element.element_list):
            local_element.update_from(other_element)

    def get_node_path(self):
        if not self._node_path:
            self._node_path = NodePath("path")
            for el in self.element_list:
                self._node_path.attachNewNode(el.get_node_path().node())
        return self._node_path


def generate_geometry_node(primitive: GeomPrimitive,
                           vertices: np.ndarray,
                           colors: np.ndarray,
                           priority: float) -> Tuple[NodePath, GeomVertexData]:
    """
    Generates a node path that draws a curve.
    :param points: points in the correct order that define the curve
    :param color: color for the curve
    :param priority: priority for display - lower is stronger
    :return: nodepath that draws the curve
    """

    format = GeomVertexFormat.getV3c4()
    vdata = GeomVertexData("vdata", format, Geom.UHStatic)
    vdata.setNumRows(vertices.shape[0])
    v_writer = GeomVertexWriter(vdata, "vertex")
    c_writer = GeomVertexWriter(vdata, "color")

    # set vertex data to point coordinates and color
    for i in range(vertices.shape[0]):
        v_writer.setData3f((vertices[i, 0], 0, vertices[i, 1]))
        c_writer.setData4f(tuple(colors[i]))

    # generate geometry primitive and connect vertices to it
    primitive.addNextVertices(vertices.shape[0])
    primitive.closePrimitive()

    # Generate geometry and add primitive to it
    geom = Geom(vdata)
    geom.setBounds(BoundingBox(min=(-10000, -10000, -10000), max=(10000, 10000, 10000)))
    geom.addPrimitive(primitive)

    # generate panda node to encapsulate everything
    geom_node = GeomNode("geom_node")
    geom_node.add_geom(geom)
    geom_node.setFinal(1)

    # generate a NodePath for this GeomNode
    node_path = NodePath(geom_node)
    node_path.setPos((0, priority, 0))
    node_path.setTransparency(TransparencyAttrib.MAlpha)
    node_path.setTwoSided(True)

    return node_path, vdata


def update_geometry(node_path: NodePath,
                    vdata: GeomVertexData,
                    vertices: np.ndarray,
                    colors: np.ndarray,
                    priority: float):
    """
    Updates an existing node with geometry as created by generate_geometry_node()
    :param node_path:
    :param vdata:
    :param vertices:
    :param colors:
    :param priority:
    :return:
    """
    v_writer = GeomVertexWriter(vdata, "vertex")
    c_writer = GeomVertexWriter(vdata, "color")
    num_rows = vdata.getNumRows()

    assert num_rows >= vertices.shape[0]

    # set vertex data to point coordinates and color
    for i in range(vertices.shape[0]):
        v_writer.setData3f((vertices[i, 0], 0, vertices[i, 1]))
        c_writer.setData4f(tuple(colors[i]))

    for i in range(vertices.shape[0], num_rows):
        c_writer.setData4f((0., 0., 0., 0.))
        v_writer.setData3f((vertices[-1, 0], 0, vertices[-1, 1]))

    node_path.setPos((0, priority, 0))
    node_path.setTransparency(TransparencyAttrib.MAlpha)
    node_path.setTwoSided(True)


class Curve(BaseRenderElement):
    def __init__(self, points: np.ndarray, thickness: int, colors: np.ndarray, priority: float, text: str = ""):
        super().__init__()
        assert points.ndim == 2
        assert points.shape[0] >= 2
        self.points = points
        self.colors = colors
        self.priority = priority
        self.thickness = thickness
        self.text = text

        self._vdata = None
        self._text_node_path = None

    def can_be_updated_from(self, render_element: 'Curve'):
        """
        This function returns true if we can update self using <render_element>
        :param render_element:
        :return:
        """
        return super().can_be_updated_from(render_element=render_element) and \
               render_element.points.shape[0] <= self._vdata.getNumRows() and \
               self.thickness == render_element.thickness

    def update_from(self, render_element: 'Curve') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        self.points = render_element.points
        self.colors = render_element.colors
        self.priority = render_element.priority
        self.thickness = render_element.thickness

        update_geometry(node_path=self.get_node_path(),
                        vdata=self._vdata,
                        vertices=self.points,
                        colors=self.colors,
                        priority=self.priority)

        if self.text is not None:
            if np.mean(np.array(self.colors[0])[:3]) > 0.7:
                self._text_node_path.node().setTextColor(0., 0., 0., 1.)
            self._text_node_path.node().setText(self.text)
            self._text_node_path.reparentTo(self._node_path)
        else:
            self._text_node_path.detachNode()

    def get_node_path(self) -> NodePath:
        if not self._node_path:
            self._node_path, self._vdata = generate_geometry_node(primitive=GeomLinestrips(Geom.UHStatic),
                                                                  vertices=self.points,
                                                                  colors=self.colors,
                                                                  priority=self.priority)

            self.generate_text_node()
            self._node_path.setRenderModeThickness(self.thickness)

        return self._node_path

    def generate_text_node(self):
        text_node = TextNode('id')
        text_node.setText(self.text)
        if np.mean(np.array(self.colors[0])[:3]) > 0.7:
            text_node.setTextColor(1., 1., 1., 1.)
        text_node.setTextScale(0.7)
        text_node.setAlign(TextNode.ACenter)
        self._text_node_path = NodePath(text_node)
        if self.text is not None:
            points = self.points[[(self.points.shape[0] - 1) // 2, (self.points.shape[0] - 1) // 2 + 1]]
            center = np.mean(points, axis=0)
            diff = np.diff(points, axis=0)[0]
            orientation = np.arctan2(diff[1], diff[0]) / np.pi * 180.
            self._text_node_path.setX(center[0])
            self._text_node_path.setY(-1e-3)
            self._text_node_path.setZ(center[1])
            self._text_node_path.setR(-orientation)
            self._text_node_path.reparentTo(self._node_path)


class DottedCurve(Curve):
    def get_node_path(self) -> NodePath:
        if not self._node_path:
            self._node_path, self._vdata = self.generate_node_path()
            self.generate_text_node()

        return self._node_path

    def generate_node_path(self) -> Tuple[NodePath, GeomVertexData]:

        vertices = self.points
        colors = self.colors

        format = GeomVertexFormat.getV3c4()
        vdata = GeomVertexData("vdata", format, Geom.UHStatic)
        vdata.setNumRows(vertices.shape[0])
        v_writer = GeomVertexWriter(vdata, "vertex")
        c_writer = GeomVertexWriter(vdata, "color")

        # set vertex data to point coordinates and color
        for i in range(vertices.shape[0]):
            v_writer.setData3f((vertices[i, 0], 0, vertices[i, 1]))
            c_writer.setData4f(tuple(colors[i]))

        # generate geometry primitive and connect vertices to it
        p_prim = GeomPoints(Geom.UHStatic)
        p_prim.addNextVertices(vertices.shape[0])
        p_prim.closePrimitive()
        c_prim = GeomLinestrips(Geom.UHStatic)
        c_prim.addNextVertices(vertices.shape[0])
        c_prim.closePrimitive()

        # Generate geometry and add primitive to it
        p_geom = Geom(vdata)
        p_geom.setBounds(BoundingBox(min=(-10000, -10000, -10000), max=(10000, 10000, 10000)))
        p_geom.addPrimitive(p_prim)
        c_geom = Geom(vdata)
        c_geom.setBounds(BoundingBox(min=(-10000, -10000, -10000), max=(10000, 10000, 10000)))
        c_geom.addPrimitive(c_prim)

        # generate panda node to encapsulate everything
        p_geom_node = GeomNode("p_geom_node")
        p_geom_node.add_geom(p_geom)
        p_geom_node.setFinal(1)
        c_geom_node = GeomNode("c_geom_node")
        c_geom_node.add_geom(c_geom)
        c_geom_node.setFinal(1)
        c_geom_node.add_child(p_geom_node)

        # generate a NodePath for this GeomNode
        node_path = NodePath(c_geom_node)
        node_path.setPos((0, self.priority, 0))
        node_path.setTransparency(True)
        node_path_p = NodePath(p_geom_node)
        node_path.setRenderModeThickness(self.thickness)
        node_path_p.setRenderModeThickness(int(self.thickness * 2))

        return node_path, vdata


class Points(BaseRenderElement):
    def __init__(self, points: np.ndarray, thickness: int, colors: np.ndarray, priority: float):
        super().__init__()
        assert points.ndim == 2 and points.shape[1] == 2
        self.points = points
        self.thickness = thickness
        self.colors = colors
        self.priority = priority

        self._vdata = None

    def can_be_updated_from(self, render_element: 'Points'):
        """
        This function returns true if we can update self using <render_element>
        :param render_element:
        :return:
        """
        return super().can_be_updated_from(render_element=render_element) and \
               render_element.points.shape[0] <= self._vdata.getNumRows()

    def update_from(self, render_element: 'Points') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        self.points = render_element.points
        self.thickness = render_element.thickness
        self.colors = render_element.colors
        self.priority = render_element.priority

        update_geometry(node_path=self.get_node_path(),
                        vdata=self._vdata,
                        vertices=self.points,
                        colors=self.colors,
                        priority=self.priority)

    def get_node_path(self) -> NodePath:
        if not self._node_path:
            self._node_path, self._vdata = generate_geometry_node(primitive=GeomPoints(Geom.UHStatic),
                                                                  vertices=self.points,
                                                                  colors=self.colors,
                                                                  priority=self.priority)
            self._node_path.setRenderModeThickness(self.thickness)
            self._node_path.setTransparency(True)
        return self._node_path


class Polygon(BaseRenderElement):
    def __init__(self, nodes: np.ndarray, color: Tuple[float, float, float, float], priority: float, text: str = ""):
        """
        :param nodes: array of nodes in counter clockwise order
        :param color: color of the polygon
        :param priority: display priority, lower is stronger
        :param text: text to display on top of polygon
        """
        super().__init__()
        assert nodes.ndim == 2 and nodes.shape[1] == 2
        self.nodes = nodes
        self.colors = np.array(color)[None, :] * np.ones((nodes.shape[0], 1))
        self.priority = priority
        self.text = text

        self._text_node_path: NodePath = None

        self._vdata = None

    def can_be_updated_from(self, render_element: 'Polygon'):
        """
        This function returns true if we can update self using <render_element>
        :param render_element:
        :return:
        """
        return super().can_be_updated_from(render_element=render_element) and \
               render_element.nodes.shape[0] <= self._vdata.getNumRows()

    def update_from(self, render_element: 'Polygon') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        self.nodes = render_element.nodes
        self.colors = render_element.colors
        self.priority = render_element.priority
        self.text = render_element.text

        update_geometry(node_path=self.get_node_path(),
                        vdata=self._vdata,
                        vertices=self.nodes,
                        colors=self.colors,
                        priority=self.priority)

        if self.text is not None:
            if np.mean(np.array(self.colors[0])[:3]) > 0.7:
                self._text_node_path.node().setTextColor(0., 0., 0., 1.)
            self._text_node_path.node().setText(self.text)
            self._text_node_path.reparentTo(self._node_path)
        else:
            self._text_node_path.detachNode()

    def get_node_path(self) -> NodePath:
        """
        Generate a polygon out of an array of nodes
        :return: NodePath
        """
        if not self._node_path:
            self._node_path, self._vdata = generate_geometry_node(primitive=GeomTristrips(Geom.UHStatic),
                                                                  vertices=self.nodes,
                                                                  colors=self.colors,
                                                                  priority=self.priority)
            text_node = TextNode('id')
            text_node.setText(self.text)
            if np.mean(np.array(self.colors[0])[:3]) > 0.7:
                text_node.setTextColor(0., 0., 0., 1.)
            text_node.setTextScale(0.7)
            text_node.setAlign(2)
            self._text_node_path = NodePath(text_node)
            if self.text is not None:
                center = np.mean(self.nodes, axis=0)
                closest_node_idx = np.argmin(np.linalg.norm(center[None, ::2] - self.nodes, axis=1))
                first_node = self.nodes[closest_node_idx]
                if closest_node_idx >= self.nodes.shape[0] - 2:
                    second_node = self.nodes[closest_node_idx - 2]
                else:
                    second_node = self.nodes[closest_node_idx + 2]
                diff = second_node - first_node
                orientation = np.arctan2(diff[1], diff[0]) / np.pi * 180.
                self._text_node_path.setX(center[0])
                self._text_node_path.setY(1e-3)
                self._text_node_path.setZ(center[1])
                self._text_node_path.setR(orientation)
                self._text_node_path.reparentTo(self._node_path)

        return self._node_path

    def update_color(self, color: np.ndarray):
        """
        Updates the color of the polygon to a different color
        """
        assert color.shape[0] == 4 and color.ndim == 1
        c_writer = GeomVertexWriter(self._vdata, "color")
        num_rows = self._vdata.getNumRows()

        # Go over all vertices and set their color
        for i in range(num_rows):
            c_writer.setData4f(tuple(color))


class Rectangle(Polygon):
    def __init__(self,
                 location: Tuple[float, float],
                 size: Tuple[float, float],
                 orientation: float,
                 color: Tuple[float, float, float, float],
                 priority: float,
                 text: str = ""):
        """

        :param location: tuple of (x, y)
        :param size: tuple of (height, width)
        :param orientation: orientation of the rectangle in radians
        :param color:
        :param priority: display priority - lower is better
        """
        self.location = location
        self.orientation = orientation + np.pi/2

        # calculate corners of the rectangle
        h2 = size[1] / 2
        w2 = size[0] / 2
        nodes = np.array([[-h2, -w2],
                          [h2, -w2],
                          [-h2, w2],
                          [h2, w2],
                          ])
        # generate the polygon. We offset this visualization twice, so we set priority to be half of its required size
        super().__init__(nodes=nodes, color=color, priority=priority, text=text)

    def update_from(self, render_element: 'Rectangle') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        self.location = render_element.location
        self.orientation = render_element.orientation

        super().update_from(render_element=render_element)

    def get_node_path(self) -> NodePath:
        """
        Generates a nodepath that renders a rectangle
        :return: NodePath
        """
        if not self._node_path:
            self._node_path = super().get_node_path()

        # set the orientation and location of the node (minus sign is due to the fact that panda use a left handed
        # coordinate system in 2d)
        self._node_path.setR(-np.rad2deg(self.orientation))
        self._node_path.setPos((self.location[0], self.priority, self.location[1]))

        return self._node_path


class Arrow(Polygon):
    class Direction(Enum):
        LEFT = 0
        RIGHT = 1

    def __init__(self,
                 location: Tuple[float, float],
                 orientation: float,
                 color: Tuple[float, float, float, float],
                 priority: float,
                 direction: Direction,
                 text: str = "",
                 base_size: float = 3.0,
                 scale: float = 1.0):
        """

        :param location: tuple of (x, y)
        :param size: tuple of (height, width)
        :param orientation: orientation of the arrow in radians
        :param color:
        :param priority: display priority - lower is better
        """
        self.location = location
        self.orientation = orientation

        # calculate corners of the rectangle
        size = base_size * scale
        width = size
        height = size/3.0
        if direction == Arrow.Direction.LEFT:
            nodes = np.array([
                [-height, width],
                [height, width],
                [-height, -width],
                [height, -width],
                [0.0, -2*width],
            ])
        else:
            nodes = np.array([
                [0.0, 2*width],
                [-height, width],
                [height, width],
                [-height, -width],
                [height, -width],
            ])

        # generate the polygon. We offset this visualization twice, so we set priority to be half of its required size
        super().__init__(nodes=nodes, color=color, priority=priority, text=text)

    def update_from(self, render_element: 'Rectangle') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        self.location = render_element.location
        self.orientation = render_element.orientation

        super().update_from(render_element=render_element)

    def get_node_path(self) -> NodePath:
        """
        Generates a nodepath that renders a rectangle
        :return: NodePath
        """
        if not self._node_path:
            self._node_path = super().get_node_path()

        # set the orientation and location of the node (minus sign is due to the fact that panda use a left handed
        # coordinate system in 2d)
        self._node_path.setR(-np.rad2deg(self.orientation))
        self._node_path.setPos((self.location[0], self.priority, self.location[1]))

        return self._node_path


class RectangleRenderedImage(BaseRenderElement):
    """
    Render element that displays an image using many rectangles per pixel to allow precise visualization
    """
    def __init__(self,
                 image_data: np.ndarray,
                 enable_image: np.ndarray,
                 cell_size: Tuple[float, float],
                 location: Tuple[float, float],
                 orientation: float,
                 priority: float,
                 ):
        super().__init__()
        self.image_data = image_data
        self.enable_image = enable_image
        self.shape = self.image_data.shape
        self.cell_size = cell_size
        self.location = location
        self.orientation = orientation
        self.priority = priority

        # Verify inputs are in the correct shape
        assert self.image_data.ndim == 3, f"Must accept a 3D array, got: {self.image_data.ndim}"
        assert self.image_data.shape[-1] == 4, f"Last dimension must be 4, got: {self.image_data.shape[-1]}"
        assert self.enable_image.shape[0] == self.image_data.shape[0] and \
               self.enable_image.shape[1] == self.image_data.shape[1] and \
               self.enable_image.ndim == 2, \
            f"Got an improper enable image shape: {self.enable_image.shape}, expected: {self.image_data[:2]}"

        # A list of rectangles to draw, every rectangle is a pixel
        self._rectangles = []
        # Mapping from rectangle index to a pair of indices on the image
        self._rect_idx_to_image_idx = []
        for x_idx in range(self.shape[0]):
            for y_idx in range(self.shape[1]):
                # 2D cartesian location of the rectangle, relative to the host
                location = (
                    x_idx * self.cell_size[0] + self.cell_size[0] / 2,
                    y_idx * self.cell_size[1] + self.cell_size[1] / 2,
                )
                self._rect_idx_to_image_idx.append((x_idx, y_idx))
                # Add a rectangle to be drawn
                self._rectangles.append(Rectangle(location=location,
                                                  size=self.cell_size,
                                                  orientation=0,
                                                  color=self.image_data[x_idx, y_idx],
                                                  priority=priority,
                                                  text="",
                                                  ))

    def can_be_updated_from(self, render_element: 'BaseRenderElement'):
        return isinstance(render_element, self.__class__) and self.shape == render_element.shape

    def update_from(self, render_element: 'BaseRenderElement') -> None:
        assert isinstance(render_element, self.__class__)
        self.image_data = render_element.image_data
        self.shape = self.image_data.shape
        self.cell_size = render_element.cell_size

        self.update_pose(location=render_element.location,
                         orientation=render_element.orientation,
                         priority=render_element.priority)

        for self_rec, other_rec in zip(self._rectangles, render_element._rectangles):
            self_rec.update_from(other_rec)

    def get_node_path(self) -> NodePath:
        if self._node_path is None:
            self._node_path = NodePath("path")

            for rect in self._rectangles:
                self._node_path.attachNewNode(rect.get_node_path().node())

            self._update_rects_attachment()

            self._update_node_pose()

        return self._node_path

    def update_pose(self, location: Tuple[float, float], orientation: float, priority: float):
        """
        Update the pose (location, orientation and priority) of the image, doesn't update internally the rectangles
        :param location: location (x, y) of the origin of the box array
        :param orientation: orientation in radians of the box array
        :param priority: priority of the box array, low value raises it above other visualized elements
        """
        self.location = location
        self.orientation = orientation
        self.priority = priority
        self._update_node_pose()

    def update_image(self, image_data: np.ndarray, enable_image: np.ndarray):
        """
        Updates the image data of the box array (colors of each rectangle)
        :param image_data: same as image_data received in constructor
        :param enable_image: same as enable_image received in constructor
        """
        assert image_data.ndim == 3 and image_data.shape[-1] == 4 and image_data.shape == self.shape, \
            f"Wrong shape received, excepted: {self.shape}, received: {image_data.shape}"

        self.image_data = image_data
        self.enable_image = enable_image

        # update all rectangles with correct color
        rect_idx = 0
        for x_idx in range(self.image_data.shape[0]):
            for y_idx in range(self.image_data.shape[1]):
                rect = self._rectangles[rect_idx]
                rect.update_color(self.image_data[x_idx, y_idx])
                rect_idx += 1

        # Update according to enable image
        self._update_rects_attachment()

    def _update_node_pose(self):
        """
        Updates visualized node pose according to internal pose data
        """
        if self._node_path is not None:
            self._node_path.setPos((self.location[0], self.priority, self.location[1]))
            self._node_path.setR(-np.rad2deg(self.orientation))

    def _update_rects_attachment(self):
        """
        Updates the rectangle visibility based on self.enable_image, if it is false at the corresponding index, then the
        rectangle is not visualized
        """
        for rect_idx, rect in enumerate(self._rectangles):
            x_idx, y_idx = self._rect_idx_to_image_idx[rect_idx]
            if self.enable_image[x_idx, y_idx]:
                # Attach rectangle to view
                rect.get_node_path().reparentTo(self._node_path)
            else:
                # Detach from view
                rect.get_node_path().detachNode()

