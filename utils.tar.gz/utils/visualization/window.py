import atexit
from typing import Dict, Tuple

from subdivision_planner.src.utils.visualization.render_commands import MovieScreenshots, SetWinPosition, SetWinSize, \
    Screenshot, SetOrigin, SetScale, ClearView, DrawElement, EraseElement
from subdivision_planner.src.utils.visualization.visualization import IRenderCommand, BaseRenderElement, Visualization


@atexit.register
def close_all_windows():
    Window.close_all()


class Window:
    """
    By using this class we avoid creating the same window over and over again when using the same window name. It is
    essentially a handle to the Visualization object with the same name
    """

    # This property holds all the visualization instances that exist and can be used. The key is a unique identifier
    # for the visualization.
    _instances: Dict[str, Visualization] = {}

    def __init__(self,
                 name: str,
                 initial_win_size: Tuple[int, int] = None,
                 initial_win_position: Tuple[int, int] = None):
        """

        :param name:
        """
        self._name: str = name

        # Generate an instance only if one doesn't exist
        if self._name not in self._instances:
            v = Visualization(name=name, initial_win_size=initial_win_size, initial_win_position=initial_win_position)
            v.daemon = True
            v.start()
            self._instances[self._name] = v

    def draw_element(self, render_element: BaseRenderElement, view_name: str = "default"):
        """
        Visualize the command, look at Visualization.visualize() function
        :param render_element:
        :param view_name:
        :return:
        """
        self._instances[self._name].add_command(DrawElement(render_element, view_name))

    def erase_element(self, render_element: BaseRenderElement):
        self._instances[self._name].add_command(EraseElement(render_element))

    def clear(self, view_name: str = "default"):
        """
        Clears visualization
        :param view_name:
        :return:
        """
        self._instances[self._name].add_command(ClearView(view_name=view_name))

    def set_scale(self, extent: float):
        """
        sets scale of visualization
        :param extent:
        :return:
        """
        self._instances[self._name].add_command(SetScale(extent=extent))

    def set_origin(self, x: float, y: float, yaw: float):
        """
        sets origin of visualization
        :return:
        """
        self._instances[self._name].add_command(SetOrigin(x=x, y=y, yaw=yaw))

    def render(self, block=False):
        self._instances[self._name].send_commands(block=block)

    @classmethod
    def close_all(cls):
        for name, instance in cls._instances.items():
            instance.stop()

        for name, instance in cls._instances.items():
            instance.join()

        cls._instances.clear()

    def screenshot(self, file_name: str = "screenshot.png", image_comment: str = ""):
        self._instances[self._name].add_command(Screenshot(file_name=file_name, image_comment=image_comment))
        self.render(block=True)

    def set_win_size(self, width, height):
        self._instances[self._name].add_command(SetWinSize(width=width, height=height))

    def set_win_position(self, x, y):
        self._instances[self._name].add_command(SetWinPosition(x=x, y=y))

    def movie(self, file_name: str = "movie", duration: float = 1., fps: float = 30., format: str = "png"):
        self._instances[self._name].add_command(MovieScreenshots(file_name=file_name,
                                                                 duration=duration,
                                                                 fps=fps,
                                                                 format=format))

    def add_command(self, cmd: IRenderCommand, render: bool = False):
        """
        puts the visualization command in the queue for the backend to process it
        :param cmd: a render command that is used to perform the visualization, it gets as the first parameter the
                    backend
        :return:
        """
        self._instances[self._name].add_command(cmd)
        if render:
            self.render()

    def get_gui_data(self):
        return self._instances[self._name].get_gui_data()

    def is_alive(self):
        return self._instances[self._name].is_alive()


if __name__ == "__main__":
    from subdivision_planner.src.utils.visualization.render_elements import Rectangle

    vis = Window('test')
    origin = (500., 500.)
    vis.set_scale(extent=100.)
    vis.set_origin(x=origin[0], y=origin[1], yaw=5.)
    vis.draw_element(Rectangle(x=origin[0] + 50., y=origin[1] + 0., height=10., width=10., orientation=10. / 180. * 3.1415, color=(0.7, 0., 0., 0.4),
                     priority=10.))
    vis.draw_element(Rectangle(x=origin[0] + 60., y=origin[1] + 10., height=10., width=10., orientation=0. / 180. * 3.1415, color=(0., 0.7, 0., 0.4),
                     priority=10.))
    vis.draw_element(Rectangle(x=origin[0] + 70., y=origin[1] + 20., height=10., width=10., orientation=-0. / 180. * 3.1415, color=(0., 0., 0.7, 0.4),
                     priority=10.))
    vis.render()
    print("a")
