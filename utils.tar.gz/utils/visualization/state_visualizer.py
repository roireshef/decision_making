from functools import lru_cache
from typing import Dict, List, Optional, Tuple, Union

import math
import matplotlib.cm as cm
import numpy as np
from interface.Rte_Types.python.sub_structures.TsSYS_OccupancyGridInstance import TsSYSOccupancyGridInstance
from interface.Rte_Types.python.sub_structures.TsSYS_PlannerInternalState import TsSYSPlannerInternalState
from matplotlib.colors import LinearSegmentedColormap, to_rgb as color_map
from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.global_constants import LANE_END_COST_IND
from subdivision_planner.src.data_structures.actor import Actor
from subdivision_planner.src.data_structures.canonic_state import CanonicState
from subdivision_planner.src.data_structures.free_space_grid import FreeSpaceGridInstance
from subdivision_planner.src.data_structures.lane_change import LaneChangeInfo, LaneChangeIntent, LaneChangeReason, \
    LaneChangeState, LaneChangeStatus
from subdivision_planner.src.data_structures.map import Map
from subdivision_planner.src.data_structures.map_elements.lane_segment import LaneSegment
from subdivision_planner.src.data_structures.motion_plan.poly1d_solutions import JerkPolySolution, QuarticPolySolution
from subdivision_planner.src.data_structures.planner_service_outputs import BlinkDirection, HmiStatuses
from subdivision_planner.src.mdp.iaction import IMDPAction
from subdivision_planner.src.mdp.state import MDPState
from subdivision_planner.src.mdp.werling.action import WerlingMDPAction
from subdivision_planner.src.mdp.werling.action_type import ActionType, LateralComponentType, LongitudinalComponentType
from subdivision_planner.src.mdp.werling.component import WerlingComponent
from subdivision_planner.src.mdp.werling.concepts.free_space_reduction import get_free_space_origin
from subdivision_planner.src.messages.scene_static_enums import Direction
from subdivision_planner.src.messages.scene_traffic_control_enums import BulbColorShape, BulbFlashingState
from subdivision_planner.src.planners.concepts.stop_bars_enforcement_manager import StopBarsEnforcementManager
from subdivision_planner.src.utils.stop_bar_utils import StopBarUtils
from subdivision_planner.src.utils.visualization.generic_visualizer import GenericVisualizer
from subdivision_planner.src.utils.visualization.render_commands import UpdateBoxArrayColor
from subdivision_planner.src.utils.visualization.render_elements import Arrow, BaseRenderElement, Curve, DottedCurve, \
    ParentRenderElement, Points, Polygon, Rectangle, RectangleRenderedImage

COLOR_GREEN = color_map('green')
COLOR_YELLOW = color_map('yellow')
COLOR_RED = color_map('red')
COLOR_WHITE = color_map('white')
COLOR_NEON_BLUE = (0.3, 0.3, 1.0)
COLOR_SCREAMIN_GREEN = (0.3, 1.0, 0.3)
COLOR_PARIS_DAISY = (1.0, 1.0, 0.3)

COLOR_BLINK_LIGHT = color_map('gold')
COLOR_EGO_DRIVER_ENGAGED = COLOR_SCREAMIN_GREEN
COLOR_EGO_DRIVER_OVERRIDE = color_map('aquamarine')
COLOR_EGO_DRIVER_DISENGAGED = COLOR_PARIS_DAISY
COLOR_FREE_SPACE_FREE = COLOR_YELLOW
COLOR_FREE_SPACE_OCCUPIED = color_map('magenta')
COLOR_FREE_SPACE_OCCUPIED_AND_ACTOR_ASSOCIATED = color_map('blue')
COLOR_FREE_SPACE_OCCUPIED_AND_ROAD_EDGE_ASSOCIATED = color_map('turquoise')
COLOR_DRIVING_STATE_LONG_DIM = color_map('blueviolet')
COLOR_DRIVING_STATE_STOPPED_FOR_ATTENTIVENESS = color_map('orangered')


###################
#  Colors Legend  #
###################
#
#  Road:
#    - Green ("Emerald") when lane is in route
#    - Grey ("Nobel") else
#
#  Ego:
#    - Green ("Screamin' Green") when engaged
#    - Turquoise ("Aqua Marine") when in driver override
#    - Yellow ("Paris Daisy") when disengaged
#
#  Others:
#    - Box in Gold is shown iff blink lights is on (where the front blink light is)
#    - Front of ego is marked purple ("BlueViolet") for long dim
#    - Front of ego is marked red ("OrangeRed") for stopped for attentiveness
#


def rotate(origin, point, angle):
    """
    Rotate a point counterclockwise by a given angle around a given origin.

    The angle should be given in radians.
    """
    ox, oy = origin
    px, py = point

    qx = ox + math.cos(angle) * (px - ox) - math.sin(angle) * (py - oy)
    qy = oy + math.sin(angle) * (px - ox) + math.cos(angle) * (py - oy)
    return qx, qy


@lru_cache(maxsize=2)
def get_speed_colormap(is_parked: bool) -> cm.ScalarMappable:
    if is_parked:
        colormap = LinearSegmentedColormap.from_list('velocity_colormap', [COLOR_RED, COLOR_RED])
    else:
        colormap = LinearSegmentedColormap.from_list('velocity_colormap', [COLOR_NEON_BLUE, COLOR_WHITE])
    return cm.ScalarMappable(cmap=colormap)


class MapVisualizer(GenericVisualizer):
    """
    This is a visualizer of our Map object
    """
    def __init__(self, win_name: str = "default", is_blocking: bool = False):
        """
        ctr
        :param win_name:
        :param is_blocking:
        """
        super().__init__(win_name=win_name, is_blocking=is_blocking)
        self._rendered_lanes: Dict[int, List[BaseRenderElement]] = {}
        self._rendered_rewards: Dict[int, float] = {}
        self._rendered_map: Map = None

        self._lane_rewards_view_name = "lane_rewards"
        self._map_view_name = "map"

        self._lane_priority = 10.

    def visualize(self, map: Map, route_plan_cost_dict: dict = (), render: bool = True):
        """
        Visualizes the map on the window
        :param map: map to visualize
        :param render: If true, function will request window to render the data after function finishes
        """
        if map == self._rendered_map:
            return

        # Add lane visualization
        for lane_segment in map.lane_segments:
            reward = 0.
            if lane_segment.id in self._rendered_lanes:
                if lane_segment.id in route_plan_cost_dict:
                    reward = 1. - route_plan_cost_dict[lane_segment.id][LANE_END_COST_IND]
                    if lane_segment.id in self._rendered_rewards and reward == self._rendered_rewards[lane_segment.id]:
                        continue
                else:
                    if lane_segment.id not in self._rendered_rewards:
                        continue

            self.clear_lane(lane_segment.id)
            if lane_segment.id in route_plan_cost_dict:
                road_color = (0.6 - 0.2 * reward, 0.6 + 0.2 * reward, 0.6 - 0.2 * reward, 1.)
            else:
                road_color = (0.6, 0.6, 0.6, 1.)
            lane_render_elements = self._convert_lane_segment(
                map=map,
                lane_segment=lane_segment,
                color=road_color,
                priority=self._lane_priority
            )
            self._rendered_lanes[lane_segment.id] = lane_render_elements
            self._rendered_rewards[lane_segment.id] = reward
            for re in lane_render_elements:
                self.window.draw_element(render_element=re, view_name=self._map_view_name)

        # remove all non existing lanes
        lanes_to_remove = []
        for lane_segment_id, lane_render_elements in self._rendered_lanes.items():
            if not map.has_lane_id(lane_id=lane_segment_id):
                lanes_to_remove.append(lane_segment_id)
                for re in lane_render_elements:
                    self.window.erase_element(re)

        for lane_id in lanes_to_remove:
            self._rendered_lanes.pop(lane_id)

        if render:
            self.window.render(block=self._is_blocking)

        self._rendered_map = map

    def clear_lane(self, lane_id: int) -> None:
        if lane_id in self._rendered_lanes:
            for re in self._rendered_lanes[lane_id]:
                self.window.erase_element(re)

    def _convert_lane_segment(self,
                              map: Map,
                              lane_segment: LaneSegment,
                              color: Tuple[float, float, float, float] = (0.6, 0.6, 0.6, 1.),
                              priority: float = 5.) -> List[BaseRenderElement]:
        """
        Converts a LaneSegment object to a list of RenderElements to be drawn in a window
        :param lane_segment: LaneSegment object to be drawn
        :param color: requested color for the road
        :return: List of render elements to draw
        """
        # Sample the lane until its end, generate the left and right boundaries of the road, generate the left and right
        # boundaries of the curb, generate a polygon for the road and a polygon behind it for the curb.
        render_elements = []

        left_points = lane_segment.left_border
        right_points = lane_segment.right_border

        # Make sure both arrays are same length by replicating the last point
        if left_points.shape[0] < right_points.shape[0]:
            n_new_points = right_points.shape[0] - left_points.shape[0]
            new_points = np.tile(left_points[-1, :], (n_new_points, 1))
            left_points = np.vstack([left_points, new_points])
        elif left_points.shape[0] > right_points.shape[0]:
            n_new_points = left_points.shape[0] - right_points.shape[0]
            new_points = np.tile(right_points[-1, :], (n_new_points, 1))
            right_points = np.vstack([right_points, new_points])

        # Order boundary points such that they are interleaved
        polygon_vertices = np.stack((left_points, right_points), axis=1).reshape((-1, 2))
        road_polygon = Polygon(nodes=polygon_vertices, color=color, priority=priority + 0.2)

        all_nominal_path_lines = list()
        for line_segment in map.get_lines_by_lane_id(lane_id=lane_segment.id):
            colors = np.zeros((line_segment.frenet_frame.points.shape[0], 4))
            colors[:, -1] = 1.
            nominal_path = DottedCurve(points=line_segment.frenet_frame.points,
                                       thickness=1,
                                       colors=colors,
                                       priority=priority + 0.1,
                                       text=str(lane_segment.id))
            all_nominal_path_lines.append(nominal_path)

        colors = np.ones((lane_segment.left_border.shape[0], 4))
        left_border = Curve(points=lane_segment.left_border, thickness=2, colors=colors, priority=priority + 0.1)
        colors = np.ones((lane_segment.right_border.shape[0], 4))
        right_border = Curve(points=lane_segment.right_border, thickness=2, colors=colors, priority=priority + 0.1)
        front_border_points = np.array([lane_segment.right_border[-1], lane_segment.left_border[-1]])
        front_border = Curve(points=front_border_points, thickness=2, colors=np.ones((2, 4)), priority=priority + 0.1)
        back_border_points = np.array([lane_segment.right_border[0], lane_segment.left_border[0]])
        back_border = Curve(points=back_border_points, thickness=2, colors=np.ones((2, 4)), priority=priority + 0.1)
        for l in all_nominal_path_lines:
            render_elements.append(l)
        render_elements.append(road_polygon)
        render_elements.append(left_border)
        render_elements.append(right_border)
        render_elements.append(front_border)
        render_elements.append(back_border)

        colors = np.array([[1., 0., 0., 1.], [1., 0., 0., 1.]])
        for bar in lane_segment.get_stop_bars():
            cpoint = bar.cpoint
            diff_left = np.linalg.norm(cpoint - lane_segment.left_border, axis=1)
            min_index_left = np.argmin(diff_left)
            diff_right = np.linalg.norm(cpoint - lane_segment.right_border, axis=1)
            min_index_right = np.argmin(diff_right)
            points = np.array([lane_segment.left_border[min_index_left], lane_segment.right_border[min_index_right]])
            bar_mark = Curve(points=points, thickness=5, colors=colors, priority=priority, text=str(bar.id))
            render_elements.append(bar_mark)

        return render_elements


class StateVisualizer(GenericVisualizer):
    """
    This class generates visualizations for our CanonicState. It visualizes the map, actors, free space, and ego
    """
    def __init__(self, win_name: str = "default", is_blocking: bool = False,  visualize_free_space: Optional[bool] = True,  visualize_fused_scene: Optional[bool] = None):
        """
        """
        super().__init__(win_name=win_name, is_blocking=is_blocking)
        self._map_visualizer = MapVisualizer(win_name=win_name, is_blocking=is_blocking)
        self._ego_priority = 2.
        self._actions_priority = 1.8
        self._actors_priority = 3.
        self._fused_scene_priority = 10.
        self._visualize_free_space = visualize_free_space if visualize_free_space is not None else Config().mcts.use_free_space_visualization
        self._visualize_fused_scene = visualize_fused_scene if visualize_fused_scene is not None else Config().mcts.use_fused_scene_visualization
        self._free_space_elements_ids = []
        self._last_visualized_state = None

    def visualize(self, state: CanonicState, render: bool = True, undeterminized_state: CanonicState = None,
                  internal_state: Optional[TsSYSPlannerInternalState] = None,
                  screenshot_filename: Optional[str] = None):
        """
        This method generates a visualization of a BareMetalMCTSState as a top view image. If screenshot_filename is
        given, the resulting image screenshot is also saved to disk.
        :param state: The state to visualize
        :param render: should we send the output to render after the function finishes
        :param undeterminized_state:
        :param internal_state:
        :param screenshot_filename: The file name of the visualizer screenshot image
        """
        # Clear the window before rendering
        self.window.clear()

        # reset the map in case of a map origin change
        if state.previous_map_origin is not None and state.map.map_origin != state.previous_map_origin:
            self._map_visualizer._rendered_map = None
            self._map_visualizer._rendered_lanes: Dict[int, List[BaseRenderElement]] = {}
            self._map_visualizer._rendered_rewards: Dict[int, float] = {}

        # Add map to scene
        self._map_visualizer.visualize(map=state.map, route_plan_cost_dict=state.route_plan_cost_dict, render=False)
        if self._visualize_free_space and state.free_space_grids is not None:
            # add occupancy grid obstacles in scene
            num_grids = len(state.free_space_grids.occupancy_grid_data)
            for i in range(num_grids):
                occupancy_grid_data = state.free_space_grids.occupancy_grid_data[i]
                free_space_image, enable_image = self.get_free_space_image(occupancy_grid_data)
                location = occupancy_grid_data.cell_origin_location
                _, _, orientation = get_free_space_origin(occupancy_grid_data)
                cell_size = occupancy_grid_data.cell_size
                priority = 1.2
                if len(self._free_space_elements_ids) <= i:
                    element = RectangleRenderedImage(image_data=free_space_image,
                                                     enable_image=enable_image,
                                                     cell_size=cell_size,
                                                     location=location,
                                                     orientation=orientation,
                                                     priority=priority,
                                                     )
                    self._free_space_elements_ids.append(element.id)
                    self.window.draw_element(element, 'freespace')
                else:
                    update_cmd = UpdateBoxArrayColor(id=self._free_space_elements_ids[i],
                                                     image_data=free_space_image,
                                                     enable_image=enable_image,
                                                     location=location,
                                                     orientation=orientation,
                                                     priority=priority)
                    self.window.add_command(update_cmd)

        render_elements = []

        # Add actors in scene
        for actor_idx, actor in enumerate(state.actors):
            if actor.has_time(state.timestamp_in_seconds):
                render_elements.extend(self._convert_actor(actor=actor,
                                                           time=state.timestamp_in_seconds,
                                                           is_determinized=undeterminized_state is not None,
                                                           add_text=True))

        render_elements.extend(self._convert_ego(cartesian_state=state.cartesian_state,
                                                 frenet_state=state.lane_center_frenet_state,
                                                 is_determinized=undeterminized_state is not None,
                                                 is_engaged=state.is_ttc_engaged,
                                                 is_driver_override=state.longitudinal_driver_override_detected))

        if undeterminized_state is not None:
            # Add actors in scene
            for actor_idx, actor in enumerate(undeterminized_state.actors):
                if actor.has_time(undeterminized_state.timestamp_in_seconds):
                    render_elements.extend(self._convert_actor(actor=actor,
                                                               time=undeterminized_state.timestamp_in_seconds,
                                                               is_determinized=False,
                                                               add_text=False))

            render_elements.extend(self._convert_ego(cartesian_state=undeterminized_state.cartesian_state,
                                                     frenet_state=state.lane_center_frenet_state,
                                                     is_determinized=False,
                                                     is_engaged=undeterminized_state.is_ttc_engaged,
                                                     is_driver_override=state.longitudinal_driver_override_detected))

            # Add intent
            render_elements.extend(self.lane_change_intent_visualization(state, internal_state))
            render_elements.extend(self.turn_type_visualization(undeterminized_state))

        if self._visualize_fused_scene:
            # always update the dynamic lanes
            for lane_segment in state.map.lane_segments:
                # is visualize fused scene is set to true, check if this lane has dynamic lane data
                if lane_segment.has_dynamic_data:

                    # get the render element for the dynamic lane
                    dynamic_lane_render_elements = self._convert_dynamic_lane_segment(map=state.map,
                                                                                      lane_segment=lane_segment)
                    render_elements.extend(dynamic_lane_render_elements)

        # Update window origin to follow route (to disable press space on visualization window)
        s = state.lane_center_frenet_state[types.FS_SX]
        heading = -state.lane_center_frenet_frame.get_yaw(s=np.array([s]))[0]

        c_heading = np.cos(heading)
        s_heading = np.sin(heading)

        rot_mat = np.array([[c_heading, s_heading],
                            [-s_heading, c_heading]])
        offset = np.dot(rot_mat, np.array([35., 0.]))
        self.window.set_origin(x=state.cartesian_state[0] + offset[0],
                               y=state.cartesian_state[1] + offset[1],
                               yaw=heading * 180 / np.pi + 90)

        self._draw_elements(render_elements=render_elements, render=render, screenshot_filename=screenshot_filename)
        self._last_visualized_state = state

    def visualize_actions(self, actions: List[IMDPAction], render: bool = True, clear: bool = True):

        curve_locations = []
        curve_accelerations = []

        for action in actions:
            curve_accelerations.append(action.cartesian_states[:, types.C_A])
            curve_locations.append(action.cartesian_states[:, [types.C_X, types.C_Y]])

        curve_locations = np.concatenate(curve_locations)
        curve_accelerations = np.concatenate(curve_accelerations)
        curve_colors = np.tile(np.array([[0., 0., 0., 1.]]), [curve_locations.shape[0], 1])
        curve_colors[:, 0] = np.where(curve_accelerations < 0.,
                                      2 * curve_accelerations / max(Config().ego.min_longitudinal_acceleration_default),
                                      np.zeros_like(curve_accelerations))
        curve_colors[:, 1] = np.where(curve_accelerations < 0.,
                                      np.zeros_like(curve_accelerations),
                                      2 * curve_accelerations / max(Config().ego.max_longitudinal_acceleration_default))
        curve_colors[:, -1] = 1.

        # generate curve
        curve = (Curve(curve_locations, thickness=5, colors=curve_colors, priority=self._actions_priority))

        # generate points
        locations = []
        state_colors = [[0., 0.5, 0., 1.]]
        for action in actions:
            location = action.cartesian_states[0][types.C_X], action.cartesian_states[0][types.C_Y]
            locations.append(location)
            state_color = [0., 0.5, 0., 1.]
            if isinstance(action, WerlingMDPAction) and action.is_longitudinal_component_finished:
                state_color[0] = 1.
                state_color[1] = 0.
            if isinstance(action, WerlingMDPAction) and action.is_lateral_component_finished:
                state_color[2] = 1.
                state_color[1] = 0.

            state_colors.append(state_color)

        locations.append((actions[-1].cartesian_states[-1][types.C_X], actions[-1].cartesian_states[-1][types.C_Y]))
        points = (Points(np.array(locations), thickness=8, colors=np.array(state_colors), priority=self._actions_priority - 0.1))

        # return a ParentRenderElement to encapsulate all elements together
        drawing_element = ParentRenderElement(element_list=[points, curve])

        if clear:
            self.window.clear(view_name="actions")
        self.window.draw_element(drawing_element, view_name="actions")

        # mark ego's actions start times on dynamic actors
        time_points = [action.start_time for action in actions]
        for actor_idx, actor in enumerate(self._last_visualized_state.actors):
            actor_points = self._get_actions_start_times_points_on_actor(actor=actor, time_points=time_points)
            if actor_points is not None:
                self.window.draw_element(actor_points, view_name="actions")

        if render:
            self.window.render()

    def visualize_hmi_statuses(
            self,
            mdp_state: MDPState,
            hmi_statuses: Optional[HmiStatuses] = None,
            render: bool = True) \
            -> None:
        """
        Visualize fields from HmiStatuses object as elements on map
        :param mdp_state: Current MDPState to position added elements
        :param hmi_statuses: Current HmiStatuses with fields to be rendered
        :param render: If true, asks window to render these elements after sending the data
        """

        if hmi_statuses is not None:

            render_elements = list()

            render_elements.append(self._visualize_hmi_blink_lights(mdp_state, hmi_statuses.blink_direction))

            if hmi_statuses.long_dim:
                render_elements.append(self._visualize_hmi_driving_state(
                    mdp_state, (*COLOR_DRIVING_STATE_LONG_DIM, 1.)))
            elif hmi_statuses.stopped_for_attentiveness:
                render_elements.append(self._visualize_hmi_driving_state(
                    mdp_state, (*COLOR_DRIVING_STATE_STOPPED_FOR_ATTENTIVENESS, 1.)))

            self._draw_elements(render_elements, render=render)

    def _visualize_hmi_blink_lights(
            self,
            mdp_state: MDPState,
            blink_direction: BlinkDirection) \
            -> Optional[BaseRenderElement]:
        """
        Visualize blink lights from HmiStatuses object as elements on map, supports only a single blink direction. Added
        blink lights will be displayed as small rectangle approximately where the front blinkers are located on the ego.
        :param mdp_state: Current MDPState to position added elements
        :param blink_direction: Current blink direction
        """

        if blink_direction == BlinkDirection.HMI_BlinkLeft or blink_direction == BlinkDirection.HMI_BlinkRight:

            cartesian_state = mdp_state.cartesian_state
            location = cartesian_state[types.C_X], cartesian_state[types.C_Y]
            height, width = Config().ego.size
            theta = cartesian_state[types.C_YAW]
            color = (*COLOR_BLINK_LIGHT, 1.)

            if blink_direction == BlinkDirection.HMI_BlinkLeft:
                light_location = (location[0] + height / 2 * math.cos(theta) - width / 4 * math.sin(theta),
                                  location[1] + height / 2 * math.sin(theta) - width / 4 * math.cos(theta))
            else:
                light_location = (location[0] + height / 2 * math.cos(theta) + width / 4 * math.sin(theta),
                                  location[1] + height / 2 * math.sin(theta) + width / 4 * math.cos(theta))

            return Rectangle(location=light_location,
                             size=(0.3 * width, 0.3 * width),
                             orientation=cartesian_state[types.C_YAW],
                             color=color,
                             priority=self._ego_priority - 0.11)

    def _visualize_hmi_driving_state(
            self,
            mdp_state: MDPState,
            indicator_color: Tuple[float, float, float, float]) \
            -> BaseRenderElement:
        """
        Visualize any desired state as an elements on map, supports only a addition (since multiple calls will override
        each other). Added element will be displayed as thin rectangle at the front of the ego.
        :param mdp_state: Current MDPState to position added elements
        :param indicator_color: Current requested indication color
        """

        cartesian_state = mdp_state.cartesian_state
        location = cartesian_state[types.C_X], cartesian_state[types.C_Y]
        height, width = Config().ego.size
        theta = cartesian_state[types.C_YAW]
        location = (location[0] + height / 2 * math.cos(theta),
                    location[1] + height / 2 * math.sin(theta))

        return Rectangle(location=location,
                         size=(height / 40, width),
                         orientation=cartesian_state[types.C_YAW],
                         color=indicator_color,
                         priority=self._ego_priority - 0.105)

    def visualize_lateral_component(self, state: MDPState, lat_component: WerlingComponent):
        if lat_component.is_t_axis:
            return
        T = 10.
        v = (lat_component.end - lat_component.start) / T
        lon_plan = QuarticPolySolution(x_0=lat_component.start, v_0=v, a_0=0, v_T=v, T=T)
        lon_component = WerlingComponent(motion_plan=lon_plan, component_type=LongitudinalComponentType.ConstantVelocity,
                                         is_emergency=False, is_completion=False, start=0., generation_time=0.)
        action = WerlingMDPAction(motion_plan_s=lon_plan, motion_plan_d=lat_component.motion_plan, gff=state.gff,
                                  start_time=0., action_type=ActionType(lon_component.component_type, lat_component.component_type),
                                  longitudinal_component=lon_component, lateral_component=lat_component, generation_time=0.)
        self.visualize_actions(state.previous_actions+[action])

    def visualize_lateral_motion_plan(self, state: MDPState, motion_plan: JerkPolySolution):
        lat_component = WerlingComponent(motion_plan=motion_plan, component_type=LateralComponentType.OvertakeStatic,
                                         is_emergency=False, is_completion=False, start=state.frenet_state[types.FS_SX], generation_time=0.)
        self.visualize_lateral_component(state, lat_component)

    def visualize_waypoints(self, cartesian_waypoints: np.array, render: bool = True):
        points = Points(np.array(cartesian_waypoints), thickness=8,
                        colors=np.full((cartesian_waypoints.shape[0], 4), [0., 1., 0., 1.]), priority=self._actions_priority - 0.1)
        self._draw_elements(render_elements=[points], render=render)

    def _convert_ego(self,
                     cartesian_state: np.ndarray,
                     frenet_state: Optional[np.ndarray],
                     is_determinized: bool = False,
                     is_engaged: bool = True,
                     is_driver_override: bool = False):
        render_elements = []
        # Create ego rectangle and add it to visualization

        if is_engaged:
            if is_driver_override:
                ego_r, ego_g, ego_b = COLOR_EGO_DRIVER_OVERRIDE
            else:
                ego_r, ego_g, ego_b = COLOR_EGO_DRIVER_ENGAGED
        else:
            ego_r, ego_g, ego_b = COLOR_EGO_DRIVER_DISENGAGED

        ego_alpha = 0.4 if is_determinized else 1.

        text = ''
        if frenet_state is not None:
            text = "v_s={:.2f}\nv_d={:.2f}".format(frenet_state[types.FS_SV], frenet_state[types.FS_DV])

        location = cartesian_state[types.C_X], cartesian_state[types.C_Y]
        render_elements.append(Rectangle(location=location,
                                         size=Config().ego.size,
                                         orientation=cartesian_state[types.C_YAW],
                                         color=(ego_r, ego_g, ego_b, ego_alpha),
                                         priority=self._ego_priority - 0.1 * float(is_determinized),
                                         text=text))

        return render_elements

    def _convert_actor(self, actor: Actor, time: float, is_determinized: bool = False, add_text: bool = True):
        assert actor.has_time(time)
        render_elements = []
        initial_state = actor.get_cstate(time)
        initial_size = tuple(actor.get_size(time))
        color = get_speed_colormap(actor.is_parked).to_rgba(initial_state[types.C_V] / 30., norm=False)
        if is_determinized:
            color = (1., 0.5 * color[1], 0.5 * color[2], 0.5)
        if add_text:
            text = "id={}\nv={:.2f}".format(actor.id, initial_state[types.C_V])
        else:
            text = ""
        render_elements.append(Rectangle(location=(initial_state[types.C_X], initial_state[types.C_Y]),
                                         size=tuple(initial_size),
                                         orientation=initial_state[types.C_YAW],
                                         color=color,
                                         priority=self._actors_priority - 0.01*float(is_determinized),
                                         text=text))

        if actor.cstates.shape[0] > 1:
            curve = Curve(points=actor.cstates[:, [types.C_X, types.C_Y]], thickness=3,
                          colors=np.tile(np.array([[0., 1., 1., 1.]]), (actor.cstates.shape[0], 1)),
                          priority=self._actors_priority)
            render_elements.append(curve)

        return render_elements

    def _get_actions_start_times_points_on_actor(self, actor: Actor, time_points: List = None) -> Optional[Points]:
        points = None

        if actor.cstates.shape[0] > 1:
            if time_points is not None and not actor.is_parked:
                locations = []
                state_colors = []
                for time_point in time_points:
                    if actor.has_time(time_point):
                        cstate = actor.get_cstate(time_point)
                        location = cstate[types.C_X], cstate[types.C_Y]
                        locations.append(location)
                        state_colors.append([1., 1., 0., 1.])  # yellow

                locations = np.array(locations)
                if locations.ndim == 2 and locations.shape[1] == 2:
                    points = Points(locations, thickness=8, colors=np.array(state_colors), priority=self._actors_priority)

        return points

    def lane_change_intent_visualization(self, state: CanonicState, internal_state: Optional[TsSYSPlannerInternalState]) -> List[BaseRenderElement]:
        if internal_state is None:
            return []

        lc_manager_state = internal_state.s_Data.s_LaneChangeManagerState
        lc_state = LaneChangeState.deserialize(internal_state.s_Data.s_LaneChangeState)
        lc_info = LaneChangeInfo.deserialize(lc_manager_state.s_LaneChangeInfo, state.map) if lc_manager_state.e_b_Valid and lc_manager_state.s_LaneChangeInfo.e_b_Valid else state.driver_lane_change_info
        reason: LaneChangeReason = lc_info.reason.name if lc_info is not None else ''
        status: LaneChangeStatus = lc_state.lane_change_status
        intent: LaneChangeIntent = lc_info.intent if lc_info is not None else ''
        intent_time: LaneChangeIntent = lc_info.start_time if lc_info is not None else ''
        position = state.cartesian_state[:2]
        angle = state.cartesian_state[types.C_YAW] + np.pi
        if intent == LaneChangeIntent.KeepLane or status == LaneChangeStatus.NoLaneChange:
            return []
        arrow_location = position + np.array([10*np.cos(angle), 10*np.sin(angle)])
        return [Arrow(location=arrow_location,
                      orientation=angle,
                      color=(1.0, 1.0, 1.0, 1.0),
                      priority=1.0,
                      direction=Arrow.Direction.LEFT if intent == LaneChangeIntent.Left else Arrow.Direction.RIGHT,
                      text=f"reason={reason} {status.name}\n Intent time = {intent_time}"
                      )]

    @staticmethod
    def get_free_space_image(free_space_grid_instance: Union[TsSYSOccupancyGridInstance, FreeSpaceGridInstance]) \
            -> Tuple[np.ndarray, np.ndarray]:
        # Extract free space image
        if isinstance(free_space_grid_instance, FreeSpaceGridInstance):
            free_space_image = free_space_grid_instance.cell_free_confidence
            actor_associated_confidence_image = free_space_grid_instance.cell_identified_confidence
            road_edge_associated_confidence_image = free_space_grid_instance.cell_obstacle_type_road_edge_confidence
        else:
            free_space_image = free_space_grid_instance.s_OccupancyGridInstanceData.a_cell_state_free_confidence
            actor_associated_confidence_image = free_space_grid_instance.s_OccupancyGridInstanceData._dic['a_cell_state_identified_confidence ']
            road_edge_associated_confidence_image = free_space_grid_instance.s_OccupancyGridInstanceData._dic['a_cell_state_obstacle_type_road_edge_confidence ']

        # Find free and occupied indices
        free = np.where(free_space_image == 1.)
        occupied = np.where((free_space_image == 0.) & (actor_associated_confidence_image == 0.) & (road_edge_associated_confidence_image == 0.))
        occupied_actor_associated = np.where((free_space_image == 0.) & (actor_associated_confidence_image == 1.))
        occupied_road_edge_associated = np.where((free_space_image == 0.) & (road_edge_associated_confidence_image == 1.))

        # Generate a free space RGB image
        free_space_image = np.ones((free_space_image.shape[0], free_space_image.shape[1], 4))
        free_space_image[..., -1] = 0.3  # Set alpha to a constant 0.3 so things under it can be viewed as well
        free_space_image[free[0], free[1], :3] = COLOR_FREE_SPACE_FREE
        free_space_image[occupied[0], occupied[1], :3] = COLOR_FREE_SPACE_OCCUPIED
        free_space_image[occupied_actor_associated[0], occupied_actor_associated[1], :3] = COLOR_FREE_SPACE_OCCUPIED_AND_ACTOR_ASSOCIATED
        free_space_image[occupied_road_edge_associated[0], occupied_road_edge_associated[1], :3] = COLOR_FREE_SPACE_OCCUPIED_AND_ROAD_EDGE_ASSOCIATED

        # Generate an enable image so we don't have to draw unknown values as well. We enable only free and occupied
        # areas.
        enable_image = np.zeros((free_space_image.shape[0], free_space_image.shape[1]), dtype=np.bool)
        enable_image[free[0], free[1]] = True
        enable_image[occupied[0], occupied[1]] = True
        enable_image[occupied_actor_associated[0], occupied_actor_associated[1]] = True
        enable_image[occupied_road_edge_associated[0], occupied_road_edge_associated[1]] = True

        return free_space_image, enable_image

    def _convert_dynamic_lane_segment(self, map: Map, lane_segment: LaneSegment):

        dynamic_render_elements = []

        left_points = lane_segment.dynamic_left_border
        right_points = lane_segment.dynamic_right_border

        colors = np.tile(np.array([[1., 1., 0., 1.]]), (left_points.shape[0], 1))
        left_border = Curve(points=left_points,
                    thickness=1.5,
                    colors=colors,
                    priority=self._fused_scene_priority)
        dynamic_render_elements.append(left_border)

        colors = np.tile(np.array([[1., 1., 0., 1.]]), (right_points.shape[0], 1))
        right_border = Curve(points=right_points,
                    thickness=1.5,
                    colors=colors,
                    priority=self._fused_scene_priority)
        dynamic_render_elements.append(right_border)

        # get nominal path points
        for line_segment in map.get_lines_by_lane_id(lane_id=lane_segment.id):
            nominal_path_points_arr = line_segment.dynamic_nominal_path_points
            if nominal_path_points_arr.ndim > 1:
                colors = np.tile(np.array([[1., 1., 0., 1.]]), (nominal_path_points_arr.shape[0], 1))

                nominal_path = DottedCurve(points=nominal_path_points_arr,
                                         thickness=1.5,
                                         colors=colors,
                                         priority=self._fused_scene_priority,
                                         text=str(lane_segment.id))
                dynamic_render_elements.append(nominal_path)

        return dynamic_render_elements



    def turn_type_visualization(self, undeterminized_state: CanonicState) -> List[BaseRenderElement]:

        render_elements = list()

        map = undeterminized_state.map
        gffs = undeterminized_state.lane_center_frenet_frames
        orientation = undeterminized_state.cartesian_state[types.C_YAW] + np.pi/2

        for gff in gffs:
            stop_bars_context = StopBarUtils.get_stop_bars_on_gff(state_map=map, gff=gff)

            if len(stop_bars_context) == 0:
                return []

            for lane_segment, stop_bar, global_s in stop_bars_context:
                id = stop_bar.id
                distance_to_stop_bar = global_s - undeterminized_state.lane_center_frenet_state[types.FS_SX]
                # only visualize traffic light if light is in reasonable distance
                if stop_bar.is_traffic_light:
                    if id in undeterminized_state.traffic_lights_status and distance_to_stop_bar < 200:
                        # get the travel direction
                        direction: Direction = StopBarsEnforcementManager.get_travel_direction(map, lane_segment, gff)

                        if direction:
                            all_tcd_color_shape = undeterminized_state.traffic_lights_status[id].bulb_color_shape
                            tcd_color_shape = all_tcd_color_shape[direction.value]
                            all_tcd_flashing_state = undeterminized_state.traffic_lights_status[id].bulb_flashing_state
                            tcd_flashing_state = all_tcd_flashing_state[direction.value]

                            # reset the position of the stop bar
                            position = np.array([stop_bar.cpoint])  # 2D location of this tcd

                            if tcd_color_shape in [BulbColorShape.GreenLeftArrow, BulbColorShape.GreenFullCircle,
                                                   BulbColorShape.GreenRightArrow, BulbColorShape.GreenStraightArrow]:
                                color = (*COLOR_GREEN, 1.0)
                                # shift position down and rotate point around origin
                                position = np.array([rotate(origin=stop_bar.cpoint,
                                                  point=[position[0][0], position[0][1] - 0.75],
                                                  angle=orientation)])

                            if tcd_color_shape in [BulbColorShape.YellowRightArrow, BulbColorShape.YellowLeftArrow,
                                                   BulbColorShape.YellowStraightArrow, BulbColorShape.YellowFullCircle]:
                                color = (*COLOR_YELLOW, 1.0)

                            if tcd_color_shape in [BulbColorShape.RedFullCircle, BulbColorShape.RedRightArrow,
                                                   BulbColorShape.RedLeftArrow, BulbColorShape.RedStraightArrow]:
                                color = (*COLOR_RED, 1.0)
                                # shift position up and rotate point around origin
                                position = np.array([rotate(origin=stop_bar.cpoint,
                                                  point=[position[0][0], position[0][1] + 0.75],
                                                  angle=orientation)])


                            if tcd_flashing_state == BulbFlashingState.Flashing:
                                # create a flashing box for the traffic light
                                light_size = list([1.8, 3.5])
                                traffic_light_flash = Rectangle(location=stop_bar.cpoint,
                                                          size=light_size,
                                                          orientation=orientation,
                                                          color=color,
                                                          priority=2.2)
                                render_elements.append(traffic_light_flash)

                            # create a black box for the traffic light
                            light_size = list([1.5, 3.0])
                            traffic_light = Rectangle(location=stop_bar.cpoint,
                                      size=light_size,
                                      orientation=orientation,
                                      color=(0, 0, 0, 1),
                                      priority=2.0)
                            render_elements.append(traffic_light)

                            size = 0.5

                            if tcd_color_shape in [BulbColorShape.GreenLeftArrow,
                                                   BulbColorShape.RedLeftArrow,
                                                   BulbColorShape.YellowLeftArrow]:

                                pos_x = position[0][0]
                                pos_y = position[0][1]

                                arrow_tip = [pos_x-size, pos_y]
                                arrow_tip_rotated = list(rotate(origin=[pos_x, pos_y],
                                                  point=arrow_tip,
                                                  angle=orientation+np.pi))
                                arrow_tail = [pos_x + size, pos_y]
                                arrow_tail_rotated = list(rotate(origin=[pos_x, pos_y],
                                                  point=arrow_tail,
                                                  angle=orientation+np.pi))
                                arrow_top = [pos_x, pos_y+size]
                                arrow_top_rotated = list(rotate(origin=[pos_x, pos_y],
                                                            point=arrow_top,
                                                            angle=orientation+np.pi))
                                arrow_bottom = [pos_x, pos_y-size]
                                arrow_bottom_rotated = list(rotate(origin=[pos_x, pos_y],
                                                            point=arrow_bottom,
                                                            angle=orientation+np.pi))

                                nodes = np.array([arrow_tip_rotated,
                                                  arrow_bottom_rotated,
                                                  arrow_top_rotated,
                                                  ])

                                polygon = Polygon(nodes=nodes, color=color, priority=1.0)

                                colors = np.array([color, color])
                                line_points = np.array([np.array([pos_x, pos_y]), np.array(arrow_tail_rotated)])
                                line = Curve(points=line_points, thickness=10, colors=colors, priority=1.0)

                                render_elements.append(polygon)
                                render_elements.append(line)

                                continue

                            if tcd_color_shape in [BulbColorShape.GreenRightArrow,
                                                   BulbColorShape.RedRightArrow,
                                                   BulbColorShape.YellowRightArrow]:

                                pos_x = position[0][0]
                                pos_y = position[0][1]

                                arrow_tip = [pos_x + size, pos_y]
                                arrow_tip_rotated = list(rotate(origin=[pos_x, pos_y],
                                                                point=arrow_tip,
                                                                angle=orientation+np.pi))
                                arrow_tail = [pos_x - size, pos_y]
                                arrow_tail_rotated = list(rotate(origin=[pos_x, pos_y],
                                                                 point=arrow_tail,
                                                                 angle=orientation+np.pi))
                                arrow_top = [pos_x, pos_y + size]
                                arrow_top_rotated = list(rotate(origin=[pos_x, pos_y],
                                                                point=arrow_top,
                                                                angle=orientation+np.pi))
                                arrow_bottom = [pos_x, pos_y - size]
                                arrow_bottom_rotated = list(rotate(origin=[pos_x, pos_y],
                                                                   point=arrow_bottom,
                                                                   angle=orientation+np.pi))

                                nodes = np.array([arrow_tip_rotated,
                                                  arrow_bottom_rotated,
                                                  arrow_top_rotated,
                                                  ])

                                polygon = Polygon(nodes=nodes, color=color, priority=1.0)

                                colors = np.array([color, color])
                                line_points = np.array([np.array([pos_x, pos_y]), np.array(arrow_tail_rotated)])
                                line = Curve(points=line_points, thickness=6, colors=colors, priority=1.0)

                                render_elements.append(polygon)
                                render_elements.append(line)
                                continue

                            if tcd_color_shape in [BulbColorShape.GreenFullCircle,
                                                   BulbColorShape.RedFullCircle,
                                                   BulbColorShape.YellowFullCircle]:

                                render_element = Points(points=position,
                                          thickness=8,
                                          colors=np.array([color]),
                                          priority=1.0,
                                          )

                                render_elements.append(render_element)
                                continue

        return render_elements

