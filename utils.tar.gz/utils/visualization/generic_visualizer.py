import os
import shutil
import time
from abc import ABC
from typing import List, Optional

from subdivision_planner.src.utils.visualization.render_elements import BaseRenderElement
from subdivision_planner.src.utils.visualization.window import Window


class GenericVisualizer(ABC):
    """
    This is an abstract class for all visualizers that use our panda3d based visualization platform
    """
    def __init__(self, win_name: str = "default", is_blocking: bool = True):
        """
        ctr
        :param win_name: Window name to be used, used as an identifier for the window to draw on
        :param is_blocking: Use False when realtime issues start happen and visualization doesn't keep up with all the
            data it is sent to. This will make some of the visualization commands drop but will allow working at a
            higher fps.
        """
        # Generate a window to visualize on
        self.window = Window(win_name, initial_win_size=(300, 950), initial_win_position=(1000, 0))
        self._win_name = win_name
        self._is_blocking = is_blocking

    def movie_capture(self, movie_dir: str) -> None:
        """
        Captures a movie in a folder. Movie is captured as a set of image files, they should be joined together later
        using ffmpeg
        :param movie_dir: directory to save images in
        """
        if os.path.isdir(movie_dir):
            shutil.rmtree(movie_dir)
        os.makedirs(movie_dir)

        self.window.movie(file_name=os.path.join(movie_dir, "movie"), duration=20., fps=24.)

    def clear(self, view_name: str = "default") -> None:
        """
        Clears visualization window
        """
        self.window.clear(view_name=view_name)

    def _draw_elements(self, render_elements: List[BaseRenderElement], render: bool = True, view_name: str = "default",
                       screenshot_filename: Optional[str] = None) -> None:
        """
        Draws multiple elements on window
        :param render_elements: render elements to draw
        :param render: If true, asks window to render these elements after sending the data
        :param view_name: Name of the view root
        :param screenshot_filename: name of the screenshot file
        :return:
        """
        # Send all elements to renderer
        for element in render_elements:
            if element is not None:
                self.window.draw_element(render_element=element, view_name=view_name)

        # Ask window to render
        if render:
            self.render(screenshot_filename)

    def render(self, screenshot_filename: Optional[str] = None) -> None:
        """
        Request window to render all elements it has in its queue and optionally saves the image
        :param screenshot_filename: name of the screenshot file
        :return:
        """
        self.window.render(block=self._is_blocking)
        if screenshot_filename is not None:
            time.sleep(2.)
            self.window.screenshot(screenshot_filename)
            time.sleep(2.)

    def visualize(self, *args, **kwargs) -> None:
        """
        abstract method to be used by deriving visualizers
        """
        raise NotImplementedError


