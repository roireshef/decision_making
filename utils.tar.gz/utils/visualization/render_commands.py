import uuid
from typing import Tuple, Optional

import numpy as np
from subdivision_planner.src.utils.visualization.gui_elements import TextBoxGuiElement
from subdivision_planner.src.utils.visualization.render_elements import RectangleRenderedImage
from subdivision_planner.src.utils.visualization.visualization import BaseRenderElement, IRenderCommand, \
    VisualizationBackend, IGuiElement


class DrawElement(IRenderCommand):
    def __init__(self, element: BaseRenderElement, view_name: str):
        self.element = element
        self.view_name = view_name

    def do_command(self, vis: VisualizationBackend):
        vis.add_to_view(render_element=self.element, view_root_name=self.view_name)

    def __str__(self):
        return "DrawCommand({})".format(str(self.element))


class EraseElement(IRenderCommand):
    def __init__(self, element: BaseRenderElement):
        self.element = element

    def do_command(self, vis: VisualizationBackend):
        vis.remove_from_view(render_element=self.element)


class ClearView(IRenderCommand):
    def __init__(self, view_name: str):
        self.view_name = view_name

    def do_command(self, vis: VisualizationBackend):
        vis.clear(view_root_name=self.view_name)


class Screenshot(IRenderCommand):
    def __init__(self, file_name: str = "screenshot.png", image_comment: str = ""):
        self.file_name = file_name
        self.image_comment = image_comment

    def do_command(self, vis: VisualizationBackend):
        vis.screenshot(namePrefix=self.file_name, defaultFilename=0, imageComment=self.image_comment)


class MovieScreenshots(IRenderCommand):
    def __init__(self, file_name: str = "movie", duration: float = 1., fps: float = 30., format: str = "png"):
        self.file_name = file_name
        self.duration = duration
        self.fps = fps
        self.format = format

    def do_command(self, vis: VisualizationBackend):
        vis.movie(namePrefix=self.file_name, duration=self.duration, fps=self.fps, format=self.format)


class SetScale(IRenderCommand):
    def __init__(self, extent: float):
        self.extent = extent

    def do_command(self, vis: VisualizationBackend):
        vis.set_scale(extent=self.extent)


class SetOrigin(IRenderCommand):
    def __init__(self, x: float, y: float, yaw: float):
        self.x = x
        self.y = y
        self.yaw = yaw

    def do_command(self, vis: VisualizationBackend):
        if vis.allow_set_origin:
            vis.set_origin(x=self.x, y=self.y, yaw=self.yaw, update=True)


class SetWinPosition(IRenderCommand):
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    def do_command(self, vis: VisualizationBackend):
        vis.set_win_position(self.x, self.y)


class SetWinSize(IRenderCommand):
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height

    def do_command(self, vis: VisualizationBackend):
        vis.set_win_size(self.width, self.height)


class AddGuiElement(IRenderCommand):
    def __init__(self, gui_element: IGuiElement):
        self._gui_element = gui_element

    def do_command(self, vis: VisualizationBackend):
        vis.register_gui(self._gui_element)


class UpdateTextBox(IRenderCommand):
    """
    This command sets the text and position of an existing TextBox GuiElement
    """
    def __init__(self, name: str, text: Optional[str] = None, pos: Optional[Tuple[float, float]] = None):
        self._name = name
        self._text = text
        self._pos = pos

    def do_command(self, vis: 'VisualizationBackend'):
        if self._name in vis.gui_elements:
            element = vis.gui_elements[self._name]
            assert isinstance(element, TextBoxGuiElement), f"Expected a {TextBoxGuiElement} but got a {element.__class__}"
            if self._text is not None:
                element.update_text(text=self._text)
            if self._pos is not None:
                element.update_pos(pos=self._pos)


class UpdateBoxArrayColor(IRenderCommand):
    """
    This command updates the color of an existing box array
    """
    def __init__(self,
                 id: uuid.UUID,
                 image_data: np.ndarray,
                 enable_image: np.ndarray,
                 location: Tuple[float, float],
                 orientation: float,
                 priority: float):
        self._id = id
        self._image_data = image_data
        self._enable_image = enable_image
        self._location = location
        self._orientation = orientation
        self._priority = priority

    def do_command(self, vis: 'VisualizationBackend'):
        for render_element in vis.render_element_to_node.keys():
            if isinstance(render_element, RectangleRenderedImage) and self._id == render_element.id:
                render_element.update_image(image_data=self._image_data, enable_image=self._enable_image)
                render_element.update_pose(location=self._location,
                                           orientation=self._orientation,
                                           priority=self._priority)
                break
