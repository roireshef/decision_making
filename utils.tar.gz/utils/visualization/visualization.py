import time
import uuid
from abc import abstractmethod, ABC
from ctypes import c_bool
from logging import Logger
from multiprocessing import Process, Queue, Value
from queue import Empty, Full
from typing import Dict, List, Tuple, Optional

import numpy as np
from direct.gui.DirectGui import OnscreenText
from direct.showbase.ShowBase import ShowBase, WindowProperties, OrthographicLens, LVecBase3, Plane, Vec3, \
    Point3, Point4
from direct.task import Task
from panda3d.core import Texture, CardMaker, NodePath, ClockObject
from rte.python.logger.AV_logger import AV_Logger
# If you get an OPENAL error when starting the visualization, you need to open the file
# /usr/local/lib/python3.6/dist-packages/panda3d/etc/Config.prc and comment the line defining
# audio-library-name. This will make panda not load audio.
from rte.python.os import catch_interrupt_signals
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.infra.manager.managed_process import apply_affinity
from subdivision_planner.src.utils.debug import get_logger


class IRenderCommand(ABC):
    """
    This data structure is used to tell the VisualizationBackend to perform a specific form of task once.
    """
    @abstractmethod
    def do_command(self, vis: 'VisualizationBackend'):
        """
        This method is run by VisualizationBackend and allows the command to express the exact task to be done
        """
        raise NotImplementedError()


class IGuiElement(ABC):
    """
    This data structure represents an element that should be rendered to visualization but the user may interact with
    """
    @property
    @abstractmethod
    def name(self) -> str:
        """
        :return: String identifier of the element. The front process will get a dictionary with this string as key and
        value with the most updated value of the element
        """
        raise NotImplementedError

    @abstractmethod
    def get_node_path(self, vis: 'VisualizationBackend') -> NodePath:
        """
        This method will be run by visualization backend to generate the NodePath that should be attached to the scene
        graph and rendered
        """
        raise NotImplementedError

    @abstractmethod
    def on_updated_value(self, vis: 'VisualizationBackend'):
        """
        This is a callback that can be used to update the rendered NodePath when the GUI changes its value
        """
        raise NotImplementedError

    @abstractmethod
    def on_update_aspect_ratio(self, vis: 'VisualizationBackend'):
        """
        This callback is run when aspect ratio of the visualization changes
        """
        # for aspect_ratio < 1
        # X: +-1
        # Y: +-1/aspect_ratio
        # for aspect ratio > 1
        # X: +-apsect_ratio
        # Y: +-1
        raise NotImplementedError

    @property
    @abstractmethod
    def value(self):
        """
        :return: The value to be returned to the front process. This represents what the GUI is set to.
        """
        raise NotImplementedError

    @abstractmethod
    def update_gui(self, vis: 'VisualizationBackend'):
        raise NotImplementedError


class BaseRenderElement(ABC):
    """
    This is the base class of all elements that can be rendered
    """
    def __init__(self):
        self._node_path = None
        self._id = uuid.uuid4()

    def can_be_updated_from(self, render_element: 'BaseRenderElement'):
        """
        This function returns true if we can update self using <render_element>
        :param render_element:
        :return:
        """

        return isinstance(render_element, self.__class__)

    def update_from(self, render_element: 'BaseRenderElement') -> None:
        """
        This function updates self using <render_element> to avoid regenerating a new NodePath
        :param render_element: RenderElement to update from
        """
        raise NotImplementedError

    def get_node_path(self) -> NodePath:
        """
        :return: NodePath representing this RenderElement
        """
        raise NotImplementedError

    @property
    def id(self):
        return self._id

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other: 'BaseRenderElement') -> bool:
        return other.id == self.id


class VisualizationBackend(ShowBase):
    """
    Backend for visualizations in Panda3D. Runs in a background process, gets visualization commands and runs them one
    after the other. This class should be inherited for different visualization apps.
    """

    def __init__(self,
                 name: str,
                 cmd_queue: Queue,
                 data_queue: Queue,
                 logger: Logger,
                 running_flag: Value):
        """
        ctr
        :param name: backend name
        :param cmd_queue: queue for inputting commands for visualization
        :param logger: logger
        :param running_flag: if True, process should quit
        """
        ShowBase.__init__(self)
        self._name: str = name
        self._cmd_queue: Queue = cmd_queue
        self._cmd_queue.cancel_join_thread()
        self._gui_elements: Dict[str, IGuiElement] = {}
        self._last_gui_update: Dict = {}
        self._data_queue: Queue = data_queue
        self._data_queue.cancel_join_thread()
        self._logger: Logger = logger
        self._running_flag: Value = running_flag

        self._elements_buffers: Dict[type, ElementsBuffer] = {}

        # set keys properties
        self.mouse2cam.detachNode()
        self._prev_mouse_location = np.array([0., 0.])
        self._prev_mouse_location_pen = None
        self._buttons_state = {}
        self._define_keymap()
        self.accept('wheel_down', self._zoom_out)
        self.accept('wheel_up', self._zoom_in)
        self._allow_set_origin = True

        self._ground_plane = Plane(Vec3(0, 1, 0), Point3(0, 0, 0))

        # tool tip text
        self._tooltip: OnscreenText = None

        self._was_rendered = False

        # get 2d lens for updating scale
        self._lens2d = OrthographicLens()
        self.cam.node().setLens(self._lens2d)

        # This node will be the root we want to clean and attach nodes to. The clear method will clear it
        self._view_roots: Dict[str, NodePath] = {}
        self.render_element_to_node: Dict[BaseRenderElement, NodePath] = {}

        # image area
        self._image_texture = None
        self._image_card = None
        self._image_size = None

        self.render2d.setDepthTest(1)
        self.render2d.setDepthWrite(1)

        # add fps meter
        self.setFrameRateMeter(True)
        globalClock = ClockObject.getGlobalClock()
        globalClock.setMode(ClockObject.MLimited)
        globalClock.setFrameRate(10)

        self.origin: Optional[Tuple[float, float, float]] = None
        self.pixels_to_meter: Optional[float] = None
        self._reset_view()

        props = WindowProperties()
        props.set_title(self._name)
        self.win.requestProperties(props)

        self.accept("aspectRatioChanged", self.update_gui_aspect_ratio)

        # add tasks
        self.taskMgr.add(self._update_camera_task)
        self.taskMgr.add(self._update_scale)
        self.taskMgr.add(self._tooltip_task)
        self.taskMgr.add(self._quit)
        self.taskMgr.add(self._process_cmd_queue)
        self.taskMgr.do_method_later(0.1, self._process_data_queue, "process_data_queue")
        self.taskMgr.do_method_later(0.1, self.update_gui, "update_gui")

    def set_win_size(self, width: int, height: int):
        props = WindowProperties()
        props.setSize((width, height))
        self.win.requestProperties(props)

    def set_win_position(self, x: int, y: int):
        props = WindowProperties()
        props.set_origin((x, y))
        self.win.requestProperties(props)

    def update_gui(self, task):
        for element in self._gui_elements.values():
            element.update_gui(self)
        return task.again

    @property
    def gui_elements(self):
        return self._gui_elements

    def _process_cmd_queue(self, task):
        """
        Go over self._cmd_queue, get any visualization commands in it and run them with VisualizationBackend as a
        parameter.
        :return:
        """
        start_time = time.time()
        self._was_rendered = False
        try:
            while time.time() - start_time < 1 / 20.:
                cmd_list: List[IRenderCommand] = self._cmd_queue.get_nowait()
                for cmd in cmd_list:
                    cmd.do_command(vis=self)
                self._was_rendered = True

        except Empty:
            pass
        except Exception as ex:
            print("Exception was raise: {}".format(ex.args))
        if self._running_flag.value:
            return Task.cont
        else:
            return Task.done

    def _process_data_queue(self, task):
        data_changed = False
        if self._was_rendered:
            return task.cont
        for name, element in self._gui_elements.items():
            data = element.value
            if name not in self._last_gui_update or self._last_gui_update[name] != data:
                self._last_gui_update[name] = data
                data_changed = True
                element.on_updated_value(vis=self)

        if data_changed:
            try:
                self._data_queue.put_nowait(self._last_gui_update)
            except Full:
                pass

        return Task.again

    def _quit(self, task):
        if not self._running_flag.value:
            self.userExit()
            return Task.done
        return Task.cont

    def _update_scale(self, task=None):
        win_x, win_y = self.win.getSize()
        self._lens2d.setFilmSize(win_x / self.pixels_to_meter, win_y / self.pixels_to_meter)
        return Task.cont

    def _tooltip_task(self, task):
        """
        tooltip task. Gets position of mouse and updates the tooltip text node accordingly. Takes into account the
        scale of the 2d renderer
        :param task:
        :return:
        """
        if not self._running_flag.value:
            return Task.done

        # verify the display has the mouse
        if self.mouseWatcherNode.hasMouse():
            mx, my = self.mouseWatcherNode.getMouseX(), self.mouseWatcherNode.getMouseY()

            # if we don't have a tooltip node, create it and add to display
            if self._tooltip is None:
                self._tooltip = OnscreenText(text="", pos=(0., 0.), scale=0.05, fg=(1., 1., 1., 1.))

            self._tooltip.setScale(50 / min(self.win.getXSize(), self.win.getYSize()))

            # get film size so that we understand the actual coordinates
            sx, sy = self._lens2d.getFilmSize()

            # set position and scale of text near the mouse
            p_aspect = self.aspect2d.getRelativePoint(self.render2d, LVecBase3(mx, 0, my))

            if my > 0:
                self._tooltip.setPos(p_aspect[0], p_aspect[2] - 0.1)
            else:
                self._tooltip.setPos(p_aspect[0], p_aspect[2] + 0.05)

            # calculate location of the mouse offset
            location = self.cam.get_net_transform().mat.xform(Point4(mx * sx/2, 0., my * sy/2, 1.))

            s = "x: {:.2f}, y: {:.2f}".format(location[0], location[2])
            self._tooltip.setText(s)

        elif self._tooltip is not None:
            # we're outside of the display, destroy the node
            self._tooltip.destroy()
            self._tooltip = None

        return Task.cont

    def _register_keys(self, key_list: List[str]) -> None:
        """
        Registers multiple keys
        :param key_list:
        :return:
        """
        for key in key_list:
            self._register_key(key)

    def _register_key(self, key: str) -> None:
        """
        Registers a key that can be pressed (up, and down).
        :param key: string that represents the key
        :return: None
        """
        assert isinstance(key, str)
        self._buttons_state[key] = False
        self.accept(key + '-up', self._key_up, [key])
        self.accept(key, self._key_down, [key])

    def _define_keymap(self) -> None:
        """
        Registers all keyboard keys
        :return: None
        """
        self._register_keys(['w', 's', 'a', 'd', 'q', 'z', 'mouse1', 'mouse3', 'arrow_left', 'arrow_right'])
        self.accept('r', self._reset_view)
        self.accept('space', self._toggle_allow_set_origin)

    @property
    def allow_set_origin(self):
        return self._allow_set_origin

    def _toggle_allow_set_origin(self):
        self._allow_set_origin = not self._allow_set_origin

    def _reset_view(self) -> None:
        """
        Resets the view
        """
        self.setBackgroundColor(0, 0, 0)
        self.set_origin(0., 0., 0.)
        self.set_scale(10., update=True)

    def _key_down(self, key: str) -> None:
        """
        callback that runs whenever a key is pressed
        :param key: string that represents the key
        """
        if key in ['mouse1', 'mouse3']:
            # For mouse we keep the current location
            if self.mouseWatcherNode.hasMouse():
                self._buttons_state[key] = True
                self._prev_mouse_location = np.array(self.mouseWatcherNode.getMouse())
        else:
            self._buttons_state[key] = True

    def _key_up(self, key: str) -> None:
        """
        Callback that runs whenever a key was pressed and is now lifted
        :param key: string that represents the key
        """
        self._buttons_state[key] = False

    def _zoom_out(self, scale=0.3, update: bool = True):
        """
        Zoom out
        :param scale:
        :param update: Whether or not to update the camera state immediately
        """
        self.set_scale(self.pixels_to_meter / 2 ** scale, update=update)

    def _zoom_in(self, scale=0.3, update: bool = True):
        """
        Zoom in
        :param scale:
        :param update: Whether or not to update the camera state immediately
        """
        self.set_scale(self.pixels_to_meter * 2 ** scale, update=update)

    def _update_camera_task(self, task):
        """
        A task function that listens to keys and updates the view accordingly
        :param task:
        :return:
        """
        scale = self.pixels_to_meter * 0.01
        if 'w' in self._buttons_state and self._buttons_state['w']:
            self.set_origin(self.origin[0] + scale, self.origin[1], self.origin[2], update=True)
        if 's' in self._buttons_state and self._buttons_state['s']:
            self.set_origin(self.origin[0] - scale, self.origin[1], self.origin[2], update=True)
        if 'a' in self._buttons_state and self._buttons_state['a']:
            self.set_origin(self.origin[0], self.origin[1] + scale, self.origin[2], update=True)
        if 'd' in self._buttons_state and self._buttons_state['d']:
            self.set_origin(self.origin[0], self.origin[1] - scale, self.origin[2], update=True)
        if 'q' in self._buttons_state and self._buttons_state['q']:
            self._zoom_in(scale=0.03, update=True)
        if 'z' in self._buttons_state and self._buttons_state['z']:
            self._zoom_out(scale=0.03, update=True)

        if 'mouse1' in self._buttons_state and self._buttons_state['mouse1'] and self.mouseWatcherNode.hasMouse():
            mouse_pos = np.array(self.mouseWatcherNode.getMouse())
            if np.linalg.norm(mouse_pos - self._prev_mouse_location) > 1e-2:
                prev_mouse_location = self._prev_mouse_location.copy()
                self._prev_mouse_location = mouse_pos
                diff = (mouse_pos - prev_mouse_location) * np.array(self._lens2d.get_film_size()) / 2
                p = self.cam.get_net_transform().mat.xform(Point3(-diff[0], 0., -diff[1]))
                self.set_origin(p[0],
                                p[2],
                                self.origin[2],
                                update=True)
        if 'mouse3' in self._buttons_state and self._buttons_state['mouse3'] and self.mouseWatcherNode.hasMouse():
            mouse_pos = np.array(self.mouseWatcherNode.getMouse())
            cross_vec = np.cross(self._prev_mouse_location, mouse_pos)
            if np.linalg.norm(cross_vec) > 1e-2:
                sin_diff_angle = cross_vec / (np.linalg.norm(self._prev_mouse_location) * np.linalg.norm(mouse_pos) + 1e-3)
                self._prev_mouse_location = mouse_pos
                diff_angle = np.arcsin(np.clip(sin_diff_angle, -1, 1))
                self.set_origin(self.origin[0],
                                self.origin[1],
                                self.origin[2] + np.rad2deg(diff_angle),
                                update=True)

        return task.cont

    def add_to_view(self, render_element: BaseRenderElement, view_root_name: str):
        """
        This method adds a render element to view, it first sees if it has this type of element available in buffer
        :param render_element: a render element to be added to view
        :param view_root_name: Name of view root
        :return: None
        """
        if view_root_name not in self._view_roots:
            self.add_view_root(view_root_name=view_root_name)

        node = render_element.get_node_path()
        self.render_element_to_node[render_element] = node

        node.reparentTo(self._view_roots[view_root_name])

    def clear(self, view_root_name: str):
        """
        This method clears the view without changing scale
        :return: None
        """
        if view_root_name not in self._view_roots:
            self.add_view_root(view_root_name=view_root_name)
        self._view_roots[view_root_name].detachNode()
        self._view_roots[view_root_name]: NodePath = self.render.attachNewNode(view_root_name)
        self.update_camera()

    def remove_from_view(self, render_element: BaseRenderElement):
        if render_element in self.render_element_to_node:
            self.render_element_to_node[render_element].detachNode()
            self.render_element_to_node.pop(render_element)

    def add_view_root(self, view_root_name: str):
        self._view_roots[view_root_name] = self.render.attachNewNode(view_root_name)

    def set_scale(self, extent: float, update: bool = False) -> None:
        """
        Sets scale of the 2d renderer.
        :param extent: the vertical size of the display in meters
        :param update: if True we update the display
        :return:
        """
        self.pixels_to_meter = extent
        if update:
            self.update_camera()
            self._update_scale()

    def set_origin(self, x: float, y: float, yaw: float, update: bool = False) -> None:
        """
        Set origin of visualization
        :param x: x coordinate
        :param y: y coordinate
        :param yaw: yaw coordinate
        :param update: if True we update the display
        """
        self.origin = (x, y, yaw)
        if update:
            self.update_camera()

    def update_camera(self):
        self.cam.setPos(self.origin[0], 0., self.origin[1])
        self.cam.setR(self.origin[2])

    def draw_image(self, image: np.ndarray, view_root_name: str, aspect_ratio: float = None):
        """
        This method draws an image to display
        :param image: numpy array of the image
        :param aspect_ratio: aspect ratio of the image
        :param view_root_name: name of view root
        :return:
        """
        if self._image_texture is None or self._image_size != image.shape:
            self._image_size = image_size = image.shape
            self._image_texture = Texture()
            self._image_texture.setup2dTexture(x_size=image_size[0],
                                               y_size=image_size[1],
                                               component_type=Texture.T_unsigned_byte,
                                               format=Texture.F_luminance)
            # set up a card to apply the numpy texture
            cm = CardMaker('card')
            self._image_card = self._view_roots[view_root_name].attachNewNode(cm.generate())
            if aspect_ratio is None:
                aspect_ratio = image_size[0] / image_size[1]
            if aspect_ratio > 1.:
                # bring it to center, put it in front of camera
                self._image_card.setPos(-0.5, 1., -aspect_ratio / 2)
                # card is square, rescale to the original image aspect
                self._image_card.setScale(1, 1, aspect_ratio)
            else:
                # bring it to center, put it in front of camera
                self._image_card.setPos(-aspect_ratio, 0, -1)
                # card is square, rescale to the original image aspect
                self._image_card.setScale(2 * aspect_ratio, 1, 2)

        frame = (image * 255).astype(np.uint8)

        buf = frame.T.tostring()  # slice RGB to gray scale, transpose 90 degree, convert to text buffer
        self._image_texture.setRamImage(buf)  # overwriting the memory with new buffer
        self._image_card.setTexture(self._image_texture)  # now apply it to the card

    def register_gui(self, gui_element: 'IGuiElement'):
        if gui_element.name not in self._gui_elements:
            self._gui_elements[gui_element.name] = gui_element
            gui_element.get_node_path(vis=self).reparent_to(self.aspect2d)
        else:
            print(f"Warning: Gui with name {gui_element.name} was registered twice, ignoring")

    def update_gui_aspect_ratio(self):
        for gui_element in self._gui_elements.values():
            gui_element.on_update_aspect_ratio(self)


class ElementsBuffer:
    """
    This object holds cached RenderElements and maintains information about whether they're already in view or not.
    Whenever some RenderElement should be rendered to view we can first see if an ElementsBuffer has free RenderElements
    to use, and use one of its free RenderElements instead such that we save some of the compute of converting a
    RenderElement to a NodePath.
    """
    def __init__(self, type: type(BaseRenderElement)):
        """
        ctr
        :param type: RenderElement types this buffer holds
        """
        self.type = type
        # Initialize the buffer of unused elements
        self.unused_buffer: List[BaseRenderElement] = []
        # Initialize the buffer of used elements
        self.used_buffer: List[BaseRenderElement] = []

    def append_used(self, render_element: BaseRenderElement) -> None:
        """
        Append a RenderElement that is already in view to buffer
        :param render_element:
        """
        self.used_buffer.append(render_element)

    def append_unused(self, render_element: BaseRenderElement) -> None:
        """
        Append a RenderElement that is not in view to buffer
        :param render_element:
        """
        self.unused_buffer.append(render_element)

    def get_free_element(self, matching_element: BaseRenderElement) -> BaseRenderElement:
        """
        This method returns a RenderElement that can be updated from matching_element and first verifies it can be
        updated from it. If it can't find an element, it returns None
        :param matching_element: Element to be matched
        :return: a free RenderElement that can be used.
        """
        good_element = None
        for idx, el in enumerate(self.unused_buffer):
            if el.can_be_updated_from(matching_element):
                good_element = self.unused_buffer.pop(idx)
                self.used_buffer.append(good_element)
                break

        return good_element

    def view_cleared(self) -> None:
        """
        Notify that view was cleared, hence all elements are now unused.
        """
        self.unused_buffer = self.unused_buffer + self.used_buffer
        self.used_buffer.clear()


class Visualization(Process):
    """
    Wrapper for Visualization backend, that runs it in a different process and exposes an interface for performing
    visualizations
    """

    def __init__(self, name: str, initial_win_size: Tuple[int, int] = None, initial_win_position: Tuple[int, int] = None):
        super().__init__()
        self._name: str = name
        self._cmd_queue: Queue = Queue(3)
        self._cmd_queue.cancel_join_thread()
        self._data_queue: Queue = Queue(3)
        self._data_queue.cancel_join_thread()
        self._gui_data = {}
        self._logger = get_logger("SubdivisionVis")
        self._running_flag: Value = Value(c_bool, False)
        self._command_list = []
        self._initial_win_size = initial_win_size
        self._initial_win_position = initial_win_position

    def run(self):
        catch_interrupt_signals()
        self._cmd_queue.cancel_join_thread()

        apply_affinity("Visualization", self._logger, Config().system.visualization_cores_indices)

        self._running_flag.value = True
        app = VisualizationBackend(name=self._name,
                                   data_queue=self._data_queue,
                                   cmd_queue=self._cmd_queue,
                                   logger=self._logger,
                                   running_flag=self._running_flag)
        if self._initial_win_size is not None:
            app.set_win_size(self._initial_win_size[0], self._initial_win_size[1])
        if self._initial_win_position is not None:
            app.set_win_position(self._initial_win_position[0], self._initial_win_position[1])

        app.run()
        app.destroy()

    def add_command(self, cmd: IRenderCommand):
        """
        puts the visualization command in the queue for the backend to process it
        :param cmd: a render command that is used to perform the visualization, it gets as the first parameter the
                    backend
        :return:
        """
        self._command_list.append(cmd)

    def send_commands(self, block=False):
        try:
            if block:
                self._cmd_queue.put(tuple(self._command_list), timeout=1.)
            else:
                self._cmd_queue.put_nowait(tuple(self._command_list))
            self._command_list.clear()
        except Full:
            self._logger.warning("Visualization {} command queue is full, skipping visualization command, {}"
                                 .format(self._name, self._cmd_queue))

    def stop(self):
        self._running_flag.value = False

    def get_gui_data(self):
        try:
            while not self._data_queue.empty():
                self._gui_data = self._data_queue.get_nowait()
        except Empty:
            pass

        return self._gui_data
