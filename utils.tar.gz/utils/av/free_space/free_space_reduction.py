from subdivision_planner.src.mdp.werling.concepts.free_space_reduction import get_free_space_origin, \
    free_space_to_targets
