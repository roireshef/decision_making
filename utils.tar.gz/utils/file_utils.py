import os


class FileUtils:
    @staticmethod
    def get_model_path(models_dir_path: str, snapshot_root_path: str):
        """
        Resolves and returns full model path, whether absolute or relative
        :param models_dir_path: The directory path of the models.
        :param snapshot_root_path:
        :return: full file path
        """
        if snapshot_root_path.startswith("/"):
            # absolute path
            model_path = snapshot_root_path
        else:
            # relative path
            model_path = os.path.join(models_dir_path, snapshot_root_path) if snapshot_root_path != 'None' else None
        if model_path is not None and not os.path.exists(model_path):
            raise FileNotFoundError('configuration file for reward model not found: ' + model_path)
        return model_path
