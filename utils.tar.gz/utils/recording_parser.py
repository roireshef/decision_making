import pickle
import os
from functools import lru_cache
from typing import Dict, Iterator, List

from subdivision_planner.src.common.recorder import Recorder, FileMetaData, FrameRecord, ModuleRecord, DataType

SUPPORTED_RECORDER_VERSION = 0


@lru_cache(maxsize=512)
def get_file_data(file_path: str) -> dict:
    with open(file_path, 'rb') as fh:
        file_data = pickle.load(fh)
    return file_data


class RecordingParser:

    def __init__(self, output_dir: str):

        self.output_dir = output_dir

        metadata_file_path = Recorder.get_metadata_file_path(output_dir=self.output_dir)

        if not os.path.exists(metadata_file_path):
            raise FileNotFoundError('Metadata file not found in ' + self.output_dir)

        with open(metadata_file_path, 'rb') as fh:
            self.metadata = pickle.load(fh)

        if self.metadata['recorder_version'] != SUPPORTED_RECORDER_VERSION:
            raise Warning('Recorder version does not match recorder version in directory' + self.output_dir)

        if 'files_metadata' not in self.metadata:
            raise Warning(self.output_dir + ' is empty')

        # Generate a mapping from frame id to list of files that contain it
        self._frame_id_to_file: Dict[int, List[str]] = {}
        for file_name, file_metadata in self.metadata['files_metadata'].items():
            for frame_id in file_metadata.frames_id:
                if frame_id not in self._frame_id_to_file:
                    self._frame_id_to_file[frame_id] = []
                self._frame_id_to_file[frame_id].append(file_name)

    def get_successful_frames_id_list(self) -> List[int]:

        res = list()

        for key, value in sorted(self.metadata['files_metadata'].items(), key=lambda e: e[1].frames_id[0]):

            # Sorted files by first frame_id

            res += value.successful_frames

        return res

    def get_frames_id_list(self) -> List[int]:
        return list(self._frame_id_to_file.keys())

    def get_by_frame_id(self, frame_id: int) -> FrameRecord:
        """
        :param frame_id:
        :return: frame record
        """

        if frame_id not in self._frame_id_to_file:
            raise IndexError('No frame with ID: ' + str(frame_id) + ' was found in ' + self.output_dir)

        frame_data = {}
        for file_name in self._frame_id_to_file[frame_id]:
            file_path = os.path.join(self.output_dir, file_name)

            assert os.path.exists(file_path), 'Files list in metadata does not match file system in folder' + self.output_dir

            # Load the file data
            file_data = get_file_data(file_path)
            frame_data.update(file_data[frame_id])

        return frame_data

    def get_by_module_name(self, module_name: str) -> Dict[int, Dict[str, DataType]]:

        """

        :param module_name:
        :return:

        <frame_id>: {
            <record_name>: data (DataType)
        }
        """

        res: Dict[int, ModuleRecord] = dict()

        for file_name, file_metadata in self.metadata['files_metadata'].items():

            if module_name not in file_metadata.modules_name:
                continue

            file_path = os.path.join(self.output_dir, file_name)
            curr_file = get_file_data(file_path)

            for frame_id in file_metadata.modules_name[module_name]:
                if frame_id not in res:
                    res[frame_id] = {}
                res[frame_id].update(curr_file[frame_id][module_name])

        return res

    def get_by_record_name(self, record_name: str) -> Dict[int, Dict[str, DataType]]:

        """

        :param record_name:
        :return:

        <frame_id>: {
            <module_name>: data (DataType)
        },

        """

        res: Dict[int, Dict[str, DataType]] = dict()

        for file_name, file_metadata in self.metadata['files_metadata'].items():

            if record_name not in file_metadata.records_name:
                continue

            file_path = os.path.join(self.output_dir, file_name)
            curr_file = get_file_data(file_path)

            for frame_id, modules_name in file_metadata.records_name[record_name].items():

                res[frame_id] = dict()

                for module_name in modules_name:
                        res[frame_id][module_name] = curr_file[frame_id][module_name][record_name]

        return res

    def get_frames_iter(self) -> Iterator[Dict[str, Dict[str, DataType]]]:

        for frame_id in sorted(self._frame_id_to_file.keys()):

            yield frame_id, self.get_by_frame_id(frame_id=frame_id)

    @staticmethod
    def is_valid_recording_folder(folder: str):
        meta_data_file_name = Recorder.get_metadata_file_path(output_dir=folder)
        return os.path.isfile(meta_data_file_name)


if __name__ == '__main__':

    output_dir = '/home2/recorder_test'

    parser = RecordingParser(output_dir=output_dir)

    frames_id = parser.get_frames_id_list()

    frame = parser.get_by_frame_id(frame_id=10)

    records = parser.get_by_module_name('ariel')

    records = parser.get_by_record_name('ariel_a')

    for frame_id, frame in parser.get_frames_iter():
        print('New frame with ID: ', frame_id)
