from datetime import datetime
import json
from collections import OrderedDict

import gc
import os

from subdivision_planner.src.common.config import Config
from subdivision_planner.src.utils.dm_profiler import DMProfiler


def _dump_gc_stats(directory_path: str) -> None:
    """
    Dump garbdge collector statistics
    :param directory_path: Output directory to dump statistics
    :return: N/A
    """

    os.makedirs(directory_path, exist_ok=True)

    """
    Count all the elements of subdivision_planner module tracked by the GC
    """
    modules = OrderedDict()
    for t in gc.get_objects():
        try:
            curr_module = t.__module__ + '.' + t.__class__.__name__

            if curr_module.split('.')[0] != 'subdivision_planner':
                continue

            if curr_module not in modules:
                modules[curr_module] = 0

            modules[curr_module] += 1
        except:
            continue

    now = datetime.now()

    current_time = now.strftime("%H_%M_%S_%f")

    with open(os.path.join(directory_path, '{}_gc_{}.json'.format(os.getpid(), current_time)), 'w') as f:
        json.dump(modules, f)


def run_manual_gc(threshold_factor: float) -> None:
    """
    Run the garbage collector. Each generation is collected only if its size is higher than the configured threshold
    multiplied by the threshold factor.
    :param threshold_factor: Factor to multiply the GC threshold.
    """

    was_collected = False

    gc_count = gc.get_count()
    gc_threshold = [threshold_factor * thres for thres in gc.get_threshold()]
    for idx in range(len(gc_count)):
        if gc_count[idx] >= gc_threshold[idx]:

            was_collected = True

            name = 'gc_collection_{}_{}'.format(os.getpid(), idx)

            with DMProfiler(name):
                gc.collect(generation=idx)

    if was_collected and len(Config().system.manual_gc_stats_output_path):
        _dump_gc_stats(directory_path=Config().system.manual_gc_stats_output_path)
