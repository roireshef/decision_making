from cachetools import cached, LRUCache
from cachetools.keys import hashkey
from typing import List, Tuple

from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.exceptions import OutOfSegmentBack, OutOfSegmentFront
from subdivision_planner.src.data_structures.driver_initiated_motion import DriverInitiatedMotionStatus
from subdivision_planner.src.data_structures.lane_sequence import LaneSequence
from subdivision_planner.src.data_structures.map import Map
from subdivision_planner.src.data_structures.map_elements.lane_segment import LaneSegment, StopBar
from subdivision_planner.src.mdp.state import MDPContext, MDPContextImp

INFINITY_TIME = 1e30
EPS = 1e-6


class StopBarUtils:

    @classmethod
    @cached(
        cache=LRUCache(maxsize=128),
        key=lambda cls, state_map, gff: hashkey((state_map.id, hash(gff))),
    )
    def get_stop_bars_on_gff(
            cls,
            state_map: Map,
            gff: LaneSequence
    ) -> (List[Tuple[LaneSegment, StopBar, float]]):
        """
        Find all the stop bars on the given gff
        :param state_map:
        :param gff:
        :return: The lanes segment that contains the stop bars, the stop bars context and longitudinal offset
        from the beginning of the GFF. Sorted w.r.t offset
        """

        res: List[Tuple[LaneSegment, StopBar, float]] = list()

        lane_segments = gff.segments

        if len(lane_segments) < 1:
            return res

        # Create a list of stopbars by going over all the stopbars in allsub-segments of current lane_segment,
        # for each stopbar, get longitudinal offset relative to gffbeginning. Return list sorted by longitudinal offsets
        for subsegment in lane_segments:

            if not state_map.has_lane_id(lane_id=subsegment.e_i_SegmentID):
                continue

            curr_lane_segment = state_map.get_lane_segment_by_id(subsegment.e_i_SegmentID)

            for stop_bar in curr_lane_segment.get_stop_bars():
                # longitudinal offset of the stop bar relative to gff beginning

                # TODO: uncommnet when the bug is fixed!

                """
                global_offset = gff.cpoint_to_fpoint(
                    cpoint=stop_bar.cpoint,
                    raise_on_points_out_of_frame=False
                )[types.FP_SX]
                if global_offset < 0.0:
                    continue
                """
                try:
                    global_offset = gff.cpoint_to_fpoint(cpoint=stop_bar.cpoint)[types.FP_SX]
                except (OutOfSegmentBack, OutOfSegmentFront):
                    continue

                res.append((curr_lane_segment, stop_bar, global_offset))

        return sorted(res, key=lambda e: e[2])

    @classmethod
    @cached(
        cache=LRUCache(maxsize=128),
        key=lambda cls, state_map, gff, current_s_offset, context, return_only_stopbars_ahead=True: hashkey(
            (state_map.id, hash(gff), current_s_offset, context.id, return_only_stopbars_ahead))
    )
    def get_next_stop_bar(
            cls,
            state_map: Map,
            gff: LaneSequence,
            current_s_offset: float,
            context: MDPContext,
            return_only_stopbars_ahead: bool = True
    ) -> (LaneSegment, StopBar, float):
        """
        Find the next stop bar on the given gff w.r.t the current longitudinal offset
        :param state_map: map of current mdp_state
        :param gff: current gff
        :param current_s_offset: current ego's longitudinal offset
        :param context: mdp context
        :param return_only_stopbars_ahead: if False, specifies if we are also interested in enforced stopbars
        that are behind ego's s (meaning - we missed them).
        :return: The lane segment that contains the next stop bar, the stop bar context and longitudinal offset
        from the beginning of the GFF. In case no stop bar found till the end of the gff, return (None, None, -1.0)
        """

        if current_s_offset < 0.0 or current_s_offset > gff.s_max:
            raise RuntimeError(
                "longitudinal offset {} on GFF is out of range [0.0, {}]".format(current_s_offset, gff.s_max))

        # Get list of stobars, sorted by longitudinal offset from beginning of gff
        stop_bars_on_gff = cls.get_stop_bars_on_gff(state_map=state_map, gff=gff)
        if len(stop_bars_on_gff) < 1:
            return None, None, -1.0

        # Find the first stop bars in-front of the current longitudinal offset that is enforced
        for stop_bar_context in stop_bars_on_gff:

            curr_lane_segment, stop_bar, global_offset = stop_bar_context

            if return_only_stopbars_ahead and current_s_offset > global_offset:
                # Stop bar behind current offset - skip it
                continue

            # Check if stopbar is enforced (can be not enforced if all traffic control devices are not enforcing, eg.
            # traffic light with GREEN state
            is_should_stop = context.stop_bar_enforcement_status[stop_bar.id] or \
                             context.driver_initiated_motion_status in \
                             (DriverInitiatedMotionStatus.WaitingForDriverInput, DriverInitiatedMotionStatus.Pending)

            # return stopbar details only if it's enforced
            if is_should_stop:
                return curr_lane_segment, stop_bar, global_offset

        # No relevant stop bar was found
        return None, None, -1.0


    @classmethod
    def get_time_to_stop_bar(cls, ego_s, stopbar_s, ego_velocity):
        # Calculate contact time to the stopbar by deviding the distance towards it by current ego's veloicity
        return (stopbar_s - ego_s) / max(ego_velocity, EPS)

    @classmethod
    def derive_stop_s_from_stop_bar_s(cls, stop_bar_s: float) -> float:
        """
        Calulate wanted stop s coordinate before stopbar by substracting half of ego's length and the wanted margin towards
        stop bar
        :param stop_bar_s: stop bar's longitudinal offset
        :return: longitudinal offset of required stop point
        """
        base_margin = Config().ego.size[0] / 2.0
        offset = base_margin + Config().driving.stop_distance_from_stop_bar
        return stop_bar_s - offset
