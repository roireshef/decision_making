from subdivision_planner.src.utils.math_utils import verify_trajectory_consistency, rotate_around_point, \
    get_closest_distance_points, are_lines_overlapping, boxes_distance
