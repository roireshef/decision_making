from typing import List


class ListUtils:

    @staticmethod
    def insort(l: List[object], elem: object, key=None) -> None:
        """
        Insert item elem in list l, and keep it sorted assuming l is sorted.

        If elem is already in l, insert it to the right of the rightmost elem.
        :param l: Sorted list
        :param elem: Element to add
        :param key: A custom key function can be supplied to customize the sort order
        :return: N/A
        """
        if key is None:
            key = lambda x: x

        lo = 0
        hi = len(l)
        while lo < hi:
            mid = (lo + hi) // 2
            if key(elem) < key(l[mid]):
                hi = mid
            else:
                lo = mid + 1
        l.insert(lo, elem)
