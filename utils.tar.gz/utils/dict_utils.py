import functools
from typing import List, Dict


class DictUtils:
    @staticmethod
    def merge_two_dicts(take_min: bool = False):
        """
        Returns a lambda function for merging two dictionaries. Conflicts in keys are solved by either taking the
        maximal or minimal value, requested using the input param.
        :param take_min: if True, resolves conflicts by taking the minimal value out of the two dicts,
               otherwise take the maximal.
        :return: A lambda function for merging two dictionaries
        """
        if take_min:
            return lambda dict1, dict2: dict(sorted((*dict1.items(), *dict2.items()), reverse=True))
        else:
            return lambda dict1, dict2: dict(sorted((*dict1.items(), *dict2.items())))

    @staticmethod
    def merge_dicts(dicts: List[Dict], take_min: bool = False):
        """
        Returns a lambda function for merging multiple dictionaries. Conflicts in keys are solved by either taking the
        maximal or minimal value, requested using the input param.
        :param dicts: A list of dictionaries to be merged
        :param take_min: if True, resolves conflicts by taking the minimal value out of the different dicts,
               otherwise take the maximal.
        :return: One dict, merging all dicts given as input, conflicts in keys are solved with take_min
        """
        return functools.reduce(DictUtils.merge_two_dicts(take_min), dicts)
