
import time
import matplotlib.pyplot as plt
import numpy as np
import sympy
import copy
from scipy.interpolate import splev, splrep, UnivariateSpline
from typing import Tuple, List, Dict, Iterable

# TODO: unused file, can be removed


class BSplinesMatricesCalculator:
    _coefficients_matrices = {}
    _template_penalty_matrices = {}

    @classmethod
    def _extract_coefficients_from_offseted_matrix(cls, poly_deg: int, matrix: np.ndarray):
        t = sympy.symbols('t')
        tt = np.array([t ** n for n in range(poly_deg + 1)])[::-1]
        polynomials = matrix.dot(tt)
        polynomials = [p.subs({t: t + i}).series() * 4 / 3 for i, p in enumerate(polynomials)]
        coef_arr = []
        for p in polynomials:
            poly_coef = []
            for t_val in tt:
                poly_coef.append(p.as_coefficients_dict()[t_val])
            coef_arr.append(poly_coef)
        return np.array(coef_arr)

    @classmethod
    def get_b_spline_poly_coeffs_matrix(cls, poly_deg):
        if poly_deg == 1:
            return np.array([
                [1., 0.],
                [-1., 1.]
            ])
        if poly_deg not in cls._coefficients_matrices:
            if poly_deg == 2:
                coef_matrix = np.array([
                    [0.5, 0., 0.],
                    [-1, 3, -3 / 2],
                    [0.5, -3, 9 / 2]
                ])
            elif poly_deg == 3:
                coef_matrix = np.array([
                    [0.25, 0., 0., 0.],
                    [-0.75, 0.75, 0.75, 0.25],
                    [0.75, -1.5, 0., 1.],
                    [-0.25, 0.75, -0.75, 0.25],
                ])
                return coef_matrix
            elif poly_deg == 5:
                coef_matrix = np.array([
                    [1 / 120, 0., 0., 0., 0., 0.],
                    [-1 / 24, 1 / 4, -0.5, 0.5, -0.25, 1 / 20],
                    [1 / 12, -1, 9 / 2., -19 / 2., 39 / 4, -79 / 20],
                    [-1 / 12, 3 / 2, -21 / 2, 71 / 2, -231 / 4, 731 / 20],
                    [1 / 24, -1, 19 / 2, -89 / 2, 409 / 4, -1829 / 20],
                    [-1 / 120, 1 / 4, -3, 18, -54, 324 / 5]
                ])
            else:
                raise ValueError(f"Unsupported polynomial degree: {poly_deg}")
            cls._coefficients_matrices[poly_deg] = cls._extract_coefficients_from_offseted_matrix(poly_deg, coef_matrix)

        return cls._coefficients_matrices[poly_deg]

    @classmethod
    def calculate_template_penalty_matrix(cls, poly_deg: int, derivative: int):
        if (poly_deg, derivative) not in cls._template_penalty_matrices:
            t = sympy.symbols('t')
            a_matrix = BSplinesMatricesCalculator.get_b_spline_poly_coeffs_matrix(poly_deg=poly_deg)
            tt = np.array([t ** n for n in range(poly_deg + 1)])[::-1]
            polynomials = a_matrix.dot(tt)

            d = []
            for poly in polynomials:
                der = poly
                for _ in range(derivative):
                    der = sympy.diff(der, t)
                d.append(der)

            template_penalty_matrix = np.zeros((poly_deg + 1, poly_deg + 1))

            for i in range(poly_deg + 1):
                for j in range(i, poly_deg + 1):
                    c = sympy.integrate(d[i] * d[j], (t, 0, 1))
                    template_penalty_matrix[i, j] = c
                    template_penalty_matrix[j, i] = c

            cls._template_penalty_matrices[(poly_deg, derivative)] = template_penalty_matrix

        return cls._template_penalty_matrices[(poly_deg, derivative)]


class BSplineFitter:
    def __init__(self, data_points_x: np.ndarray, poly_deg: int, knots: np.ndarray,
                 penalty_derivatives: Iterable[int] = (1, 2, 3, 4)):
        self._penalty_derivatives = penalty_derivatives if penalty_derivatives is not None else (1, 2, 3)
        self._poly_deg = poly_deg

        self._a_matrices = {}

        self._A = self.calculate_transmission_matrix(data_points_x=data_points_x, knots=knots, poly_deg=poly_deg, derivative=0)
        self._A_tag = self.calculate_transmission_matrix(data_points_x=data_points_x, knots=knots, poly_deg=poly_deg, derivative=1)[[0,-1]]
        self._A_tagtag = self.calculate_transmission_matrix(data_points_x=data_points_x, knots=knots, poly_deg=poly_deg, derivative=2)[[0,-1]]

        self._penalty_matrices = {}
        for penalty_derivative in self._penalty_derivatives:
            template_penalty_matrix = BSplinesMatricesCalculator.calculate_template_penalty_matrix(poly_deg=poly_deg,
                                                                                                   derivative=self._penalty_derivatives[0])
            self._penalty_matrices[penalty_derivative] = \
                self.calculate_penalty_matrix(template_penalty_matrix=template_penalty_matrix,
                                              K=knots.shape[0],
                                              poly_deg=poly_deg)

    def fit(self, y: np.ndarray, y_tag_0: float, y_tagtag_0: float, importance: np.ndarray, w: Dict[int, float]):
        # remove from computation uninteresting points
        indices_to_keep = np.where(importance > 1e-5)[0]
        importance = importance[indices_to_keep]
        y = y[indices_to_keep]
        A = self._A[indices_to_keep]

        A = np.concatenate((self._A_tagtag, self._A_tag, A), axis=0)
        points_fitted = np.concatenate((np.array([y_tagtag_0, 0., y_tag_0, 0.]), y))
        importance = np.concatenate((np.array([1000., 1000., 1000., 1000.]), importance))
        # points_fitted = y

        sigma = np.diag(importance)
        m = A.T.dot(sigma)
        weighted_penalty_matrix = sum(w[derivative_idx] * self._penalty_matrices[derivative_idx] for derivative_idx, weight in w.items())
        ab = m.dot(A) + weighted_penalty_matrix
        b = m.dot(points_fitted)

        banded_ab = np.zeros((self._poly_deg, ab.shape[1]))
        for k in range(self._poly_deg):
            d = np.diag(ab, k)
            banded_ab[k, :d.size] = d

        # theta = solveh_banded(banded_ab, b, lower=True)
        theta = np.linalg.inv(ab).dot(b)

        return theta

    def calculate_penalty_matrix(self, template_penalty_matrix: np.ndarray, K: int, poly_deg: int):
        """
        :return:
        """
        penalty_matrix = np.zeros((K, K))

        for i in range(penalty_matrix.shape[0] - poly_deg):
            penalty_matrix[i:i + template_penalty_matrix.shape[0],
            i:i + template_penalty_matrix.shape[1]] += template_penalty_matrix

        return penalty_matrix

    @classmethod
    def calculate_transmission_matrix(cls, data_points_x: np.array, knots: np.array, poly_deg: int, derivative: int = 0):
        t = sympy.symbols('t')
        a_matrix = BSplinesMatricesCalculator.get_b_spline_poly_coeffs_matrix(poly_deg=poly_deg)
        tt = np.array([t ** n for n in range(poly_deg + 1)])[::-1]
        polynomials = a_matrix.dot(tt)

        poly_der = np.copy(polynomials)
        for i, poly in enumerate(polynomials):
            for _ in range(derivative):
                poly_der[i] = sympy.diff(poly_der[i], t)

        N = data_points_x.shape[0]
        K = N + poly_deg + 1
        A = np.zeros((N, K))
        knots_step = knots[1] - knots[0]
        for i, point_x in enumerate(data_points_x):
            normalized_x = (point_x / knots_step) % 1.
            until_knot = int((point_x - knots[0]) // knots_step) + 1
            from_knot = max(0, until_knot - poly_deg - 1)
            for knot_idx in range(from_knot, until_knot):
                A[i, knot_idx] = poly_der[until_knot - knot_idx - 1].subs({t: normalized_x})

        return A


# if __name__ == "__main__":
#
#     poly_deg = 3
#     data_points = np.array([[0, 1],
#                             [2.8, 3],
#                             [5, 1.5],
#                             [6.3, 1.9]])
#
#     knots = np.linspace(data_points[0, 0], data_points[-1, 0], data_points.shape[0])
#     knots_step = knots[1] - knots[0]
#     first_knot = (data_points[0, 0]//knots_step - poly_deg) * knots_step
#     knots = np.concatenate((np.arange(first_knot, knots[0] - 1e-3, knots_step), knots))
#
#     fitter = BSplineFitter(data_points_x=data_points[:, 0], poly_deg=poly_deg, knots=knots)
#
#     importance = np.ones(data_points.shape[0])
#     weights = {1: 0e-5, 2: 1e-5, 3: 0.0, 4: 0.}
#
#     initial_tag = 0.
#     initial_tagtag = 0.
#
#     theta = fitter.fit(y=data_points[:, 1],
#                        y_tag_0=initial_tag,
#                        y_tagtag_0=initial_tagtag,
#                        importance=importance,
#                        w=weights)


def concatenate_splines(spl1: UnivariateSpline, spl2: UnivariateSpline, adjust_knots_to_first: bool) -> UnivariateSpline:
    """
    Concatenate two univariate splines.
    :param spl1:
    :param spl2:
    :param adjust_knots_to_first: if True, adjust spl2 knots to spl1, otherwise adjust spl1 knots to spl2
    :return: merged spline
    """
    tck1 = spl1._eval_args
    tck2 = spl2._eval_args
    assert tck1[2] == tck2[2]
    k = tck1[2]
    knots1, coefs1, knots2, coefs2 = tck1[0], tck1[1], tck2[0], tck2[1]
    # make the knots to be continuous: the last knot of knots1 should coincide with first knot of knots2
    if adjust_knots_to_first:
        t = np.concatenate((knots1[:-k-1], knots2 + knots1[-1] - knots2[0]))
    else:
        t = np.concatenate((knots1[:-k-1] + knots2[0] - knots1[-1], knots2))
    c = np.concatenate((coefs1[:-k-1], coefs2))
    return UnivariateSpline._from_tck((t, c, k))


def insert_knot(spl: UnivariateSpline, new_knot: float) -> UnivariateSpline:
    """
    https://pages.mtu.edu/~shene/COURSES/cs3621/NOTES/spline/NURBS-knot-insert.html
    :param spl:
    :param new_knot:
    :return:
    """
    k = spl._eval_args[2]
    knots = spl._eval_args[0]
    coefs = spl._eval_args[1]
    i = np.searchsorted(knots, new_knot)

    new_knots = np.insert(knots, i, new_knot)
    new_coefs = np.insert(coefs, i-1, 0)

    a = (new_knot - knots[i-k:i]) / (knots[i:i+k] - knots[i-k:i])
    new_coefs[i-k:i] = (1 - a) * coefs[i-k-1:i-1] + a * coefs[i-k:i]

    new_spl = UnivariateSpline._from_tck((new_knots, new_coefs, k))
    return new_spl


def split_spline(spl: UnivariateSpline, s: float, spline2_from_zero: bool = False) -> [UnivariateSpline, UnivariateSpline]:
    """
    Split univariate spline in point s
    :param spl:
    :param s: splitting place
    :param spline2_from_zero: if True, move the knots of the second resulting spline to start from zero
    :return: two splines
    """
    k = spl._eval_args[2]
    knots = spl._eval_args[0]
    multiplicity = np.count_nonzero(knots == s)

    new_spl = copy.deepcopy(spl)
    for _ in range(k+1 - multiplicity):
        new_spl = insert_knot(new_spl, s)

    knots = new_spl._eval_args[0]
    coefs = new_spl._eval_args[1]
    i = np.searchsorted(knots, s)
    knots1 = knots[:i+k+1]
    if spline2_from_zero:
        knots2 = knots[i:] - knots[i]
    else:
        knots2 = knots[i:]

    coefs1 = coefs[:i+k+1]
    coefs2 = coefs[i:]

    spl1 = UnivariateSpline._from_tck((knots1, coefs1, k))
    spl2 = UnivariateSpline._from_tck((knots2, coefs2, k))
    return spl1, spl2


if __name__ == "__main__":
    st = time.time()
    x = np.array([-0.02, -0.01, 0., 2.8, 5, 6.3])
    y = np.array([1., 1., 1., 2, 1.5, 1.9])
    w = np.array([10000, 10000, 10000, 1, 1, 1])
    t = []
    s = 0.5
    if len(t) > 0:
        tk = splrep(x, y, w=w, s=s, t=t)
        plt.title('t = ' + str(t))
    else:
        tk = splrep(x, y, w=w, s=s)
        plt.title('automatic')
    #print(time.time() - st)
    xx = np.linspace(x[0], x[-1], 100)
    yy = splev(xx, tk, der=0)
    plt.plot(x, y, '*')
    plt.plot(xx, yy)
    plt.show()
    print(tk[0])
