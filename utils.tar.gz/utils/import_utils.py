import inspect
import pkgutil
from pydoc import locate
from typing import Dict, Callable


def dynamic_import_from_package(package_path: str, predicate: Callable[[type], bool] = None) -> Dict[str, type]:
    """
    This function imports dynamically all concrete classes that are located in a specific package (only one level is
    currently supported)
    :param package_path: package path that contains all the  classes that should be imported
    :param predicate: predicate that returns True for all classes that should be imported
    :return: Dictionary with classes' names as keys and actual classes as values
    """
    modules = [package_path + "." + module.name for module in pkgutil.iter_modules(locate(package_path).__path__)]

    if predicate is None:
        predicate = lambda x: True

    # Goes over all modules and load all concrete classes that fit the input predicate
    classes = {}
    for module in modules:
        members = inspect.getmembers(locate(module))

        # Go over all members of this module to find relevant analyzers
        for name, cls in members:

            # If the current member is a concrete class and derives from BaseAnalyzer we add it to the dictionary of
            # analyzers
            if inspect.isclass(cls) and not inspect.isabstract(cls) and predicate(cls) and name not in classes:
                classes[name] = cls

    return classes
