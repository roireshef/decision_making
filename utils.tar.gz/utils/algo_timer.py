import time
from threading import Lock
from typing import NamedTuple
import io

from tabulate import tabulate

from subdivision_planner.src.common.singleton import singleton


class RunTime(NamedTuple):
    mean: float = 0.0
    std: float = 0.0
    total: float = 0.0


# TODO: Make AlgoTimer implementation optionally have a list of times so we can debug issues of inconsistent timings
class AlgoTimerImplementation:

    """
    Please use the Singleton AlgoTimer instead of the class
    
    example:
        AlgoTimer().start('foo')
        foo()
        AlgoTimer().stop('foo')
    
        ....
        
        print(AlgoTimer())
    """

    def __init__(self):
        self.timers = dict()
        self.lock = Lock()
        self._memory_size = 1000

    def start(self, timer_name: str):
        with self.lock:
            if timer_name not in self.timers:
                self.timers[timer_name] = {"start_time": None, "average": 0., 'counter': 0, "total_time": 0.}
            current_timer = self.timers[timer_name]
            current_timer["start_time"] = time.time()

    def stop(self, timer_name: str):
        end_time = time.time()
        with self.lock:
            if timer_name not in self.timers:
                raise ValueError('Error: unknown timer: %s' % timer_name)
            current_timer = self.timers[timer_name]
            if current_timer["start_time"] is None:
                raise ValueError("Call stop before start for time: {}".format(timer_name))
            current_timer["counter"] += 1
            n = min(current_timer["counter"], self._memory_size)
            diff = end_time - current_timer["start_time"]
            current_timer["average"] += 1 / n * (diff - current_timer["average"])
            current_timer["total_time"] += diff
            current_timer["start_time"] = None

    def reset(self):
        self.timers = dict()

    def __str__(self):
        data = []
        for timer_name, current_timer in self.timers.items():
            if current_timer["counter"] > 0:
                data.append(
                    [
                        timer_name,
                        current_timer["counter"],
                        f"{current_timer['average']:.4f}",
                        f"{current_timer['total_time']:.4f}",
                    ]
                )
        return tabulate(
            data, headers=["Name", "Iterations", "Average", "Total"], tablefmt="github"
        )

    def get_runtime_values(self, timer_name: str) -> RunTime:

        with self.lock:

            if timer_name not in self.timers:
                return RunTime()

            curr_timer = self.timers[timer_name]

        return RunTime(mean=curr_timer["average"],
                       total=curr_timer["total_time"])


@singleton
class AlgoTimer(AlgoTimerImplementation):
    pass
