import copy
import itertools
from typing import List, Optional, Tuple, Iterable

import numpy as np
from cachetools import cached, LRUCache
from cachetools.keys import hashkey
from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.types import CartesianState, FrenetState2D
from subdivision_planner.src.data_structures.actor import Actor, ActorRelativeLongitudinalPosition
from subdivision_planner.src.data_structures.frenet_serret_frame import FrenetSerret2DFrame
from subdivision_planner.src.data_structures.lane_sequence import LaneSequence
from subdivision_planner.src.data_structures.map import Map
from subdivision_planner.src.data_structures.map_elements.lane_segment import LaneConnectivityType
from subdivision_planner.src.mdp.state import MDPState, MDPContextImp
from subdivision_planner.src.messages.scene_static_enums import MapLaneClass
from subdivision_planner.src.utils.map.map_utils import MapUtils


class ActorUtils:

    @staticmethod
    def _get_relative_heading(frenet_frame: FrenetSerret2DFrame, cstate: CartesianState,
                              preconverted_fstate: Optional[FrenetState2D] = None):
        """
        Get relative heading of a cartesian state with respect to a frenet frame
        :param frenet_frame:
        :param cstate:
        :param preconverted_fstate
        :return:
        """
        if preconverted_fstate is None:
            preconverted_fstate = frenet_frame.cstate_to_fstate(cstate, raise_on_points_out_of_frame=False)

        if np.isnan(preconverted_fstate).any():
            # Unable to place actor on GFF
            return np.nan

        road_yaw = frenet_frame.get_yaw(np.array([preconverted_fstate[types.FS_SX]]))[0]
        return (cstate[types.C_YAW] - road_yaw + np.pi) % (2 * np.pi) - np.pi

    @staticmethod
    @cached(
        cache=LRUCache(maxsize=256),
        key=lambda actors, gff, t: hashkey((hash(actors), hash(gff), t)),
    )
    def _generate_actors_fstates_at_time(actors: Tuple[Actor, ...], gff: LaneSequence, t: float) -> List[FrenetState2D]:
        """
        Get fstates of actors at time t without calling actor.fstates, which converts all cstates->fstates
        :param actors:
        :param gff:
        :param t:
        :return: List of valid actors and array of their fstates at time t
        """

        valid_time_actors_mask = [actor.has_time(t) for actor in actors]
        valid_time_actors = list(itertools.compress(actors, valid_time_actors_mask))

        # Initialize fstates to nan. Invalid actors will return all nan.
        actor_initial_fstates = np.full((len(actors), 6), np.nan)

        if len(valid_time_actors) > 0:
            valid_actor_cstates = [actor.get_cstate(t) for actor in valid_time_actors]
            # Convert all cstates-> fstates for all actors with one call
            valid_actor_fstates = gff.ctrajectory_to_ftrajectory(np.array(valid_actor_cstates),
                                                                 raise_on_points_out_of_frame=False)

            # Fill in valid fstates that were calculated.
            actor_initial_fstates[valid_time_actors_mask] = valid_actor_fstates

        return list(actor_initial_fstates)

    @staticmethod
    @cached(
        cache=LRUCache(maxsize=64),
        key=lambda actors, gff, timestamp: hashkey((hash(actors), hash(gff), timestamp)),
    )
    def _get_sorted_actor_fstate_at_timestamp(actors: Tuple[Actor, ...], gff: LaneSequence, timestamp: float) \
            -> Tuple[List[int], List[FrenetState2D]]:
        """
        Takes all actors that have data during timestamp and sorts them by initial s distance on the provided GFF.
        This method does not call actor.fstates, which converts all cstates->fstates for the actor.
        :param actors:
        :param gff: GFF to project actors on
        :param timestamp: timestamp at which to sample the actor fstates
        :return: List of (actor index, initial fstate) sorted by the initial fstate FS_SX
        """
        actors = tuple([actor for actor in actors if actor.is_vehicle])

        # Batch convert initial fstates for actors
        actor_initial_fstates = np.array(ActorUtils._generate_actors_fstates_at_time(actors, gff, timestamp))

        if len(actor_initial_fstates) == 0:
            # No valid actors
            return [], []

        # Filter out invalid actors
        valid_idx = np.where(~np.isnan(actor_initial_fstates).any(axis=1))[0]

        if len(valid_idx) == 0:
            # All actors contain fstates with nan
            return [], []

        valid_actor_fstates = actor_initial_fstates[valid_idx, :]

        # Create list of tuples of (actor, initial_s)
        actor_initial_fstate_tuples = [(indx, actor_fstate) for indx, actor_fstate in
                                       zip(valid_idx, valid_actor_fstates)]

        # Sort list of actors by s distance on gff
        actor_initial_fstate_tuples.sort(key=lambda tup: tup[1][types.FS_SX])

        return tuple(map(list, zip(*actor_initial_fstate_tuples)))

    @staticmethod
    def are_actors_in_lanes(actors: Iterable[Actor], lane_ids: Tuple[int]) -> np.ndarray:
        """
        Returns a boolean mask. True if any of an actor's initial lane hypotheses are in the provided lane_ids.
        :param actors:
        :param lane_ids:
        :return:
        """
        return np.array([any(
            lane_id in actor.invasion and actor.invasion[lane_id] > Config().driving.permitted_lane_invasion_of_actor
            for lane_id in lane_ids)
                         for actor in actors])

    @staticmethod
    def are_actors_in_gffs(actors: Iterable[Actor], gffs: Tuple[LaneSequence, ...]) -> np.ndarray:
        """
        Returns a boolean mask. True if any of an actor's initial lane hypotheses are in the provided gffs.
        :param actors:
        :param gffs:
        :return:
        """
        return np.array(
            [any(gff in actor.invasion and actor.invasion[gff] > Config().driving.permitted_lane_invasion_of_actor
                 for gff in gffs)
             for actor in actors])

    @staticmethod
    def are_actors_parked(actors: Iterable[Actor]) -> np.ndarray:
        """
        Returns a boolean mask. True if an actor is parked.
        :param actors:
        :return:
        """
        return np.array([actor.is_parked for actor in actors], dtype=np.bool)

    @staticmethod
    def are_actors_valid_at_time(actors: Iterable[Actor], state: MDPState, gff: LaneSequence):
        """
        Returns a boolean mask. True if the actor's fstates at the state's timestamp does not contain any Nans.
        """
        actor_fstates_at_timestamp = ActorUtils._generate_actors_fstates_at_time(tuple(actors), gff, state.timestamp)
        # Force array to be 2d, even if there is only one actor.
        actor_fstates_at_timestamp = np.atleast_2d(actor_fstates_at_timestamp)
        return ~np.isnan(actor_fstates_at_timestamp).any(axis=1)

    @staticmethod
    def _get_actors_relative_longitudinal_position(actors: Tuple[Actor, ...], ego_fstate: FrenetState2D, timestamp: float,
                                                   gff: LaneSequence) -> List[ActorRelativeLongitudinalPosition]:
        """
        Return list of ActorRelativeLongitudinalPositions based on the actor's relative position to the ego_fstate at the provided timetamp.
        Ahead if is greater than the ego's s position + half the ego length on that gff during state.timestamp.
        :param actors: list of actors whose relative longitudinal positions will be calculated.
        :param ego_fstate: ego's fstate on the provided gff at the provided timestamp.
        :param timestamp: timestamp at which to sample the actor positions. This should correspond to ego_fstate.
        :param gff: The GFF on which the actor's will be projected onto. The ego_fstate should be on this GFF.
        :return:
        """
        ego_s = ego_fstate[types.FS_SX]

        # Generate actor fstates without call to actor.get_fstate
        actor_fstates = ActorUtils._generate_actors_fstates_at_time(tuple(actors), gff, timestamp)

        # Actor is ahead if an its s position - half its length on the provided GFF
        # is greater than the ego's s position + half the ego length on that gff during state.timestamp.
        actors_ahead_mask = np.array(
            [actor_fstate[types.FS_SX] - actor.get_size(timestamp)[0] / 2 > ego_s + Config().ego.size[0] / 2
             if not np.isnan(actor_fstate[types.FS_SX]) else False
             for actor, actor_fstate in zip(actors, actor_fstates)])

        # Actor is behind if an actor's s position + half its length on the provided GFF
        # is less than the ego's s position - half the ego length on that gff during state.timestamp.
        actors_behind_mask = np.array(
            [actor_fstate[types.FS_SX] + actor.get_size(timestamp)[0] / 2 < ego_s - Config().ego.size[0] / 2
             if not np.isnan(actor_fstate[types.FS_SX]) else False
             for actor, actor_fstate in zip(actors, actor_fstates)])

        # Actors are intersecting if they are in the deadband between ahead and behind.
        # Generate list of ActorRelativeLongitudinalPositions
        return [ActorRelativeLongitudinalPosition.Ahead if is_ahead else
                ActorRelativeLongitudinalPosition.Behind if is_behind else
                ActorRelativeLongitudinalPosition.Intersecting
                for is_ahead, is_behind in zip(actors_ahead_mask, actors_behind_mask)]

    @staticmethod
    def _get_actors_relative_longitudinal_position_from_state(actors: Iterable[Actor], state: MDPState,
                                                              gff: LaneSequence) \
            -> List[ActorRelativeLongitudinalPosition]:
        """
        Return of ActorRelativeLongitudinalPositions based on the actor's relative position to the ego at the provided state.
        :param actors:
        :param state:
        :param gff:
        :return:
        """
        # Get ego fstate on the provided GFF
        ego_fstate_on_gff = state.frenet_state if state.gff == gff else \
            gff.cstate_to_fstate(state.cartesian_state, raise_on_points_out_of_frame=False)

        relative_positions = ActorUtils._get_actors_relative_longitudinal_position(actors=tuple(actors),
                                                                                   ego_fstate=ego_fstate_on_gff,
                                                                                   timestamp=state.timestamp,
                                                                                   gff=gff)
        return relative_positions

    @staticmethod
    def are_actors_ahead(actors: Iterable[Actor], state: MDPState, gff: LaneSequence) -> np.ndarray:
        """
        Returns a boolean mask. True if an actor's s position - half its length on the provided GFF
        is greater than the ego's s position + half the ego length on that gff during state.timestamp.
        Note: this is not equal to ~are_actors_behind due to the vehicle length buffers
        :param actors:
        :param state:
        :param gff:
        :return:
        """
        relative_positions = ActorUtils._get_actors_relative_longitudinal_position_from_state(actors, state, gff)
        return np.array([pos == ActorRelativeLongitudinalPosition.Ahead for pos in relative_positions])

    @staticmethod
    def are_actors_behind(actors: Iterable[Actor], state: MDPState, gff: LaneSequence) -> np.ndarray:
        """
        Returns a boolean mask. True if an actor's s position + half its length on the provided GFF
        is less than the ego's s position - half the ego length on that gff during state.timestamp.
        Note: this is not equal to ~are_actors_ahead, due to the vehicle length buffers
        :param actors:
        :param state:
        :param gff:
        :return:
        """
        relative_positions = ActorUtils._get_actors_relative_longitudinal_position_from_state(actors, state, gff)
        return np.array([pos == ActorRelativeLongitudinalPosition.Behind for pos in relative_positions])

    @staticmethod
    def are_actors_alongside(actors: Iterable[Actor], state: MDPState, gff: LaneSequence) -> np.ndarray:
        """
        Returns a boolean mask. True if an actor's s position on the gff intersects with the vehicles s position.
        This is equivalent to ~are_actors_behind && ~are_actors_ahead
        Note: this is not equal to ~are_actors_ahead, due to the vehicle length buffers
        :param actors:
        :param state:
        :param gff:
        :return:
        """
        relative_positions = ActorUtils._get_actors_relative_longitudinal_position_from_state(actors, state, gff)
        return np.array([pos == ActorRelativeLongitudinalPosition.Intersecting for pos in relative_positions])

    @staticmethod
    def are_actors_oncoming(context: MDPContextImp, actors: Iterable[Actor], state: MDPState) -> np.ndarray:
        """
        Returns a boolean mask. True if an actor is oncoming relative to the ego.
        In subdivisions, an oncoming may have an oncoming heading or negative velocity.
        In highways, only heading is considered.
        :param context: MDPContext
        :param actors:
        :param state:
        :return:
        """
        # Convert to tuple since actors may be an iterator, which may be exhausted by generate_actors_fstates_at_time
        actors = tuple(actors)
        gff = state.gff

        ego_lane_idxs = np.where(gff.segment_ids == state.lane_id)[0]
        if len(ego_lane_idxs) == 0:  # should not happen
            return np.zeros(len(actors)).astype(bool)
        ego_lane_idx = ego_lane_idxs[0]

        # find the closest intersection with turn left/right and look for oncoming until this turn, if the turn exists
        until_idx = len(gff.segment_ids)
        for i, lane_id in enumerate(gff.segment_ids[ego_lane_idx:-1]):
            downstream = context.map.get_lane_segment_by_id(lane_id).get_downstream_lanes_connectivity()
            conn_types = [conn.connectivity_type for conn in downstream if conn.lane_id == gff.segment_ids[ego_lane_idx+i+1]]
            if conn_types and conn_types[0] in [LaneConnectivityType.LEFT_TURN_CONNECTION, LaneConnectivityType.RIGHT_TURN_CONNECTION]:
                until_idx = ego_lane_idx + i + 1
                break

        # If actor fstates are not provided, generate fstates without call to actor.get_fstate
        actor_fstates_at_timestamp = ActorUtils._generate_actors_fstates_at_time(actors, gff, context.timestamp)

        def is_oncoming(actor: Actor, precalculated_fstate: FrenetState2D, t: float) -> bool:
            """Inner method to determine if an actor is oncoming"""
            if actor.is_parked:
                return False
            if not actor.has_time(t):
                return False
            if np.isnan(precalculated_fstate).any():
                return False

            # if the actor does not invade to gff, it is not oncoming
            if not ActorUtils.are_actors_in_lanes([actor], gff.segment_ids[ego_lane_idx:until_idx])[0]:
                return False
            # decide according to its heading
            actor_cstate = actor.get_cstate(t)
            return ActorUtils.is_oncoming_heading(gff, actor_cstate, precalculated_fstate)

        return np.array([is_oncoming(actor, actor_fstate, context.timestamp)
                         for actor, actor_fstate in zip(actors, actor_fstates_at_timestamp)])

    @staticmethod
    def is_oncoming_heading(gff: FrenetSerret2DFrame, actor_cstate: CartesianState, precalculated_fstate: FrenetState2D) -> bool:
        # decide according to its heading
        heading = ActorUtils._get_relative_heading(gff, actor_cstate, precalculated_fstate)
        # heading should be inside interval [pi - x, pi + x]
        return abs(heading % (2*np.pi) - np.pi) < Config().driving.oncoming_heading_threshold

    @staticmethod
    @cached(
        cache=LRUCache(maxsize=32),
        key=lambda context, actors, gff, timestamp, k_ahead, k_behind, include_intersecting, ego_fstate=None: hashkey(
            (context.id, hash(actors), hash(gff), timestamp, k_ahead, k_behind, include_intersecting, ego_fstate)),
    )
    def _get_closest_k_constraining_dynamic_actors(context: MDPContextImp, actors: Tuple[Actor, ...], gff: LaneSequence, timestamp: float,
                                                   k_ahead: int, k_behind: int, include_intersecting: bool,
                                                   ego_fstate: Optional[Tuple[float]] = None) \
            -> Tuple[List[int], List[int], List[int]]:
        """
        Finds the k closest ahead and k closest behind constraining dynamic actors on the provided GFF, and lanes that merge into the GFF.
        The ego and actor positions at the root state are used. If desired, all intersecting actors are returned as well. Intersecting
        actors meet one of the following conditions:
            1. actor_s + actor_half_length >= ego_s - ego_half_length
            2. actor_s - actor_half_length <= ego_s + ego_half_length
        :param context:
        :param actors:
        :param gff:
        :param timestamp:
        :param k_ahead:
        :param k_behind:
        :param include_intersecting:
        :param ego_fstate: Must be supplied if the timestamp is not the same as the root state time.
        :return: List of k closest actor ids ahead, list of k closest actor ids behind, and a list of all intersecting actor ids with the ego. The
                 size of the first two arrays may be less than k_ahead/k_behind if not enough actors are available. The actors ahead and
                 actors behind are sorted by their proximity to the ego. For actors ahead, this means lowest s value to highest. For
                 actors behind, this means highest s value to lowest. The intersecting actors are sorted from lowest s value to highest.
        """

        # Sorted list of tuples of (Actor, initial_s_dist) - this method should have a cached result
        sorted_actor_indx, sorted_actors_initial_fstates = ActorUtils._get_sorted_actor_fstate_at_timestamp(actors,
                                                                                                        gff, timestamp)

        if len(sorted_actor_indx) == 0:
            # No actors
            return [], [], []

        sorted_actors = np.array(actors)[sorted_actor_indx]

        # Do cheap checks that do not involve calculating actor fstates
        merging_lanes = list(MapUtils.get_merging_lane_ids_and_limits(gff, context.map).keys())
        lanes_to_check = merging_lanes + list(gff.segment_ids)

        # Ignore actors outside the gff+merging lanes and parked cars
        initial_checks_mask = ActorUtils.are_actors_in_lanes(sorted_actors, tuple(lanes_to_check)) \
                              & np.invert(ActorUtils.are_actors_parked(sorted_actors))

        sorted_actors = list(itertools.compress(sorted_actors, initial_checks_mask))

        assert not (ego_fstate is None and timestamp!=context.timestamp), "The ego_fstate is required if not using the root state"
        is_from_root_state = timestamp == context.timestamp and ego_fstate is None

        # Take precalculated relative positions if the timestamp and ego_fstate are the root state's.
        if is_from_root_state:
            # Determine actors ahead and behind
            ahead_actors_mask = np.array([actor.relative_longitudinal_position == ActorRelativeLongitudinalPosition.Ahead for actor in sorted_actors])
            behind_actors_mask = np.array([actor.relative_longitudinal_position == ActorRelativeLongitudinalPosition.Behind for actor in sorted_actors])
            intersecting_actors_mask = np.array([actor.relative_longitudinal_position == ActorRelativeLongitudinalPosition.Intersecting for actor in sorted_actors])

        # Otherwise calculate them based on the provided ego_fstate
        else:
            actor_relative_longitudinal_positions = ActorUtils._get_actors_relative_longitudinal_position(sorted_actors, ego_fstate, timestamp, gff)
            ahead_actors_mask = np.array([pos == ActorRelativeLongitudinalPosition.Ahead for pos in actor_relative_longitudinal_positions])
            behind_actors_mask = np.array([pos == ActorRelativeLongitudinalPosition.Behind for pos in actor_relative_longitudinal_positions])
            intersecting_actors_mask = np.array([pos == ActorRelativeLongitudinalPosition.Intersecting for pos in actor_relative_longitudinal_positions])

        constraining_actors_ahead_ids = []
        constraining_actors_behind_ids = []
        constraining_actors_intersecting_ids = []

        def check_constraining_actor_validity(actor: Actor) -> bool:
            """Helper method to do initial validity checks for constraining dynamic actors"""
            # Validate actor has valid fstates on gff
            actor_fstates = actor.fstates(gff, strict=False)
            if np.all(np.isnan(actor_fstates)):
                # actor can not projected to the given gff
                return False

            # Get times without nan
            valid_indices = np.logical_not(np.any(np.isnan(actor_fstates), axis=-1))
            valid_times = actor.times[valid_indices]

            # Check actor headings
            relative_headings = actor.get_relative_headings(gff, valid_times)
            velocities = actor.get_fstates(gff, valid_times)[:, types.FS_SV]

            threshold = Config().driving.static_vehicle_vel_threshold

            # Ignore actors that have flipped headings that are moving (they are likely ghost vehicles)
            # Don't ignore actors with flipped headings that are stopped
            if np.any(np.logical_and(
                    np.abs(velocities) > threshold,
                    np.abs(relative_headings) > 0.5 * np.pi)):
                # actor is moving and has an oncoming heading
                return False
            # Passed all checks
            return True

        # Validate actors - expensive actor.get_fstates is called here
        for actor_ahead in itertools.compress(sorted_actors, ahead_actors_mask):

            # Exit when desired k is met
            if len(constraining_actors_ahead_ids) >= k_ahead:
                break
            if not check_constraining_actor_validity(actor_ahead):
                continue
            constraining_actors_ahead_ids.append(actor_ahead.id)

        # Reverse behind actors list, since we want the closest backwards actors
        for actor_behind in reversed(list(itertools.compress(sorted_actors, behind_actors_mask))):

            # Exit when desired k is met
            if len(constraining_actors_behind_ids) >= k_behind:
                break
            if not check_constraining_actor_validity(actor_behind):
                continue
            constraining_actors_behind_ids.append(actor_behind.id)

        if include_intersecting:
            for actor_intersecting in itertools.compress(sorted_actors, intersecting_actors_mask):
                if not check_constraining_actor_validity(actor_intersecting):
                    continue
                constraining_actors_intersecting_ids.append(actor_intersecting.id)

        return constraining_actors_ahead_ids, constraining_actors_behind_ids, constraining_actors_intersecting_ids

    @staticmethod
    def get_closest_k_constraining_dynamic_actors_at_root_state(context: MDPContextImp, actors: Tuple[Actor, ...], gff: LaneSequence,
                                                                k_ahead: int, k_behind: int = 0,
                                                                include_intersecting: bool = False) \
            -> Tuple[List[Actor], List[Actor], List[Actor]]:
        """
        Finds the k closest ahead and k closest behind constraining dynamic actors on the provided GFF, and lanes that merge into the GFF.
        The ego and actor positions at the root state are used. If desired, all intersecting actors are returned as well. Intersecting
        actors meet one of the following conditions:
            1. actor_s + actor_half_length >= ego_s - ego_half_length
            2. actor_s - actor_half_length <= ego_s + ego_half_length
        :param actors:
        :param context:
        :param gff:
        :param k_ahead:
        :param k_behind:
        :param include_intersecting:
        :return: List of k closest actors ahead, list of k closest actors behind, and a list of all intersecting actors with the ego. The
                 size of the first two arrays may be less than k_ahead/k_behind if not enough actors are available. The actors ahead and
                 actors behind are sorted by their proximity to the ego. For actors ahead, this means lowest s value to highest. For
                 actors behind, this means highest s value to lowest. The intersecting actors are sorted from lowest s value to highest.
        """
        constraining_actor_ids_ahead, constraining_actor_ids_behind, constraining_actor_ids_intersecting = \
            ActorUtils._get_closest_k_constraining_dynamic_actors(
                context=context,
                actors=actors,
                gff=gff,
                timestamp=context.timestamp, k_ahead=k_ahead,
                k_behind=k_behind,
                include_intersecting=include_intersecting
            )

        actor_indices = [a.id for a in actors]

        constraining_actors_ahead = [actors[actor_indices.index(actor_id)] for actor_id in constraining_actor_ids_ahead]

        # Overwrite initial negative speeds if actor was detected with negative speeds
        for i, actor_ahead in enumerate(constraining_actors_ahead):
            actor_fstates = actor_ahead.get_fstates(gff, actor_ahead.times, strict=False)
            if np.any(actor_fstates[0:min(10, actor_fstates.shape[0]), types.FS_SV] < -1e-3):
                # Replace original actor with corrected actor
                constraining_actors_ahead[i] = ActorUtils._correct_negative_velocity_actor(context, actor_ahead, context.map, gff)

        constraining_actors_behind = [actors[actor_indices.index(actor_id)] for actor_id in constraining_actor_ids_behind]
        constraining_actors_intersecting = [actors[actor_indices.index(actor_id)] for actor_id in constraining_actor_ids_intersecting]

        return constraining_actors_ahead, constraining_actors_behind, constraining_actors_intersecting

    @staticmethod
    def get_closest_k_constraining_dynamic_actors_at_time(context: MDPContextImp, actors: Tuple[Actor, ...], gff: LaneSequence,
                                                          ego_fstate: Tuple[float], timestamp: float, k_ahead: int,
                                                          k_behind: int = 0, include_intersecting: bool = False) \
            -> Tuple[List[Actor], List[Actor], List[Actor]]:
        """
        Finds the k closest ahead and k closest behind constraining dynamic actors on the provided GFF, and lanes that merge into the GFF.
        The provided ego position and actor positions at the provided timestamp. If desired, all intersecting actors are returned as well. Intersecting
        actors meet one of the following conditions:
            1. actor_s + actor_half_length >= ego_s - ego_half_length
            2. actor_s - actor_half_length <= ego_s + ego_half_length
        :param context:
        :param actors:
        :param gff:
        :param ego_fstate: ego position at the provided timestamp. Note that this is passed as a Tuple instead of ndarray - done for caching
        :param timestamp: timestamp at which to sample the actors
        :param k_ahead:
        :param k_behind:
        :param include_intersecting:
        :return: List of k closest actors ahead, list of k closest actors behind, and a list of all intersecting actors with the ego. The
                 size of the first two arrays may be less than k_ahead/k_behind if not enough actors are available. The actors ahead and
                 actors behind are sorted by their proximity to the ego. For actors ahead, this means lowest s value to highest. For
                 actors behind, this means highest s value to lowest. The intersecting actors are sorted from lowest s value to highest.
        """
        constraining_actor_ids_ahead, constraining_actor_ids_behind, constraining_actor_ids_intersecting = \
            ActorUtils._get_closest_k_constraining_dynamic_actors(
                context=context,
                actors=actors,
                gff=gff,
                timestamp=timestamp,
                ego_fstate=ego_fstate,
                k_ahead=k_ahead,
                k_behind=k_behind,
                include_intersecting=include_intersecting
            )

        actor_indices = [a.id for a in actors]

        constraining_actors_ahead = [actors[actor_indices.index(actor_id)] for actor_id in constraining_actor_ids_ahead]

        # Overwrite initial negative speeds if actor was detected with negative speeds
        for i, actor_ahead in enumerate(constraining_actors_ahead):
            actor_fstates = actor_ahead.get_fstates(gff, actor_ahead.times, strict=False)
            if np.any(actor_fstates[0:min(10, actor_fstates.shape[0]), types.FS_SV] < -1e-3):
                # Replace original actor with corrected actor
                constraining_actors_ahead[i] = ActorUtils._correct_negative_velocity_actor(context, actor_ahead, context.map, gff)

        constraining_actors_behind = [actors[actor_indices.index(actor_id)] for actor_id in
                                      constraining_actor_ids_behind]
        constraining_actors_intersecting = [actors[actor_indices.index(actor_id)] for actor_id in
                                            constraining_actor_ids_intersecting]

        return constraining_actors_ahead, constraining_actors_behind, constraining_actors_intersecting

    @staticmethod
    def _correct_negative_velocity_actor(context: MDPContextImp, actor: Actor, map: Map, gff: LaneSequence) -> Actor:
        """
         Takes an actor with negative velocities and corrects it's trajectory to reflect 0 velocity.
         This will only be done if any of the actor's points from its creation to the current time have negative velocities,
         it's lane is not bidirectional, and the actor does not have an oncoming heading.
         :param context:
         :param actor:
         :param map:
         :param gff:
         :return:
         """
        # Don't modify the original actor object
        actor = copy.deepcopy(actor)

        # Check actor's fstates from its creation to the current time to maintain consistency
        times_to_check = np.arange(actor.start_time, context.timestamp + 0.01, Config().mcts.determinization_dt)
        actor_fstates = actor.get_fstates(gff=gff, t=times_to_check, strict=False)

        if np.all(np.isnan(actor_fstates)):
            # actor has invalid fstates, so skip corrections
            return actor

        # Check if actor has negative velocities
        if np.any(actor_fstates[:, types.FS_SV] < -1e-3):
            # Don't correct actors with negative velocities if they are in bidirectional lanes
            in_bidirectional_lane = any(
                [
                    map.has_lane_id(lane_id)
                    and (MapLaneClass.BidirectionalLane in map.get_lane_segment_by_id(lane_id).lane_classes
                    or not MapLaneClass.OneWay in map.get_lane_segment_by_id(lane_id).lane_classes)
                    for lane_id in actor.initial_hypothesis_lane_ids
                ]
            )
            if not in_bidirectional_lane:
                # Do correction only if actor's heading is the lane's direction
                actor_headings = actor.get_relative_headings(gff, times_to_check)
                if np.all(np.abs(actor_headings) < 0.5 * np.pi):
                    # Reset cached fstates
                    actor._fstates_dict = {}
                    # Correct actor cstates by assuming it is stopped
                    actor_initial_cstate = actor.get_cstate(actor.times[0])
                    actor_initial_cstate[types.C_V] = 0
                    actor_initial_cstate[types.C_A] = 0
                    # Stack stopped cstates and overwrite actor's cstates
                    actor._cstates = np.repeat(actor_initial_cstate[np.newaxis, ...], len(actor.times), axis=0)

                    # Regenerate fstates
                    actor.fstates(gff, strict=False)
        return actor

    @staticmethod
    @cached(
        cache=LRUCache(maxsize=128),
        key=lambda context, state: hashkey((context.id, state.id)),
    )
    def get_closest_oncoming_actor(context: MDPContextImp, state: MDPState) -> Optional[Actor]:
        """
        Find closest oncoming actor in front of the ego during state.timestamp.
        :param context: context
        :param state:
        :return: closest oncoming actor
        """
        # This should have a cached result
        sorted_actor_indx, sorted_actors_initial_fstates = ActorUtils._get_sorted_actor_fstate_at_timestamp(state.get_actors(),
                                                                                                        state.gff,
                                                                                                        context.timestamp)
        if len(sorted_actor_indx) == 0:
            return None

        sorted_actors = np.array(state.get_actors())[sorted_actor_indx]

        are_actors_oncoming = ActorUtils.are_actors_oncoming(context, sorted_actors, state)
        are_actors_in_gff = ActorUtils.are_actors_in_gffs(sorted_actors, (state.gff,))
        are_actors_ahead = ActorUtils.are_actors_ahead(sorted_actors, state, state.gff)

        oncoming_actors_ahead_mask = are_actors_oncoming \
                                     & are_actors_in_gff \
                                     & are_actors_ahead

        if not np.any(oncoming_actors_ahead_mask):
            # No oncoming actors ahead
            return None

        # Since the actors are sorted by s position, take the first valid one
        closest_oncoming_idx = np.where(oncoming_actors_ahead_mask)[0][0]
        return sorted_actors[closest_oncoming_idx]

    @staticmethod
    def should_stray_right(context: MDPContextImp, state: MDPState) -> bool:
        """
        Decide whether we need to react to oncoming traffic.
        Stray if:
          0. In subdivision.
          1. oncoming actor exists - ahead of ego, coming towards ego
        :param context:
        :param state: MDP state
        :return: whether to react to dynamic actor
        """
        if not context.map.get_lane_segment_by_id(state.lane_id).is_local_unmarked_two_way:
            return False

        oncoming_actor = ActorUtils.get_closest_oncoming_actor(context, state)

        if oncoming_actor is None or not Config().driving.react_to_oncoming_traffic:
            return False

        return True
