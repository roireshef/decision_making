from typing import List

from cachetools import Cache


class CachePool:
    """
    A singleton to maintain all lru caches so that they can be cleared at once
    """
    _cache_list: List[Cache] = []

    @classmethod
    def register_cache(cls, cache: Cache):
        cls._cache_list.append(cache)
        return cache

    @classmethod
    def clear(cls) -> None:
        for cache in cls._cache_list:
            cache.clear()
