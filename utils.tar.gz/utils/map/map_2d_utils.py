from cachetools import cached, LRUCache
from cachetools.keys import hashkey
from typing import Tuple, List

import cv2
import numpy as np
from subdivision_planner.src.data_structures.map import LaneSegment
from subdivision_planner.src.utils.algo_timer import AlgoTimer
from subdivision_planner.src.utils.math_utils import RigidTransform2D


@cached(
    cache=LRUCache(maxsize=128),
    key=lambda lane_segments, longitudinal_resolution, lateral_resolution, origin_coordinates, orientation, longitudinal_range, lateral_range, inherent_resolution=0.25, lane_id=None: hashkey(
        (lane_segments, longitudinal_resolution, lateral_resolution, origin_coordinates, orientation, longitudinal_range, lateral_range, inherent_resolution, lane_id)),
)
def create_lane_bev_map(lane_segments: Tuple[LaneSegment],
                        longitudinal_resolution: float,
                        lateral_resolution: float,
                        origin_coordinates: Tuple[float, float],
                        orientation: float,
                        longitudinal_range: Tuple[float, float],
                        lateral_range: Tuple[float, float],
                        inherent_resolution: float = 0.25,
                        lane_id: int = None):
    """
    Creates a top view image of the lane in cartesian coordinates aligned according to input. For generation of this
    image, one should give an origin coordinates and orientation (in radians) and a range of lateral and longitudinal
    range values. e.g. If input is ego cartesian coordinates and orientation we get the top view image as ego centered
    and oriented. The calculation of the image is done with inherent resolution and then resized to requested
    resolution.
    :param lane_segments:
    :param longitudinal_resolution: longitudinal resolution of image output
    :param lateral_resolution: lateral resolution of image output
    :param origin_coordinates: cartesian coordinates of image reference
    :param orientation: origin orientation
    :param longitudinal_range: longitudinal range of image, first element is the minimal longitudinal coordinate, second
                               is the maximal longitudinal coordinate.
    :param lateral_range: lateral range of image, first element is the minimal lateral coordinate, second
                          is the maximal lateral coordinate.
    :param inherent_resolution: resolution of calculation of image
    :return: top view image of lane
    """

    lanes_data = []
    for lane in lane_segments:
        if lane_id is None or lane.id == lane_id:
            curr_lane_boundary = np.concatenate([lane.left_border, np.flip(lane.right_border, axis=0)], axis=0)
            lanes_data.append(curr_lane_boundary)

    origin_coordinates = np.array(origin_coordinates)
    image_size = (int((longitudinal_range[1] - longitudinal_range[0]) / inherent_resolution),
                  int((lateral_range[1] - lateral_range[0]) / inherent_resolution))

    map2d_image = np.zeros((image_size[1], image_size[0], 3), dtype=np.uint8)

    # transform to ego coordinates
    ego_transform_inv = RigidTransform2D(rotation=orientation, translation=origin_coordinates).invert()

    for lane_points in lanes_data:
        # transform lanes blobs to ego coordinates
        lane_points_ego_coordinates = ego_transform_inv.transform(lane_points)

        # calculate pixel coordinates of lanes blobs
        lane_points_image_coordinates = (lane_points_ego_coordinates -
                                         np.array(
                                             [[longitudinal_range[0], lateral_range[0]]])) / inherent_resolution

        # keep only relevant points
        longitudinal_in_range = (lane_points_image_coordinates[:, 0] >= 0.) & \
                                (lane_points_image_coordinates[:, 0] < image_size[0])
        lateral_in_range = (lane_points_image_coordinates[:, 1] >= 0.) & \
                           (lane_points_image_coordinates[:, 1] < image_size[1])

        # clip points outside of image
        blob_clipped = lane_points_image_coordinates[longitudinal_in_range | lateral_in_range]
        blob_clipped[:, 0] = np.clip(blob_clipped[:, 0], a_min=0., a_max=image_size[0])
        blob_clipped[:, 1] = np.clip(blob_clipped[:, 1], a_min=0., a_max=image_size[1])

        # generate polygon for lane
        if 0 == blob_clipped.size:
            continue

        cv2.fillPoly(img=map2d_image, pts=[blob_clipped.astype(np.int32)], color=[255, 255, 255])

    resized_patch_size = (int(image_size[0] / (longitudinal_resolution / inherent_resolution)),
                          int(image_size[1] / (lateral_resolution / inherent_resolution)))

    # inverse order of patch_size due to opencv treating the size as (width, height) (while we use (height, width)
    out_map_resized = cv2.resize(map2d_image, resized_patch_size)

    # rot90 and flip to change opencv convention to our convention
    return np.rot90(out_map_resized, k=-1)[:, ::-1]


class BevMapSampler:

    def __init__(self,
                 lane_segments: List[LaneSegment],
                 map_center: Tuple[float, float],
                 longitudinal_resolution: float = 0.5,
                 lateral_resolution: float = 0.5,
                 longitudinal_range: Tuple[float, float] = (-1000.0, 1000.0),
                 lateral_range: Tuple[float, float] = (-1000.0, 1000.0),
                 inherent_resolution: float = 0.25):
        """
        This class allows fast determination of lane id by creation of a bev map of lanes, where each lane is a blob in
         the image, and sampling (x,y) point from this image to determine the lane id.
        :param lane_segments:
        :param longitudinal_resolution:
        :param lateral_resolution:
        :param longitudinal_range:
        :param lateral_range:
        :param inherent_resolution:
        """
        # Generate top-view map
        self._lane_segments = lane_segments
        self._longitudinal_resolution = longitudinal_resolution
        self._lateral_resolution = lateral_resolution
        self._longitudinal_range = longitudinal_range
        self._lateral_range = lateral_range
        self._inherent_resolution = inherent_resolution
        self._origin_coordinates = np.array(map_center)
        self._orientation = 0.
        AlgoTimer().start("generate_top_view")
        self._lanes_map = {}

        lanes_values = np.array([int(v)+1 for v in range(len(self._lane_segments))])
        for i, v in enumerate(lanes_values):
            self._lanes_map[v] = self._lane_segments[i].id
        # Creating the BEV map
        self._bev_maps = {}
        self._bev_map_shape = None
        for lane_key, lane_id in self._lanes_map.items():
            self._bev_maps[lane_key]: np.ndarray = create_lane_bev_map(lane_segments=tuple(self._lane_segments),
                                                                       longitudinal_resolution=self._longitudinal_resolution,
                                                                       lateral_resolution=self._lateral_resolution,
                                                                       origin_coordinates=tuple(self._origin_coordinates),
                                                                       orientation=self._orientation,
                                                                       longitudinal_range=longitudinal_range,
                                                                       lateral_range=lateral_range,
                                                                       inherent_resolution=inherent_resolution,
                                                                       lane_id=lane_id)
            self._bev_map_shape = self._bev_maps[lane_key].shape
        self.ego_tran = RigidTransform2D(rotation=self._orientation,
                                         translation=self._origin_coordinates)
        self.ego_tran = self.ego_tran.invert()
        self.range = np.array([self._longitudinal_range[0], self._lateral_range[0]])
        self.resolution = np.array([self._longitudinal_resolution, self._lateral_resolution])
        AlgoTimer().stop("generate_top_view")

    def get_lane_id_by_coordinates(self, x: float, y: float) -> List[int]:
        """
        This function return the lane id by:
        a) getting the index in the map
        b) extracting the lane from the (i,j) point
        :param x:
        :param y:
        :return:
        """
        AlgoTimer().start("bev_map_sample")
        i, j = self._xy_to_ij(x, y)
        lane_ids = self.get_lane_by_ij(i, j)
        AlgoTimer().stop("bev_map_sample")
        return lane_ids

    def _xy_to_ij(self, x: float, y: float) -> Tuple[int, int]:
        """
        This function transform a cartesian point (x.y) into indexes in the image (i,j)
        :param x:
        :param y:
        :return: i,j indexes
        """
        AlgoTimer().start("_xy_to_ij")
        xy = np.array([x, y])
        transformed_xy = self.ego_tran.transform(xy)
        ij = (transformed_xy[0] - self.range) / self.resolution
        ij = ij.astype(np.uint16)
        AlgoTimer().stop("_xy_to_ij")
        return ij[0], ij[1]

    def get_lane_by_ij(self, i: int, j: int) -> List[int]:
        """
        This function outputs all the relevant lane adhacent to a specific (i,j) point by the following rule:
        We sample a 3x3 grid around the (i,j) coordinate
        We get the unique values
        We then filter the zeros (no lane)
        :param i:
        :param j:
        :return:
        """
        min_i = max(i-1, 0)
        min_j = max(j-1, 0)
        max_i = min(i+2, self._bev_map_shape[0])
        max_j = min(j+2, self._bev_map_shape[1])
        lane_keys = []
        for lane_key, lane_map in self._bev_maps.items():
            if np.any(lane_map[min_i:max_i, min_j:max_j, :]):
                lane_keys.append(lane_key)
        # Get unique values
        lane_keys = np.unique(lane_keys)

        # Convert to actual lane ids
        lane_ids = [self._lanes_map[i] for i in lane_keys]
        return lane_ids


if __name__ == '__main__':
    from subdivision_planner.src.utils import debug
    d = debug.load_from_pickle()
    raw_state = d['raw_state']
    map_descriptor = d['map_descriptor']
    map_descriptor.extract_raw_features(raw_state)