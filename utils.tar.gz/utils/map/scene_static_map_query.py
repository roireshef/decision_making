"""
Abstract classes to support map queries needed for MCTS simulation.
"""
from abc import ABC, abstractmethod
from typing import List

import common_types


class IGeometry(ABC):

    @abstractmethod
    def sample(self, s: float) -> common_types.FFrame:
        raise NotImplementedError("Class %s doesn't implement sample()" % self.__class__.__name__)

    @abstractmethod
    def project(self, x: float, y: float) -> common_types.FCoord:
        raise NotImplementedError("Class %s doesn't implement project()" % self.__class__.__name__)

    @abstractmethod
    def heading(self, s: float) -> float:
        raise NotImplementedError("Class %s doesn't implement heading()" % self.__class__.__name__)

    @abstractmethod
    def get_length(self) -> float:
        raise NotImplementedError("Class %s doesn't implement get_length()" % self.__class__.__name__)

    @abstractmethod
    def get_width(self, s: float) -> float:
        raise NotImplementedError("Class %s doesn't implement get_width()" % self.__class__.__name__)


class ILane(IGeometry):

    @abstractmethod
    def get_id(self) -> int:
        raise NotImplementedError("Class %s doesn't implement get_id()" % self.__class__.__name__)

    @abstractmethod
    def get_road_id(self) -> int:
        raise NotImplementedError("Class %s doesn't implement get_road_id()" % self.__class__.__name__)

    @abstractmethod
    def get_downstream_lanes(self) -> List[int]:
        raise NotImplementedError("Class %s doesn't implement get_downstream_lanes()" % self.__class__.__name__)

    @abstractmethod
    def get_upstream_lanes(self) -> List[int]:
        raise NotImplementedError("Class %s doesn't implement get_upstream_lanes()" % self.__class__.__name__)


class IMapQuery(ABC):

    @abstractmethod
    def get_lane(self, x: float, y: float, heading: float) -> ILane:
        raise NotImplementedError("Class %s doesn't implement get_lane()" % self.__class__.__name__)

    @abstractmethod
    def get_lane_by_id(self, lane_id: int) -> ILane:
        raise NotImplementedError("Class %s doesn't implement get_lane_by_id()" % self.__class__.__name__)
