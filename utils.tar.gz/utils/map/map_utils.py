import numpy as np
from cachetools import cached, LRUCache
from cachetools.keys import hashkey
from typing import List, Dict, Tuple

from subdivision_planner.src.data_structures.map import Map

from subdivision_planner.src.data_structures.map_elements.lane_segment import LaneConnectivityType
from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.exceptions import raises, IDAppearsMoreThanOnce, RoadNotFound, OutOfSegmentBack, \
    OutOfSegmentFront
from subdivision_planner.src.data_structures.lane_sequence import LaneSequence
from subdivision_planner.src.messages.map_attributes_message import SceneRoadSegment, MapAttributes


class MapUtils:
    @staticmethod
    def get_road_segment_ids(map_attributes: MapAttributes) -> List[int]:
        """
        :return:road_segment_ids of every road in the static scene
        """
        road_segments = map_attributes.s_Data.s_SceneStaticBase.as_scene_road_segment[
                        :map_attributes.s_Data.s_SceneStaticBase.e_Cnt_num_road_segments]
        return [road_segment.e_i_road_segment_id for road_segment in road_segments]

    @staticmethod
    def get_lanes_ids_from_road_segment_id(map_attributes: MapAttributes, road_segment_id: int) -> List[int]:
        """
        Get sorted list of lanes for given road segment. The output lanes are ordered by the lanes' ordinal,
        i.e. from the rightest lane to the most left.
        :param road_segment_id:
        :return: sorted list of lane segments' IDs
        """
        return list(MapUtils.get_road_segment(map_attributes, road_segment_id).a_i_lane_segment_ids)

    @staticmethod
    @raises(RoadNotFound)
    def get_road_segment(map_attributes: MapAttributes, road_id: int) -> SceneRoadSegment:
        """
        Retrieves road by road_id  according to the last message
        :param road_id:
        :return:
        """
        road_segments = [road_segment for road_segment in map_attributes.s_Data.s_SceneStaticBase.as_scene_road_segment if
                         road_segment.e_i_road_segment_id == road_id]
        if len(road_segments) == 0:
            raise RoadNotFound('road %d not found' % road_id)
        if len(road_segments) > 1:
            raise IDAppearsMoreThanOnce('road %d appears more than once' % road_id)
        return road_segments[0]

    @staticmethod
    def is_inside_lane_borders(cstate: types.CartesianExtendedState, gff: LaneSequence) -> bool:

        # TODO: uncomment when the bug is fixed - https://jira.ultracruise.gm.com/browse/GMUC-25969
        #fpoint = gff.cpoint_to_fpoint(cpoint=cstate[[types.C_X, types.C_Y]], raise_on_points_out_of_frame=False)
        try:
            fpoint = gff.cpoint_to_fpoint(cpoint=cstate[[types.C_X, types.C_Y]])
        except (OutOfSegmentBack, OutOfSegmentFront):
            return False

        s_val = fpoint[types.FP_SX]
        if s_val < 0.0:
            return False

        d_val = fpoint[types.FP_DX]

        if d_val > 0:
            # Left side
            return gff.get_distances_to_left_lane_edge(s_values=np.array([s_val]))[0] > d_val

        # Right side
        return gff.get_distances_to_right_lane_edge(s_values=np.array([s_val]))[0] > -d_val

    @staticmethod
    def is_path_inside_gff(
            cpoints: types.CartesianPath2D,
            gff: LaneSequence,
            margin: float
    ):
        """
        Determine for each cartesian point whether it inside the given lane sequence boundaries up to given margin
        :param cpoints: Vector of cartesian points to test
        :param gff: The generalized Fernet Serret frame
        :param margin: Margin w.r.t lane boundaries (equally applied to both sides) to indicate true
        :return: Boolean vector when the ith element indicate whether the ith cpoint is inside the gff boundaries
        up to the given margin
        """

        # TODO: uncomment when the bug is fixed! https://jira.ultracruise.gm.com/browse/GMUC-25969
        #fpoints = gff.cpoints_to_fpoints(cpoints=cpoints, raise_on_points_out_of_frame=False)
        fpoints = gff.cpoints_to_fpoints(cpoints=cpoints, raise_on_points_out_of_frame=True)

        # Create mask of points that can be projected on the gff
        valid_points_mask = fpoints[:, types.FP_SX] >= 0.0

        # Keep only the points that are valid
        valid_fpoints = fpoints[valid_points_mask, :]

        dist_left, dist_right = gff.get_distances_to_left_and_right_lane_edge(s_values=valid_fpoints[:, types.FP_SX])

        mask_inside_left = dist_left + margin >= valid_fpoints[:, types.FP_DX]
        mask_inside_right = valid_fpoints[:, types.FP_DX] >= -dist_right - margin
        mask_inside = mask_inside_left & mask_inside_right

        res = np.zeros((cpoints.shape[0]), dtype=np.bool)

        res[valid_points_mask] = mask_inside

        return res

    @staticmethod
    @cached(cache=LRUCache(maxsize=16),
            key=lambda gff, map: hashkey((hash(gff), map.id)))
    def get_merging_lane_ids_and_limits(gff: LaneSequence, map: Map) -> Dict[int, Tuple[float, float]]:
        """
        Get the IDs of lanes that merge into the provided gff as well as the GFF start and end positions where merging is relevant.
        :param gff:
        :param map:
        :return:
        """
        merging_lane_ids_dict = {}

        for subsegment in gff.segments:
            if not map.has_lane_id(lane_id=subsegment.e_i_SegmentID):
                continue

            # Find adjacent lanes that share a downstream lane with this segment
            lane_segment = map.get_lane_segment_by_id(lane_id=subsegment.e_i_SegmentID)
            adjacent_lane_ids = lane_segment.left_adjacent_lanes + lane_segment.right_adjacent_lanes

            if len(adjacent_lane_ids) == 0:
                continue

            merging_lane_ids = []

            for downstream_connectivity in lane_segment.get_downstream_lanes_connectivity():
                if not map.has_lane_id(downstream_connectivity.lane_id):
                    continue

                downstream_lane = map.get_lane_segment_by_id(downstream_connectivity.lane_id)
                merging_lane_ids += [upstream_connectivity.lane_id
                                     for upstream_connectivity in downstream_lane.get_upstream_lanes_connectivity()
                                     if upstream_connectivity.lane_id in adjacent_lane_ids]

            merging_lane_ids = list(set(merging_lane_ids))  # Make sure lane IDs are unique

            for merging_lane_id in merging_lane_ids:
                # Ignore merging lanes that are missing in the map
                if not map.has_lane_id(merging_lane_id):
                    continue

                lane_id_lists = map.enumerate_routes(
                    start_lane_id=merging_lane_id,
                    min_distance=Config().state.min_upstream_distance_from_merge,
                    is_downstream=False,
                    connectivity_types=[LaneConnectivityType.STRAIGHT_CONNECTION,
                                        LaneConnectivityType.LEFT_MERGE_CONNECTION,
                                        LaneConnectivityType.RIGHT_MERGE_CONNECTION]
                )
                for lane_id_list in lane_id_lists:
                    for lane_id in lane_id_list:
                        if lane_id in gff.segment_ids:
                            continue

                        # If a merging lane is already in the dictionary and the recorded merging area is different than the current
                        # merging area, enlarge the recorded merging area so that it includes both merging areas. Perhaps in the future
                        # we can record each area separately, but for now, enlarging the merging area simply makes us cautious on a larger
                        # portion of the GFF.
                        start_s, end_s = merging_lane_ids_dict[lane_id] if lane_id in merging_lane_ids_dict else (np.inf, np.NINF)
                        start_s, end_s = min(start_s, subsegment.e_i_SStart), max(end_s, subsegment.e_i_SEnd)
                        merging_lane_ids_dict[lane_id] = (start_s, end_s)

        return merging_lane_ids_dict
