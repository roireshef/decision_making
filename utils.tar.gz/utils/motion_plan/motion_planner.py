import abc
from typing import Optional, List

import numpy as np
from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.data_structures.motion_plan.motion_plan import IMotionPlan
from subdivision_planner.src.data_structures.motion_plan.multi_poly_solution import MultiPolySolution
from subdivision_planner.src.data_structures.motion_plan.poly1d_solutions import QuinticPolySolution, RootsToReturn, \
    PolyType, JerkPolySolution, QuarticPolySolution, EPS_DURATION, CubicPolySolution
from subdivision_planner.src.mdp.determinizer import Determinizer
from subdivision_planner.src.mdp.werling.action_type import ComponentDirection
from subdivision_planner.src.mdp.werling.utils.longitudinal_utils import _get_longitudinal_physicality_limits
from subdivision_planner.src.utils.motion_plan.motion_plan_toolbox import MotionPlanToolbox, build_accel_cubic_follow

DIVISION_THRESH = 0.01
LOW_SPEED = 1.


class IMotionPlanner(abc.ABC):
    @classmethod
    @abc.abstractmethod
    def plan_motion(cls, ego_init_fstate: np.ndarray, j_0: float = None, target_init_fstate: np.ndarray = None,
                    desired_jerk: float = None, desired_accel: float = None,
                    desired_snap: Optional[np.ndarray] = None, acceleration_cubics: bool = False,
                    T_offset: float = 0., headway=2.0, is_subdivision: bool = False) -> (List[IMotionPlan], List[str]):
        pass


class QuinticCubicMotionPlanner(IMotionPlanner):

    @classmethod
    def plan_motion(cls, ego_init_fstate: np.ndarray, j_0: float = None, target_init_fstate: np.ndarray = None,
                    desired_jerk: float = None, desired_accel: float = None,
                    desired_snap: Optional[np.ndarray] = None, acceleration_cubics: bool = False,
                    T_offset: float = 0., headway=2.0, is_subdivision: bool = False) -> (List[IMotionPlan], List[str]):

        # Assumption: jerk_level, i.e. ideal acceleration, is non-positive
        min_accel = Config().ego.min_longitudinal_acceleration_default_interpolator(ego_init_fstate[types.FS_SV])
        max_accel = max(Config().ego.max_longitudinal_acceleration_default)
        desired_accel = float(np.clip(desired_accel, a_min=min_accel + 0.05,
                                      a_max=max_accel))
        if acceleration_cubics:
            multipoly_solution = build_accel_cubic_follow(ego_init_fstate=ego_init_fstate,
                                                          j_0=j_0,
                                                          actor_effective_init_fstate=target_init_fstate)
            partial_fluctuation_name = 'acceleration_cubic_quartic'
        else:
            # If we aim to decelerate desired acceleration can't be positive
            assert desired_accel <= 1e-3
            multipoly_solution = MotionPlanToolbox.create_multipoly_for_jerk_and_accel_levels(ego_fstate=ego_init_fstate,
                                                                                        a_target=desired_accel,
                                                                                        j_0=j_0,
                                                                                        j_limit=desired_jerk,
                                                                                        min_duration=Config().driving.follow_cubic_min_duration)

            partial_fluctuation_name = 'cubic_jerk_{}_acc_{}'.format(np.round(desired_jerk, decimals=1),
                                                                     np.round(desired_accel, decimals=1))

        if multipoly_solution and len(multipoly_solution.polynomials) > 0:
            return [multipoly_solution], [partial_fluctuation_name]
        return [], []


class TrapezoidalMotionPlanner(IMotionPlanner):

    @classmethod
    def plan_motion(cls, ego_init_fstate: np.ndarray, j_0: float = None, target_init_fstate: np.ndarray = None,
                    desired_jerk: float = None, desired_accel: float = None,
                    desired_snap: Optional[np.ndarray] = None, acceleration_cubics: bool = False,
                    T_offset: float = 0., headway=2.0, is_subdivision: bool = False) -> (List[IMotionPlan], List[str]):

        delta_jerk = desired_jerk - j_0
        max_abs_snap = np.clip(
            abs(delta_jerk) / Config().driving.follow_cubic_time_to_build_jerk,
            Config().driving.follow_cubic_min_snap,
            Config().driving.follow_cubic_max_snap
        )
        motion_plan_multi_poly = MotionPlanToolbox.build_acceleration_delta(
            ego_fstate=ego_init_fstate,
            a_target=desired_accel,
            j_0=j_0,
            j_limit=abs(desired_jerk),
            snap_max_abs=max_abs_snap,
            min_time=Config().driving.follow_trapezoidal_min_duration,
            negative_velocity_backup=Config().driving.follow_trapezoidal_negative_velocity_backup
        )
        if motion_plan_multi_poly is None:
            return [], []
        partial_fluctuation_name = 'cubic_jerk_{}_acc_{}'.format(np.round(desired_jerk, decimals=1),
                                                                 np.round(desired_accel, decimals=1))
        return [motion_plan_multi_poly], [partial_fluctuation_name]


class ClassicQuinticMotionPlanner(IMotionPlanner):

    @classmethod
    def plan_motion(cls, ego_init_fstate: np.ndarray, j_0: float = None, target_init_fstate: np.ndarray = None,
                    desired_jerk: float = None, desired_accel: float = None,
                    desired_snap: Optional[np.ndarray] = None, acceleration_cubics: bool = False,
                    T_offset: float = 0., headway=2.0, is_subdivision: bool = False) -> (List[IMotionPlan], List[str]):

        #TODO: verify that this condition is equivalent to before
        follow_max_duration = Config().mcts.action_cubic_quintic_follow_max_duration if T_offset > 0. else \
            Config().mcts.action_follow_max_duration

        eff_init_s_dist = target_init_fstate[types.FS_SX] - ego_init_fstate[types.FS_SX]

        w_J = Config().mcts.longitudinal_action_default_w_J
        # Find natural durations to achieve this headway
        if ego_init_fstate[types.FS_SV] < Config().driving.velocity_threshold_to_perfer_moderate_quintics_for_stop and \
                target_init_fstate[types.FS_SV] < Config().driving.negligible_velocity:
            w_J = Config().mcts.longitudinal_action_prefer_moderate

        w_J = np.array(w_J)
        final_motion_max_duration = follow_max_duration - T_offset
        root_to_return = RootsToReturn.MIN
        durations = QuinticPolySolution.calc_jerk_optimal_duration(
            frenet_component_state=ego_init_fstate, w_J=w_J,
            duration_range=(0, final_motion_max_duration),
            target_speeds=[target_init_fstate[types.FS_SV]], target_distances=[eff_init_s_dist],
            target_headways=[headway],
            roots_to_return=root_to_return)[0]

        with np.errstate(invalid='ignore'):  # disregard np warning on comparing nan and number
            valid_duration_idxs = [tuple(x) for x in
                                   np.argwhere(np.logical_and(~np.isnan(durations), durations > 1e-1))]
            if len(valid_duration_idxs) == 0:
                return [], []

        if root_to_return == RootsToReturn.ALL:
            # w_J needs to be repeated to form shape (len(w_J) x 6) since durations contains all roots and also has shape (len(w_J) x 6)
            w_J = np.repeat(w_J, durations.shape[1], axis=0).reshape(len(w_J), durations.shape[1])

        w_J = w_J[tuple(zip(*valid_duration_idxs))]
        durations = durations[tuple(zip(*valid_duration_idxs))]

        if len(durations) == 0:
            return [], []

        determinized_durations = (((T_offset + durations) / Config().mcts.determinization_dt).astype(int) + 1) * \
                                 Config().mcts.determinization_dt - T_offset

        # remove duplicates resulting from determinization
        _, idxs = np.unique(determinized_durations, return_index=True)
        unique_durations = determinized_durations[np.sort(idxs)]
        w_J = w_J[np.sort(idxs)]

        durations_list = unique_durations.tolist()

        fluctuation_name_list = ['w_J=' + str(w) for w in w_J]

        target_s_list = (target_init_fstate[types.FS_SX] + target_init_fstate[types.FS_SV] * (
                unique_durations - headway)).tolist()
        target_final_fstate_per_duration = [np.array([curr_s, target_init_fstate[types.FS_SV], 0.])
                                            for curr_s in target_s_list]

        motion_plan_list = []
        # Pre-generate the motion_plan for all fluctuations:
        for duration, target_final_fstate in zip(durations_list, target_final_fstate_per_duration):
            motion_plan = JerkPolySolution.generate_motion_plan(PolyType.Quintic, ego_init_fstate, target_final_fstate,
                                                                ComponentDirection.Longitudinal, duration)
            motion_plan_list.append(motion_plan)

        return motion_plan_list, fluctuation_name_list


class QuarticQuinticMotionPlanner(IMotionPlanner):

    @staticmethod
    def get_desired_snaps() -> np.array:
        return np.array(Config().driving.action_follow_quartic_snaps)

    @classmethod
    def plan_motion(cls, ego_init_fstate: np.ndarray, j_0: float = None, target_init_fstate: np.ndarray = None,
                    desired_jerk: float = None, desired_accel: float = None,
                    desired_snaps: Optional[np.ndarray] = None, acceleration_cubics: bool = False,
                    T_offset: float = 0., headway=2.0, is_subdivision: bool = False) -> (List[IMotionPlan], List[str]):

        #TODO: verify that this condition is equivalent to before
        follow_max_duration = Config().mcts.action_cubic_quintic_follow_max_duration if T_offset > 0. else \
            Config().mcts.action_follow_max_duration

        w_J = Config().mcts.longitudinal_action_default_w_J
        # Find natural durations to achieve this headway
        if ego_init_fstate[types.FS_SV] < Config().driving.velocity_threshold_to_perfer_moderate_quintics_for_stop and \
                target_init_fstate[types.FS_SV] < Config().driving.negligible_velocity:
            w_J = Config().mcts.longitudinal_action_prefer_moderate
        w_J = np.array(w_J)

        dt = Config().mcts.determinization_dt
        action_durations = Determinizer.determinize_times(time=np.arange(dt, follow_max_duration - T_offset, dt), offset=T_offset)

        # Build a list of quartic+quintic multi-polynomials for different durations and quartic snaps.
        # For each w_J find the best multi-polynomial that optimizes a cost function and holds physicality.
        best_full_durations, best_quartic_durations, best_snaps = \
            QuarticQuinticMotionPlanner._calculate_best_quartic_bridge_to_quintic(
                ego_init_fstate=ego_init_fstate,
                init_jerk=j_0,
                actor_fstate=target_init_fstate,
                headway=headway,
                full_durations=action_durations,
                snaps=desired_snaps,
                w_J=w_J)
        if best_full_durations is None:
            return [], []

        motion_plan_list = []
        fluctuation_name_list = []
        for w_J, T, T0, snap in zip(w_J, best_full_durations, best_quartic_durations, best_snaps):
            x_0, v_0, a_0 = ego_init_fstate[:types.FS_DX]
            x_T, v_T, a_T = target_init_fstate[:types.FS_DX]

            if T0 < 0.01:  # then no need in quartic bridge, create only quintic
                quintic = QuinticPolySolution(T=T, a_0=a_0, v_0=v_0, x_0=x_0, v_T=v_T, a_T=a_T, x_T=x_T + v_T * (T - headway))
                motion_plan_list.append(quintic)
            else:
                # calculate final quartic velocity and acceleration
                quartic = QuarticPolySolution.from_initial_jerk_and_snap(x_0=x_0, v_0=v_0, a_0=a_0, j_0=j_0, snap=snap, T=T0)
                quintic = QuinticPolySolution(T=T - T0, a_0=quartic.a_T, v_0=quartic.v_T, x_0=quartic.x_T,
                                              v_T=v_T, a_T=a_T, x_T=x_T + v_T * (T - headway))
                motion_plan_list.append(MultiPolySolution([quartic, quintic]))

            fluctuation_name_list.append('quartic_quintic_w_J='+str(w_J))

        return motion_plan_list, fluctuation_name_list

    @classmethod
    def _calculate_best_quartic_bridge_to_quintic(cls, ego_init_fstate: np.array, init_jerk: float,
                                                  actor_fstate: np.array, headway: float,
                                                  full_durations: np.array, snaps: np.array,
                                                  w_J: np.array) -> [np.array, np.array, np.array]:
        """
        Find time-jerk optimal quartic bridge to quintic polynomials maintaining continuous jerk.
        The obtained multi-polynomial holds acceleration and jerk limits.
        :param ego_init_fstate:
        :param init_jerk: initial jerk of ego (from prev driving plan)
        :param actor_fstate: followed actor init fstate
        :param headway: target headway
        :param full_durations: array of total durations of the output multi-poly
        :param snaps: array of all possible snaps of the quartic bridge
        :param w_J: array of jerk weights
        :return:
        """
        perform_physicality_validation = False

        v0, a0 = ego_init_fstate[[types.FS_SV, types.FS_SA]]
        j0 = init_jerk
        vT = actor_fstate[types.FS_SV]
        sT = actor_fstate[types.FS_SX] - ego_init_fstate[types.FS_SX]
        aT = 0.
        T = full_durations

        # build quartic+quintic polynomials data
        T_arr, T0_arr, snap_arr = QuarticQuinticMotionPlanner._build_quartic_bridge_to_quintic(
            v0=v0, a0=a0, j0=j0, sT=sT, vT=vT, aT=aT, headway=headway, T=T, snap=snaps)
        if T_arr.shape[-1] < 3:  # local minimum on T requires at least 3 times
            return None, None, None

        # calculate final states of the quartic part
        seam_s, seam_v, seam_a = QuarticQuinticMotionPlanner._calculate_final_quartic_states(
            T0_arr, snap_arr, v0, a0, j0)
        quintic_dist = sT + vT * (T_arr - headway) - seam_s

        # find polynomials with valid acceleration & jerk (physicality)
        if perform_physicality_validation:
            is_valid = QuarticQuinticMotionPlanner._check_physicality(
                a0=a0, j0=j0, seam_v=seam_v, seam_a=seam_a, quintic_dist=quintic_dist, vT=vT, T=T_arr, T0=T0_arr,
                snaps=snap_arr)
            if not is_valid.any():
                return None, None, None
        else:
            is_valid = np.ones_like(T_arr).astype(bool)

        # choose time-jerk optimal polynomials for different weights
        best_snap_idxs, best_T_idxs = QuarticQuinticMotionPlanner._find_jerk_optimal_duration(
            j0=j0, seam_v=seam_v, seam_a=seam_a, quintic_dist=quintic_dist, vT=vT, T=T_arr, T0=T0_arr, snaps=snap_arr,
            w_J=w_J, is_valid=is_valid)

        # remove duplicates
        best_idxs = best_snap_idxs * T_arr.shape[1] + best_T_idxs
        _, idx = np.unique(best_idxs, return_index=True)
        unique_idxs = best_idxs[np.sort(idx)]
        return T_arr.ravel()[unique_idxs], T0_arr.ravel()[unique_idxs], snap_arr.ravel()[unique_idxs]

    @classmethod
    def _build_quartic_bridge_to_quintic(cls, v0: float, a0: float, j0: float, sT: float, vT: float, aT: float,
                                         headway: float, T: np.array, snap: np.array) -> [np.array, np.array, np.array]:
        """
        Calculate multi-polynomial of quartic & quintic, such that the quartic ends in the same state as the quintic
        starts, including jerk. The quartic's jerk starts from the given initial jerk (e.g. from the prev driving plan).
        The multi-poly has the given total duration T.
        :param T: array of total durations of the output multi-poly
        :param v0: initial speed
        :param a0: initial acceleration
        :param j0: initial jerk
        :param sT: initial distance from the followed car
        :param vT: target speed
        :param aT: target acceleration
        :param headway: target headway
        :param snap: array of constant snaps (jerk derivative) of the quartic polynomial
        :return: for all valid combinations of (T, snap): full durations, snaps, quartic durations

        The following pysym code calculates the quartic duration, given full duration T and snap:

        t, T, T0 = symbols('t T T0')
        v0, a0, j0 = symbols('v0 a0 j0')
        sT, vT, aT, Tm = symbols('sT vT aT Tm')
        snap = symbols('snap')

        # calculate the quartic end state
        s1 = v0 * T0 + 0.5 * a0 * T0 ** 2 + j0 * T0 ** 3 / 6. + snap * T0 ** 4 / 24.
        v1 = v0 + a0 * T0 + 0.5 * j0 * T0 ** 2 + snap * T0 ** 3 / 6.
        a1 = a0 + j0 * T0 + 0.5 * snap * T0 ** 2
        T1 = T - T0  # quintic duration

        A = Matrix([
            [0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 1, 0],
            [0, 0, 0, 2, 0, 0],
            [T1 ** 5, T1 ** 4, T1 ** 3, T1 ** 2, T1, 1],
            [5 * T1 ** 4, 4 * T1 ** 3, 3 * T1 ** 2, 2 * T1, 1, 0],
            [20 * T1 ** 3, 12 * T1 ** 2, 6 * T1, 2, 0, 0]]
        )
        [c5, c4, c3, c2, c1, c0] = A.inv() * Matrix([s1, v1, a1, sT + vT * (T - Tm), vT, aT])
        x_t = (c5 * t ** 5 + c4 * t ** 4 + c3 * t ** 3 + c2 * t ** 2 + c1 * t + c0).simplify()
        j_t = sp.diff(x_t, t, 3).simplify()
        quintic_J0 = j_t.subs(t, 0.).simplify()
        print('quintic_J0 =', quintic_J0)
        J1 = T0*snap + j0

        # multiply quintic_J0 and J1 by denominator of quintic_J0 to create equation with polynomials
        equation = (2*T1**3 * quintic_J0).simplify() - (2*T1**3 * J1)
        print('equation poly', poly(equation, T0))
        T0_sol = solve(equation, T0)
        print('T0_sol', T0_sol)
        """

        # create the cartesian product of snaps and durations
        snaps_num = snap.shape[0]
        times_num = T.shape[0]
        snap = (snap[:, None] + np.zeros((snaps_num, times_num))).ravel()
        T = (T[None, :] + np.zeros((snaps_num, times_num))).ravel()

        T2 = T * T
        T3 = T2 * T
        T4 = T3 * T

        # calculate the snap's sign according to the difference between the initial jerk of the simple quintic and j0
        orig_quintic_jerk = 3 * (-3 * T2 * a0 + T2 * aT - 12 * T * v0 + 12 * T * vT - 20 * headway * vT + 20 * sT) / T3
        snap = snap * np.sign(orig_quintic_jerk - j0)  # set sign to snap

        # Calculate quartic polynomial, such that it ends in the same state as quintic polynomial starts including jerk.
        # Preserve the original total duration of the multi-poly.
        # The solution is quadratic equation obtained by comparison between the jerks of the polynomials.

        # quadratic polynomial coefficients of equation: a*T0**2 + 2*b*T + 2*c = 0
        a = 3 * T2 * snap + 6 * (T * j0 + a0 - aT)
        b = T3 * snap + 6 * T * (T * j0 + aT) + 18 * T * a0 + 24 * (v0 - vT)
        c = T3 * j0 + 9 * T2 * a0 - 3 * T2 * aT + 36 * T * (v0 - vT) + 60 * (headway * vT - sT)

        discr = (T4 * (T * snap + 3 * j0) ** 2 - T4 * snap * (18.0 * a0 - 30.0 * aT) + 24 * T3 * j0 * (5 * aT + a0)
                 + 6 * T2 * (6 * a0 + T * j0) ** 2 + 9 * T4 * j0 ** 2
                 + (168.0 * T3 * snap + 144.0 * T2 * j0 - 432.0 * T * a0 - 720.0 * T * aT + 576.0 * (vT - v0)) * (vT - v0)
                 + 360 * (T2 * a0 * aT + (headway * vT - sT) * (2 * (aT - a0 - T * j0) - T2 * snap)))
        invalid_roots = (discr < 0) | (a == 0)
        a[invalid_roots] = 1.  # to prevent warning of division by 0
        discr[invalid_roots] = 0.  # to prevent warning of sqrt(-1)
        sqrt_discr = np.sqrt(discr)
        T0_sol = np.stack([(-b - sqrt_discr) / a, (-b + sqrt_discr) / a])  # solutions of the quadratic equations

        # invalidate solutions for T0 outside the interval [0, T]
        T0_sol[(T0_sol < 0) | (T0_sol > T)] = np.inf
        # take the minimal root for each equation
        T0 = np.min(T0_sol, axis=0)
        T0[invalid_roots | ~np.isfinite(T0)] = np.nan

        # calculate linear equations for degenerate quadratic
        is_linear = (a == 0)
        if is_linear.any():
            T0[is_linear] = -c[is_linear] / b[is_linear]  # solve linear equations

        T = T.reshape((snaps_num, times_num))
        T0 = T0.reshape((snaps_num, times_num))
        snap = snap.reshape((snaps_num, times_num))

        # remove T0 that invalid for all snaps and roots (but still T0=nan is possible for some T and snap)
        valid_times = np.isfinite(T0).any(axis=0)  # axis=0 for snaps, axis=1 for T
        T0 = T0[..., valid_times]
        T = T[:, valid_times]
        snap = snap[:, valid_times]
        return T, T0, snap

    @classmethod
    def _calculate_final_quartic_states(cls, T, snaps, v0, a0, j0) -> [np.array, np.array, np.array]:
        """
        Calculate analytically final states of quartic polynomials.
        :param T: quartic durations
        :param snaps: quartic constant snaps
        :param v0:
        :param a0:
        :param j0:
        :return:
        """
        T2 = T * T
        T3 = T2 * T
        T4 = T3 * T
        xT = T4 * snaps / 24. + T3 * j0 / 6. + 0.5 * T2 * a0 + T * v0
        vT = T3 * snaps / 6. + 0.5 * T2 * j0 + T * a0 + v0
        aT = 0.5 * T2 * snaps + T * j0 + a0
        return xT, vT, aT

    @classmethod
    def _check_physicality(cls, a0: float, j0: float, seam_v: np.array, seam_a: np.array, quintic_dist: np.array, vT: float,
                           T: np.array, T0: np.array, snaps: np.array) -> np.array:
        """
        Check acceleration and jerk limits of the multi-polynomials.
        In addition check negative speed when the target speed is 0.
        :param a0:
        :param j0:
        :param seam_v: final quartic (or initial quintic) speed
        :param seam_a: final quartic (or initial quintic) acceleration
        :param quintic_dist: difference between final and initial s of the quintic polynomial
        :param T: array of full durations
        :param T0: array of quartic duations (the same shape as T)
        :param snaps: array of quartic snaps (the same shape as T)
        :return: boolean array of physical validity for all input polynomials
        """
        min_jerk, max_jerk = Config().ego.min_longitudinal_jerk, max(Config().ego.max_longitudinal_jerk)
        min_acc, max_acc = min(Config().ego.min_longitudinal_acceleration_default), max(Config().ego.max_longitudinal_acceleration_default)

        quartic_a_extr_t = -j0 / snaps  # acceleration extremum time of quartic
        quartic_a_extr = a0 - 0.5 * j0 ** 2 / snaps  # acceleration extremum of quartic
        valid_quartic_a = ((quartic_a_extr_t < 0) | (quartic_a_extr_t > T0) | (
                    (quartic_a_extr > min_acc) & (quartic_a_extr < max_acc)))
        valid_a1 = (seam_a > min_acc) & (seam_a < max_acc)

        T1 = T - T0
        T2 = T1 * T1
        T3 = T2 * T1

        J1 = T0 * snaps + j0  # final jerk of quartic
        JT = 3 * (-T2 * seam_a - 8 * T1 * seam_v - 12 * T1 * vT + 20 * quintic_dist) / T3  # final jerk of quintic

        # polynomial coefficients of quintic acceleration
        a_t_coeffs = np.array([(-10 * T2 * seam_a - 60 * T1 * (seam_v + vT) + 120 * quintic_dist) / (T3 * T2),
                               (18 * T2 * seam_a + 96 * T1 * seam_v + 84 * T1 * vT - 180 * quintic_dist) / (T3 * T1),
                               (-9 * T2 * seam_a - 36 * T1 * seam_v - 24 * T1 * vT + 60 * quintic_dist) / T3,
                               seam_a])
        # check jerk validity
        j_t_coeffs = np.array([3 * a_t_coeffs[0], 2 * a_t_coeffs[1], a_t_coeffs[2]])  # quintic jerk coefficients
        internal_j_t = -j_t_coeffs[1] / (2 * j_t_coeffs[0])  # jerk extremum time of quintic
        invalid_internal_j_t = (a_t_coeffs[0] == 0) | (internal_j_t < 0) | (internal_j_t > T1)
        internal_j = j_t_coeffs[0] * internal_j_t ** 2 + j_t_coeffs[1] * internal_j_t + j_t_coeffs[2]
        valid_internal_j = invalid_internal_j_t | ((internal_j > min_jerk) & (internal_j < max_jerk))
        valid_edge_jerks = (J1 > min_jerk) & (J1 < max_jerk) & (JT > min_jerk) & (JT < max_jerk)
        valid_jerk = (valid_edge_jerks & valid_internal_j)

        # check acceleration validity
        # first calculate acceleration extremum time by solving quadratic equation
        discr = np.sqrt(j_t_coeffs[1] * j_t_coeffs[1] - 4 * j_t_coeffs[0] * j_t_coeffs[2])
        internal_a_t = np.array([-j_t_coeffs[1] - discr, -j_t_coeffs[1] + discr]) / (2 * j_t_coeffs[0])
        invalid_internal_a_t = np.isnan(internal_a_t) | (internal_a_t < 0) | (internal_a_t > T1)
        internal_a = a_t_coeffs[0] * internal_a_t ** 3 + a_t_coeffs[1] * internal_a_t ** 2 + a_t_coeffs[
            2] * internal_a_t + a_t_coeffs[3]
        valid_internal_a = (invalid_internal_a_t | ((internal_a > min_acc) & (internal_a < max_acc))).all(axis=0)
        valid_acc = (valid_quartic_a & valid_a1 & valid_internal_a)

        # check speed validity
        valid_speed = (vT > 0) | (JT >= 0)  # invalidate only negative final speed, i.e. vT=0 and negative final jerk

        is_valid = (valid_speed & valid_acc & valid_jerk)
        return is_valid

    @classmethod
    def _find_jerk_optimal_duration(cls, j0: float, seam_v: np.array, seam_a: np.array, quintic_dist: np.array,
                                    vT: float, T: np.array, T0: np.array, snaps: np.array,
                                    w_J: np.array, is_valid: np.array) -> [np.array, np.array]:
        """
        Choose time-jerk optimal multi-polynomials for the given jerk weights.
        The resulting polynomials are valid by physically.
        :param j0:
        :param seam_v: final quartic (or initial quintic) speed
        :param seam_a: final quartic (or initial quintic) acceleration
        :param quintic_dist: difference between final and initial s of the quintic polynomial
        :param vT: final speed
        :param T: 2D array of full durations of shape (snaps x durations)
        :param T0: 2D array of quartic durations (the same shape as T)
        :param snaps: 2D array of quartic snaps (the same shape as T)
        :param w_J: array of jerk weights
        :param is_valid: boolean array (the same shape as T) indicating valid physicality
        :return: 2 arrays of size len(w_J): best snap idxs (dim 0 of the input 2D array), best T idxs (dim 1 of the input 2D array)

        The following pysym code calculates the quartic and quintic cumulative jerks:

        t, T0, T1 = symbols('t T0 T1')
        v0, a0, j0 = symbols('v0 a0 j0')
        sT, vT, aT, Tm = symbols('sT vT aT Tm')
        snap = symbols('snap')
        quintic_dist, seam_v, seam_a = symbols('quintic_dist seam_v seam_a')

        # calculate quartic cumulative jerk
        x_t = (snap/24. * t ** 4 + j0/6. * t ** 3 + 0.5*a0 * t ** 2 + v0 * t).simplify()
        j_t = sp.diff(x_t, t, 3).simplify()
        J0_cum = sp.integrate(j_t ** 2, (t, 0, T0)).simplify()
        print('J0_cum', J0_cum)

        # calculate quintic cumulative jerk
        A = Matrix([
            [0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 1, 0],
            [0, 0, 0, 2, 0, 0],
            [T1 ** 5, T1 ** 4, T1 ** 3, T1 ** 2, T1, 1],
            [5 * T1 ** 4, 4 * T1 ** 3, 3 * T1 ** 2, 2 * T1, 1, 0],
            [20 * T1 ** 3, 12 * T1 ** 2, 6 * T1, 2, 0, 0]]
        )
        [c5, c4, c3, c2, c1, c0] = A.inv() * Matrix([0., seam_v, seam_a, quintic_dist, vT, 0.])
        x_t = (c5 * t ** 5 + c4 * t ** 4 + c3 * t ** 3 + c2 * t ** 2 + c1 * t + c0).simplify()
        j_t = sp.diff(x_t, t, 3).simplify()
        J1_cum = sp.integrate(j_t ** 2, (t, 0, T1)).simplify()
        print('J1_cum =', J1_cum)
        """

        T1 = T - T0  # quintic durations

        # calculate cumulative jerk for the quintic polynomial
        T2 = T1 * T1
        T3 = T2 * T1

        # calculate cumulative jerk for quartic and quintic polynomials
        J0_cum = T0 * (T0 ** 2 * snaps ** 2 / 3. + T0 * j0 * snaps + j0 ** 2)  # quartic
        J1_cum = 3 * (T3 * seam_a * (3 * T1 * seam_a + 24 * seam_v + 16 * vT)
                      + T2 * (64 * (seam_v + vT) ** 2 - 16 * seam_v * vT - 40 * seam_a * quintic_dist)
                      + 240 * quintic_dist * (quintic_dist - T1 * (seam_v + vT))) / (T3 * T2)

        # full cumulative jerk
        J_cum = J0_cum + J1_cum

        T = T[None, ...] + np.zeros(w_J.shape + T.shape[-2:])
        snaps = snaps[None, ...] + np.zeros(w_J.shape + T.shape[-2:])

        costs = J_cum[None, ...] * w_J[:, None, None] + T
        costs[np.isnan(costs)] = np.inf

        # For each pair of w_J and snap find the first local minimum of the cost function over all T.
        # Then for each w_J choose snap with the lowest cost. Sign flip of snap cannot be chosen as local minima.
        local_minima = (is_valid[..., 1:-1] &
                        (costs[..., 1:-1] < costs[..., 2:]) & (costs[..., 1:-1] < costs[..., :-2])
                        & (snaps[..., 2:] * snaps[..., :-2] > 0))
        best_snap_T_idx = np.argmax(local_minima, axis=-1) + 1  # matrix of T indices of shape (w_J x snaps)
        # for the cases when there is no local minimum, choose global minimum
        monotonic = (~local_minima).all(axis=-1)  # find cases when there is no local minimum
        costs[:, ~is_valid] = np.inf
        best_snap_T_idx[monotonic] = np.nanargmin(costs[monotonic], axis=-1)  # set global minimum
        # choose best snap among the found local minima
        snap_grid, w_J_grid = np.meshgrid(np.arange(costs.shape[1]), np.arange(costs.shape[0]))
        best_snap_idx = np.argmin(costs[w_J_grid, snap_grid, best_snap_T_idx], axis=1)
        best_T_idx = best_snap_T_idx[np.arange(costs.shape[0]), best_snap_idx]

        # extract aggressiveness levels with valid costs
        valid_aggr_levels = np.isfinite(costs[np.arange(w_J.shape[0]), best_snap_idx, best_T_idx])
        return best_snap_idx[valid_aggr_levels], best_T_idx[valid_aggr_levels]


class QuinticQuarticMotionPlanner(IMotionPlanner):

    @classmethod
    def plan_motion(cls, ego_init_fstate: np.ndarray, j_0: float = None, target_init_fstate: np.ndarray = None,
                    desired_jerk: float = None, desired_accel: float = None,
                    desired_snaps: Optional[np.ndarray] = None, acceleration_cubics: bool = False,
                    T_offset: float = 0., headway=2.0, is_subdivision: bool = False) -> (List[IMotionPlan], List[str]):
        """
        Generate follow motion plan for decelerating situations, where first we reach the strongest deceleration
        using quintic poly, then reach actor's velocity at desired headway with quartic poly.
        We play with the duration of the first quintic and with final headway violation.
        """

        x0, v0, a0 = ego_init_fstate[[types.FS_SX, types.FS_SV, types.FS_SA]]
        j0 = j_0
        xA = target_init_fstate[types.FS_SX] - ego_init_fstate[types.FS_SX]
        vT = target_init_fstate[types.FS_SV]
        hw = headway

        if v0 < vT + Config().driving.negligible_velocity and \
                (v0 < vT or vT > Config().driving.negligible_velocity or xA > 0):  # only braking profiles are relevant
            return [], []

        t0_res = 0.25
        T0 = np.arange(t0_res, 6, t0_res)[None, :]  # DOF for quintic duration
        eff_vT = max(vT, LOW_SPEED)
        XA = np.linspace(xA - 0.125*hw*eff_vT, xA + 0.5*hw*eff_vT, 30)[:, None]  # DOF for headway violation

        min_allowed_acc, max_allowed_acc, min_allowed_jerk, max_allowed_jerk = \
            _get_longitudinal_physicality_limits(fstate=ego_init_fstate, is_emergency=False, is_subdivision=is_subdivision)

        if vT < Config().driving.negligible_velocity and xA < 0:  # if effective stopped actor is behind ego, then stop
            if v0 < 1e-3:
                return [], []
            poly = QuinticQuarticMotionPlanner.stop_for_stopped_aggressive(x0, v0, a0, min_allowed_jerk, max_allowed_jerk, min_allowed_acc)
            polynomials = [poly]
            action_name = 'quartic_stop'
        else:
            # penalize stronger for headway violation in case of stopping actors than in case of moving actors
            target_weight = Config().driving.follow_target_weight if vT > Config().driving.negligible_velocity else Config().driving.follow_target_weight_for_stopping

            # calculate quintic-quartic (q5q4) parameters
            T1, x1, v1, a1, q5q4_total_cost = QuinticQuarticMotionPlanner.calc_quintic_quartic(
                v0, a0, j0, xA, XA, vT, hw, T0, min_allowed_acc, max_allowed_acc, min_allowed_jerk, max_allowed_jerk, target_weight)

            # check quartic alone (q4)
            q4_T, q4_xT, q4_total_cost = QuinticQuarticMotionPlanner.calc_quartic_alone(v0, a0, j0, xA, vT, hw, max_allowed_jerk, target_weight)

            # among q5q4 and q4 choose having the lowest cost
            q5q4_cost = np.nanmin(q5q4_total_cost) if np.isfinite(q5q4_total_cost).any() else np.inf
            q4_cost = np.nanmin(q4_total_cost) if np.isfinite(q4_total_cost).any() else np.inf

            if q5q4_cost < q4_cost:
                polynomials = QuinticQuarticMotionPlanner.build_best_score_quintic_quartic(x0, v0, a0, vT, T0, XA, T1, x1, v1, a1, q5q4_total_cost)
                action_name = 'quintic_quartic'
            elif np.isfinite(q4_cost):
                idx = np.nanargmin(q4_total_cost)
                polynomials = [QuarticPolySolution(T=q4_T[idx], x_0=x0, v_0=v0, a_0=a0, v_T=vT)]
                action_name = 'quartic'
            elif v0 - vT > 3 and vT > LOW_SPEED and (v0 - vT)**2 > (hw*vT - xA) * min_allowed_acc:  # required avg dec is stronger than 1/2 min_allowed_acc
                # the most aggressive braking, if quintic_quartic is not valid
                polynomials = QuinticQuarticMotionPlanner.create_most_aggressive_braking(x0, v0, a0, j0, vT, min_allowed_acc, min_allowed_jerk, max_allowed_jerk)
                action_name = 'most_aggressive'
            else:
                return [], []

            # determinize poly by addition constant velocity (or constant acceleration for non-zero final acceleration)
            poly = MultiPolySolution(polynomials)
            if poly.T > Config().mcts.action_follow_max_duration:
                poly = poly.crop(0., Config().mcts.action_follow_max_duration)

        T = Determinizer.determinize_time(0., offset=poly.T)
        if T > EPS_DURATION:
            if np.isclose(poly.a_T, 0):  # constant velocity
                const_poly = QuarticPolySolution(T=T, x_0=poly.x_T, v_0=poly.v_T, a_0=poly.a_T, v_T=poly.v_T)
            else:  # constant acceleration
                const_poly = CubicPolySolution(T=T, x_0=poly.x_T, v_0=poly.v_T, a_0=poly.a_T, a_T=poly.a_T)
            quantized = MultiPolySolution(polynomials + [const_poly])
        elif T > 0:
            quantized = poly.extend(T)
        else:
            quantized = poly
        return [quantized], [action_name]

    @staticmethod
    def calc_quintic_quartic(v0: float, a0: float, j0: float, xA: float, XA: np.ndarray, vT: float, hw: float, T0: np.ndarray,
                             min_allowed_acceleration: float, max_allowed_acceleration: float,
                             min_allowed_jerk: float, max_allowed_jerk: float, target_weight: float):
        """
        Calculate quintic-quartic profiles for 2 degrees of freedom.
        :param v0: init vel
        :param a0: init acc
        :param j0: init jerk
        :param xA: init dist from actor (after subtraction of margins)
        :param XA: array of init dist from actor (used by DOF for headway violation)
        :param vT: target vel
        :param hw: desired headway
        :param T0: array of quintic durations
        :param min_allowed_acceleration:
        :param max_allowed_acceleration:
        :param min_allowed_jerk:
        :param max_allowed_jerk:
        :param target_weight: weight of headway violation
        :return: quartic durations (T1), s,v,a in the seam between quintic and quartic, total costs for each profile
        """

        # Let T0, T1 are durations of quintic and quartic, x1,v1,a1 are (s,v,a) in the seam
        # Algorithm:
        # 1. calc x1 based on T0, a1, v1 using equation j(0) = j0
        # 2. calc v1 based on T0, a1, using equation j(T0) = 0 (quintic ends with the strongest deceleration)
        # 3. calc inverted (accelerating) quartic from vT to v1, when the final x1 is given instead of a1
        #    (see class Quartic_given_x_T)
        # 4. calc T1 based on T0, x1, v1, a1 using equation for the quartic: j(T1) = 0
        # 5. substitute calculated T1, x1, v1 in a1, obtaining expression of the variable a1 (and T0)
        # 6. calc a1 based on T0, using the equation a1_quartic == -a1_quintic (quadratic equation with 2 roots)

        dv = v0 - vT
        hx = hw*vT - XA
        T0_2 = T0*T0
        T0_3 = T0_2*T0
        Tj = T0*j0

        disc = (T0_2*T0_2*(Tj*(Tj + 14*a0) + (64*a0*a0 + 40*j0*dv))
                + 40*T0_2*(T0*(13*a0*dv + j0*hx) + 22*a0*hx + 34*dv*dv)
                + hx*(5600*T0*dv + 6400*hx))

        disc_sqrt = 4 * np.sqrt(disc)
        b = -T0_3*j0 - 22*T0_2*a0 - 140*T0*dv - 320*hx

        a1 = np.array([b + disc_sqrt, b - disc_sqrt]) / (6*T0_2)

        x1 = T0_2/20 * (Tj + 7*a0 + 3*a1) + T0*v0
        v1 = T0_2*j0/12 + 0.5*T0 * (a0 + a1) + v0
        T1 = 8 * (T0*vT - hx - x1) / (3*(v1 - vT))

        # calculate j_quin (the lowest jerk) and previous root of parabola j(t) (in addition to t=T1)
        j_root_t, j_quin = QuinticQuarticMotionPlanner.calc_quintic_jerk(T0, T0_2, T0_3, Tj, a0, j0, a1)
        j_quar = 2*(T1*a1 + 3*(v1 - vT)) / (T1*T1)  # final jerk of quintic-quartic
        j_max = np.maximum(np.abs(j_quin), np.abs(j_quar))
        c5_sign = 0.5*T0_2*(a1 - a0) - 3*T0*(v0 + v1) + 6*x1  # highest quintic coefficient * T0^5

        # measure early braking cost based on the parabola j(t) roots, such that the result does not depend on the
        # current time and does not change in time if we continue with the same braking profile
        T_ext = T0 - j_root_t  # the distance between two roots of the parabola j(t)
        # mark all invalid states
        T_ext[(T_ext < 0) | (T1 < 0) | (T0 + T1 > 25) | (v1 < 0) |
              (j_quar > max_allowed_jerk) | (j_quar < min_allowed_jerk) |
              (j_quin > max_allowed_jerk) | (j_quin < min_allowed_jerk) |
              (a1 > max_allowed_acceleration) | (a1 < min_allowed_acceleration) |
              ((c5_sign < 0) & (j_quar < 0))  # prevent acc increase (sad jerk parabola) and headway violation (v(t) < vT)
        ] = np.nan
        rel_brake_t = T_ext / (T_ext + T1)  # relative braking time: how early ego reaches the strongest deceleration

        # calculate 3D total cost of the braking profile for two DOF (T0 and XA) and two roots of quadratic equation
        if not np.isnan(rel_brake_t).all():
            q5q4_total_cost = QuinticQuarticMotionPlanner.calc_total_cost(
                v0=v0, j_max=j_max, j_final=j_quar, delta_a=a1 - a0, rel_brake_t=rel_brake_t,
                poly_j0=j0, j0=j0, poly_xT=XA + (T0 + T1 - hw) * vT, target_xT=xA + (T0 + T1 - hw) * vT, vT=vT, headway=hw,
                rel_brake_wgt=Config().driving.follow_reactivity_weight, target_wgt=target_weight)
        else:
            q5q4_total_cost = np.array([np.inf])

        return T1, x1, v1, a1, q5q4_total_cost

    @staticmethod
    def calc_quartic_alone(v0, a0, j0, xA, vT, hw, max_allowed_jerk, target_weight):
        """
        Calculate quartic braking profile for the case we passed the quintic part.
        :param v0:
        :param a0:
        :param j0:
        :param xA:
        :param vT:
        :param hw:
        :param max_allowed_jerk:
        :param target_weight: weight of headway violation
        :return:
        """
        # We enable the quartic to violate the desired headway, but punish it in target cost.
        # quartic.x_T is determined only by the quartic duration.
        T_j = QuinticQuarticMotionPlanner.get_quartic_duration_given_j0(v0, a0, j0, vT)
        # We enable the quartic poly to start with j(0) != j0, but punish it in consistency cost.
        # j(0) is determined only by the quartic duration.
        T_x_min = QuinticQuarticMotionPlanner.get_quartic_duration_given_xA(v0, a0, vT, xA, hw)
        if not (np.isfinite(T_j) or np.isfinite(T_x_min)):
            return None, None, np.array([np.inf])

        # calc duration for the largest headway violation
        T_x_max = QuinticQuarticMotionPlanner.get_quartic_duration_given_xA(v0, a0, vT, xA + 0.5*hw*vT, hw)
        T_x_max = min(T_x_max, Config().mcts.action_follow_max_duration)
        dt = 0.125
        T_min = max(dt, min(T_j, T_x_min))
        T_max = max(T_j, T_x_max)
        if np.isfinite(T_min) and np.isfinite(T_max):
            T = np.arange(T_min, T_max + 1e-3, dt)
        elif np.isfinite(T_x_max):
            T = np.arange(dt, T_x_max + 1e-3, dt)
        else:
            T = np.arange(dt, Config().mcts.action_follow_max_duration, dt)

        dv = v0 - vT
        c = 6*dv/T**2
        poly_j0 = -4*a0/T - c
        poly_jT = 2*a0/T + c
        T[poly_j0 > poly_jT] = np.nan  # linear j(t) has to increase because we start with braking and release it
        if np.isnan(T).all():
            return None, None, np.array([np.inf])

        valid = np.isfinite(T)
        T_valid = T[valid]
        Ta = T_valid*a0
        c1 = 2*Ta + 3*dv
        c2 = Ta + 2*dv

        a_min_t = T_valid*c1/(3*c2)  # time of minimal acc (may be negative)
        a_min_valid = np.where(a_min_t > 0, (Ta * c2 - c1 * c1 / 3) / (T_valid * c2), a0)
        xT_valid = T_valid * (Ta / 12 + (v0 + vT) / 2)
        rel_a_min_t_valid = np.maximum(0., a_min_t / T_valid)  # early braking (the smaller the better)

        # calc the deceleration peak
        xT = np.full_like(T, np.nan)
        xT[valid] = xT_valid
        rel_a_min_t = np.full_like(T, np.nan)
        rel_a_min_t[valid] = rel_a_min_t_valid
        a_min = np.full_like(T, np.nan)
        a_min[valid] = a_min_valid

        # calc maximal jerk
        q4_jerk = np.maximum(-poly_j0, poly_jT)
        q4_jerk[poly_jT > max_allowed_jerk] = np.nan

        # calc total cost
        q4_total_cost = QuinticQuarticMotionPlanner.calc_total_cost(
            v0=v0, j_max=q4_jerk, j_final=poly_jT, delta_a=a_min - a0, rel_brake_t=rel_a_min_t,
            poly_j0=poly_j0, j0=j0, poly_xT=xT, target_xT=xA + (T - hw) * vT, vT=vT, headway=hw,
            rel_brake_wgt=Config().driving.follow_reactivity_weight, target_wgt=target_weight)

        return T, xT, q4_total_cost

    @staticmethod
    def build_best_score_quintic_quartic(x0: float, v0: float, a0: float, vT: float, T0: np.ndarray, XA: np.ndarray,
                                         T1: np.ndarray, x1: np.ndarray, v1: np.ndarray, a1: np.ndarray,
                                         q5q4_total_cost: np.ndarray):
        """
        Calculate quintic & quartic polynomials using parameters with the lowest cost.
        :param x0:
        :param v0:
        :param a0:
        :param vT: target speed
        :param T0: array of quintic durations
        :param XA: array of initial distances from actor (used for DOF of headway violation)
        :param T1: array of quartic durations
        :param x1: s at the seam point
        :param v1:
        :param a1:
        :param q5q4_total_cost:
        :return:
        """
        idx = np.nanargmin(q5q4_total_cost.ravel())
        T0_idx = idx % T0.shape[-1]
        xA_idx = (idx // T0.shape[-1]) % XA.shape[0]
        quad_idx = idx // (T0.shape[-1] * XA.shape[0])
        res_T0 = T0[0, T0_idx]
        res_T1 = T1[quad_idx, xA_idx, T0_idx]
        res_x1 = x1[quad_idx, xA_idx, T0_idx]
        res_v1 = v1[quad_idx, xA_idx, T0_idx]
        res_a1 = a1[quad_idx, xA_idx, T0_idx]
        quintic1 = QuinticPolySolution(T=res_T0, x_0=x0, v_0=v0, a_0=a0, x_T=x0 + res_x1, v_T=res_v1, a_T=res_a1)
        quartic2 = QuarticPolySolution(T=res_T1, x_0=x0 + res_x1, v_0=res_v1, a_0=res_a1, v_T=vT)
        return [quintic1, quartic2]

    @staticmethod
    def get_quartic_duration_given_j0(v0, a0, j0, vT):
        """
        Calculate quartic given its initial jerk instead of final acceleration.
        :param v0:
        :param a0:
        :param j0:
        :param vT:
        :return:
        """
        dv = v0 - vT
        if abs(j0) > DIVISION_THRESH:
            disc = 4*a0**2 - 6*j0*dv
            if disc < 0:
                return np.inf
            sqrt_disc = np.sqrt(disc)
            if np.isnan(sqrt_disc):
                return np.inf
            T1 = -(2*a0 - sqrt_disc)/j0
            T2 = -(2*a0 + sqrt_disc)/j0
        else:  # j0 is almost zero
            if abs(a0) < DIVISION_THRESH:
                return np.inf
            T1 = -3*dv/(2*a0)
            T2 = np.inf

        if T1 < 0:
            T1 = np.inf
        if T2 < 0:
            T2 = np.inf
        return min(T1, T2)

    @staticmethod
    def get_quartic_duration_given_xA(v0, a0, vT, xA, hw):
        """
         Calculate quartic given its initial distance from followed actor instead of final acceleration.
        :param v0:
        :param a0:
        :param vT:
        :param xA:
        :param hw:
        :return:
        """
        dv = v0 - vT
        if abs(a0) > DIVISION_THRESH:
            disc = -12*a0*(hw*vT - xA) + 9*dv**2
            if disc < 0:
                return np.inf
            disc_sqrt = np.sqrt(disc)
            T1 = (-3*dv - disc_sqrt)/a0
            T2 = (-3*dv + disc_sqrt)/a0
        else:
            if abs(dv) < DIVISION_THRESH:
                return np.inf
            T1 = -2*(hw*vT - xA)/dv
            T2 = np.inf

        if T1 < 0:
            T1 = np.inf
        if T2 < 0:
            T2 = np.inf
        return min(T1, T2)

    @staticmethod
    def create_most_aggressive_braking(x0, v0, a0, j0, vT, min_allowed_acc, min_allowed_jerk, max_allowed_jerk):
        """
        Create the most aggressive braking and then reach zero acceleration ASAP.
        First, reach strongest deceleration, then continue with constant min_allowed_acceleration until vT,
        finally, reach zero acceleration ASAP.
        :param x0:
        :param v0:
        :param a0:
        :param j0:
        :param vT:
        :param min_allowed_acc:
        :param min_allowed_jerk:
        :param max_allowed_jerk:
        :return:
        """
        # reach strongest deceleration with minimal allowed jerk
        T_res = 0.05
        T_arr = np.arange(T_res, 2., T_res)
        q5_T0, q5_x1, q5_v1 = QuinticQuarticMotionPlanner.calc_quintic_alone(
            T_arr, v0, a0, j0, aT=min_allowed_acc, min_allowed_jerk=min_allowed_jerk,
            max_allowed_jerk=max_allowed_jerk)
        q5_dec = QuinticPolySolution(T=q5_T0, x_0=x0, v_0=v0, a_0=a0, x_T=x0 + q5_x1, v_T=q5_v1, a_T=min_allowed_acc)

        if q5_v1 > vT:  # continue with constant min_allowed_acceleration until vT
            q3 = CubicPolySolution(a_0=min_allowed_acc, v_0=q5_v1, x_0=x0 + q5_x1, a_T=min_allowed_acc,
                                   T=(vT - q5_v1) / min_allowed_acc)
            polynomials = [q5_dec, q3]
        else:  # crop q5 when it reaches vT
            times = np.arange(0., q5_dec.T, T_res)
            vt = q5_dec.velocity(times)
            t_idx = np.where(vt > vT)[0][-1]
            q5_dec = q5_dec.crop(start_time=0, end_time=times[t_idx])
            polynomials = [q5_dec]

        # reach zero acceleration ASAP
        last_poly = polynomials[-1]
        x1, v1, a1, j1 = last_poly.x_T, last_poly.v_T, last_poly.a_T, last_poly.jerk(last_poly.T)
        q5_T, q5_xT, q5_vT = QuinticQuarticMotionPlanner.calc_quintic_alone(
            T=T_arr, v0=v1, a0=a1, j0=j1, aT=0., min_allowed_jerk=min_allowed_jerk, max_allowed_jerk=max_allowed_jerk)
        q5_acc = QuinticPolySolution(T=q5_T, x_0=x1, v_0=v1, a_0=a1, x_T=x1 + q5_xT, v_T=q5_vT, a_T=0.)
        polynomials.append(q5_acc)
        return polynomials

    @staticmethod
    def calc_quintic_alone(T, v0, a0, j0, aT, min_allowed_jerk: float, max_allowed_jerk: float):
        """
        Create quintic based on the minimal jerk
        :param T:
        :param v0:
        :param a0:
        :param j0:
        :param aT:
        :param min_allowed_jerk:
        :param max_allowed_jerk:
        :return:
        """
        T0_2 = T * T
        T0_3 = T0_2 * T
        Tj = T * j0
        q5_x1 = T * ((Tj + 7 * a0 + 3 * aT) * T / 20 + v0)
        q5_v1 = T0_2 * j0 / 12 + 0.5 * T * (a0 + aT) + v0

        _, q5_j = QuinticQuarticMotionPlanner.calc_quintic_jerk(T, T0_2, T0_3, Tj, a0, j0, aT)
        valid_jerk_idxs = np.where((q5_j > min_allowed_jerk) & (q5_j < max_allowed_jerk))[0]
        if len(valid_jerk_idxs) == 0:
            return None, None, None
        idx = valid_jerk_idxs[0]
        return T[idx], q5_x1[idx], q5_v1[idx]

    @staticmethod
    def stop_for_stopped_aggressive(x0, v0, a0, min_allowed_jerk: float, max_allowed_jerk: float, min_allowed_acceleration: float):
        """
        Create stopping quartic from low speed with shortest T, such that it does not get negative velocities.
        :param v0:
        :param a0:
        :param min_allowed_jerk:
        :return:
        """
        dt = Config().mcts.determinization_dt
        T = np.arange(dt, 6, dt)[:, None]
        t = np.arange(dt, 6, dt)[None, :]
        tT = t/T
        v_t = a0*t + v0 + tT*(a0*t*(tT - 2) + v0*tT*(2*tT - 3))
        a_t = a0 + tT*(a0*(3*tT - 4) + 6*v0*(tT - 1)/T)
        j_t = 2*(T*a0*(3*tT - 2) + 3*v0*(2*tT - 1))/T**2

        is_invalid_T = np.any((t < T) &
                              ((v_t < 0) | (a_t < min_allowed_acceleration) | (j_t < min_allowed_jerk) | (j_t > max_allowed_jerk)),
                              axis=1)
        if is_invalid_T.all():
            return None
        min_T = T[np.argmin(is_invalid_T), 0]  # get first valid T
        return QuarticPolySolution(T=min_T, x_0=x0, v_0=v0, a_0=a0, v_T=0.)

    @staticmethod
    def calc_quintic_jerk(T, T_2, T_3, Tj, a0, j0, aT):
        """
        Calculate minimal jerk of quintic
        :param T: duration
        :param T_2: T**2
        :param T_3: T**3
        :param Tj: T*j0
        :param a0:
        :param j0:
        :param aT:
        :return: j(t) root, jerk peak
        """
        c5 = (Tj + 2 * (a0 - aT)) / (4 * T_3)
        c4 = (-Tj / 6 - 0.25 * (a0 - aT)) / T_2
        c4_div_c5 = c4 / c5

        # find j_root_t < T0 as another root of parabola j(t), i.e. the place where j'(t) = -j'(T0)
        j_root_t = -T - 2 * c4_div_c5
        j_min_t = -c4_div_c5
        j_min = j0 + 12 * j_min_t * (2 * c4 + c5 * j_min_t)
        return j_root_t, j_min

    @staticmethod
    def calc_total_cost(v0, j_max, j_final, delta_a, rel_brake_t, poly_j0, j0, poly_xT, target_xT, vT, headway,
                        rel_brake_wgt, target_wgt):
        """
        Cost:
        1. Comfort (j_min)
        2. Consistency (j0_q - j0)
        3. Target (xT_q - xT)
        4. Early braking (time of a_min) * a_min^2 (weight)
        5. Duration (T)
        :param v0:
        :param j_max:
        :param j_final:
        :param delta_a:
        :param rel_brake_t:
        :param poly_j0:
        :param j0:
        :param poly_xT:
        :param target_xT:
        :param vT:
        :param headway:
        :return:
        """
        j_thresh = abs(Config().ego.min_longitudinal_jerk)
        a_thresh = Config().ego.min_longitudinal_acceleration_default_interpolator(v0)

        # relative jerk
        comfort_cost = np.abs(j_max / j_thresh)

        # how close j0 of the polynomial to j0 from the prev plan; penalize more for opposite sign
        consistency_cost = 0
        if not np.isscalar(poly_j0):
            j0_sign_change = -(j0*poly_j0) * (j0*poly_j0 < 0).astype(float)
            consistency_cost = np.abs((poly_j0 - j0)/j_thresh) * (1 + 3*j0_sign_change)

        # how close xT of the polynomial to the target xT; unsafe xT is punished much stronger
        rel_headway = (poly_xT - target_xT) / (max(vT, LOW_SPEED) * headway)  # relative headway
        target_cost = np.full_like(rel_headway, np.nan)
        valid = np.isfinite(rel_headway)
        valid_rel_headway = rel_headway[valid]
        valid[valid] = valid_rel_headway < 1  # prevent overflow of np.exp
        valid_rel_headway = valid_rel_headway[valid_rel_headway < 1]
        exp_coef = target_wgt / max(1e-2, (headway - 1)**2)  # for smaller desired headway use stronger violation cost
        target_cost[valid] = np.where(valid_rel_headway > 0,
                                      np.exp(np.minimum(100, exp_coef*valid_rel_headway**2)) - 1,  # prevent exp overflow
                                      valid_rel_headway**2)

        # smaller relative time of a_min is better; the weight: relative magnitude of acceleration
        early_braking_cost = rel_brake_wgt * (np.abs(delta_a / a_thresh)) * rel_brake_t

        non_monotonic_vel_cost = 0.5 * (j_final < 0).astype(float)  # v0 > vT but near the end v < vT

        total_cost = comfort_cost + consistency_cost + target_cost + early_braking_cost + non_monotonic_vel_cost
        return total_cost
