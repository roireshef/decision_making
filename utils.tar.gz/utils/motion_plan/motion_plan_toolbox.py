import copy
import numpy as np
from typing import Optional

from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.data_structures.motion_plan.multi_poly_solution import MultiPolySolution
from subdivision_planner.src.data_structures.motion_plan.poly1d_solutions import QuarticPolySolution, CubicPolySolution, \
    QuinticPolySolution, EPS_DURATION
from subdivision_planner.src.mdp.determinizer import Determinizer
from subdivision_planner.src.mdp.werling.action_type import ComponentDirection
from subdivision_planner.src.mdp.werling.utils.acceleration_profile import sample_a_spec, \
    estimate_cubic_intersection_with_spec


MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED = 1e-3
NEGLIGIBLE_A = 1e-2


def create_jerk_continuous_quintic(ego_fstate: np.ndarray,
                                   delta_a: float,
                                   j_0: float,
                                   max_abs_jerk: float) -> Optional[QuinticPolySolution]:
    """
    Create the quintic polynomial which preserves continuity with j_0, and ends in j_T = 0.0
    :param ego_fstate:
    :param delta_a:
    :param j_0:
    :param max_abs_jerk:
    :return:
    """
    t_min = max(abs(j_0) / Config().ego.max_snap, Config().mcts.determinization_dt)
    first_quintic_durations = np.arange(t_min, Config().driving.follow_cubic_max_duration,
                                        Config().mcts.determinization_dt)
    quintic = None

    for idx in range(first_quintic_durations.size):
        # todo: vectorize
        # todo: explain or remove
        first_quintic_duration = first_quintic_durations[idx]
        beta = 6. * j_0 / (first_quintic_duration ** 2) - 12 * delta_a / (first_quintic_duration ** 3)
        alpha = -0.5 * beta * first_quintic_duration - j_0 / first_quintic_duration

        t_ext = -alpha / beta
        if 0. <= t_ext <= first_quintic_duration:
            j_ext = -(alpha ** 2) / (2. * beta) + j_0
            if abs(j_ext) > max_abs_jerk:
                continue

        # Check max snap is not passed
        snap_0 = alpha
        snap_T = alpha + beta * first_quintic_duration
        max_abs_snap = max(abs(snap_0), abs(snap_T))
        if max_abs_snap > Config().ego.max_snap:
            continue

        v_T = ego_fstate[types.FS_SV] + ego_fstate[types.FS_SA] * first_quintic_duration + \
              j_0 * (first_quintic_duration ** 2) / 2. + alpha * (first_quintic_duration ** 3) / 6. + \
              beta * (first_quintic_duration ** 4) / 24.
        x_T = ego_fstate[types.FS_SX] + ego_fstate[types.FS_SV] * first_quintic_duration + \
              ego_fstate[types.FS_SA] * (first_quintic_duration ** 2) / 2. + j_0 * (first_quintic_duration ** 3) / 6. + \
              alpha * (first_quintic_duration ** 4) / 24. + beta * (first_quintic_duration ** 5) / 120.
        quintic = QuinticPolySolution(a_0=ego_fstate[types.FS_SA],
                                      v_0=ego_fstate[types.FS_SV],
                                      x_0=ego_fstate[types.FS_SX],
                                      a_T=ego_fstate[types.FS_SA] + delta_a,
                                      v_T=v_T,
                                      x_T=x_T,
                                      T=first_quintic_duration)
        break

    if quintic is not None and quintic.T < MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED:
        return None

    return quintic


def build_accel_cubic_follow(ego_init_fstate: np.ndarray,
                             actor_effective_init_fstate: np.ndarray,
                             j_0: float):
    """
    Generates multi poly of when acceleration is needed.
    Using program tables to choose acceleration level.
    :param ego_init_fstate:
    :param actor_effective_init_fstate:
    :param j_0:
    :return:
    """
    cubic_polys = []

    v0 = ego_init_fstate[types.FS_SV]
    a0 = ego_init_fstate[types.FS_SA]
    vT = actor_effective_init_fstate[types.FS_SV]

    if vT - v0 < Config().driving.action_follow_acc_cubic_min_dv:
        return None

    # Generate cubic to zero accel
    cubic_2_v0 = v0
    cubic_2_a0 = a0
    cubic_2_j0 = j_0
    cubic_2_x0 = ego_init_fstate[types.FS_SX]
    cubic_poly_1 = None
    should_create_cubic_1 = a0 < -1
    if should_create_cubic_1:

        cubic_poly_1 = create_jerk_continuous_quintic(ego_fstate=ego_init_fstate,
                                                      delta_a=0.0 - a0,
                                                      j_0=j_0,
                                                      max_abs_jerk=max(4., abs(j_0)))
        if cubic_poly_1 is not None:
            cubic_2_v0 = cubic_poly_1.v_T
            cubic_2_a0 = 0.0
            cubic_2_j0 = 0.0
            cubic_2_x0 = cubic_poly_1.x_T
            cubic_polys.append(cubic_poly_1)

    a_spec_at_v0 = sample_a_spec(velocities=cubic_2_v0,
                                 target_velocity=vT,
                                 is_subdivision=False)

    # If current acceleration is at spec or higher, this acceleration profile shouldn't be used
    cubic1_phase_failed = should_create_cubic_1 and cubic_poly_1 is None
    should_create_cubic_2 = (not cubic1_phase_failed) and (cubic_2_a0 < a_spec_at_v0)
    if should_create_cubic_2:
        J0_magnitude = Config().mcts.action_accelerate_cubic_jerk
        cubic_2_vT, cubic_2_aT, cubic_2_T = estimate_cubic_intersection_with_spec(cubic_2_v0,
                                                                                  cubic_2_a0,
                                                                                  vT,
                                                                                  J0_magnitude,
                                                                                  False)

        if cubic_2_vT is not None and cubic_2_vT >= 0.0:
            cubic_2_fstate = np.array([cubic_2_x0, cubic_2_v0, cubic_2_a0])
            cubic_poly_2 = create_jerk_continuous_quintic(ego_fstate=cubic_2_fstate,
                                                          delta_a=cubic_2_aT - cubic_2_a0,
                                                          j_0=cubic_2_j0,
                                                          max_abs_jerk=max(2., abs(j_0)))

            if cubic_poly_2 is not None:
                cubic_polys.append(cubic_poly_2)

                quartic_duration = 30. - sum([cubic.T for cubic in cubic_polys])
                quartic_poly = QuarticPolySolution(T=quartic_duration, a_0=cubic_poly_2.a_T, v_0=cubic_poly_2.v_T,
                                                   x_0=cubic_poly_2.x_T, v_T=vT, a_T=0.0)
                cubic_polys.append(quartic_poly)

                multi_poly = MultiPolySolution.generate_motion_plan(
                    poly_types=[p.poly_type for p in cubic_polys],
                    initial_frenet_state=ego_init_fstate[:types.FS_SA + 1],
                    final_frenet_states=[p.target_fstate for p in cubic_polys],
                    direction=ComponentDirection.Longitudinal,
                    durations=[p.T for p in cubic_polys],
                    generate_polynomials=cubic_polys)
                return multi_poly

    if len(cubic_polys) == 0:
        return None


class MotionPlanToolbox:

    @staticmethod
    def build_acceleration_delta(
            ego_fstate: np.ndarray,
            a_target: float,
            j_0: float,
            j_limit: float,
            j_T: float = 0.0,
            snap_max_abs = 2.0,
            min_time = -1.0,
            negative_velocity_backup: float = 0.5
    ) -> Optional[MultiPolySolution]:
        """
        This function builds the acceleration delta in trapezoidal form.
        1st Quartic polynomial - go with constant snap to a certain jerk level
        2nd Cubic polynomial (optional) - stays on this jerk
        3rd Quartic polynomial - Gets back to j = 0.0
        :param ego_fstate:
        :param a_target:
        :param j_0:
        :param j_limit:
        :param j_T:
        :param snap_max_abs:
        :param min_time:
        :param negative_velocity_backup:
        :return:
        """
        if j_limit < abs(j_0):
            j_limit = abs(j_0)

        delta_a = a_target - ego_fstate[2]
        j_limit_sign = np.sign(delta_a)

        # Check with j_ext = j_min to check if t2>0
        def get_poly_times(j_ext, j_T, j_0):
            t1 = abs((j_ext - j_0) / snap_max_abs)
            t3 = abs((j_T - j_ext) / snap_max_abs)
            return t1, t3

        def delta_accel(j_ext, j_T, j_0, former_signed_snap):
            t1, t3 = get_poly_times(j_ext, j_T, j_0)
            delta_a = t1 * j_0 + former_signed_snap * t1 ** 2 / 2.0 + \
                      t3 * j_ext + -former_signed_snap * t3 ** 2 / 2.0
            return delta_a

        j_limit_max = max(j_limit, j_0)
        j_limit_min = min(-j_limit, j_0)
        positive_snap_first_total_a = delta_accel(j_limit_max, j_T, j_0, snap_max_abs)
        negative_snap_first_total_a = delta_accel(j_limit_min, j_T, j_0, -snap_max_abs)

        if min(negative_snap_first_total_a, positive_snap_first_total_a) < delta_a < max(negative_snap_first_total_a,
                                                                                         positive_snap_first_total_a):

            # No need for intermidiate poly
            positive_snap_first_j_ext_abs_val = np.sqrt(j_0 ** 2 / 2.0 + j_T ** 2 / 2.0 + delta_a * snap_max_abs)
            negative_snap_first_j_ext_abs_val = np.sqrt(j_0 ** 2 / 2.0 + j_T ** 2 / 2.0 + delta_a * -snap_max_abs)

            positive_snap_first_delta_a1 = delta_accel(positive_snap_first_j_ext_abs_val, j_T, j_0, snap_max_abs)
            positive_snap_first_delta_a2 = delta_accel(-positive_snap_first_j_ext_abs_val, j_T, j_0, snap_max_abs)
            negative_snap_first_delta_a1 = delta_accel(negative_snap_first_j_ext_abs_val, j_T, j_0, -snap_max_abs)
            negative_snap_first_delta_a2 = delta_accel(-negative_snap_first_j_ext_abs_val, j_T, j_0, -snap_max_abs)

            # snap_sign = np.sign(j_T - j_0)
            snap_options = [snap_max_abs, snap_max_abs, -snap_max_abs, -snap_max_abs]
            j_ext_options = [positive_snap_first_j_ext_abs_val, -positive_snap_first_j_ext_abs_val,
                             negative_snap_first_j_ext_abs_val, -negative_snap_first_j_ext_abs_val]
            delta_a_options = [
                positive_snap_first_delta_a1,
                positive_snap_first_delta_a2,
                negative_snap_first_delta_a1,
                negative_snap_first_delta_a2
            ]
            i = np.where(np.isclose(delta_a, delta_a_options))[0][0]
            snap_sign = np.sign(snap_options[i])
            j_ext = j_ext_options[i]

            t1, t3 = get_poly_times(j_ext, j_T, j_0)

            if t1 < MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED:
                t1 = 0

            if t3 < MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED:
                t3 = 0

            # Poly 1
            poly1 = QuarticPolySolution.from_initial_jerk_and_snap(
                x_0=ego_fstate[0],
                v_0=ego_fstate[1],
                a_0=ego_fstate[2],
                j_0=j_0,
                snap=snap_max_abs * snap_sign,
                T=t1
            )

            # Poly 3
            poly3 = QuarticPolySolution.from_initial_jerk_and_snap(
                x_0=poly1.x_T,
                v_0=poly1.v_T,
                a_0=poly1.a_T,
                j_0=j_ext,
                snap=-snap_max_abs * snap_sign,
                T=t3
            )

            poly = MultiPolySolution(polynomials=[poly1, poly3])

        else:
            j_ext = j_limit_max if j_limit_sign > 0 else j_limit_min
            closer_to_negative_border = abs(delta_a - negative_snap_first_total_a) < \
                                        abs(delta_a - positive_snap_first_total_a)
            snap_sign = -1 if closer_to_negative_border else 1
            total_a = negative_snap_first_total_a if closer_to_negative_border else positive_snap_first_total_a
            snap = snap_max_abs * snap_sign
            t1, t3 = get_poly_times(j_ext, j_T, j_0)
            t2 = abs((delta_a - total_a) / j_ext)

            if t1 < MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED:
                t1 = 0

            if t2 < MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED:
                t2 = 0

            if t3 < MIN_TIME_FOR_MULTI_POLY_TO_BE_CREATED:
                t3 = 0

            # Poly 1
            poly1 = QuarticPolySolution.from_initial_jerk_and_snap(
                x_0=ego_fstate[0],
                v_0=ego_fstate[1],
                a_0=ego_fstate[2],
                j_0=j_0,
                snap=snap,
                T=t1
            )

            # Poly 2
            poly2 = QuarticPolySolution.from_initial_jerk_and_snap(
                x_0=poly1.x_T,
                v_0=poly1.v_T,
                a_0=poly1.a_T,
                j_0=j_ext,
                snap=0.0,
                T=t2
            )

            # Poly 3
            poly3 = QuarticPolySolution.from_initial_jerk_and_snap(
                x_0=poly2.x_T,
                v_0=poly2.v_T,
                a_0=poly2.a_T,
                j_0=j_ext,
                snap=-snap,
                T=t3
            )

            poly = MultiPolySolution(polynomials=[poly1, poly2, poly3])

        def add_zero_jerk_poly(poly: MultiPolySolution, duration: float) -> MultiPolySolution:
            if duration <= 0:
                return poly

            zero_jerk_cubic = CubicPolySolution.from_fstate(init_fstate=poly.target_fstate,
                                                            a_T=poly.a_T,
                                                            T=duration)
            new_polynomials = copy.deepcopy(poly.polynomials)
            new_polynomials.append(zero_jerk_cubic)

            return MultiPolySolution(polynomials=new_polynomials)

        def determinize_poly(poly: MultiPolySolution) -> MultiPolySolution:
            t_to_be_determinized = Determinizer.determinize_time(poly.T) - poly.T
            return add_zero_jerk_poly(poly, t_to_be_determinized)

        # Extend multipoly with zero jerk poly if less than min time
        if poly.T < min_time:
            delta_t = Determinizer.determinize_time(min_time) - poly.T
            poly = add_zero_jerk_poly(poly, delta_t)

        poly = determinize_poly(poly)

        # Modify motion plan if we reach negative velocities
        times = np.linspace(0., poly.T, 100)
        velocity = poly.velocity(times)

        if any(velocity < 0):
            if np.isclose(ego_fstate[types.FS_SV], 0):
                return None

            first_negative_velocity_idx = np.where(velocity < 0)[0][0]
            crop_time = times[first_negative_velocity_idx] - negative_velocity_backup

            if crop_time > 0:
                cropped_poly = poly.crop(0., crop_time)
                assert isinstance(cropped_poly, MultiPolySolution)
                fstate_at_crop = cropped_poly.target_fstate
                polynomials = cropped_poly.polynomials
            else:
                fstate_at_crop = ego_fstate
                polynomials = []

            v0, a0 = fstate_at_crop[[types.FS_SV, types.FS_SA]]
            a2_desired = -NEGLIGIBLE_A

            # Constant jerk scenarios dependent on a0
            #   a0 < 0           a0 >= 0
            # a              a
            # ^              ^ t0
            # |              | \
            # |-------> t    |  \     t3
            # |    /         |------------> t
            # |   /          |  t1\  /
            # |  /           |     \/
            # | t0 t1        |     t2
            if a0 < 0:
                if a0 <= -NEGLIGIBLE_A:
                    # v1 = v0 + a0*t01 + 1/2*j01*t01^2 ---- j01 = (a1 - a0)/t01 = (0 - a0)/t01 = -a0/t01 ----> v1 = v0 + 1/2*a0*t01
                    # v1 = 0 ----> t01 = -2*v0/a0
                    duration = -2 * v0 / a0
                    constant_jerk_to_stop_cubic = CubicPolySolution.from_fstate(init_fstate=fstate_at_crop,
                                                                                a_T=0.,
                                                                                T=duration)
                    new_polynomials = [constant_jerk_to_stop_cubic]
                else:
                    # First ramp to a higher deceleration and then down to zero.
                    # a
                    # ^
                    # |      t2
                    # |----------> t
                    # |      /
                    # |  \  /
                    # |   \/
                    # | t0 t1
                    # v1 = v0 + a0*t01 + 1/2*j01*t01^2 ---- j01 = (a1 - a0)/t01 ----> v1 = v0 + 1/2*t01*(a0 + a1)
                    # v2 = v1 + a1*t12 + 1/2*j12*t12^2 ---- j12 = (a2 - a1)/t12 = (0 - a1)/t12 = -a1/t12 ----> v2 = v1 + 1/2*a1*t12
                    # Plug v1 into v2 equation and solve for t12 where v2 = 0 and j01 = -j12
                    # ----> t12 = 2*v0*a1 / (a0^2 - 2*a1^2)    v0 > 0, a1 < 0 therefore, for t12 > 0, a0^2 - 2*a1^2 < 0
                    # ----> a1 >  |a0| * (1/2)^(1/2)
                    #       a1 < -|a0| * (1/2)^(1/2)
                    a1_limit = -abs(a0) * np.sqrt(.5)
                    a1 = -NEGLIGIBLE_A if -NEGLIGIBLE_A < a1_limit else a1_limit - NEGLIGIBLE_A
                    t12 = 2*v0*a1 / (a0**2 - 2*a1**2)
                    t01 = (a1 - a0) * t12 / a1
                    constant_jerk_to_a1_cubic = CubicPolySolution.from_fstate(init_fstate=fstate_at_crop,
                                                                              a_T=a1,
                                                                              T=t01)
                    constant_jerk_to_stop_cubic = CubicPolySolution.from_fstate(init_fstate=constant_jerk_to_a1_cubic.target_fstate,
                                                                                a_T=0.,
                                                                                T=t12)
                    new_polynomials = [constant_jerk_to_a1_cubic, constant_jerk_to_stop_cubic]
            else:
                # v1 = v0 + a0*t01 + 1/2*j01*t01^2 ---- j01 = (a1 - a0)/t01 = (0 - a0)/t01 = -a0/t01 ----> v1 = v0 + 1/2*a0*t01
                # v2 = v1 + a1*t12 + 1/2*j12*t12^2 ---- j12 = (a2 - a1)/t12 = (a2 - 0)/t12 = a2/t12 ----> v2 = v1 + 1/2*a2*t12
                # v3 = v2 + a2*t23 + 1/2*j23*t23^2 ---- j23 = (a3 - a2)/t23 = (0 - a2)/tj23 = -a2/t23 ----> v3 = v2 + 1/2*a2*t23
                #  0 = v1 + 1/2*a2*t12 + 1/2*a2*t23 = v0 + 1/2*a0*t01 + a2*t12    since t12 = t23 and v3 = 0
                if a0 == 0:
                    # 0 = v0 + 1/2*a0*t01 + a2*t12 = v0 + a2*t12    since a0 = 0
                    # ----> t12 = -v0 / a2
                    t12 = -v0 / a2_desired  # t12 = t23
                    constant_jerk_to_a2_cubic = CubicPolySolution.from_fstate(init_fstate=fstate_at_crop,
                                                                              a_T=a2_desired,
                                                                              T=t12)
                else:
                    # j01 = j12 ----> -a0/t01 = a2/t12 ----> t12 = -a2*t01 / a0
                    # 0 = v0 + 1/2*a0*t01 + a2*(-a2*t01 / a0) = v0 + (a0^2 - 2*a2^2) * t01 / (2*a0)
                    # ----> t01 = 2*v0*a0 / (2*a2^2 - a0^2)    v0 and a0 > 0 therefore, for t01 > 0, 2*a2^2 - a0^2 > 0
                    # ----> a2 >  a0 * (1/2)^(1/2)    but we know that the RHS is positive and a2 < 0 so we only need the next line
                    #       a2 < -a0 * (1/2)^(1/2)
                    a2_limit = -a0 * np.sqrt(.5)
                    a2 = a2_desired if a2_desired < a2_limit else a2_limit - NEGLIGIBLE_A

                    t01 = 2 * v0 * a0 / (2 * a2**2 - a0**2)
                    assert t01 > 0, f't01 = {t01}, v0 = {v0}, a0 = {a0}, a2 = {a2}'
                    t12 = -a2 * t01 / a0  # t12 = t23
                    assert t12 > 0, f't12 = {t12}, t01 = {t01}, a0 = {a0}, a2 = {a2}'
                    constant_jerk_to_a2_cubic = CubicPolySolution.from_fstate(init_fstate=fstate_at_crop,
                                                                              a_T=a2,
                                                                              T=t01 + t12)
                constant_jerk_to_stop_cubic = CubicPolySolution.from_fstate(init_fstate=constant_jerk_to_a2_cubic.target_fstate,
                                                                            a_T=0.,
                                                                            T=t12)
                new_polynomials = [constant_jerk_to_a2_cubic, constant_jerk_to_stop_cubic]

            poly = determinize_poly(MultiPolySolution(polynomials=polynomials + new_polynomials))

        # verify that the final state enables to stop with valid constant positive jerk
        max_jerk = Config().ego.max_longitudinal_jerk[-1]
        v_T, a_T = poly.v_T, poly.a_T

        # solve the equation for final speed assuming constant jerk: v + at + jt^2/2 = 0, where t = -a/j
        if a_T < 0 and 2 * v_T * max_jerk < a_T * a_T:
            dt = Config().mcts.determinization_dt
            times = np.arange(dt, poly.T + 1e-3, dt)
            a_t = poly.acceleration(times)
            v_t = poly.velocity(times)
            valid_idxs = np.where(2*v_t*max_jerk > a_t*a_t)[0]
            if len(valid_idxs) == 0:  # no valid time
                return None
            poly = poly.crop(0., times[valid_idxs[-1]])  # crop at last valid time

        # generate poly
        return poly

    @staticmethod
    def create_multipoly_for_jerk_and_accel_levels(ego_fstate: np.ndarray,
                                                   a_target: float,
                                                   j_0: float,
                                                   j_limit: float,
                                                   min_duration: float = 2.0) -> MultiPolySolution:
        """
        Given ego_state, this method returns a list of JerkPolySolution that have to be carried out sequentially
        The first polynomial decelerates to max_decel with a continuous jerk Quintic poly,
        and the next drives with constant acceleration (jerk=0) up to a
        :param ego_fstate: ego current frenet state
        :param j_0: Current jerk. Used for continuity purposes
        :param a_target: Target acceleration
        :param j_limit: applied constant jerk during the cubic action
        :param min_duration: cubic duration
        :return: A list of CubicPolySolution to be carried out.
        """

        if (abs(ego_fstate[types.FS_SA] - a_target) < Config().driving.delta_a_to_keep_jerk_0_polynomial) and \
                abs(
                    j_0) < Config().driving.delta_j_to_keep_jerk_0_polynomial:  # todo: consider putting that: max_snap * dt
            cubic = CubicPolySolution.from_fstate(ego_fstate, ego_fstate[types.FS_SA], min_duration)
            return MultiPolySolution(polynomials=[cubic])

        max_abs_jerk = max(min(abs(j_limit), abs(Config().ego.min_longitudinal_jerk)),
                           abs(j_0))

        quintic_1 = create_jerk_continuous_quintic(ego_fstate=ego_fstate,
                                                   delta_a=a_target - ego_fstate[types.FS_SA],
                                                   j_0=j_0,
                                                   max_abs_jerk=max_abs_jerk)
        if quintic_1 is None:
            # todo: Maybe apply the good old cubic?
            return MultiPolySolution(polynomials=[])

        if quintic_1.T >= min_duration:
            return MultiPolySolution(polynomials=[quintic_1])

        # Add a cubic to fill the duration
        ego_fstate = quintic_1.target_fstate

        second_cubic_duration = min_duration - quintic_1.T
        cubic_2 = CubicPolySolution.from_fstate(ego_fstate, a_target, second_cubic_duration)

        return MultiPolySolution(polynomials=[quintic_1, cubic_2])

    @staticmethod
    def generate_trapezoidal_stop_motion_plan(ego_fstate: np.ndarray,
                                              nominal_decel: float,
                                              time_nominal_decel: float,
                                              nominal_jerk: float,
                                              min_jerk: float
                                              ) -> MultiPolySolution:
        """
        Generates a 1, 2, or 3 polynomial motion plan to bring vehicle to a stop, with determinized duration
        First cubic decelerates to a nominal deceleration based on a defined jerk -
            used if host's acceleration is above a defined acceleration
        Second cubic decelerates at the nominal deceleration with 0 jerk -
            used if a stop can't be achieved with constant jerk without decelerating with bigger deceleration then the
            defined one
        Third cubic decelerates to a stop (v_final=0, a_final=0) based on the same defined jerk
        This function is used only if v0 > 0, otherwise a stopped component should be used (generated externally)
        :param ego_fstate: initial Frenet state
        :param nominal_decel: nominal deceleration for the stop (negative value)
        :param time_nominal_decel: minimal time (sec) to use nominal deceleration to ensure comfortable not-jerky
            stopping motion plan (should be positive)
        :param nominal_jerk: nominal jerk used when reaching the nominal decel (negative value)
        :param min_jerk: minimal allowed negative jerk (negative value)
        :return: determinized MultiPolySolution composing of a one, two or three cubic polynomials
        """
        motion_plans = []

        assert nominal_jerk < 0, "nominal_jerk must be less than 0"
        assert min_jerk < 0, "min_jerk must be less than 0"
        assert time_nominal_decel > 0, "time_at_nominal_decel must be greater than 0"

        a0 = ego_fstate[types.FS_SA]
        v0 = ego_fstate[types.FS_SV]

        # Case 1
        # Nominal jerk can be too big and zero the velocity before the acceleration is zeroed,so just come to a stop with
        # a jerk that zeroes the velocity and acceleration:
        # a = a0 + JT = 0
        # v = v0 + a0*T / 2 = 0
        # --->  J = (a0^2 / (2*v0),  T = -a0/J
        #   a
        #   |
        #   |
        #   |
        #   |------------------->t
        #   |        /
        #   |       /
        #   |      /
        #         t0 t1

        if a0 < 0 and v0 <= a0*a0 / (-2*nominal_jerk):
            constant_jerk_to_stop_cubic_poly = CubicPolySolution.from_fstate(init_fstate=ego_fstate,
                                                                             T=-2*v0/a0,
                                                                             a_T=0.)
            motion_plans.append(constant_jerk_to_stop_cubic_poly)
            end_time = constant_jerk_to_stop_cubic_poly.T
            t_to_determinized = Determinizer.determinize_time(end_time) - end_time
            stopped_poly = CubicPolySolution.from_fstate(init_fstate=constant_jerk_to_stop_cubic_poly.target_fstate,
                                                         T=t_to_determinized,
                                                         a_T=0.)
            motion_plans.append(stopped_poly)
            motion_plan = MultiPolySolution(polynomials=motion_plans)
            return motion_plan

        # Case 2
        #   The target is to create three motion plans. The middle one will be at least T sec long(config) with a
        #   deceleration value which is not bigger than max_nominal_decel (config).
        #   The first one will be a constant jerk motion plan which ends with that deceleration value and the third one will
        #   start with that deceleration and go down to a stop with constant jerk
        #
        #   T23 = time_nominal_decel
        #   a2 = a3 = nominal_decel
        #   a
        #   |  \                            |                               |                           |
        #   |   \                           |                               |                           |
        #   |    \                          |                               |                           |
        #   |------------------->t   or     |------------------------   or  |------------------- or     |------------------
        #   |      \         /              |      \         /              |           /               |           /
        #   |       \       /               |       \       /               |   \      /                |          /
        #   |        \_____/                |        \_____/                |    \____/                 |    _____/
        #     t0  t1 t2   t3 t4                                                                         |   /
        #           Case 2.1                         Case 2.2                     Case 2.3                  Case 2.4
        # If the calculated deceleration is bigger (a_Wanted < a_max_nominal), the max_nominal deceleration time will be
        # used and the duration of the motion plan will be calculated accordingly

        # All the calculations are based on zeroing the velocity at the end of the full motion plan with the first and third
        # parts of the motion plan being with a preset constant jerk.

        if a0 <= 0:
            # Cases 2.2/2.3/2.4 a0 = a1, v0=v1
            v1 = v0
            a1 = a0
            jerk = nominal_jerk
            initial_state_for_decel_to_nom_decel_poly = ego_fstate
        else:
            # Case 2.1
            # v1 = v0-J*T01, T01 = a0/J ---> v1 = v0-(a0^2)/(2J)
            # The actual jerk is a sum of nominal jerk and current acceleration multiplied by a weight factor
            # Jerk is limited
            aimed_jerk01 = nominal_jerk - a0 * Config().driving.trapezoidal_stop_accel_factor
            jerk01 = max(aimed_jerk01, min_jerk)
            v1 = v0 - 0.5*a0**2/jerk01
            a1 = 0
            t_to_zero_decel = -a0/jerk01
            constant_jerk_to_max_decel_cubic_poly = CubicPolySolution.from_fstate(
                init_fstate=ego_fstate,
                a_T=0.,
                T=t_to_zero_decel)
            # Polynomial for the first part of the motion plan - decelerating to zero deceleration
            motion_plans.append(constant_jerk_to_max_decel_cubic_poly)
            initial_state_for_decel_to_nom_decel_poly = constant_jerk_to_max_decel_cubic_poly.target_fstate

            aimed_jerk12 = nominal_jerk - v1 * Config().driving.trapezoidal_stop_velocity_factor
            jerk = max(aimed_jerk12, min_jerk)
        jt = jerk * time_nominal_decel

        # Calculate deceleration of the constant deceleration motion plan with its target duration set to time_nominal_decel
        v1j = v1 * jerk
        if a1 >= nominal_decel:
            # v4 = v1 - (a1+a2)*(a1-a2)/(2J) + a2*T + (a2^2)/(2J) = 0
            # ---> (a2)^2 + J*T*a2 + J*v1 - (a1^2)/2 = 0 ----------> a2 = (-J*T - sqrt((J*T)^2 - 4*J*v1 + 2*a1^2))/2
            needed_nominal_decel = (-jt-np.sqrt(jt**2 - 4*v1j + 2*a1**2))/2
        else:
            # v4 = v1 + (a1+a2)*(a1-a2)/(2J) =0
            # ---> a2*T + v1 + (a1^2)/(2*J) = 0 ----------> a2 = -(2*v1*J + a1^2)/(2*J*T)
            needed_nominal_decel = -(v1j + 0.5*a1**2)/jt

        # Nominal deceleration is limited by max_nominal_decel.  If the calculated nominal deceleration is bigger than
        # the max nominal deceleration (config), use the max_nominal deceleration and derive the duration of that
        # motion plan.
        if needed_nominal_decel < nominal_decel:
            max_decel = nominal_decel
        else:
            max_decel = needed_nominal_decel

        # After a2 (max decel) is defined, we can calculate the duration od the first and third motions:
        # T12 = (a2 - a1)/J
        t_to_max_decel_const_jerk = np.abs((max_decel - a1)/jerk)
        # T34 = (0-a2)/J
        t_max_decel_to_stop_const_jerk = max_decel / jerk

        # Polynomial for the part of the motion plan that decelerates to max deceleration
        # (from the accel = min(0, initial acceleration))
        constant_jerk_to_max_decel_cubic_poly = CubicPolySolution.from_fstate(
            init_fstate=initial_state_for_decel_to_nom_decel_poly,
            a_T=max_decel,
            T=t_to_max_decel_const_jerk)
        motion_plans.append(constant_jerk_to_max_decel_cubic_poly)

        # Polynomial for the second part of the motion plan - constant deceleration
        # Calculation of the time needed at constant deceleration (T23) is based on zeroing the velcoity with
        # the constant deceleration polynomial and the last constant jerk polynomial:
        # V4 = V2 + T23*a_nominal + T34*a_nominal/2 = 0 (zeroing the integral of acceleration at T24)
        # T34 = a_nominal/j_nominal
        # ----> T23 = -V2/a_nominal - a_nominal /(2*j_nominal)
        # Dividing by max_decel is legal as it can't equal 0 for initial positive velocity
        assert max_decel != 0
        t_constant_deceleration = ((max_decel / (2*(-jerk))) - constant_jerk_to_max_decel_cubic_poly.v_T / max_decel)
        if t_constant_deceleration >= EPS_DURATION:
            constant_decel_cubic_poly = CubicPolySolution.from_fstate(
                init_fstate=constant_jerk_to_max_decel_cubic_poly.target_fstate,
                T=t_constant_deceleration,
                a_T=max_decel)
            motion_plans.append(constant_decel_cubic_poly)

        # The final state of the constant acceleration poly will be the initial state for the third part
        initial_state_for_to_stop_poly = motion_plans[-1].target_fstate

        # Polynomial for the last part of the motion plan - constant jerk to stop
        constant_jerk_to_stop_cubic_poly = CubicPolySolution.from_fstate(init_fstate=initial_state_for_to_stop_poly,
                                                                         T=t_max_decel_to_stop_const_jerk,
                                                                         a_T=0.)
        motion_plans.append(constant_jerk_to_stop_cubic_poly)

        # Append another polynomial to ensure that the end of the action is in a determinized time
        undeterminized_motion_plan = MultiPolySolution(polynomials=motion_plans)
        end_time = undeterminized_motion_plan.T
        t_to_determinized = Determinizer.determinize_time(end_time) - end_time
        stopped_poly = CubicPolySolution.from_fstate(init_fstate=undeterminized_motion_plan.target_fstate,
                                                     T=t_to_determinized,
                                                     a_T=0.)
        motion_plan = MultiPolySolution(polynomials=motion_plans + [stopped_poly])
        return motion_plan
