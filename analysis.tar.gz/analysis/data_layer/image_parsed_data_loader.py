import os
import pickle
from functools import lru_cache

import cv2
import numpy as np
from subdivision_planner.src.messages.scene_common_messages import Timestamp
import CtmPython


@lru_cache(maxsize=128)
def read_image(path: str):
    image = cv2.imread(path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


class ImageParsedDataLoader:
    """
    Loader for image data that relies on ADA parsed data (data parsed by ADA team and saved in a common location).
    Abstracts entire parsed folder, meaning it assumes the folder is structured in the specific way ADA generated it.
    It is also used to access meta data of the images (CTM transformations, timestamps, etc...)
    """
    def __init__(self, base_path: str, sensor_name: str):
        """
        ctor
        :param base_path: Base path for the parse folder (folder with json files)
        :param sensor_name: Name of the sensor to be loaded
        """
        self._base_path = base_path
        self._sensor_name = sensor_name

        self._timestamps = None
        self._data_creation_timestamps = None
        self._image_filenames = None

        # CTM object to be used for projections
        self._ctm = None

        # Camera object to be used for transforms
        self._camera = None

        # Load meta data (file names etc.)
        self._load_metadata()

    def _load_metadata(self):
        """
        This method loads from pickled files all the meta data of the recorded images like timestamp and file names so
        data can be accessed easily later
        """
        meta_data_file_name = f"{self._sensor_name}_parsed_pure_json.json.pkl"
        with open(os.path.join(self._base_path, meta_data_file_name), 'rb') as f:
            meta_data = pickle.load(f)

        self._timestamps = []
        self._data_creation_timestamps = []
        self._image_filenames = []
        for image_meta_data in meta_data:
            timestamp = Timestamp(e_Cnt_Secs=image_meta_data['data']['s_PhysicalEventTime']['e_Cnt_Secs'],
                                  e_Cnt_FractionSecs=image_meta_data['data']['s_PhysicalEventTime']['e_Cnt_FractionSecs']).timestamp_in_seconds
            data_creation_timestamp = Timestamp(e_Cnt_Secs=image_meta_data['data']['s_DataCreationTime']['e_Cnt_Secs'],
                                  e_Cnt_FractionSecs=image_meta_data['data']['s_DataCreationTime'][
                                      'e_Cnt_FractionSecs']).timestamp_in_seconds
            self._timestamps.append(timestamp)
            self._data_creation_timestamps.append(data_creation_timestamp)
            self._image_filenames.append(image_meta_data["parser_processed_info"]["file_name"])

    def __len__(self):
        return len(self._timestamps)

    def __getitem__(self, item):
        """
        :param item: index of image to retrieve
        :return: image
        """
        path = os.path.join(self._base_path, self._sensor_name, self._image_filenames[item])
        if os.path.isfile(path):
            return read_image(path=path)
        else:
            return None

    def get_by_timestamp(self, time: float):
        """
        Retreives image by timestamp (loads the closest)
        :param time: physical event time of image to load
        :return: image
        """
        idx = np.argmin(np.abs(time - np.array(self._timestamps)))
        return self[idx]

    def get_by_data_creation_timestamp(self, time: float):
        """
        Retreives image by timestamp (loads the closest)
        :param time: physical event time of image to load
        :return: image
        """
        idx = np.argmin(np.abs(time - np.array(self._data_creation_timestamps)))
        return self[idx]

    @property
    def ctm(self):
        """
        :return: ctm object that contains transformations between sensors
        """
        if self._ctm is None:
            self._ctm = CtmPython.get_ctm(path=os.path.join(self._base_path, "config", "CTM"))
        return self._ctm

    @property
    def camera(self):
        """
        :return: Camera object as given by CTM, used for transformations
        """
        if self._camera is None:
            self._camera = self.ctm.get_camera(self._sensor_name)
        return self._camera

    @property
    def sensor_name(self):
        return self._sensor_name


if __name__ == "__main__":
    path = "/data/recordings/cdrive/integration/2020_07_28/parsed/EN8/Scenario_1_trial_1_host_1_t_10_14_12"
    sensor_name = "CAMERA_4MB_IMAGE_LF_BEHIND_WINDSHIELD"
    p = ImageParsedDataLoader(base_path=path, sensor_name=sensor_name)