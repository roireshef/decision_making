import os
from collections import defaultdict
from typing import Tuple, Dict, List, Optional

from interface.Rte_Types.python.sub_structures.TsSYS_PlannerInternalState import TsSYSPlannerInternalState
from rte.python.logger.log_utils import LOG_DIRECTORY
from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame, CanonicSequence
from subdivision_planner.src.data_structures.canonic_state import CanonicState
from subdivision_planner.src.utils.recording_parser import RecordingParser


class RecorderCanonicSequenceParser(ICanonicSequenceParser):
    """
    This class parses recorded data into canonic sequence
    """
    def __init__(self, path: Optional[str] = None):
        # recording parser
        if path is None:
            path = os.path.join(LOG_DIRECTORY, 'sd_recorded_data/planner')

        self._reader = RecordingParser(output_dir=path)

        self._frames = defaultdict(CanonicFrame)

        self._start_to_finish: Dict[int, int] = None
        self._finish_to_start: Dict[int, int] = None

    def to_canonic_sequence(self) -> CanonicSequence:
        return [self.__getitem__(frame_id) for frame_id in self.get_frame_ids()]

    def get_frame_ids(self) -> List[int]:
        return self._reader.get_frames_id_list()

    def __len__(self):
        return len(self.get_frame_ids())

    def get_deep_search_connections(self) -> Tuple[Dict[int, int], Dict[int, int]]:
        if self._start_to_finish is None:
            self._start_to_finish = defaultdict(lambda: None)
            deep_search_start = None

            for frame_id in self.get_frame_ids():
                frame: CanonicFrame = self.__getitem__(frame_id)

                data = frame.execution_info.s_Data

                # If the deep search finished in that frame, we log it to the start to finish dictionary for later use
                if data.e_b_IsDeepSearchFinished:
                    if deep_search_start is not None:
                        self._start_to_finish[deep_search_start] = data.e_Cnt_SeqNum
                    else:
                        print("Deep search finished, but didn't have a recording of deep search start, "
                              "frame: {}".format(data.e_Cnt_SeqNum))

                # If the deep search was initiated, remember that for later use
                if data.e_b_IsDeepSearchInitiated:
                    deep_search_start = data.e_Cnt_SeqNum
                    # Deal with cases where a deep search was reset in the middle of the run
                    self._start_to_finish[deep_search_start] = None

            self._finish_to_start = {v: k for k, v in self._start_to_finish.items() if v is None}

        return self._start_to_finish, self._finish_to_start

    def __getitem__(self, frame_id: int) -> CanonicFrame:
        if frame_id not in self._frames:
            frame_data = self._reader.get_by_frame_id(frame_id=frame_id)

            planner_data = frame_data.get("PlanningModule", frame_data.get("SubdivisionBTPlanner"))
            if planner_data:
                canonic_state: CanonicState = planner_data["state"]
                self._frames[frame_id].state = canonic_state

                if "action" in planner_data:
                    canonic_action: CanonicState = planner_data["action"]
                    self._frames[frame_id].action = canonic_action

            # TODO: add internal state to recorder
            if "planner_internal_state" in frame_data:
                internal_state: TsSYSPlannerInternalState = frame_data["MctsNode"]["internal_state"]
                self._frames[frame_id].internal_state = internal_state

        return self._frames[frame_id]
