import collections
import os
import numpy as np
import pickle
from collections import defaultdict
from typing import Optional, Dict, Tuple
from weakref import WeakValueDictionary

import yaml
from tqdm import tqdm
import warnings

from subdivision_learning.analysis.data_layer.canonic_sequence_pubsub_parser import RecordingMetadata, \
    PubSubCanonicFrameIdentifier, get_scene_static_map_cached, get_map_attributes_map_cached
from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_learning.analysis.data_layer.pubsub_data_loader import PubSubDataLoader
from subdivision_planner.src.common import types
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.data_structures.canonic_state import CanonicState
from subdivision_planner.src.data_structures.map import Map
from subdivision_planner.src.messages.scene_common_messages import Timestamp
# from subdivision_planner.src.map.map_provider import augment_map_with_stop_bars


class PubSubCanonicSequenceParserLite(ICanonicSequenceParser):
    """
    This class parses pubsub data into canonic sequence
    """

    def get_deep_search_connections(self) -> Tuple[Dict[int, int], Dict[int, int]]:
        raise NotImplementedError()

    def __init__(self,
                 path: str,
                 map_attributes_loader: Optional[PubSubDataLoader],
                 scene_static_loader: Optional[PubSubDataLoader],
                 canonic_state_loader: PubSubDataLoader,
                 scene_traffic_control_loader: Optional[PubSubDataLoader],
                 recording_metadata: Optional[RecordingMetadata] = None,
                 max_cache_size: int = 1
                 ):
        """
        ctor.
        The data the parser will read will be according to the loader it is given. Additional cropping of a recording
        can be done via recording_metadata
        :param path: path for the pub sub recordings
        :param map_attributes_loader: PubSubDataLoader of MapAttributes pubsub message
        :param scene_static_loader: PubSubDataLoader of SceneStatic pubsub message
        :param canonic_state_loader: PubSubDataLoader of Canonic State pubsub message
        :param scene_traffic_control_loader: PubSubDataLoader of SceneTrafficControl pubsub message
        :param recording_metadata: Metadata of the recordings to be loaded by the parser. If None is given, parser will
        :param max_cache_size: Maximal number of cached frames
        load all data and generate the meta data on its own. This metadata can be saved to file for future load.
        """
        assert map_attributes_loader is not None or scene_static_loader is not None, \
            f"Either the map attributes or scene static loader needs to be provided but neither are."

        self._path = path

        self._map_attributes_loader: PubSubDataLoader = map_attributes_loader
        self._scene_static_loader: PubSubDataLoader = scene_static_loader
        self._canonic_state_loader: PubSubDataLoader = canonic_state_loader
        self._scene_traffic_control_loader: PubSubDataLoader = scene_traffic_control_loader

        # This is a dictionary of all the frames in the recording with frame id as key and dictionaries as values. The
        # dictionaries contain canonic state, canonic action and planner internal state
        self._frames = WeakValueDictionary()

        if recording_metadata is None:
            self._parse_meta_data()
        else:
            self._frame_identifiers = recording_metadata.frame_identifiers
            self._map_attributes_identifiers = recording_metadata.map_attributes_identifiers
            self._scene_static_identifiers = recording_metadata.scene_static_identifiers
            self._scene_traffic_control_identifiers = recording_metadata.scene_traffic_control_identifiers

        self._max_cache_size = max(max_cache_size, 1)
        self._frame_identifiers_in_cache = collections.deque()

    def __next__(self):
        if self._frame_idx >= len(self):
            raise StopIteration

        self._frame_idx += 1
        # Return CanonicState, PlannerInternalState and CanonicAction at correct frame index
        return self[self.get_frame_ids()[self._frame_idx-1]]

    def __getitem__(self, item: int) -> CanonicFrame:
        """
        Return CanonicState, PlannerInternalState and CanonicAction at correct frame id (item)
        """
        frame = self.get_frame(self._frame_identifiers[item])
        return frame

    def __iter__(self):
        """
        Create an iterator out of the parser
        """
        self._frame_idx = 0
        return self

    def __len__(self):
        return len(self._frame_identifiers)

    def to_file(self, path: str):
        """
        This method generates a cache file this parser can be generated from to save precious parsing time. Note that
        from_file() assumes the cache file was generated for the entire recording parser and not for a cropped version
        of it.
        :param path: path of the cache file
        """
        with open(path, 'wb') as f:
            meta_data = RecordingMetadata(frame_identifiers=self._frame_identifiers,
                                          map_attributes_identifiers=self._map_attributes_identifiers,
                                          scene_static_identifiers=self._scene_static_identifiers,
                                          scene_traffic_control_identifiers=self._scene_traffic_control_identifiers,
                                          scene_og_identifiers=dict(),
                                          scene_fusion_identifiers=dict(),
                                          deep_search_start_to_finish=dict(),
                                          )
            pickle.dump((self._path, meta_data), f)

    @classmethod
    def from_file(cls,
                  path: str,
                  map_attributes_loader: PubSubDataLoader,
                  scene_static_loader: PubSubDataLoader,
                  canonic_state_loader: PubSubDataLoader,
                  scene_traffic_control_loader: PubSubDataLoader,
                  absolute_start_time: Optional[float] = None,
                  relative_start_time: Optional[float] = None,
                  duration: Optional[float] = None
                  ):
        """
        Loads the parser from cache file. Absolute start time and duration can be applied here to crop specific part of
        the recording
        :param map_attributes_loader: PubSubDataLoader of SceneStatic pubsub message
        :param scene_static_loader: PubSubDataLoader of SceneStatic pubsub message
        :param canonic_state_loader: PubSubDataLoader of Canonic State pubsub message
        :param scene_traffic_control_loader:PubSubDataLoader of SceneTrafficControl pubsub message
        :param path: path of the cache file
        :param relative_start_time: Time to start loading the data relative to beginning of recording in seconds, if not
            given, will start in beginning of recording. Can't be set together with absolute start time.
        :param absolute_start_time: Similar to relative_start_time, just in in absolute time (380...) and not relative
                                    to beginning of the recording. Can't be set together with relative start time
        :param duration: duration in seconds of time to load, if not given, will load data until recording ends
        :return:
        """
        with open(path, 'rb') as f:
            rec_path, meta_data = pickle.load(f)

            assert absolute_start_time is None or relative_start_time is None, "Can't set absolute and relative start time together"

            # Filter frame ids according to relative or absolute start time
            if absolute_start_time is not None or relative_start_time is not None:
                frame_identifiers = meta_data.frame_identifiers
                frame_ids_to_pop = []
                if absolute_start_time is not None:
                    for frame_id, frame_identifier in frame_identifiers.items():
                        relative_time = frame_identifier.state * 1e-9 - absolute_start_time
                        if not 0. <= relative_time <= duration:
                            frame_ids_to_pop.append(frame_id)

                if relative_start_time is not None:
                    first_frame_id = min(list(frame_identifiers.keys()))
                    first_timestamp = frame_identifiers[first_frame_id].state * 1e-9
                    for frame_id, frame_identifier in frame_identifiers.items():
                        relative_time = frame_identifier.state * 1e-9 - first_timestamp
                        if not relative_start_time <= relative_time <= relative_start_time + duration:
                            frame_ids_to_pop.append(frame_id)

                for frame_id in frame_ids_to_pop:
                    frame_identifiers.pop(frame_id)

            return cls(
                path=rec_path,
                map_attributes_loader=map_attributes_loader,
                scene_static_loader=scene_static_loader,
                canonic_state_loader=canonic_state_loader,
                scene_traffic_control_loader=scene_traffic_control_loader,
                recording_metadata=meta_data,
            )

    def _parse_meta_data(self):
        """
        This method loads all the data from the recording
        """
        # Reset all identifier dictionaries
        self._frame_identifiers = defaultdict(PubSubCanonicFrameIdentifier)
        self._map_attributes_identifiers = defaultdict(list)
        self._scene_static_identifiers = defaultdict(list)
        self._scene_occupancy_grid_identifiers = defaultdict(int)
        self._scene_traffic_control_identifiers = defaultdict(list)

        self._parse_map_attributes_meta_data()
        self._parse_scene_static_meta_data()
        self._parse_canonic_state_meta_data()
        self._parse_scene_traffic_control_meta_data()

    def _parse_map_attributes_meta_data(self):
        # Parse the maps from map attributes
        if self._map_attributes_loader is not None:
            timestamps, headers, _ = self._map_attributes_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, map_attributes_header in zip(timestamps, headers):
                map_id = map_attributes_header.e_Cnt_SeqNum
                self._map_attributes_identifiers[map_id].append(timestamp_nano)

    def _parse_scene_static_meta_data(self):
        # Parse the maps from scene static
        if self._scene_static_loader is not None:
            timestamps, headers, _ = self._scene_static_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, scene_static_header in zip(timestamps, headers):
                map_id = scene_static_header.e_Cnt_SeqNum
                self._scene_static_identifiers[map_id].append(timestamp_nano)

    def _parse_canonic_state_meta_data(self):
        # Parse the canonic state messages
        timestamps, headers, _ = self._canonic_state_loader.get_header_reader().read_pubsub_headers()
        for timestamp_nano, canonic_state_header in zip(timestamps, headers):
            frame_id = canonic_state_header.e_Cnt_SeqNum

            if self._frame_identifiers[frame_id].state is not None:
                print(f"Warning: CanonicState with frame id {frame_id} already exists, stopping parsing")
                return

            self._frame_identifiers[frame_id].state = timestamp_nano
            self._frame_identifiers[frame_id].frame_id = frame_id
            self._frame_identifiers[frame_id].timestamp = Timestamp.deserialize(canonic_state_header.s_Timestamp).timestamp_in_seconds

    def _parse_scene_traffic_control_meta_data(self):
        # Parse the scene_fusion messages
        if self._scene_traffic_control_loader is not None:
            timestamps, headers, _ = self._scene_traffic_control_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, scene_traffic_control_header in zip(timestamps, headers):
                scene_traffic_control_id = scene_traffic_control_header.e_Cnt_SeqNum
                self._scene_traffic_control_identifiers[scene_traffic_control_id] = timestamp_nano

    def get_map(self, map_id: int, timestamp: float = None) -> Optional[Map]:
        """
        Returns a map from map id. If map_id doesn't exit, returns None.
        :param map_id: id of the Map to retrieve
        :param timestamp: Timestamp of the map id, if received None will take the first one
        """
        if self._map_attributes_loader:
            data_loader = self._map_attributes_loader
            map_identifier = self._map_attributes_identifiers
        else:
            data_loader = self._scene_static_loader
            map_identifier = self._scene_static_identifiers

        if map_id not in map_identifier:
            return None

        if timestamp is None:
            # get the first timestamp if received None
            timestamp_nano = map_identifier[map_id][0]
        else:
            optional_timestamps = np.array(map_identifier[map_id])
            nearest_idx = np.argmin(np.abs(optional_timestamps * 1e-9 - timestamp))
            timestamp_nano = int(optional_timestamps.take(nearest_idx))

        if self._map_attributes_loader:
            return get_map_attributes_map_cached(timestamp_nano, data_loader)
        else:
            return get_scene_static_map_cached(timestamp_nano, data_loader)

    def get_frame(self, frame_identifier: PubSubCanonicFrameIdentifier) -> CanonicFrame:
        """
        Converts frame identifier to actual CanonicFrame. Always returns CanonicFrame, if part of it doesn't exist,
        might return an empty frame.
        """
        try:
            return self._frames[frame_identifier.frame_id]
        except KeyError:
            pass

        frame = CanonicFrame()

        if frame_identifier.state:
            canonic_state_pubsub_msg = self._canonic_state_loader.read_by_timestamp(frame_identifier.state)

            # get corresponding map for this frame
            map_id = canonic_state_pubsub_msg.s_Data.e_MapSeqNum
            if map_id not in self._scene_static_identifiers and map_id not in self._map_attributes_identifiers:
                print(f"Corresponding map not found for frame id {frame_identifier.frame_id}, pubsub parsing stopped")
                raise StopIteration  # show what you can

            map = self.get_map(map_id, frame_identifier.state*1e-9)

            # # TODO: enable map augmentation when scene traffic control publishes all road objects in the map
            # # augment the map with stop bars from scene traffic control
            # if self._scene_traffic_control_loader is not None:
            #     if 's_SceneTrafficControlTimestamp' in canonic_state_pubsub_msg.s_Data._dic:
            #         scene_traffic_control_timestamp = Timestamp.deserialize(
            #             canonic_state_pubsub_msg.s_Data.s_SceneTrafficControlTimestamp).timestamp_in_seconds
            #         scene_traffic_control_message = self._scene_traffic_control_loader.get_by_data_timestamp(
            #             timestamp=scene_traffic_control_timestamp)
            #         scene_traffic_control_data = scene_traffic_control_message.s_Data
            #         augment_map_with_stop_bars(map, scene_traffic_control_data)

            frame.state = CanonicState.deserialize(canonic_state_pubsub_msg, map)

        if len(self._frame_identifiers_in_cache) == self._max_cache_size:
            elem_to_remove = self._frame_identifiers_in_cache.popleft()
            if elem_to_remove in self._frames:
                self._frames.pop(elem_to_remove)

        self._frames[frame_identifier.frame_id] = frame
        self._frame_identifiers_in_cache.append(frame_identifier.frame_id)
        return frame

    def get_frame_ids(self):
        """
        :return: Returns a list of frame ids that exist in this recording. if only part of the recording is used, only
        part of the ids will be exposed.
        """
        return list(self._frame_identifiers.keys())

    def get_frame_ids_to_timestamps(self) -> Dict[int, float]:
        """
        :return: Returns a dictionary mapping from frame id to the physical event time of this frame
        """
        return {frame_id: identifier.timestamp for frame_id, identifier in self._frame_identifiers.items()}

    def to_canonic_sequence(self):
        """
        Generates a canonic sequence from all the frames this parser sees.
        """
        out = []
        for el in tqdm(self):
            out.append(el)
        return out


class PubSubRecordingMasterParserLite:
    """
    This class abstracts reading of data from a downloaded recording and exposes relevant parsers
    """
    def __init__(
            self,
            base_recording_path: str,
            relative_start_time: float = None,
            absolute_start_time: float = None,
            duration: float = 1e30
    ):
        """
        :param base_recording_path: path for the folder that contains the recording. The folder should be the parent
                                    folder of a "recordings" folder which contains all the pubsub data
        :param relative_start_time: Offset in time (in seconds) relative to the first frame state timestamp to start
                                    loading data from. This filter is on the the frame level and not on the pubsub
                                    message level.
        :param absolute_start_time: Time to start loading data from. This filter is on the the frame level and not on
                                    the pubsub message level
        :param duration: duration (in seconds) of the recording to be exposed
        """
        self._base_path = base_recording_path
        self._recording_path = self.get_recording_path(self._base_path)

        assert os.path.isdir(self._recording_path), f"A folder called recordings or Recordings doesn't exist in {self._base_path}"

        # Canonic sequence parser that can be exposed by this class
        self._canonic_sequence_parser: Optional[PubSubCanonicSequenceParserLite] = None
        self._canonic_sequence_parser_cache_file = os.path.join(self._base_path, "cache.pkl")

        # A dictionary of pubsub data loaders that can be exposed by this class
        self._pubsub_data_loaders: Dict[Tuple[str, str], PubSubDataLoader] = {}

        self._relative_start_time = relative_start_time
        self._absolute_start_time = absolute_start_time
        assert self._absolute_start_time is None or self._relative_start_time is None, \
            "Can't set absolute and relative start time together"
        self._duration = duration

    @property
    def canonic_sequence_parser(self) -> PubSubCanonicSequenceParserLite:
        if self._canonic_sequence_parser is None:
            # When first loading a recording, we must parse the entire recording so it can be cached
            all_recording = not os.path.isfile(self._canonic_sequence_parser_cache_file)
            all_recording = True

            map_attributes_loader = self.get_data_loader("UC_SYSTEM", "MAP_ATTRIBUTES", all_recording=all_recording, is_quick_parse=True)
            scene_static_loader = self.get_data_loader("UC_SYSTEM", "SCENE_STATIC", all_recording=all_recording, is_quick_parse=True)
            assert map_attributes_loader is not None or scene_static_loader is not None, f"Neither SceneStatic nor MapAttributes topic exist in folder {self._recording_path}"
            canonic_state_loader = self.get_data_loader("UC_PLANNING_INTERNAL", "CANONIC_STATE", all_recording=all_recording, is_quick_parse=True)
            assert canonic_state_loader, f"CanonicState topic doesn't exist in folder {self._recording_path}"
            scene_traffic_control_loader = self.get_data_loader("UC_SYSTEM", "SCENE_TRAFFIC_CONTROL", all_recording=all_recording,is_quick_parse=True)
            warnings.warn(f"SCeneTrafficControl topic doesn't exist in {self._recording_path}, scene traffic control data won't be loaded")


            try:
                self._canonic_sequence_parser = PubSubCanonicSequenceParserLite.from_file(
                    path=self._canonic_sequence_parser_cache_file,
                    map_attributes_loader=map_attributes_loader,
                    scene_static_loader=scene_static_loader,
                    canonic_state_loader=canonic_state_loader,
                    scene_traffic_control_loader=scene_traffic_control_loader,
                    absolute_start_time=self._absolute_start_time,
                    relative_start_time=self._relative_start_time,
                    duration=self._duration
                )
            except:
                self._canonic_sequence_parser = \
                    PubSubCanonicSequenceParserLite(
                        path=self._recording_path,
                        map_attributes_loader=map_attributes_loader,
                        scene_static_loader=scene_static_loader,
                        canonic_state_loader=canonic_state_loader,
                        scene_traffic_control_loader=scene_traffic_control_loader
                    )
                self._canonic_sequence_parser.to_file(self._canonic_sequence_parser_cache_file)

        return self._canonic_sequence_parser

    def is_map_source(self, map_data_loader: PubSubDataLoader) -> bool:
        '''
        Determine if this topic was used as source for the map data by checking it's attributes. Either MAP_ATTRIBUTES
        or SCENE_STATIC holds the SceneStaticBase structure but this structure will never appear in both topics.
        :param map_data_loader: data loader for the map topic (either SCENE_STATIC or MAPATTRIBUTES)
        :return: True if the s_SceneStaticBase exists in this map topic
        '''
        # check if this topic was the source for the map data
        msg = map_data_loader.reader.get_next()[1]

        if hasattr(msg.s_Data, 's_SceneStaticBase'):
            return True
        else:
            return False

    def get_data_loader(self,
                        domain: str,
                        topic: str,
                        all_recording: bool = False,
                        is_quick_parse: bool = False,
                        quick_parse_offseted_data: Dict[str, Tuple[int, str]] = None) -> Optional[PubSubDataLoader]:
        """
        Retrieves a data loader based on the domain and topic. Data loader will be sliced according to the relevant time
        parameters as the entire parser.
        If topic doesn't exists in folder, returns None
        if all_recording is true, returns a loader that is not sliced according to the relevant time parameters
        if is_quick_parse is true, data loader will read only pubsub headers and quick parse offseted data in order to
        map the file
        """
        if (domain, topic) not in self._pubsub_data_loaders:
            if not PubSubDataLoader.is_topic_available(path=self._recording_path, domain=domain, topic=topic):
                return None

            if quick_parse_offseted_data is None:
                quick_parse_offseted_data = {}
            if is_quick_parse or self._is_always_quick_parse(domain=domain, topic=topic):
                # Read quick parse offseted data from definitions
                quick_parse_info = self._get_timestamp_quick_parse_data(domain=domain, topic=topic)
                if quick_parse_info is not None:
                    quick_parse_offseted_data.update(quick_parse_info)

            if all_recording:
                self._pubsub_data_loaders[(domain, topic)] = \
                    PubSubDataLoader(path=self._recording_path,
                                     domain=domain,
                                     topic=topic,
                                     relative_start_time=1.,
                                     duration=1e30,
                                     cache_path=os.path.join(self._base_path, f"{domain}_{topic}_cache.pkl"),
                                     is_quick_parse=is_quick_parse,
                                     quick_parse_offseted_data=quick_parse_offseted_data)
            else:
                self._pubsub_data_loaders[(domain, topic)] = \
                    PubSubDataLoader(path=self._recording_path,
                                     domain=domain,
                                     topic=topic,
                                     absolute_start_time=self._absolute_start_time,
                                     duration=self._duration,
                                     cache_path=os.path.join(self._base_path, f"{domain}_{topic}_cache.pkl"),
                                     is_quick_parse=is_quick_parse,
                                     quick_parse_offseted_data=quick_parse_offseted_data)

            if topic in ["MAP_ATTRIBUTES", "SCENE_STATIC"]:
                is_source_for_map = self.is_map_source(self._pubsub_data_loaders[(domain, topic)])
                if not is_source_for_map:
                    self._pubsub_data_loaders.pop((domain, topic))
                    return None

        return self._pubsub_data_loaders[(domain, topic)]

    @staticmethod
    def get_recording_path(base_path: str):
        recordings_path = os.path.join(base_path, 'recordings')
        if not os.path.isdir(recordings_path):
            recordings_path = os.path.join(base_path, 'Recordings')

        return recordings_path

    @staticmethod
    def _get_timestamp_quick_parse_data(domain: str, topic: str):
        """
        This functions allows definition of offsets in bytes from end of s_Header and struct format to read additional
        fields inside the topic message
        """
        with open(os.path.join(os.path.dirname(__file__), "pubsub_cfg.yml"), 'r') as f:
            cfg = yaml.load(f, Loader=yaml.FullLoader)
        quick_parse_data_dict = cfg["quick_parse_data"]

        if domain in quick_parse_data_dict:
            if topic in quick_parse_data_dict[domain]:
                return quick_parse_data_dict[domain][topic]

        return None

    @staticmethod
    def _is_always_quick_parse(domain: str, topic: str):
        with open(os.path.join(os.path.dirname(__file__), "pubsub_cfg.yml"), 'r') as f:
            cfg = yaml.load(f, Loader=yaml.FullLoader)
        always_quick_parse_dict = cfg["always_quick_parse"]
        return domain in always_quick_parse_dict and topic in always_quick_parse_dict[domain]
