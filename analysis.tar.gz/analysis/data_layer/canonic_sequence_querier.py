from collections import defaultdict
from typing import Tuple, Dict, List

from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame, CanonicSequence


class CanonicSequenceQuerier(ICanonicSequenceParser):
    """
    Adapt CanonicSequence to ICanonicSequenceParser interface
    """

    def __init__(self, canonic_sequence: CanonicSequence):
        self._canonic_sequence = canonic_sequence
        self._frame_ids_to_timestamps = {frame.state.frame_id: frame.state.timestamp_in_seconds for frame in self._canonic_sequence}
        self._frame_ids_to_frame = {frame.state.frame_id: frame for frame in self._canonic_sequence}
        self._start_to_finish: Dict[int, int] = {}
        self._finish_to_start: Dict[int, int] = {}

    def to_canonic_sequence(self) -> CanonicSequence:
        return self._canonic_sequence

    def get_frame_ids(self) -> List[int]:
        return list(self._frame_ids_to_timestamps.keys())

    def get_frame_ids_to_timestamps(self) -> Dict[int, float]:
        return self._frame_ids_to_timestamps

    def __getitem__(self, item: int) -> CanonicFrame:
        return self._frame_ids_to_frame[item]

    def __len__(self):
        return len(self._canonic_sequence)

    def get_deep_search_connections(self) -> Tuple[Dict[int, int], Dict[int, int]]:
        if not self._start_to_finish:
            self._start_to_finish = defaultdict(lambda: None)
            deep_search_start = None

            for frame_id in self.get_frame_ids():
                frame: CanonicFrame = self._frame_ids_to_frame[frame_id]

                data = frame.execution_info.s_Data

                # If the deep search finished in that frame, we log it to the start to finish dictionary for later use
                if data.e_b_IsDeepSearchFinished:
                    if deep_search_start is not None:
                        self._start_to_finish[deep_search_start] = data.e_Cnt_SeqNum
                        deep_search_start = None
                    else:
                        print("Deep search finished, but didn't have a recording of deep search start, "
                              "frame: {}".format(data.e_Cnt_SeqNum))

                # If the deep search was initiated, remember that for later use
                if data.e_b_IsDeepSearchInitiated:
                    deep_search_start = data.e_Cnt_SeqNum
                    # Deal with cases where a deep search was reset in the middle of the run
                    self._start_to_finish[deep_search_start] = None

            self._finish_to_start = {v: k for k, v in self._start_to_finish.items() if v is not None}

        return self._start_to_finish, self._finish_to_start
