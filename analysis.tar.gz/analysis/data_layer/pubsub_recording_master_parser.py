import os
from enum import Enum
from typing import Optional, Dict, Tuple, List
import warnings

import yaml
from subdivision_learning.analysis.data_layer.canonic_sequence_pubsub_parser import PubSubCanonicSequenceParser
from subdivision_learning.analysis.data_layer.pubsub_data_loader import PubSubDataLoader
from subdivision_learning.analysis.recordings_utilities.events_handling import get_events


class VehiclePlatform(Enum):
    K2 = 0
    T1 = 1


class PubSubRecordingMasterParser:
    """
    This class abstracts reading of data from a downloaded recording and exposes relevant parsers. It assumes visualizer
    output format.
    """
    def __init__(
            self,
            base_recording_path: str,
            relative_start_time: float = None,
            absolute_start_time: float = None,
            duration: float = 1e30
    ):
        """
        :param base_recording_path: path for the folder that contains the recording. The folder should be the parent
                                    folder of a "recordings" folder which contains all the pubsub data
        :param relative_start_time: Offset in time (in seconds) relative to the first frame state timestamp to start
                                    loading data from. This filter is on the the frame level and not on the pubsub
                                    message level.
        :param absolute_start_time: Time to start loading data from. This filter is on the the frame level and not on
                                    the pubsub message level
        :param duration: duration (in seconds) of the recording to be exposed
        """
        self._base_path = base_recording_path
        self._recording_path = self.get_recording_path(self._base_path)

        assert os.path.isdir(self._recording_path), f"A folder called recordings or Recordings doesn't exist in {self._base_path}"

        # Canonic sequence parser that can be exposed by this class
        self._canonic_sequence_parser: Optional[PubSubCanonicSequenceParser] = None
        self._canonic_sequence_parser_cache_file = os.path.join(self._base_path, "cache.pkl")

        # A dictionary of pubsub data loaders that can be exposed by this class
        self._pubsub_data_loaders: Dict[Tuple[str, str], PubSubDataLoader] = {}

        self._relative_start_time = relative_start_time
        self._absolute_start_time = absolute_start_time
        assert self._absolute_start_time is None or self._relative_start_time is None, \
            "Can't set absolute and relative start time together"
        self._duration = duration

    @classmethod
    def load_event(cls, base_recording_path: str, event_idx: int, relative_start_time: float, duration: float):
        recording_path = cls.get_recording_path(base_recording_path)
        # Extraction of actual event data
        events = get_events(recording_path)

        # If event exists, update relative start time to be relative to event time
        if len(events) > event_idx - 1:
            event_relative_time, event_absolute_time, event_comment = events[event_idx - 1]
            absolute_start_time = event_absolute_time + relative_start_time
        else:
            raise ValueError(f"Event {event_idx} doesn't exist in recording, found {len(events)} events.")

        return cls(base_recording_path=base_recording_path, absolute_start_time=absolute_start_time, duration=duration)

    @property
    def canonic_sequence_parser(self) -> PubSubCanonicSequenceParser:
        if self._canonic_sequence_parser is None:
            # When first loading a recording, we must parse the entire recording so it can be cached
            all_recording = not os.path.isfile(self._canonic_sequence_parser_cache_file)

            map_attributes_loader = self.get_data_loader("UC_SYSTEM", "MAP_ATTRIBUTES", all_recording=all_recording, is_quick_parse=True)
            scene_static_loader = self.get_data_loader("UC_SYSTEM", "SCENE_STATIC", all_recording=all_recording, is_quick_parse=True)
            assert map_attributes_loader is not None or scene_static_loader is not None, f"Neither SceneStatic nor MapAttributes topic exist in folder {self._recording_path}"
            canonic_state_loader = self.get_data_loader("UC_PLANNING_INTERNAL", "CANONIC_STATE", all_recording=all_recording, is_quick_parse=True)
            assert canonic_state_loader, f"CanonicState topic doesn't exist in folder {self._recording_path}"
            planner_internal_state_loader = self.get_data_loader("UC_PLANNING_INTERNAL", "PLANNER_INTERNAL_STATE", all_recording=all_recording, is_quick_parse=True)
            assert planner_internal_state_loader, f"PlannerInternalState topic doesn't exist in folder {self._recording_path}"
            canonic_action_loader = self.get_data_loader("UC_PLANNING_INTERNAL", "CANONIC_ACTION", all_recording=all_recording, is_quick_parse=True)
            assert canonic_action_loader, f"CanonicAction topic doesn't exist in folder {self._recording_path}"
            execution_info_loader = self.get_data_loader("UC_PLANNING_INTERNAL", "PLANNER_EXECUTION_INFO", all_recording=all_recording, is_quick_parse=True)
            planner_service_outputs_loader = self.get_data_loader("UC_SYSTEM", "PLANNER_SERVICE_OUTPUTS", all_recording=all_recording, is_quick_parse=True)
            if planner_service_outputs_loader is None:
                warnings.warn(f"PlannerServiceOutputs topic doesn't exist in {self._recording_path}, generated service outputs won't be loaded")
            scene_occupancy_grid_loader = self.get_data_loader("UC_SYSTEM", "SCENE_OG", all_recording=all_recording,is_quick_parse=True)
            if scene_occupancy_grid_loader is None:
                warnings.warn(f"SceneOG topic doesn't exist in {self._recording_path}, free space data won't be loaded")
            scene_fusion_loader = self.get_data_loader("UC_SYSTEM", "FUSED_SCENE_REPACK", all_recording=all_recording,is_quick_parse=False)
            if scene_fusion_loader is None:
                warnings.warn(f"SceneFusion topic doesn't exist in {self._recording_path}, scene fusion data won't be loaded")
            scene_traffic_control_loader = self.get_data_loader("UC_SYSTEM", "SCENE_TRAFFIC_CONTROL", all_recording=all_recording,is_quick_parse=True)
            if scene_traffic_control_loader is None:
                warnings.warn(f"SceneTrafficControl topic doesn't exist in {self._recording_path}, scene traffic control data won't be loaded")

            try:
                self._canonic_sequence_parser = PubSubCanonicSequenceParser.from_file(
                    path=self._canonic_sequence_parser_cache_file,
                    map_attributes_loader=map_attributes_loader,
                    scene_static_loader=scene_static_loader,
                    canonic_state_loader=canonic_state_loader,
                    planner_internal_state_loader=planner_internal_state_loader,
                    canonic_action_loader=canonic_action_loader,
                    execution_info_loader=execution_info_loader,
                    planner_service_outputs_loader=planner_service_outputs_loader,
                    scene_occupancy_grid_loader=scene_occupancy_grid_loader,
                    scene_fusion_loader=scene_fusion_loader,
                    scene_traffic_control_loader=scene_traffic_control_loader,
                    absolute_start_time=self._absolute_start_time,
                    relative_start_time=self._relative_start_time,
                    duration=self._duration
                )
            except Exception:
                self._canonic_sequence_parser = \
                    PubSubCanonicSequenceParser(path=self._recording_path,
                                                map_attributes_loader=map_attributes_loader,
                                                scene_static_loader=scene_static_loader,
                                                canonic_state_loader=canonic_state_loader,
                                                planner_internal_state_loader=planner_internal_state_loader,
                                                canonic_action_loader=canonic_action_loader,
                                                execution_info_loader=execution_info_loader,
                                                planner_service_outputs_loader=planner_service_outputs_loader,
                                                scene_occupancy_grid_loader=scene_occupancy_grid_loader,
                                                scene_fusion_loader=scene_fusion_loader,
                                                scene_traffic_control_loader=scene_traffic_control_loader
                                                )
                self._canonic_sequence_parser.to_file(self._canonic_sequence_parser_cache_file)

        return self._canonic_sequence_parser

    def is_map_source(self, map_data_loader: PubSubDataLoader) -> bool:
        '''
        Determine if this topic was used as source for the map data by checking it's attributes. Either MAP_ATTRIBUTES
        or SCENE_STATIC holds the SceneStaticBase structure but this structure will never appear in both topics.
        :param map_data_loader: data loader for the map topic (either SCENE_STATIC or MAPATTRIBUTES)
        :return: True if the s_SceneStaticBase exists in this map topic
        '''
        # check if this topic was the source for the map data
        msg = map_data_loader.reader.get_next()[1]

        if hasattr(msg.s_Data, 's_SceneStaticBase'):
            return True
        else:
            return False

    def get_data_loader(self,
                        domain: str,
                        topic: str,
                        all_recording: bool = False,
                        is_quick_parse: bool = False,
                        quick_parse_offseted_data: Dict[str, Tuple[int, str]] = None) -> Optional[PubSubDataLoader]:
        """
        Retrieves a data loader based on the domain and topic. Data loader will be sliced according to the relevant time
        parameters as the entire parser.
        If topic doesn't exists in folder, returns None
        if all_recording is true, returns a loader that is not sliced according to the relevant time parameters
        if is_quick_parse is true, data loader will read only pubsub headers and quick parse offseted data in order to
        map the file
        """
        if (domain, topic) not in self._pubsub_data_loaders:
            if not PubSubDataLoader.is_topic_available(path=self._recording_path, domain=domain, topic=topic):
                return None

            if quick_parse_offseted_data is None:
                quick_parse_offseted_data = {}
            if is_quick_parse or self._is_always_quick_parse(domain=domain, topic=topic):
                # Read quick parse offseted data from definitions
                quick_parse_info = self._get_timestamp_quick_parse_data(domain=domain, topic=topic)
                if quick_parse_info is not None:
                    quick_parse_offseted_data.update(quick_parse_info)

            if all_recording:
                self._pubsub_data_loaders[(domain, topic)] = \
                    PubSubDataLoader(path=self._recording_path,
                                     domain=domain,
                                     topic=topic,
                                     relative_start_time=1.,
                                     duration=1e30,
                                     cache_path=os.path.join(self._base_path, f"{domain}_{topic}_cache.pkl"),
                                     is_quick_parse=is_quick_parse,
                                     quick_parse_offseted_data=quick_parse_offseted_data)
            else:
                self._pubsub_data_loaders[(domain, topic)] = \
                    PubSubDataLoader(path=self._recording_path,
                                     domain=domain,
                                     topic=topic,
                                     absolute_start_time=self._absolute_start_time,
                                     duration=self._duration,
                                     cache_path=os.path.join(self._base_path, f"{domain}_{topic}_cache.pkl"),
                                     is_quick_parse=is_quick_parse,
                                     quick_parse_offseted_data=quick_parse_offseted_data)

            if topic in ["MAP_ATTRIBUTES", "SCENE_STATIC"]:
                is_source_for_map = self.is_map_source(self._pubsub_data_loaders[(domain, topic)])
                if not is_source_for_map:
                    self._pubsub_data_loaders.pop((domain, topic))
                    return None

        return self._pubsub_data_loaders[(domain, topic)]

    @staticmethod
    def get_recording_path(base_path: str):
        recordings_path = os.path.join(base_path, 'recordings')
        if not os.path.isdir(recordings_path):
            recordings_path = os.path.join(base_path, 'Recordings')

        return recordings_path

    @classmethod
    def get_cameras(cls, base_path: str) -> List[Tuple[VehiclePlatform, str, str]]:
        """
        Retrieves vehicle platform and camera name pair according to front camera data existence, if no camera data
        exists, returns None, None
        :param base_path: base path of the recording, must contain recordings folder in it
        :return:
        """
        recording_folder = cls.get_recording_path(base_path)
        assert os.path.isdir(recording_folder), "Recording folder doesn't exist: " + recording_folder
        domain = "UC_SYSTEM"

        platform_to_topic = {
            (VehiclePlatform.K2, "CAMERA_4MB_IMAGE_RF_BEHIND_WINDSHIELD", "Front Camera"),
            (VehiclePlatform.T1, "CAMERA_4MB_IMAGE_EXTWIDE_FRONT_WS", "Front Camera"),
            (VehiclePlatform.T1, "CAMERA_2MB_IMAGE_WIDE_REAR_LIFT_GATE", "Rear Camera"),
        }

        available_cameras = []
        for platform, topic, camera_name in platform_to_topic:
            if PubSubDataLoader.is_topic_available(path=recording_folder, domain=domain, topic=topic) or \
                    os.path.isdir(os.path.join(base_path, topic)):
                available_cameras.append((platform, topic, camera_name))

        return available_cameras

    @classmethod
    def get_rear_camera(cls, base_path: str) -> Tuple[VehiclePlatform, str]:
        """
        Retrieves vehicle platform and camera name pair according to front camera data existence, if no camera data
        exists, returns None, None
        :param base_path: base path of the recording, must contain recordings folder in it
        :return:
        """
        recording_folder = cls.get_recording_path(base_path)
        assert os.path.isdir(recording_folder), "Recording folder doesn't exist: " + recording_folder
        domain = "UC_SYSTEM"

        platform_to_topic = {
            VehiclePlatform.T1: "CAMERA_2MB_IMAGE_WIDE_REAR_LIFT_GATE",
        }

        available_cameras = []
        for platform, topic, camera_name in platform_to_topic:
            if PubSubDataLoader.is_topic_available(path=recording_folder, domain=domain, topic=topic) or \
                    os.path.isdir(os.path.join(base_path, topic)):
                available_cameras.append((platform, topic, camera_name))

        return available_cameras

    @staticmethod
    def _get_timestamp_quick_parse_data(domain: str, topic: str):
        """
        This functions allows definition of offsets in bytes from end of s_Header and struct format to read additional
        fields inside the topic message
        """
        with open(os.path.join(os.path.dirname(__file__), "pubsub_cfg.yml"), 'r') as f:
            cfg = yaml.load(f, Loader=yaml.FullLoader)
        quick_parse_data_dict = cfg["quick_parse_data"]

        if domain in quick_parse_data_dict:
            if topic in quick_parse_data_dict[domain]:
                return quick_parse_data_dict[domain][topic]

        return None

    @staticmethod
    def _is_always_quick_parse(domain: str, topic: str):
        with open(os.path.join(os.path.dirname(__file__), "pubsub_cfg.yml"), 'r') as f:
            cfg = yaml.load(f, Loader=yaml.FullLoader)
        always_quick_parse_dict = cfg["always_quick_parse"]

        return domain in always_quick_parse_dict and topic in always_quick_parse_dict[domain]
