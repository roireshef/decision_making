from abc import abstractmethod, ABC
from typing import Tuple, Dict, List

from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame, CanonicSequence


class ICanonicSequenceParser(ABC):
    """
    This class parses pubsub data into canonic sequence
    """
    @abstractmethod
    def to_canonic_sequence(self) -> CanonicSequence:
        raise NotImplementedError()

    @abstractmethod
    def get_frame_ids(self) -> List[int]:
        raise NotImplementedError()

    def get_frame_ids_to_timestamps(self) -> Dict[int, float]:
        raise NotImplementedError()

    @abstractmethod
    def __getitem__(self, item: int) -> CanonicFrame:
        raise NotImplementedError()

    @abstractmethod
    def __len__(self):
        raise NotImplementedError()

    @abstractmethod
    def get_deep_search_connections(self) -> Tuple[Dict[int, int], Dict[int, int]]:
        raise NotImplementedError()
