import pickle
import warnings
from collections import defaultdict
from functools import lru_cache
from typing import Dict, List, Optional, Tuple
from weakref import WeakValueDictionary

import numpy as np
from interface.Rte_Types.python.sub_structures.TsSYS_DataCanonicState import TsSYSDataCanonicState
from interface.Rte_Types.python.sub_structures.TsSYS_Header import TsSYSHeader
from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_learning.analysis.data_layer.pubsub_data_loader import PubSubDataLoader
from subdivision_learning.scripts.convert_old_scene_static_to_map_attribute import \
    convert_serialized_scene_static_to_serialized_map_attributes
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.data_structures.canonic_action import CanonicAction
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.data_structures.canonic_state import CanonicState
from subdivision_planner.src.data_structures.free_space_grid import FreeSpaceGrids
from subdivision_planner.src.data_structures.map import Map
from subdivision_planner.src.data_structures.planner_service_outputs import DCUTriggerStatuses, FMSStatuses, HmiStatuses
from subdivision_planner.src.map.map_provider import MapAttributesMapGenerator, augment_map_with_stop_bars_from_scene_static
from subdivision_planner.src.map.mnp_converter import MNPConverter
from subdivision_planner.src.messages.map_attributes_message import MapAttributes
from subdivision_planner.src.messages.scene_common_messages import Timestamp
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.src.planners.concepts.spline_smoothing_manager import SmoothPath
from tqdm import tqdm
from subdivision_planner.src.planners.state_converters.scene_provider import augment_map_with_stop_bars
from subdivision_planner.src.messages.scene_traffic_control_message import DataSceneTrafficControl


class PubSubCanonicFrameIdentifier:
    def __init__(self,
                 frame_id: int = -1,
                 timestamp: float = 0.,
                 state: int = None,
                 internal_state: int = None,
                 action: int = None,
                 execution_info: int = None,
                 planner_service_outputs: int = None):
        self.frame_id = frame_id
        self.timestamp = timestamp
        self.state = state
        self.internal_state = internal_state
        self.action = action
        self.execution_info = execution_info
        self.planner_service_outputs = planner_service_outputs


class RecordingMetadata:
    def __init__(self,
                 frame_identifiers: Dict[int, PubSubCanonicFrameIdentifier],
                 map_attributes_identifiers: Dict[int, List[int]],
                 scene_static_identifiers: Dict[int, List[int]],
                 scene_og_identifiers: Dict[int, List[int]],
                 scene_fusion_identifiers: Dict[int, int],
                 scene_traffic_control_identifiers: Dict[int, int],
                 deep_search_start_to_finish: Dict[int, int]
                 ):
        self.frame_identifiers = frame_identifiers
        self.map_attributes_identifiers = map_attributes_identifiers
        self.scene_static_identifiers = scene_static_identifiers
        self.scene_og_identifiers = scene_og_identifiers
        self.scene_fusion_identifiers = scene_fusion_identifiers
        self.scene_traffic_control_identifiers = scene_traffic_control_identifiers
        self.deep_search_start_to_finish = deep_search_start_to_finish


@lru_cache(maxsize=1)
def get_map_attributes_from_scene_static_cached(timestamp_nano: int, scene_static_data_loader):
    scene_static_message = scene_static_data_loader.read_by_timestamp(timestamp_nano=timestamp_nano)
    logger = get_logger()
    # when working with a scene static message it must be converted to a map attribute message
    map_attributes = convert_serialized_scene_static_to_serialized_map_attributes(scene_static=scene_static_message)
    if Config().state.is_convert_old_to_mnp:
        map_attributes = MNPConverter.convert(msg=map_attributes.serialize(), logger=logger)
    return map_attributes

@lru_cache(maxsize=1)
def get_map_attributes_cached(timestamp_nano: int, map_attributes_data_loader):
    map_attributes_message = map_attributes_data_loader.read_by_timestamp(timestamp_nano=timestamp_nano)
    logger = get_logger()
    map_attributes = MapAttributes.deserialize(map_attributes_message)
    return map_attributes

@lru_cache(maxsize=1)
def convert_map_attributes_cached(map_attributes):
    return MapAttributesMapGenerator.convert_map(map_attributes, logger=get_logger())

@lru_cache(maxsize=1)
def get_scene_og_cached(timestamp_nano: int, scene_occupancy_grid_loader):
    scene_og_message = scene_occupancy_grid_loader.read_by_timestamp(timestamp_nano=timestamp_nano)
    free_space_grid = FreeSpaceGrids.from_scene_og_msg(scene_og_message)
    free_space_grid.timestamp_nano = timestamp_nano
    return free_space_grid


class PubSubCanonicSequenceParser(ICanonicSequenceParser):
    """
    This class parses pubsub data into canonic sequence
    """
    def __init__(self,
                 path: str,
                 map_attributes_loader: PubSubDataLoader,
                 scene_static_loader: PubSubDataLoader,
                 canonic_state_loader: PubSubDataLoader,
                 planner_internal_state_loader: PubSubDataLoader,
                 canonic_action_loader: PubSubDataLoader,
                 execution_info_loader: Optional[PubSubDataLoader],
                 planner_service_outputs_loader: Optional[PubSubDataLoader],
                 scene_occupancy_grid_loader: Optional[PubSubDataLoader],
                 scene_fusion_loader: Optional[PubSubDataLoader],
                 scene_traffic_control_loader: Optional[PubSubDataLoader],
                 recording_metadata: RecordingMetadata = None,
                 ):
        """
        ctor.
        The data the parser will read will be according to the loader it is given. Additional cropping of a recording
        can be done via recording_metadata
        :param path: path for the pub sub recordings
        :param map_attributes_loader: PubSubDataLoader of MapAttributes pubsub message
        :param scene_static_loader: PubSubDataLoader of SceneStatic pubsub message
        :param canonic_state_loader: PubSubDataLoader of Canonic State pubsub message
        :param planner_internal_state_loader: PubSubDataLoader of PlannerInternalState pubsub message
        :param canonic_action_loader: PubSubDataLoader of Canonic Action pubsub message
        :param execution_info_loader: PubSubDataLoader of PlannerExecutionInfo pubsub message
        :param planner_service_outputs_loader:PubSubDataLoader of PlannerServiceOutputs pubsub message
        :param scene_occupancy_grid_loader:PubSubDataLoader of SceneOG pubsub message
        :param scene_fusion_loader:PubSubDataLoader of SceneFusion pubsub message
        :param scene_traffic_control_loader:PubSubDataLoader of SceneTrafficControl pubsub message
        :param recording_metadata: Metadata of the recordings to be loaded by the parser. If None is given, parser will
        load all data and generate the meta data on its own. This metadata can be saved to file for future load.
        """

        self._path = path

        self._map_attributes_loader: PubSubDataLoader = map_attributes_loader
        self._scene_static_loader: PubSubDataLoader = scene_static_loader
        self._canonic_state_loader: PubSubDataLoader = canonic_state_loader
        self._planner_internal_state_loader: PubSubDataLoader = planner_internal_state_loader
        self._canonic_action_loader: PubSubDataLoader = canonic_action_loader
        self._execution_info_loader: Optional[PubSubDataLoader] = execution_info_loader
        self._planner_service_outputs_loader: Optional[PubSubDataLoader] = planner_service_outputs_loader
        self._scene_occupancy_grid_loader: PubSubDataLoader = scene_occupancy_grid_loader
        self._scene_fusion_loader: PubSubDataLoader = scene_fusion_loader
        self._scene_traffic_control_loader: PubSubDataLoader = scene_traffic_control_loader

        # This is a dictionary of all the frames in the recording with frame id as key and dictionaries as values. The
        # dictionaries contain canonic state, canonic action and planner internal state
        self._frames = WeakValueDictionary()

        # dictionaries that can convert frame id that the planner started a deep search to the frame id in which the
        # deep search was finished and vice versa.
        self._start_to_finish: Dict[int, int] = {}
        self._finish_to_start: Dict[int, int] = {}

        if recording_metadata is None:
            self._parse_meta_data()
        else:
            self._frame_identifiers = recording_metadata.frame_identifiers
            self._map_attributes_identifiers = recording_metadata.map_attributes_identifiers
            self._scene_static_identifiers = recording_metadata.scene_static_identifiers
            self._scene_occupancy_grid_identifiers = recording_metadata.scene_og_identifiers
            self._scene_fusion_identifiers = recording_metadata.scene_fusion_identifiers
            self._scene_traffic_control_identifiers = recording_metadata.scene_traffic_control_identifiers
            self._start_to_finish = recording_metadata.deep_search_start_to_finish

    def __next__(self):
        if self._frame_idx >= len(self):
            raise StopIteration

        self._frame_idx += 1
        # Return CanonicState, PlannerInternalState and CanonicAction at correct frame index
        return self[self.get_frame_ids()[self._frame_idx-1]]

    def __getitem__(self, item: int) -> CanonicFrame:
        """
        Return CanonicState, PlannerInternalState and CanonicAction at correct frame id (item)
        """
        return self.get_frame(self._frame_identifiers[item])

    def __iter__(self):
        """
        Create an iterator out of the parser
        """
        self._frame_idx = 0
        return self

    def __len__(self):
        return len(self._frame_identifiers)

    def to_file(self, path: str):
        """
        This method generates a cache file this parser can be generated from to save precious parsing time. Note that
        from_file() assumes the cache file was generated for the entire recording parser and not for a cropped version
        of it.
        :param path: path of the cache file
        """
        with open(path, 'wb') as f:
            meta_data = RecordingMetadata(self._frame_identifiers,
                                          self._map_attributes_identifiers,
                                          self._scene_static_identifiers,
                                          self._scene_occupancy_grid_identifiers,
                                          self._scene_fusion_identifiers,
                                          self._scene_traffic_control_identifiers,
                                          self._start_to_finish)
            pickle.dump((self._path, meta_data), f)

    @classmethod
    def from_file(cls,
                  path: str,
                  map_attributes_loader: PubSubDataLoader,
                  scene_static_loader: PubSubDataLoader,
                  canonic_state_loader: PubSubDataLoader,
                  planner_internal_state_loader: PubSubDataLoader,
                  canonic_action_loader: PubSubDataLoader,
                  execution_info_loader: PubSubDataLoader,
                  planner_service_outputs_loader: PubSubDataLoader,
                  scene_occupancy_grid_loader: PubSubDataLoader,
                  scene_fusion_loader: PubSubDataLoader,
                  scene_traffic_control_loader: PubSubDataLoader,
                  absolute_start_time: float = None,
                  relative_start_time: float = None,
                  duration: float = None
                  ):
        """
        Loads the parser from cache file. Absolute start time and duration can be applied here to crop specific part of
        the recording
        :param map_attributes_loader: PubSubDataLoader of MapAttributes pubsub message
        :param scene_static_loader: PubSubDataLoader of SceneStatic pubsub message
        :param canonic_state_loader: PubSubDataLoader of Canonic State pubsub message
        :param planner_internal_state_loader: PubSubDataLoader of PlannerInternalState pubsub message
        :param canonic_action_loader: PubSubDataLoader of Canonic Action pubsub message
        :param execution_info_loader: PubSubDataLoader of PlannerExecutionInfo pubsub message
        :param planner_service_outputs_loader: PubSubDataLoader of PlannerServiceOutputs pubsub message
        :param scene_occupancy_grid_loader: PubSubDataLoader of SceneOG pubsub message
        :param scene_fusion_loader: PubSubDataLoader of SceneFusion pubsub message
        :param scene_traffic_control_loader: PubSubDataLoader of SceneTrafficControl pubsub message
        :param path: path of the cache file
        :param relative_start_time: Time to start loading the data relative to beginning of recording in seconds, if not
            given, will start in beginning of recording. Can't be set together with absolute start time.
        :param absolute_start_time: Similar to relative_start_time, just in in absolute time (380...) and not relative
                                    to beginning of the recording. Can't be set together with relative start time
        :param duration: duration in seconds of time to load, if not given, will load data until recording ends
        :return:
        """
        with open(path, 'rb') as f:
            rec_path, meta_data = pickle.load(f)

            assert absolute_start_time is None or relative_start_time is None, "Can't set absolute and relative start time together"

            # Filter frame ids according to relative or absolute start time
            if absolute_start_time is not None or relative_start_time is not None:
                frame_identifiers = meta_data.frame_identifiers
                frame_ids_to_pop = []
                if absolute_start_time is not None:
                    for frame_id, frame_identifier in frame_identifiers.items():
                        relative_time = frame_identifier.state * 1e-9 - absolute_start_time
                        if not 0. <= relative_time <= duration:
                            frame_ids_to_pop.append(frame_id)

                if relative_start_time is not None:
                    first_frame_id = min(list(frame_identifiers.keys()))
                    first_timestamp = frame_identifiers[first_frame_id].state * 1e-9
                    for frame_id, frame_identifier in frame_identifiers.items():
                        relative_time = frame_identifier.state * 1e-9 - first_timestamp
                        if not relative_start_time <= relative_time <= relative_start_time + duration:
                            frame_ids_to_pop.append(frame_id)

                for frame_id in frame_ids_to_pop:
                    frame_identifiers.pop(frame_id)

            return cls(
                path=rec_path,
                map_attributes_loader=map_attributes_loader,
                scene_static_loader=scene_static_loader,
                canonic_state_loader=canonic_state_loader,
                planner_internal_state_loader=planner_internal_state_loader,
                canonic_action_loader=canonic_action_loader,
                execution_info_loader=execution_info_loader,
                planner_service_outputs_loader=planner_service_outputs_loader,
                scene_occupancy_grid_loader=scene_occupancy_grid_loader,
                scene_fusion_loader=scene_fusion_loader,
                scene_traffic_control_loader=scene_traffic_control_loader,
                recording_metadata=meta_data,
            )

    def _parse_meta_data(self):
        """
        This method loads all the data from the recording
        """
        # Reset all identifier dictionaries
        self._frame_identifiers = defaultdict(PubSubCanonicFrameIdentifier)
        self._map_attributes_identifiers = defaultdict(list)
        self._scene_static_identifiers = defaultdict(list)
        self._scene_occupancy_grid_identifiers = defaultdict(list)
        self._scene_fusion_identifiers = defaultdict(int)
        self._scene_traffic_control_identifiers = defaultdict(int)

        self._parse_map_attributes_meta_data()
        self._parse_scene_static_meta_data()
        self._parse_canonic_state_meta_data()
        self._parse_planner_internal_state_meta_data()
        self._parse_canonic_action_meta_data()
        self._parse_planner_execution_info_meta_data()
        self._parse_planner_planner_service_outputs_meta_data()
        self._parse_scene_og_meta_data()
        self._parse_scene_fusion_meta_data()
        self._parse_scene_traffic_control_meta_data()

    def _parse_map_attributes_meta_data(self):
        # Parse the maps from scene static
        if self._map_attributes_loader:
            timestamps, headers, _ = self._map_attributes_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, map_attributes_header in zip(timestamps, headers):
                map_id = map_attributes_header.e_Cnt_SeqNum
                self._map_attributes_identifiers[map_id].append(timestamp_nano)

    def _parse_scene_static_meta_data(self):
        # Parse the maps from scene static
        if self._scene_static_loader:
            timestamps, headers, _ = self._scene_static_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, scene_static_header in zip(timestamps, headers):
                map_id = scene_static_header.e_Cnt_SeqNum
                self._scene_static_identifiers[map_id].append(timestamp_nano)

    def _parse_canonic_state_meta_data(self):
        # Parse the canonic state messages
        timestamps, headers, _ = self._canonic_state_loader.get_header_reader().read_pubsub_headers()
        for timestamp_nano, canonic_state_msg in self._canonic_state_loader:
            canonic_state_header: TsSYSHeader = canonic_state_msg.s_Header
            canonic_state_data: TsSYSDataCanonicState = canonic_state_msg.s_Data
            frame_id = canonic_state_header.e_Cnt_SeqNum
            map_id = canonic_state_data.e_MapSeqNum
            if map_id not in self._scene_static_identifiers and map_id not in self._map_attributes_identifiers:
                print(f"Warning: CanonicState with frame id {frame_id} doesn't have matching map with id {map_id},"
                      f"skipping message")
                continue

            if self._frame_identifiers[frame_id].state is not None:
                print(f"Warning: CanonicState with frame id {frame_id} already exists, stopping parsing")
                return

            self._frame_identifiers[frame_id].state = timestamp_nano
            self._frame_identifiers[frame_id].frame_id = frame_id
            self._frame_identifiers[frame_id].timestamp = Timestamp.deserialize(canonic_state_header.s_Timestamp).timestamp_in_seconds

    def _parse_planner_internal_state_meta_data(self):
        # Parse the planner internal state messages
        deep_search_start = None
        for timestamp_nano, planner_internal_state_msg in self._planner_internal_state_loader:
            frame_id = planner_internal_state_msg.s_Data.e_Cnt_SeqNum

            if frame_id not in self._frame_identifiers:
                print(f"Warning: PlannerInternalState with frame id {frame_id} was found without corresponding "
                      f"CanonicState, skipping this msg")
                continue

            if self._frame_identifiers[frame_id].internal_state is not None:
                print(f"Warning: PlannerInternalState with frame id {frame_id} already exists, stopping parsing")
                return

            self._frame_identifiers[frame_id].internal_state = timestamp_nano

    def _parse_canonic_action_meta_data(self):
        # Parse the canonic action messages
        timestamps, headers, _ = self._canonic_action_loader.get_header_reader().read_pubsub_headers()

        for timestamp_nano, canonic_action_header in zip(timestamps, headers):
            frame_id = canonic_action_header.e_Cnt_SeqNum

            if frame_id not in self._frame_identifiers:
                print(f"Warning: CanonicAction with frame id {frame_id} was found without corresponding "
                      f"CanonicState or PlannerInternalState, skipping this msg")
                continue

            if self._frame_identifiers[frame_id].state is None:
                print(f"Warning: CanonicAction with frame id {frame_id} was found without corresponding "
                      f"CanonicState, skipping this msg")

            if self._frame_identifiers[frame_id].internal_state is None:
                print(f"Warning: CanonicAction with frame id {frame_id} was found without corresponding "
                      f"PlannerInternalState, skipping this msg")

            if self._frame_identifiers[frame_id].action is not None:
                print(f"Warning: CanonicAction with frame id {frame_id} already exists, stopping parsing")
                return

            self._frame_identifiers[frame_id].action = timestamp_nano

    def _parse_scene_og_meta_data(self):
        # Parse the scene_occupancy_grid messages
        if self._scene_occupancy_grid_loader is not None:
            timestamps, headers, _ = self._scene_occupancy_grid_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, scene_occupancy_grid_header in zip(timestamps, headers):
                scene_og_id = scene_occupancy_grid_header.e_Cnt_SeqNum
                self._scene_occupancy_grid_identifiers[scene_og_id].append(timestamp_nano)

    def _parse_scene_fusion_meta_data(self):
        # Parse the scene_fusion messages
        if self._scene_fusion_loader is not None:
            timestamps, headers, _ = self._scene_fusion_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, scene_fusion_header in zip(timestamps, headers):
                scene_fusion_id = scene_fusion_header.e_Cnt_SeqNum
                self._scene_fusion_identifiers[scene_fusion_id] = timestamp_nano

    def _parse_scene_traffic_control_meta_data(self):
        # Parse the scene_fusion messages
        if self._scene_traffic_control_loader is not None:
            timestamps, headers, _ = self._scene_traffic_control_loader.get_header_reader().read_pubsub_headers()
            for timestamp_nano, scene_traffic_control_header in zip(timestamps, headers):
                scene_traffic_control_id = scene_traffic_control_header.e_Cnt_SeqNum
                self._scene_traffic_control_identifiers[scene_traffic_control_id] = timestamp_nano

    def _parse_planner_execution_info_meta_data(self):
        # Parse the planner execution info messages
        deep_search_start = None
        if self._execution_info_loader is None:
            print(f"Warning: PlannerExecutionInfo not found, is this an old recording?")
            return
        for timestamp_nano, execution_info_msg in self._execution_info_loader:
            frame_id = execution_info_msg.s_Data.e_Cnt_SeqNum

            if frame_id not in self._frame_identifiers:
                print(f"Warning: PlannerExecutionInfo with frame id {frame_id} was found without corresponding "
                      f"CanonicState, skipping this msg")
                continue

            if self._frame_identifiers[frame_id].execution_info is not None:
                print(f"Warning: PlannerExecutionInfo with frame id {frame_id} already exists, stopping parsing")
                return

            self._frame_identifiers[frame_id].execution_info = timestamp_nano

            data = execution_info_msg.s_Data
            # If the deep search finished in that frame, we log it to the start to finish dictionary for later use
            if data.e_b_IsDeepSearchFinished:
                if deep_search_start is not None:
                    self._start_to_finish[deep_search_start] = data.e_Cnt_SeqNum
                    deep_search_start = None
                else:
                    print("Deep search finished, but didn't have a recording of deep search start, "
                          "frame: {}".format(data.e_Cnt_SeqNum))

            # If the deep search was initiated, remember that for later use
            if data.e_b_IsDeepSearchInitiated:
                deep_search_start = data.e_Cnt_SeqNum
                # Deal with cases where a deep search was reset in the middle of the run
                self._start_to_finish[deep_search_start] = None

    def _parse_planner_planner_service_outputs_meta_data(self):

        if self._planner_service_outputs_loader is None:
            print(f"Warning: PlannerServiceOutputs not found, is this an old recording?")
            return

        for timestamp_nano, planner_service_outputs_msg in self._planner_service_outputs_loader:
            frame_id = planner_service_outputs_msg.s_Header.e_Cnt_SeqNum

            if frame_id not in self._frame_identifiers:
                print(f"Warning: PlannerServiceOutputs with frame id {frame_id} was found without corresponding "
                      f"CanonicState, skipping this msg")
                continue

            if self._frame_identifiers[frame_id].planner_service_outputs is not None:
                print(f"Warning: PlannerServiceOutputs with frame id {frame_id} already exists, stopping parsing")
                return

            self._frame_identifiers[frame_id].planner_service_outputs = timestamp_nano

    def get_map_attributes(self, map_id: int, timestamp: float = None) -> Optional[MapAttributes]:
        if self._map_attributes_loader:
            data_loader = self._map_attributes_loader
            map_identifier = self._map_attributes_identifiers
        else:
            data_loader = self._scene_static_loader
            map_identifier = self._scene_static_identifiers

        if map_id not in map_identifier:
            return None

        if timestamp is None:
            # get the first timestamp if received None
            timestamp_nano = map_identifier[map_id][0]
        else:
            optional_timestamps = np.array(map_identifier[map_id])
            nearest_idx = np.argmin(np.abs(optional_timestamps * 1e-9 - timestamp))
            timestamp_nano = int(optional_timestamps.take(nearest_idx))

        if self._map_attributes_loader:
            map_attributes = get_map_attributes_cached(timestamp_nano, data_loader)
        else:
            map_attributes = get_map_attributes_from_scene_static_cached(timestamp_nano, data_loader)

        return map_attributes

    def get_map(self, map_id: int, timestamp: float = None) -> Optional[Map]:
        """
        Returns a map from map id. If map_id doesn't exit, returns None.
        :param map_id: id of the Map to draw
        :param timestamp: Timestamp of the map id, if received None will take the first one
        """

        map_attributes = self.get_map_attributes(map_id, timestamp)

        return convert_map_attributes_cached(map_attributes)

    def get_frame(self, frame_identifier: PubSubCanonicFrameIdentifier) -> CanonicFrame:
        """
        Converts frame identifier to actual CanonicFrame. Always returns CanonicFrame, if part of it doesn't exist,
        might return an empty frame.
        """
        try:
            return self._frames[frame_identifier.frame_id]
        except KeyError:
            pass

        frame = CanonicFrame()

        if frame_identifier.state:
            canonic_state_pubsub_msg = self._canonic_state_loader.read_by_timestamp(frame_identifier.state)

            # get corresponding map for this frame
            map_id = canonic_state_pubsub_msg.s_Data.e_MapSeqNum
            if map_id not in self._scene_static_identifiers and map_id not in self._map_attributes_identifiers:
                print(f"Corresponding map not found for frame id {frame_identifier.frame_id}, pubsub parsing stopped")
                raise StopIteration  # show what you can

            map = self.get_map(map_id, frame_identifier.state*1e-9)

            # TODO: enable map augmentation when scene traffic control publishes all road objects in the map
            # augment the map with stop bars from scene traffic control
            if self._scene_traffic_control_loader is not None:
                if 's_SceneTrafficControlTimestamp' in canonic_state_pubsub_msg.s_Data._dic:
                    # TODO: Figure out why get_by_data_timestamp does not work
                    # scene_traffic_control_timestamp = Timestamp.deserialize(
                    #     canonic_state_pubsub_msg.s_Data.s_SceneTrafficControlTimestamp).timestamp_in_seconds
                    # scene_traffic_control_message = self._scene_traffic_control_loader.get_by_data_timestamp(
                    #     timestamp=scene_traffic_control_timestamp)

                    scene_traffic_control_message = self._scene_traffic_control_loader.read_by_timestamp(
                        frame_identifier.state)

                    if not 'as_scene_road_object' in scene_traffic_control_message.s_Data:
                        # If scene traffic control format is new, in which there are no road objects,
                        # use it to consume control points
                        scene_traffic_control_data = DataSceneTrafficControl.deserialize(scene_traffic_control_message.s_Data)
                        augment_map_with_stop_bars(map, scene_traffic_control_data)
                    else:
                        # Otherwise use scene static base data and convert it to control points
                        map_attributes = self.get_map_attributes(map_id, timestamp=frame_identifier.state*1e-9)
                        augment_map_with_stop_bars_from_scene_static(map, map_attributes.s_Data.s_SceneStaticBase)

            # augment the map with scene fusion data
            if self._scene_fusion_loader is not None:
                # for backwards compatibility, check if the canonic state has the fused scene timestamp
                if 's_FusedSceneTimestamp' in canonic_state_pubsub_msg.s_Data._dic:
                    scene_fusion_timestamp = Timestamp.deserialize(canonic_state_pubsub_msg.s_Data.s_FusedSceneTimestamp).timestamp_in_seconds
                    scene_fusion_message = self._scene_fusion_loader.get_by_data_timestamp(timestamp=scene_fusion_timestamp)
                    _ = MapAttributesMapGenerator.update_dynamic_map(map, scene_fusion_message)

            if Config().driving.consume_free_space and self._scene_occupancy_grid_loader is not None:
                scene_og_message_id = canonic_state_pubsub_msg.s_Data.e_SceneOGMessageId
                if scene_og_message_id == 0:
                    warnings.warn("Looks like the recording ran with Config().driving.consume_free_space set to False.")
                free_space_grids = self.get_scene_og(scene_og_message_id, frame_identifier.state)
                # assert free_space_grids.occupancy_grid_message_id == scene_og_message_id
            else:
                free_space_grids = None

            frame.state = CanonicState.deserialize(canonic_state_pubsub_msg, map, free_space_grids)

            if frame_identifier.internal_state:
                frame.internal_state = self._planner_internal_state_loader.read_by_timestamp(frame_identifier.internal_state)

                if frame_identifier.action:
                    canonic_action_msg = self._canonic_action_loader.read_by_timestamp(frame_identifier.action)
                    canonic_action = CanonicAction.deserialize(canonic_action_msg, map=map)

                    if "e_Cnt_LastPaths" in frame.internal_state.s_Data._dic:
                        # Recreate the smooth paths due to spline smoothing that defines the gff for the driving plan
                        prev_paths = [SmoothPath.deserialize(frame.internal_state.s_Data.as_LastPaths[i], map) for i in
                                      range(frame.internal_state.s_Data.e_Cnt_LastPaths)]
                        # Replace the gff of each action in the driving plan with its corresponding smooth path
                        if canonic_action.driving_plan is not None:
                            for action in canonic_action.driving_plan.actions:
                                for path in prev_paths:
                                    if set(action.gff.segment_ids) == set(path.lane_sequence.segment_ids):
                                        action.gff._ctm_gff = path.lane_sequence._ctm_gff

                    if hasattr(frame_identifier, 'planner_service_outputs') and frame_identifier.planner_service_outputs:
                        planner_service_outputs_msg = self._planner_service_outputs_loader.read_by_timestamp(frame_identifier.planner_service_outputs)
                        canonic_action.hmi_statuses = HmiStatuses.deserialize(planner_service_outputs_msg.s_Data.s_HMIInfo)
                        canonic_action.dcu_trigger_statuses = DCUTriggerStatuses.deserialize(planner_service_outputs_msg.s_Data.s_DCUTriggerInfo)
                        canonic_action.fms_statuses = FMSStatuses.deserialize(planner_service_outputs_msg.s_Data.s_FMSInfo)
                    frame.action = canonic_action
                if hasattr(frame_identifier, 'execution_info') and frame_identifier.execution_info:
                    frame.execution_info = self._execution_info_loader.read_by_timestamp(frame_identifier.execution_info)

        self._frames[frame_identifier.frame_id] = frame
        return frame

    def get_deep_search_connections(self) -> Tuple[Dict[int, int], Dict[int, int]]:
        """
        Returns the connections between frames in term of the deep search. every key is either the frame a deep search
        was start and value the frame a deep search was finished or vice versa
        :return:
        """

        if not self._finish_to_start:
            self._finish_to_start = {v: k for k, v in self._start_to_finish.items()}
        return self._start_to_finish, self._finish_to_start

    def get_frame_ids(self):
        """
        :return: Returns a list of frame ids that exist in this recording. if only part of the recording is used, only
        part of the ids will be exposed.
        """
        return list(self._frame_identifiers.keys())

    def get_frame_ids_to_timestamps(self) -> Dict[int, float]:
        """
        :return: Returns a dictionary mapping from frame id to the physical event time of this frame
        """
        return {frame_id: identifier.timestamp for frame_id, identifier in self._frame_identifiers.items()}

    def to_canonic_sequence(self):
        """
        Generates a canonic sequence from all the frames this parser sees.
        """
        out = []
        for el in tqdm(self):
            out.append(el)
        return out

    def get_scene_og(self, scene_og_id: int, timestamp: float):
        """
        Returns a scene og from id. If id doesn't exit, returns None.
        :param scene_og_id: id of scenn og message to draw
        :param timestamp: The same id can be received for different message,
        given an id, find the one closest to the timestamp.
        """
        if scene_og_id not in self._scene_occupancy_grid_identifiers:
            return None

        if timestamp is None:
            # get the first timestamp if received None
            timestamp_nano = self._scene_occupancy_grid_identifiers[scene_og_id][0]
        else:
            optional_timestamps = np.array(self._scene_occupancy_grid_identifiers[scene_og_id])
            nearest_idx = np.argmin(np.abs(optional_timestamps - timestamp))
            timestamp_nano = int(optional_timestamps.take(nearest_idx))
            diff_seconds = abs(timestamp_nano - timestamp) * 1e-9
            if diff_seconds < 0.5:
                warnings.warn("Half a second passed between scene fusion message and canonic state time."
                              "\nBad syncronization issue.")

        return get_scene_og_cached(timestamp_nano, self._scene_occupancy_grid_loader)
