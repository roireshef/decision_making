import os
import pickle
from collections import OrderedDict
from functools import lru_cache
from typing import Optional, List, Any, Tuple, Dict

import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_header_reader import PubSubHeaderReader
from subdivision_planner.src.messages.scene_common_messages import Timestamp
from infrastructure.Python.utils.PubSubReader import pub_sub_reader
from interface.Rte_Types.python.Rte_Types_pubsub import PubSubMessageTypes
from tqdm import tqdm


class PubSubRecordingMetaData:
    """
    This class holds metadata of pubsub recordings used to random access data
    """
    def __init__(self,
                 timestamps_nano: List[int],
                 data_timestamps_dict: Optional[Dict[float, int]],
                 physical_timestamps_dict: Optional[Dict[float, int]],
                 image_capture_timestamps_dict: Optional[Dict[float, int]],
                 ):
        """
        ctor
        :param timestamps_nano: timestamps in nano seconds of each message
        :param data_timestamps_dict: data creation time of each message if relevant
        :param physical_timestamps_dict: physical event time of each message if relevant
        :param image_capture_timestamps_dict: time the image corresponding to this message was captured if relevant
        """
        self.timestamps_nano = timestamps_nano
        self.data_timestamps_dict = data_timestamps_dict
        self.physical_timestamps_dict = physical_timestamps_dict
        self.image_capture_timestamps_dict = image_capture_timestamps_dict
        self.version = self.get_current_version()

    @classmethod
    def get_current_version(cls):
        return 1.1


@lru_cache(maxsize=128)
def get_topic_list(path: str) -> List[str]:
    """
    :param path: path to search for topics
    :return: List of topics in <domain>_<topic> format that exists in this path
    """
    channels = pub_sub_reader.PubSubMultiReader.get_channel_list(dir_path=path)
    return [f"{c.domain}_{c.topic}" for c in channels]


class PubSubDataLoader:
    """
    This class abstracts data read from a pubsub recording. On first load it maps the entire recording to allow random
    access afterwards using timestamps.
    """
    def __init__(self,
                 path: str,
                 domain: str,
                 topic: str,
                 relative_start_time: float = None,
                 duration: float = None,
                 absolute_start_time: float = None,
                 cache_path: str = None,
                 is_quick_parse: bool = False,
                 quick_parse_offseted_data: Dict[str, Tuple[int, str]] = None,
                 ):
        """
        ctr
        :param path: Path for the tlv files
        :param domain: pubsub domain (e.g. UC_SYSTEM)
        :param topic: pubsub topic (e.g. SCENE_DYNAMIC)
        :param relative_start_time: Time to start loading the data relative to beginning of recording in seconds, if not
            given, will start in beginning of recording
        :param duration: duration in seconds of time to load, if not given, will load data until recording ends
        :param absolute_start_time: Similar to relative_start_time, just in in absolute time (380...) and not relative
                                    to beginning of the recording
        :param cache_path: Path to store cache file for future quick read
        :param is_quick_parse: In quick parse loader will not read the entire message but only the TsSYSHeader. This means
                            that DataCreationTime, PhysicalEventTime and ImageCaptureTime won't be available
        :param quick_parse_offseted_data: Offseted data description to be used by pubsub header reader. Used only if
                                            is_quick_parse is True
        """

        assert absolute_start_time is None or relative_start_time is None, \
            "Can't set absolute and relative start time together"

        self._path = path
        self._domain = domain
        self._topic = topic
        self._relative_start_time = relative_start_time if relative_start_time else 0.
        self._requested_duration = duration
        self._cache_path = cache_path
        self._is_quick_parse = is_quick_parse
        self._quick_parse_offseted_data = quick_parse_offseted_data

        self._reader: Optional[pub_sub_reader.PubSubMultiReader] = None
        self._start_time: Optional[float] = absolute_start_time
        self._end_time: Optional[float] = None
        self._duration: Optional[float] = None

        self._meta_data: Optional[PubSubRecordingMetaData] = None
        self._messages_dict: OrderedDict[int, Any] = OrderedDict()

        self._prev_time_load = None
        self._pbar = None

        if self._cache_path is not None:
            success = self._load_meta_data()
            if not success:
                self._read_meta_data()
                self._dump_meta_data()
        else:
            self._read_meta_data()

        self._lru_size = 1

    @property
    def reader(self):
        """
        :return: Returns the pubsub multi reader that is used by this loader
        """
        if self._reader is None:
            cfg = pub_sub_reader.PubSubMultiReaderConfig()
            cfg.add_channel_filter(pub_sub_channel=pub_sub_reader.PubSubChannel(domain=self._domain, topic=self._topic))
            self._reader = pub_sub_reader.PubSubMultiReader(path_to_rec=self._path, config=cfg, layout_file_name=PubSubMessageTypes)

        return self._reader

    @classmethod
    def is_topic_available(cls, path: str, domain: str, topic: str):
        """
        :param path: Path to search for pubsub topic
        :param domain: domain name
        :param topic: topic name
        :return: True if topic exists in path, False otherwise
        """
        topics = get_topic_list(path)
        return f"{domain}_{topic}" in topics

    def __iter__(self):
        """
        Generate an iterator over the messages.
        """
        self._pbar = tqdm(total=self.duration, desc=f"Loading {self._domain}_{self._topic} messages")
        self._prev_time_load = None

        self._iterator_timestamp_nano_idx = np.argmin(np.abs(self.start_time - np.array(self._meta_data.timestamps_nano) * 1e-9)) - 1

        return self

    def __next__(self) -> Tuple[int, Any]:
        """
        Read the next message and return its timestamp in nano seconds together with it
        """
        self._iterator_timestamp_nano_idx += 1
        if self._iterator_timestamp_nano_idx >= len(self._meta_data.timestamps_nano):
            self._pbar.close()
            raise StopIteration

        timestamp_nano = self._meta_data.timestamps_nano[self._iterator_timestamp_nano_idx]
        timestamp_sec = timestamp_nano * 1e-9
        if timestamp_sec > self.end_time:
            self._pbar.close()
            raise StopIteration

        msg = self.read_by_timestamp(timestamp_nano)
        if self._pbar is not None and self._prev_time_load is not None:
            self._pbar.update(timestamp_sec - self._prev_time_load)
        self._prev_time_load = timestamp_sec
        return timestamp_nano, msg

    @property
    def start_time(self) -> float:
        if self._start_time is None:
            self._start_time = self._relative_start_time + self.reader.first_frame_timestamp_nano_sec * 1e-9

        return self._start_time

    @property
    def end_time(self) -> float:
        if self._end_time is None:
            self._end_time = self.start_time + self.duration
        return self._end_time

    @property
    def duration(self) -> float:
        """
        Duration of the recording in seconds in float
        """
        if self._duration is None:
            rec_start, rec_end = self.reader.get_duration()
            max_duration = rec_end * 1e-9 - (rec_start * 1e-9 + self._relative_start_time)
            if self._requested_duration is not None:
                self._duration = min(self._requested_duration, max_duration)
            else:
                self._duration = max_duration

        return self._duration

    @property
    def physical_timestamps(self):
        """
        Retrieves all PhysicalEventTime timestamps
        """
        return list(self._meta_data.physical_timestamps_dict.keys())

    def get_by_physical_timestamp(self, timestamp: float):
        """
        Retrieves message according to physical event timestamp
        :param timestamp: physical event time in float
        """
        idx = int(np.argmin(np.abs(timestamp - np.array(self.physical_timestamps))))
        return self.read_by_timestamp(self._meta_data.physical_timestamps_dict[self.physical_timestamps[idx]])

    @property
    def data_timestamps(self):
        """
        Retrieves all DataCreationTime timestamps
        """
        return list(self._meta_data.data_timestamps_dict.keys())

    def get_by_data_timestamp(self, timestamp: float):
        """
        Retrieves data according to DataCreationTime
        :param timestamp: timestamp in float
        """
        idx = int(np.argmin(np.abs(timestamp - np.array(self.data_timestamps))))
        return self.read_by_timestamp(self._meta_data.data_timestamps_dict[self.data_timestamps[idx]])

    @property
    def header_timestamps(self):
        """
        Retrieves all header timestamps
        """
        a = np.array(self._meta_data.timestamps_nano) / 1e9
        return a.tolist()

    def get_by_header_timestamp(self, timestamp: float):
        """
        Retrieves data according to HeaderTimestamp
        :param timestamp: timestamp in float
        """
        idx = int(np.argmin(np.abs(timestamp - np.array(self.header_timestamps))))
        return self.read_by_timestamp(self._meta_data.timestamps_nano[idx])

    @property
    def image_capture_timestamps(self):
        """
        Retrieves all DataCreationTime timestamps
        """
        return list(self._meta_data.image_capture_timestamps_dict.keys())

    def get_by_image_capture_timestamp(self, timestamp: float):
        """
        Retrieves data according to DataCreationTime
        :param timestamp: timestamp in float
        """
        idx = int(np.argmin(np.abs(timestamp - np.array(self.image_capture_timestamps))))
        return self.read_by_timestamp(self._meta_data.image_capture_timestamps_dict[self.image_capture_timestamps[idx]])

    def read_by_timestamp(self, timestamp_nano: int):
        """
        Reads the relevant message according to the timestamp in nano second as saved by pubsub recorder. This function
        uses an LRU cache to speed up access to data.
        :param timestamp_nano: timestamp according to pubsub recorder in nano seconds
        :return: message read
        """
        if timestamp_nano not in self._messages_dict:
            # If the message is not already in the dictionary, read it
            msg = self.reader.get_next_by_absolute_time(time_offset_nano=timestamp_nano)[1]
        else:
            # If the message is already in the dictionary, pop it so that it is added afterwards in the end
            # (note that self._messages_dict is an OrderedDict)
            msg = self._messages_dict.pop(timestamp_nano)

        # Add the newest message to the end
        self._messages_dict[timestamp_nano] = msg

        # If the size of the dictionary is larger than the LRU size, pop the first message. We assume that the
        # reading is done one message at a time and therefore violation of lru is always by 1
        if len(self._messages_dict) > self._lru_size:
            self._messages_dict.pop(next(iter(self._messages_dict)))

        return msg

    def _load_meta_data(self) -> bool:
        """
        Loads timestamps data from cache file. Checks if cache file exists and if cache version is correct.
        :return: Success or failed.
        """
        # Verify cache file exists
        if not os.path.isfile(self._cache_path):
            return False

        # Load cache data from file
        with open(self._cache_path, 'rb') as f:
            meta_data: PubSubRecordingMetaData = pickle.load(f)

        if not isinstance(meta_data, PubSubRecordingMetaData) or \
                "version" not in meta_data.__dict__ or \
                meta_data.version != PubSubRecordingMetaData.get_current_version():
            return False

        self._meta_data = meta_data

        return True

    def _dump_meta_data(self):
        """
        Dump data to cache file
        """
        # Dump data to file
        with open(self._cache_path, 'wb') as f:
            pickle.dump(self._meta_data, f)

    def _read_meta_data(self):
        """
        Read meta data straight from recording. This is done hopefully once and then saved to cache
        """
        if self._is_quick_parse:
            # Here we perform parsing without reading the actual message by reading the headers and timestamps if given
            # as offseted data
            header_reader = self.get_header_reader(self._quick_parse_offseted_data)
            timestamps_nano, headers, offseted_data = header_reader.read_pubsub_headers()

            data_timestamps_dict = None
            if "s_DataCreationTime" in offseted_data:
                data_timestamps = offseted_data["s_DataCreationTime"]
                data_timestamps_dict = {(sec + frac / (2 << 31)): ts_nano
                                        for ts_nano, (sec, frac) in zip(timestamps_nano, data_timestamps)}

            physical_timestamps_dict = None
            if "s_PhysicalEventTime" in offseted_data:
                phy_timestamps = offseted_data["s_PhysicalEventTime"]
                physical_timestamps_dict = {(sec + frac / (2 << 31)): ts_nano
                                            for ts_nano, (sec, frac) in zip(timestamps_nano, phy_timestamps)}

            image_capture_timestamps_dict = None
            if "s_ImageCapturedTimeStamp" in offseted_data:
                cap_timestamps = offseted_data["s_ImageCapturedTimeStamp"]
                image_capture_timestamps_dict = {(sec + frac / (2 << 31)): ts_nano
                                                 for ts_nano, (sec, frac) in zip(timestamps_nano, cap_timestamps)}

            self._meta_data = PubSubRecordingMetaData(timestamps_nano=timestamps_nano,
                                                      data_timestamps_dict=data_timestamps_dict,
                                                      physical_timestamps_dict=physical_timestamps_dict,
                                                      image_capture_timestamps_dict=image_capture_timestamps_dict)
            return

        # Initialize progress bar
        rec_start, rec_end = self.reader.get_duration()
        max_duration = rec_end * 1e-9 - (rec_start * 1e-9 + self._relative_start_time)
        pbar = tqdm(total=max_duration, desc=f"Loading {self._domain}_{self._topic} messages")
        self._prev_time_load = None

        # Read next message
        msg = self.reader.get_next()

        timestamps_nano = []
        physical_timestamps_dict = None
        data_timestamps_dict = None
        image_timestamps_dict = None

        while msg[0] is not None:
            # if we retrieved a message, save the timestamps
            timestamp_nano = msg[0]['data_nano_time']
            timestamps_nano.append(timestamp_nano)

            if "s_Data" in msg[1]._dic.keys() and "s_PhysicalEventTime" in msg[1].s_Data._dic.keys():
                if physical_timestamps_dict is None:
                    physical_timestamps_dict = OrderedDict()
                physical_timestamp = Timestamp.deserialize(msg[1].s_Data.s_PhysicalEventTime).timestamp_in_seconds
                physical_timestamps_dict[physical_timestamp] = timestamp_nano

            if "s_Data" in msg[1]._dic.keys() and "s_DataCreationTime" in msg[1].s_Data._dic.keys():
                if data_timestamps_dict is None:
                    data_timestamps_dict = OrderedDict()
                data_timestamp = Timestamp.deserialize(msg[1].s_Data.s_DataCreationTime).timestamp_in_seconds
                data_timestamps_dict[data_timestamp] = timestamp_nano

            if "s_Data" in msg[1]._dic.keys() and "s_ImageCapturedTimeStamp" in msg[1].s_Data._dic.keys():
                if image_timestamps_dict is None:
                    image_timestamps_dict = OrderedDict()
                image_timestamp = Timestamp.deserialize(msg[1].s_Data.s_ImageCapturedTimeStamp).timestamp_in_seconds
                image_timestamps_dict[image_timestamp] = timestamp_nano

            # update progress bar
            if self._prev_time_load is not None:
                pbar.update(timestamp_nano * 1e-9 - self._prev_time_load)
            self._prev_time_load = timestamp_nano * 1e-9

            # Read next message
            msg = self.reader.get_next()

        pbar.close()

        self._meta_data = PubSubRecordingMetaData(timestamps_nano=timestamps_nano,
                                                  data_timestamps_dict=data_timestamps_dict,
                                                  physical_timestamps_dict=physical_timestamps_dict,
                                                  image_capture_timestamps_dict=image_timestamps_dict)

    def get_header_reader(self, offseted_data: Dict[str, Tuple[int, str]] = None):
        """
        :param offseted_data: Offseted data description to be used by pubsub header reader.
        :return: PubSubHeaderReader to allow reading parts of the pubsub data without reading the entire message
        """
        return PubSubHeaderReader(self._path, self._domain, self._topic, offseted_data)