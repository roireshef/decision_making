import glob
import os
import struct
from abc import ABC, abstractmethod
from typing import List, Tuple, Dict, Any

from interface.Rte_Types.python.sub_structures.TsSYS_Header import TsSYSHeader
from interface.Rte_Types.python.sub_structures.TsSYS_Timestamp import TsSYSTimestamp
from tqdm import tqdm


def read_and_unpack(format, f):
    return struct.unpack(format, f.read(struct.calcsize(format)))


class StructSerializable(ABC):
    """
    This class allows definition of a payload that can be deserializable via struct with some utilities
    """
    @classmethod
    @abstractmethod
    def _get_format(cls):
        """
        :return: Format as required by struct of the payload
        """
        raise NotImplementedError

    @classmethod
    def get_size(cls):
        """
        :return: Number of bytes in the payload
        """
        return struct.calcsize(cls._get_format())

    @classmethod
    def deserialize(cls, f):
        """
        Deserializes the payload from a file descriptor
        :param f: file descriptor or buffer to read from
        :return: instance of the payload. Fields are assumed to be in the order they are read
        """
        return cls(*read_and_unpack(cls._get_format(), f))


class FileHeader(StructSerializable):
    """
    Pubsub file header
    """
    @classmethod
    def _get_format(cls):
        return "=8sI4xQc7xQQQQ"

    def __init__(self,
                 magic_str,
                 pub_sub_version,
                 file_serial_number,
                 is_big_endian,
                 total_payload_size,
                 total_compressed_size,
                 elem_count,
                 header_ext_size):
        self.magic_str = magic_str
        self.pub_sub_version = pub_sub_version
        self.file_serial_number = file_serial_number
        self.is_big_endian = is_big_endian
        self.total_payload_size = total_payload_size
        self.total_compressed_size = total_compressed_size
        self.elem_count = elem_count
        self.header_ext_size = header_ext_size


class ElemHeader(StructSerializable):
    """
    Pubsub element header - used for every message
    """
    @classmethod
    def _get_format(cls):
        return "=QQQQcHH2xc"

    def __init__(self, serial_number, timestamp, data_size, data_padding_size, is_compressed, data_checksum, checksum,
                 metadata_ext_set):
        self.serial_number = serial_number
        self.timestamp = timestamp
        self.data_size = data_size
        self.data_padding_size = data_padding_size
        self.is_compressed = is_compressed
        self.data_checksum = data_checksum
        self.checksum = checksum
        self.metadata_ext_set = metadata_ext_set


class PrefixMetaDataHeader(StructSerializable):
    """
    First part of meta data header
    """
    @classmethod
    def _get_format(cls):
        return "=QQ32sQQI"

    def __init__(self, channel_frame_count, process_id, process_name, send_time, pub_send_count, num_subscribers):
        self.channel_frame_count = channel_frame_count
        self.process_id = process_id
        self.process_name = process_name
        self.send_time = send_time
        self.pub_send_count = pub_send_count
        self.num_subscribers = num_subscribers


class PostfixMetaDataHeader(StructSerializable):
    """
    Last part of meta data header
    """
    @classmethod
    def _get_format(cls):
        return "=HH"

    def __init__(self, checksum, reserved):
        self.checksum = checksum
        self.reserved = reserved


class SubscriberMetaData(StructSerializable):
    """
    Middle part of meta data header, appears multiple times inside the meta data header
    """
    @classmethod
    def _get_format(cls):
        return "=Q32sQQ"

    def __init__(self, process_id, process_name, recv_time, sub_recv_count):
        self.process_id = process_id
        self.process_name = process_name
        self.recv_time = recv_time
        self.sub_recv_count = sub_recv_count


class PubSubHeader(StructSerializable):
    """
    Pubsub header (part of the payload of each message), can be serialized to TsSYSHeader
    """
    @classmethod
    def _get_format(cls):
        return "=IIII"

    def __init__(self, e_Cnt_SeqNum, s_Timestamp_e_Cnt_Secs, s_Timestamp_e_Cnt_FractionSecs, e_Cnt_version):
        self.e_Cnt_SeqNum = e_Cnt_SeqNum
        self.s_Timestamp_e_Cnt_Secs = s_Timestamp_e_Cnt_Secs
        self.s_Timestamp_e_Cnt_FractionSecs = s_Timestamp_e_Cnt_FractionSecs
        self.e_Cnt_version = e_Cnt_version

    def to_TsSYSHeader(self):
        timestamp = TsSYSTimestamp()
        timestamp.e_Cnt_FractionSecs = self.s_Timestamp_e_Cnt_FractionSecs
        timestamp.e_Cnt_Secs = self.s_Timestamp_e_Cnt_Secs

        header = TsSYSHeader()
        header.e_Cnt_SeqNum = self.e_Cnt_SeqNum
        header.e_Cnt_version = self.e_Cnt_version
        header.s_Timestamp = timestamp

        return header


class PubSubHeaderReader:
    """
    This class allows fast reading of headers and pubsub timestamps from file without reading the entire message
    """
    def __init__(self, base_path: str, domain: str, topic: str, offseted_data: Dict[str, Tuple[int, str]] = None):
        """
        ctr
        :param base_path: Path containing the pubsub data
        :param domain:
        :param topic:
        :param offseted_data: Dictionary containing additional data to be read from pubsub with the offset starting
                                from where the TsSYSHeader finishes and the struct format to parse it with
        """
        self._base_path = base_path
        self._domain = domain
        self._topic = topic
        self._offseted_data = offseted_data or {}

        # File list to read from
        self._file_list = []

        # Total number of elements in the recording topic (in all files together)
        self._total_elements = None

        # Perform initial analysis of the pubsub topic
        self._initial_analysis()

    def _initial_analysis(self):
        """
        This method runs an initial analysis of the pubsub recorded data to allow later faster reading of data.
        It performs the following operations:
        - Enumerate the different files in the folder
        - Find out the total number of messages
        - Find out the size of each message to allow fast skipping between messages
        """
        self._file_list = sorted(glob.glob1(self._base_path, f"{self._domain}_{self._topic}*"))
        file_abs_path = os.path.join(self._base_path, self._file_list[0])
        with open(file_abs_path, 'rb') as f:
            first_file_header = FileHeader.deserialize(f)

        if len(self._file_list) == 1:
            self._total_elements = first_file_header.elem_count
        else:
            # Number of elements is the same in each file except for the last file
            file_abs_path = os.path.join(self._base_path, self._file_list[-1])
            with open(file_abs_path, 'rb') as f:
                last_file_header = FileHeader.deserialize(f)

            self._total_elements = first_file_header.elem_count * (len(self._file_list) - 1) + last_file_header.elem_count

    def read_pubsub_headers(self) -> Tuple[List[int], List[TsSYSHeader], Dict[str, List[Any]]]:
        """
        This method reads all the timestamps in nano seconds of the messages and all the pubsub headers of the contained
        messages
        :return: Tuple with the following:
            - List of timestamps in nano seconds for each pubsub message (can be used by pubsub reader
                to read this message again)
            - List of TsSYSHeader corresponding to every pubsub message
            - Dictionary whose keys are the identifiers of the data to be read and the values are lists of read data
              according to self._offseted_data. If self._offseted_data is None, this dictionary is empty.
        """
        pbar = tqdm(total=self._total_elements, desc=f"Loading {self._domain}_{self._topic} headers")
        headers = []
        timestamps = []
        parsed_offseted_data = {k: [] for k in self._offseted_data}
        # Go over all files and read them one after the other
        for file in self._file_list:
            file_abs_path = os.path.join(self._base_path, file)
            with open(file_abs_path, 'rb') as f:
                # Deserialize the file header to understand where actual data starts from
                file_header = FileHeader.deserialize(f)
                data_start_offset = f.tell() + file_header.header_ext_size
                # Go through all messages and parse them one after the other
                next_elem_offset = data_start_offset
                for elem_idx in range(file_header.elem_count):
                    f.seek(next_elem_offset)
                    # Get the timestamp from the message pubsub header
                    elem_header = ElemHeader.deserialize(f)
                    timestamps.append(elem_header.timestamp)
                    if bool(int.from_bytes(elem_header.metadata_ext_set, 'little')):
                        prefix = PrefixMetaDataHeader.deserialize(f)
                        meta_data_size = prefix.get_size() + \
                                         SubscriberMetaData.get_size() * prefix.num_subscribers + \
                                         PostfixMetaDataHeader.get_size()
                        f.seek(next_elem_offset + elem_header.get_size() + meta_data_size)

                    next_elem_offset = f.tell() + elem_header.data_size + elem_header.data_padding_size

                    # Read the TsSYSHeader header
                    headers.append(PubSubHeader.deserialize(f).to_TsSYSHeader())

                    # Read offseted data as well
                    payload_offset = f.tell()
                    for name, (offset, fmt) in self._offseted_data.items():
                        f.seek(payload_offset + offset)
                        parsed_offseted_data[name].append(read_and_unpack(fmt, f))

                    pbar.update(1)

        pbar.close()
        return timestamps, headers, parsed_offseted_data
