
from subdivision_learning.analysis.recordings_utilities.events_handling import get_events
import pandas
import os

control_disable_reason_dictionary = {
    0: "Hands on steering wheel",
    1: "Brake pedal pressed",
    2: "CC button pressed",
    3: "Acc pedal pressed",
    4: "EPS failed",
    5: "Engine failed",
    6: "Brake system failed",
    7: "Trajectory loss",
    8: "Message stale",
    (9, 10, 11, 12,13,14,15): "None",

}

# Define indices of relevant fields in the tuple that represents each event
ABSOLUTE_TIME_INDEX = 1
EVENT_TYPE_INDEX = 2

def extract_events_to_csv(recording_path: str, ignore_engagements: bool):
    """
    The function extracts all events in a specific recording to a .csv file.
    Events are extracted using get_events method.

    :param recording_path: path to the base directory of the recording. This should be the path to the parent directory
    that holds an internal "recording" directory with the downloaded recording.
    :param ignore_engagements: a boolean indicating whether to omit "AUTONOMOUS_DRIVING_ENGAGEMENT" events, which are written automatically on the recording's vehicle_test_events.Json file.
    :return: The function creates a .csv file in the base_path that holds the timestamps and event descriptions of all the events in the recording.
    """

    assert os.path.isdir(recording_path), f"Directory does not exist: {recording_path}"

    events = get_events(os.path.join(recording_path,"recordings"))

    if not events:
        print("\nNo events found, terminating.")
        return
    else:

        # Extract relevant fields from events
        if ignore_engagements:
            events_types = [event[EVENT_TYPE_INDEX] for event in events if "AUTONOMOUS_DRIVING_ENGAGEMENT" not in event[EVENT_TYPE_INDEX]]
            events_absolute_times = [event[ABSOLUTE_TIME_INDEX] for event in events if "AUTONOMOUS_DRIVING_ENGAGEMENT" not in event[EVENT_TYPE_INDEX]]
        else:
            events_types = [event[EVENT_TYPE_INDEX] for event in events]
            events_absolute_times = [event[ABSOLUTE_TIME_INDEX] for event in events]

        num_events = len(events_types)
        print("\nFound ", num_events, " events. Extracting CSV file.. ")

        unparsed_control_display_reasons = [event_type.split("_disable_reason:_")[-1] for event_type in events_types]
        parsed_control_display_reasons = [parse_reasons_from_decimal_representation(int(disable_reason)) if disable_reason.isdecimal() else disable_reason for disable_reason in unparsed_control_display_reasons]

        events_table = pandas.DataFrame({ '#': list(range(1, num_events+1)), 'Reviewer': ['']*num_events, 'Timestamps/Frame#': events_absolute_times, 'Description': events_types, 'Control disable reason/ Driver notes': parsed_control_display_reasons, 'Status/Analysis':['']*num_events, 'Jira Link': ['']*num_events, 'Assigned Team': ['']*num_events})
        events_table.to_csv(os.path.join(base_path,'events_list.csv'))



def parse_reasons_from_decimal_representation(decimal_reasons_representation: int):
    """
        The function returns a string describing the control disable reasons given a decimal representation of the reasons.
        The decimal representation is converted to a binary representation, where each bit indicates whether or not a specific control issue
        occured. The mappingg between the bit index to the control issue is defined in control_disable_reason_dictionary


        :param decimal_reasons_representation: an integer holding the decimal value of the encoded representation.
        :return: parsed_reasons_str: A string in which the control disable reasons are concatenated
        """

    reasons_in_str_binary_representation = "{0:b}".format(decimal_reasons_representation)[::-1]

    indices_of_1s = [idx for idx in range(len(reasons_in_str_binary_representation)) if reasons_in_str_binary_representation[idx] == '1']

    if not indices_of_1s:
        parsed_reasons_str = ""
    else:
        parsed_reasons_str = ", ".join([control_disable_reason_dictionary[i] for i in indices_of_1s])

    return parsed_reasons_str



if __name__ == "__main__":

    base_path = "/data2/recordings/usa_integ/2020_11_24/Scenario_1_trial_1_host_1_t_16_24_21" # base_path should be the path to the parent directory that holds an internal "recording" directory with the downloaded recording
    ignore_engagement_events = True  # If True, skip engagement events (which are listed automatically)

    extract_events_to_csv(base_path, ignore_engagement_events)