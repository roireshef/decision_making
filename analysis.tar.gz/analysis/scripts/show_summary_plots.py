import argparse
import os
from traceback import format_exc
from typing import Callable, Dict

import matplotlib.pyplot as plt
import yaml
from rte.python.logger.log_utils import LOG_DIRECTORY
from subdivision_learning.analysis.plots.actor_plots import ActorLocationXPlot, ActorLocationYPlot, ActorVelocityPlot, \
    ActorYawPlot, ActorCurvaturePlot, ActorAccelerationPlot, ActorIDPlot, ActorDistancePlot, \
    ActorHeadwayPlot, ActorRelativeVelocityPlot

from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.control_plots import ControlInterpTrjTimePlot, ControlTTCEngagedPlot
from subdivision_learning.analysis.plots.ego_plots import DriverPathTopViewData, PlannerRuntime, \
    LocalizationErrorTimePlot, ExpectedActualTrjPlotType, FrameIDTimePlot, PlannerActionTypeTimePlot, \
    PlannerAllActionTypesTimePlot, \
    PlannerActionVelocityDurationTimePlot, LocationXPlot, VelocityPlot, CurvaturePlot, PlannerStateTimePlot, \
    LocationYPlot, YawPlot, AccelerationPlot, LaneSpeedPlot, AccelerationLimitPlot, PedalPositionPlot, \
    LateralAccelerationPlot, LateralJerkPlot, JerkPlot, PlannerActionEscalationTimePlot, \
    EgoCurveSpeedLimitPlot, LateralOffsetPlot, TrajectoryDurationTimePlot, LaneChangeStatusPlot, SearchIterationsPlot
from subdivision_learning.analysis.plots.HMI_FMS_Statuses import HMIStatusesTimePlot, FMSStatuses_1_TimePlot, \
    FMSStatuses_2_TimePlot, FMSStatuses_3_TimePlot, \
    ActiveActorTimePlot
from subdivision_learning.analysis.plots.map_plots import TrafficLightStatesTimePlot
from subdivision_learning.analysis.plots.map_top_view_data import MapTopViewData
from subdivision_learning.analysis.plots.plot_interfaces import UnifiedPlot, ITimePlot
from subdivision_learning.analysis.plots.summary_plot import summary_plot_vs_time, summary_plot_top_view
from subdivision_learning.analysis.plots.system_plots import FeatureMonitorReturnCodeTimePlot, DriverOverrideTimePlot, \
    FeatureMonitorStateTimePlot, FeatureMonitorVizTimePlot
from subdivision_learning.analysis.plots.ucrl_plots import ValueFunctionTimePlot, LateralPositionTimePlot, \
    PlannedAccelerationTimePlot, PlannedVelocityTimePlot, ActionSpecInfoTimePlot, LateralDirectionEventTimePlot, \
    LaneChangeStateTimePlot, LaneChangeTimeSincePlot, ActivePlannerPlot
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
from subdivision_planner.src.utils.recording_parser import RecordingParser

default_expected_actual_plot_type = ExpectedActualTrjPlotType.Trajectory

time_plots_dict: Dict[str, Callable[[PubSubRecordingMasterParser], ITimePlot]] = {
    "LocationX": lambda: LocationXPlot(plot_type=default_expected_actual_plot_type),
    "LocationY": lambda: LocationYPlot(plot_type=default_expected_actual_plot_type),
    "Velocity": lambda: UnifiedPlot(VelocityPlot(plot_type=default_expected_actual_plot_type),
                                    LaneSpeedPlot(), EgoCurveSpeedLimitPlot()),
    "Yaw": lambda: YawPlot(plot_type=default_expected_actual_plot_type),
    "Curvature": lambda: CurvaturePlot(plot_type=default_expected_actual_plot_type),
    "Acceleration": lambda: UnifiedPlot(AccelerationPlot(plot_type=default_expected_actual_plot_type),
                                        AccelerationLimitPlot()),
    "LatAcceleration": LateralAccelerationPlot,
    "Jerk": JerkPlot,
    "LatJerk": LateralJerkPlot,
    "LateralOffset": LateralOffsetPlot,
    "PlannerState": PlannerStateTimePlot,
    "PlannerRuntime": PlannerRuntime,
    "SearchIterations": SearchIterationsPlot,
    "LocalizationError": LocalizationErrorTimePlot,
    "PlannerActionType": PlannerActionTypeTimePlot,
    "PlannerAllActionTypes": PlannerAllActionTypesTimePlot,
    "PlannerActionVelocityDuration": PlannerActionVelocityDurationTimePlot,
    "FeatureMonitorReturnCode": FeatureMonitorReturnCodeTimePlot,
    "PlannerActionEscalation": PlannerActionEscalationTimePlot,
    "FeatureMonitorState": FeatureMonitorStateTimePlot,
    "FeatureMonitorVizTimePlot": FeatureMonitorVizTimePlot,
    "LaneChangeStatus": LaneChangeStatusPlot,
    "PedalPosition": PedalPositionPlot,
    "TrafficLightStates": TrafficLightStatesTimePlot,
    "ControlInterpTrj_Lon": lambda: ControlInterpTrjTimePlot(field=ControlInterpTrjTimePlot.ControlInterpTrjField.LonPosition),
    "ControlInterpTrj_Lat": lambda: ControlInterpTrjTimePlot(field=ControlInterpTrjTimePlot.ControlInterpTrjField.LatPosition),
    "ControlInterpTrj_Heading": lambda: ControlInterpTrjTimePlot(field=ControlInterpTrjTimePlot.ControlInterpTrjField.Heading),
    "ControlInterpTrj_Velocity": lambda: ControlInterpTrjTimePlot(field=ControlInterpTrjTimePlot.ControlInterpTrjField.Velocity),
    "ControlInterpTrj_Acceleration": lambda: ControlInterpTrjTimePlot(field=ControlInterpTrjTimePlot.ControlInterpTrjField.Acceleration),
    "ControlInterpTrj_Curvature": lambda: ControlInterpTrjTimePlot(field=ControlInterpTrjTimePlot.ControlInterpTrjField.Curvature),
    "DriverOverride": DriverOverrideTimePlot,
    "ControlTTCEngagedPlot": ControlTTCEngagedPlot,
    "FrameID": FrameIDTimePlot,
    "TrajectoryDuration": TrajectoryDurationTimePlot,
    "HMIStatuses": HMIStatusesTimePlot,
    "FMSStatuses_1": FMSStatuses_1_TimePlot,
    "FMSStatuses_2": FMSStatuses_2_TimePlot,
    "FMSStatuses_3": FMSStatuses_3_TimePlot,
    "ActiveActor": ActiveActorTimePlot,

    # UCRL plots
    "ValueFunction": ValueFunctionTimePlot,
    "LateralPosition": LateralPositionTimePlot,
    "LateralDirectionEvent": LateralDirectionEventTimePlot,
    "PlannedAcceleration": PlannedAccelerationTimePlot,
    "PlannedVelocity": PlannedVelocityTimePlot,
    "ActionSpecInfo": ActionSpecInfoTimePlot,
    "LaneChangeStateTime": LaneChangeStateTimePlot,
    "LaneChangeTimeSince": LaneChangeTimeSincePlot,

    # Planner integration plots
    "ActivePlanner": ActivePlannerPlot,
}

top_view_overlay_dict = {
    "Map": MapTopViewData,
    "DriverPath": DriverPathTopViewData,
}

actor_plot_dict = {
    "ActorLocationX": ActorLocationXPlot,
    "ActorLocationY": ActorLocationYPlot,
    "ActorVelocity": ActorVelocityPlot,
    "ActorYaw":  ActorYawPlot,
    "ActorCurvature": ActorCurvaturePlot,
    "ActorAcceleration": ActorAccelerationPlot,
    "ActorID": ActorIDPlot,
    "ActorDistance": ActorDistancePlot,
    "ActorHeadway": ActorHeadwayPlot,
    "ActorRelativeV_s": ActorRelativeVelocityPlot
}


def generate_plot(cfg, canonic_sequence: CanonicSequence, master_parser: PubSubRecordingMasterParser, record_data: Dict) -> None:

    # General time graphs
    if cfg["type"] == "Time" and isinstance(cfg["plots_type_name"], list):
        # Whether the time axis should display relative or absolute times
        relative_time_axis = cfg["relative_axis"]

        graph_list = [time_plots_dict[plot_name]() for plot_name in cfg["plots_type_name"]]
        summary_plot_vs_time(canonic_sequence=canonic_sequence,
                             master_parser=master_parser,
                             record_data=record_data,
                             graphs=graph_list,
                             num_horizontal_plots=cfg["num_horizontal_plots"],
                             relative_time=relative_time_axis,
                             title_addition=cfg["title_addition"])

    elif cfg["type"] == "TopView" and isinstance(cfg["plots_type_name"], list):
        top_view_data = [top_view_overlay_dict[plot_name]() for plot_name in cfg["plots_type_name"]]
        summary_plot_top_view(canonic_sequence=canonic_sequence,
                              master_parser=master_parser,
                              top_view_data=top_view_data)

    elif cfg["type"] == "Actor" and isinstance(cfg["plots_type_name"], list):
        # Whether the time axis should display relative or absolute times
        relative_time_axis = cfg["relative_axis"]

        graph_list = [actor_plot_dict[plot_name]() for plot_name in cfg["plots_type_name"]]
        summary_plot_vs_time(canonic_sequence=canonic_sequence,
                             master_parser=master_parser,
                             graphs=graph_list,
                             num_horizontal_plots=cfg["num_horizontal_plots"],
                             relative_time=relative_time_axis,
                             title_addition=cfg["title_addition"])


def load_recording(cfg: dict):
    if cfg["load_event_data"]:
        master_parser = PubSubRecordingMasterParser.load_event(base_recording_path=cfg["base_path"],
                                                               event_idx=cfg["event_idx"],
                                                               relative_start_time=cfg["event_time_offset"],
                                                               duration=cfg["event_duration"])
    else:
        if cfg["use_relative_start_time"]:
            master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["base_path"],
                                                        relative_start_time=cfg["relative_start_time"],
                                                        duration=cfg["duration"])
        else:
            master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["base_path"],
                                                        absolute_start_time=cfg["absolute_start_time"],
                                                        duration=cfg["duration"])

    return master_parser


def main(cfg):
    # load pubsub messages
    master_parser = load_recording(cfg["recording"])
    canonic_sequence = master_parser.canonic_sequence_parser.to_canonic_sequence()
    existing_frames = master_parser.canonic_sequence_parser.get_frame_ids()

    # load recorder messages
    # default_base_log_dir = LOG_DIRECTORY
    default_base_log_dir = os.path.expanduser("~/projects/uc_workspace/ultracruise/build/python/logs")  # LOG_DIRECTORY
    recorder_path = cfg["recording"].get("recorder_path", None) or \
                    os.path.join(default_base_log_dir, 'sd_recorded_data', cfg["recording"]["base_path"].split('/')[-1])
    try:
        recording_parser = RecordingParser(output_dir=recorder_path)
        recorder_frames = {frame: contents
                           for frame, contents in recording_parser.get_frames_iter()
                           if frame in set(existing_frames)}
    except Exception:
        print("Exception raised while trying read from %s:\n %s" % (recorder_path, format_exc()))
        recorder_frames = {}

    # generate plots
    for figure_cfg in cfg["figures"]:
        generate_plot(figure_cfg, canonic_sequence=canonic_sequence, master_parser=master_parser,
                      record_data=recorder_frames)
    plt.show(block=True)


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Summary plots')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/summary_plots_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    main(cfg)
