import argparse
import os
import shutil

from subdivision_learning.analysis.scripts.da_vinci_download import topics_to_copy


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--src', help="Source dir")
    parser.add_argument('-d', '--dst', help="Destination dir")

    args = parser.parse_args()

    return args


if __name__ == "__main__":
    # This script is used to copy only relevant data from vehicle instead of copying all the folder

    args = parse_args()

    # That's the base path for the recording. Each recording will be downloaded to a separate folder, so better group
    # recordings from the same day in the same folder
    src_path = args.src
    dst_path = args.dst

    # Go over all files and copy files with their relative path
    dst_path = os.path.join(dst_path, os.path.basename(src_path))
    os.makedirs(dst_path)
    for abs_path, dirs, files in os.walk(src_path):
        for file in files:
            if not any(topic in file for topic in topics_to_copy):
                continue
            dst_folder = os.path.join(dst_path, os.path.relpath(abs_path, src_path))
            if not os.path.isdir(dst_folder):
                os.makedirs(dst_folder, exist_ok=True)
            dst_file = os.path.join(dst_folder, file)
            print(f"Copying: {file}")
            shutil.copy(os.path.join(abs_path, file), dst_file)
