from subdivision_learning.analysis.recordings_utilities.events_handling import crop_events

# Path to recording

path = "/data2/recordings/usa_integ/2020_07_28/Scenario_1_trial_1_host_1_t_10_14_12"

duration = 30.
time_offset = 30.

crop_events(path, time_offset, duration, gen_rec2sim_scenario=True)
