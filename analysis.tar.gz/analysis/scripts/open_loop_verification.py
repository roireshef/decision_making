import os

import yaml
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
from subdivision_learning.analysis.utils.searcher_mock import SearcherMock
from subdivision_learning.utils.planner import plan_exists
from subdivision_planner.src.common.recorder import DummyRecorder
from subdivision_planner.src.utils.debug import get_logger
from tqdm import tqdm

if __name__ == "__main__":

    logger = get_logger()

    # Load all recordings identifiers
    frames_file_path = os.path.join(os.environ["ULTRACRUISE"], 'subdivision_learning', 'analysis',
                                    'open_loop_frames.yml')
    with open(frames_file_path, 'r') as f:
        yml_data = yaml.load(f, Loader=yaml.FullLoader)
        base_recordings_dir = yml_data["base_dir"]
        recordings_identifiers = yml_data["recordings_identifiers"]

    # Generate searcher mock
    deep_searcher_mock = SearcherMock(recorder=DummyRecorder(),
                                      logger=logger,
                                      name="ShallowSearcherMock")

    shallow_searcher_mock = SearcherMock(recorder=DummyRecorder(),
                                         logger=logger,
                                         name="ShallowSearcherMock")

    no_valid_actions_frames = {}
    metric_calculators = {}
    # Go over all identifiers and run search from them to calculate different metrics
    for identifier in recordings_identifiers:
        recording_path = os.path.join(base_recordings_dir, identifier['path'])
        no_valid_actions_per_run = []
        no_valid_actions_frames[recording_path] = no_valid_actions_per_run
        master_parser = PubSubRecordingMasterParser(base_recording_path=recording_path)
        canonic_sequence_parser = master_parser.canonic_sequence_parser
        planner_runner = PlannerRunner(logger=logger,
                                       parser=canonic_sequence_parser,
                                       deep_searcher_mock=deep_searcher_mock,
                                       shallow_searcher_mock=shallow_searcher_mock)
        metric_calculators_per_run = [
        ]
        metric_calculators[recording_path] = metric_calculators_per_run
        for frame_id in tqdm(identifier['frames']):
            try:
                print("frame", frame_id)
                canonic_action = planner_runner.plan(frame=frame_id)
                if not plan_exists(canonic_action):
                    no_valid_actions_per_run.append(frame_id)
                    actions = []
                else:
                    actions = canonic_action.driving_plan.actions
                for metric_calc in metric_calculators_per_run:
                    metric_calc.update(actions)

            except Exception:
                for metric_calc in metric_calculators_per_run:
                    metric_calc.update([])
                no_valid_actions_per_run.append(frame_id)
                logger.exception(f"Exception raised in frame {frame_id}")

    # Performs reduction of all metrics and returns the result
    reduced_metrics = {}
    for identifier in metric_calculators.keys():
        reduced_metrics_per_run = {}
        for metric_calc in metric_calculators[identifier]:
            reduced_metrics_per_run[metric_calc.__class__.__name__] = metric_calc.reduce()
        reduced_metrics[identifier] = reduced_metrics_per_run

    print("Reduced metrics: \n", reduced_metrics)
    print(f"No valid actions frames: {no_valid_actions_frames}")
