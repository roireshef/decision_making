import os
import pickle

import cv2
import numpy as np
from infrastructure.Python.utils.PubSubReader import pub_sub_reader
from interface.Rte_Types.python.Rte_Types_pubsub import PubSubMessageTypes
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import VehiclePlatform, \
    PubSubRecordingMasterParser
from tqdm import tqdm


def convert_to_rgb(raw: np.array, res_width, res_height, vehicle_platform: VehiclePlatform):
    """
    convert input camera image (Yuv vector to RGB matrix)
    :param raw: data vector in the format of [u,Y,v,Y...]
    :param res_width: width of image
    :param res_height: height of image
    :return:
    """
    num_pixels = res_width * res_height

    yuv_image = np.zeros((res_width * res_height, 3), dtype=np.uint8)

    yuv_image[:, 0] = raw[1:num_pixels * 2:2]
    yuv_image[0::2, 1] = raw[0:num_pixels * 2:4]
    yuv_image[1::2, 1] = raw[0:num_pixels * 2:4]
    yuv_image[0::2, 2] = raw[2:num_pixels * 2:4]
    yuv_image[1::2, 2] = raw[2:num_pixels * 2:4]

    yuv_image = yuv_image.reshape((res_height, res_width, 3))
    if vehicle_platform == VehiclePlatform.K2:
        return cv2.cvtColor(yuv_image, cv2.COLOR_YCrCb2RGB)
    elif vehicle_platform == VehiclePlatform.T1:
        return cv2.cvtColor(yuv_image, cv2.COLOR_YCrCb2BGR)


def parse_msg(msg, file_name, vehicle_platform: VehiclePlatform):
    data = msg.s_Data.a_PixelData
    res_width = np.int(msg.s_Data.s_SensingCameraImageHeader.e_Cnt_ResWidthPixels)
    res_height = np.int(msg.s_Data.s_SensingCameraImageHeader.e_Cnt_ResHeightPixels)

    meta_data = {
        "data": {"s_PhysicalEventTime": msg.s_Data.s_PhysicalEventTime._dic,
                 "s_DataCreationTime": msg.s_Data.s_DataCreationTime._dic},
        "parser_processed_info": {"file_name": file_name}
    }

    return convert_to_rgb(data, res_width=res_width, res_height=res_height, vehicle_platform=vehicle_platform), meta_data


def parse_images(base_path: str):

    recording_folder = os.path.join(base_path, 'recordings')
    domain = "UC_SYSTEM"

    camera_topics = PubSubRecordingMasterParser.get_cameras(base_path=base_path)

    parsed_any = False
    for vehicle_platform, topic, camera_name in camera_topics:

        cfg = pub_sub_reader.PubSubMultiReaderConfig()
        cfg.add_channel_filter(pub_sub_channel=pub_sub_reader.PubSubChannel(domain=domain, topic=topic))
        reader = pub_sub_reader.PubSubMultiReader(path_to_rec=recording_folder, config=cfg, layout_file_name=PubSubMessageTypes)

        parsed_images_folder_path = os.path.join(base_path, topic)
        os.makedirs(parsed_images_folder_path, exist_ok=True)

        meta_data_file = os.path.join(base_path, f"{topic}_parsed_pure_json.json.pkl")
        if os.path.isfile(meta_data_file):
            with open(meta_data_file, 'rb') as f:
                meta_data_list = pickle.load(f)
        else:
            meta_data_list = []
        msg_meta_data, msg = reader.get_next()

        if msg_meta_data is None:
            print(f"No image pubsub data was found for topic {topic}, skipping parsing of images for camera {camera_name}")
            continue

        parsed_any = True

        prev_time_load = msg_meta_data["data_nano_time"] * 1e-9
        start, stop = reader.get_duration()
        file_idx = 0
        pbar = tqdm(total=(stop-start)*1e-9, desc=f"Parsing images")
        while msg is not None:
            file_name = f"{str(file_idx).zfill(12)}.png"
            dst_file = os.path.join(parsed_images_folder_path, file_name)
            if not os.path.isfile(dst_file):
                img, meta_data = parse_msg(msg, file_name, vehicle_platform)
                meta_data_list.append(meta_data)
                cv2.imwrite(dst_file, img)
            msg_meta_data, msg = reader.get_next()
            if msg is not None:
                timestamp_nano = msg_meta_data["data_nano_time"]
                pbar.update(timestamp_nano * 1e-9 - prev_time_load)
                prev_time_load = timestamp_nano * 1e-9
                file_idx += 1
            if file_idx % 100 == 0:
                with open(os.path.join(base_path, f"{topic}_parsed_pure_json.json.pkl"), 'wb') as f:
                    pickle.dump(meta_data_list, f)

        pbar.close()
        with open(os.path.join(base_path, f"{topic}_parsed_pure_json.json.pkl"), 'wb') as f:
            pickle.dump(meta_data_list, f)

    return parsed_any


if __name__ == "__main__":
    base_path = "/data2/recordings/usa_integ/2020_11_30/Scenario_1_trial_1_host_1_t_16_07_10_sub_master"
    parse_images(base_path)
