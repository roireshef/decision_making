import argparse

import matplotlib.pyplot as plt
import yaml
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.scripts.show_summary_plots import generate_plot
from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.utils.algo_timer import AlgoTimer
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.src.utils.manual_gc import run_manual_gc


def main(cfg: dict):
    logger = get_logger()
    master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["path"])

    frame_ids = range(cfg["start_frame_id"], cfg["end_frame_id"] + 1)

    # Find missing frames in canonic sequence parser
    existing_frames = master_parser.canonic_sequence_parser.get_frame_ids()
    missing_frames = [frame_id
                      for frame_id in frame_ids
                      if frame_id not in existing_frames]
    assert len(missing_frames) == 0, f"Missing frames in canonic sequence, {missing_frames},\n existing from {min(existing_frames)} to {max(existing_frames)}"

    planner_runner = PlannerRunner(logger=logger, parser=master_parser.canonic_sequence_parser)

    canonic_sequence = []

    for frame_id in frame_ids:
        print("frame id", frame_id)
        original_frame = master_parser.canonic_sequence_parser[frame_id]
        new_frame = CanonicFrame(state=original_frame.state,
                                 action=None,
                                 internal_state=original_frame.internal_state,
                                 execution_info=original_frame.execution_info)

        try:
            action_result = planner_runner.plan(frame_id, cfg["skip_deep_search"], False, set_iterations=cfg["set_iterations"])
            print(action_result.driving_plan if action_result.driving_plan is not None else "planner produced no action")
            new_frame.action = action_result
        except Exception:
            logger.exception(f"Exception when running frame {frame_id}")
        finally:
            # Manual garbage collection
            if Config().system.manual_gc:
                internal_state = planner_runner._planner.get_state()
                gc_threshold = Config().system.manual_gc_shallow_threshold_factor \
                    if internal_state is not None and internal_state.s_Data.e_b_IsShallowSearchInitiated \
                    else 1.0

                run_manual_gc(gc_threshold)

            logger.debug(str(AlgoTimer()))
            AlgoTimer().reset()

        canonic_sequence.append(new_frame)

    if cfg["show_summary_plots"]:
        for figure_cfg in cfg["figures"]:
            generate_plot(figure_cfg, canonic_sequence=canonic_sequence, master_parser=master_parser)

        plt.show(block=True)


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Planner runner')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/planner_runner_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    main(cfg)
