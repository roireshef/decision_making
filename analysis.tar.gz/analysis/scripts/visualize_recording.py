import argparse
import os
import threading

import yaml
from subdivision_learning.analysis.data_layer.image_parsed_data_loader import ImageParsedDataLoader
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.visualization.image_visualizer import ImageVisualizer
from subdivision_learning.analysis.visualization.sequence_visualizer import SequenceVisualizer


# This script visualizes an event from a recording both using pubsub data and parsed image data


def main(cfg: dict, cfg_path: str):
    if cfg["load_event_data"]:
        master_parser = PubSubRecordingMasterParser.load_event(base_recording_path=cfg["base_path"],
                                                               event_idx=cfg["event_idx"],
                                                               relative_start_time=cfg["event_time_offset"],
                                                               duration=cfg["event_duration"])
    else:
        if cfg["use_relative_start_time"]:
            master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["base_path"],
                                                        relative_start_time=cfg["relative_start_time"],
                                                        duration=cfg["duration"])
        else:
            master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["base_path"],
                                                        absolute_start_time=cfg["absolute_start_time"],
                                                        duration=cfg["duration"])

    image_visualizers = []
    if cfg["load_image_visualization"] and "image_visualizer" in cfg:

        assert os.path.isdir(cfg["parsed_recordings_path"]), f"Parsed recording path doesn't exist: {cfg['parsed_recordings_path']}"

        camera_topics = master_parser.get_cameras(base_path=cfg["base_path"])
        for vehicle_platform, topic, camera_name in camera_topics:
            parsed_image_parser = ImageParsedDataLoader(base_path=cfg["parsed_recordings_path"], sensor_name=topic)

            image_visualizer = ImageVisualizer(name=camera_name,
                                               config_path=cfg_path,
                                               image_parsed_data_loader=parsed_image_parser,
                                               master_parser=master_parser,
                                               image_downscale=cfg["image_downscale"],
                                               )
            image_visualizers.append(image_visualizer)

    sequence_visualizer = SequenceVisualizer(master_parser=master_parser,
                                             config_path=cfg_path,
                                             win_name=f"Planning State data: {cfg['base_path']}",
                                             is_blocking=False,
                                             image_visualizers=image_visualizers,
                                             visualize_free_space=cfg['visualize_free_space'],
                                             visualize_fused_scene=cfg['visualize_fused_scene']
                                             )

    # Run in separate thread to allow using interactive python console
    visualizer_thread = threading.Thread(target=sequence_visualizer.run)
    visualizer_thread.start()

    return master_parser.canonic_sequence_parser


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Recording visualizer')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/visualize_recording_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    parser = main(cfg, args.cfg)
    # In PyCharm, Run - Edit Configurations - Run with python console
    # Use parser[frame_id] to access frames
