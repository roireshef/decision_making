import argparse
import os
import pprint
import json

import yaml
from rte.python.logger.log_utils import LOG_DIRECTORY
from subdivision_planner.src.planners.state_converters.scene_provider import SceneProviderStateConverter
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.src.utils.recording_parser import RecordingParser


def main(cfg: dict):
    logger = get_logger('state_converter_debug')
    sp = SceneProviderStateConverter(recorder=None, logger=logger)

    # load recorder messages
    recorder_path = cfg["recorder_path"] or os.path.join(LOG_DIRECTORY, 'sd_recorded_data', cfg["path"].split('/')[-1])
    recording_parser = RecordingParser(output_dir=recorder_path)

    existing_frames = recording_parser.get_frames_id_list()
    frame_ids = range(max(cfg["start_frame_id"], existing_frames[0]),
                      min(cfg["end_frame_id"], existing_frames[-1]) + 1)

    for frame_id in frame_ids:
        print('Frame #%s' % frame_id)
        recorder_frame = recording_parser.get_by_frame_id(frame_id)
        state_data = recorder_frame['PlanningModule']['state_data']
        # print('State Conversion input: %s' % get_json(state_data))
        converted_state = sp.convert(frame_id=frame_id, **state_data)
        # print('Converted state: %s' % get_json(converted_state))


def get_json(obj):
    return json.loads(json.dumps(obj, default=lambda o: getattr(o, '__dict__', repr(o))))


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Planner runner')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/planner_runner_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    main(cfg)
