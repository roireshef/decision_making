printf 'Frames\tSearches\tShallow\tDeep\tReplans\tDisengaged\tBestEffort\tShallowFailed\n'

for log in "$@"
do

# echo $log

valid_trajectory_num=$(grep 'Got valid trajectory' $log | wc -l)
planner_frames_num=$(grep 'Initializing MDP' $log | wc -l)
shallow_search_num=$(grep 'Starting search' $log | grep Shallow | wc -l)
deep_search_num=$(grep 'Starting search' $log | grep Deep | wc -l)
all_search_num=$(grep 'Starting search' $log | grep -v Searcher | wc -l)
best_effort_num=$(grep 'Initializing level 1 best effort search' $log | wc -l)
shallow_failed_num=$(grep 'Exiting with Failure, Shallow failed' $log | wc -l)
replan_num=$(grep -i 'replan.*stopping searcher' $log | wc -l)
disengaged_num=$(grep -i 'is_ttc_engaged: False' $log | wc -l)

printf "$planner_frames_num\t"
printf "$all_search_num\t"
printf "$shallow_search_num\t"
printf "$deep_search_num\t"
printf "$replan_num\t"
printf "$disengaged_num\t"
printf "$best_effort_num\t"
printf "$shallow_failed_num\t"
printf "\n"

printf "100 %%\t"
printf "%.2f %%\t" $(bc -l <<< "$all_search_num / $planner_frames_num * 100.")
printf "%.2f %%\t" $(bc -l <<< "$shallow_search_num / $planner_frames_num * 100.")
printf "%.2f %%\t" $(bc -l <<< "$deep_search_num / $planner_frames_num * 100.")
printf "%.2f %%\t" $(bc -l <<< "$replan_num / $planner_frames_num * 100.")
printf "%.2f %%\t" $(bc -l <<< "$disengaged_num / $planner_frames_num * 100.")
printf "%.2f %%\t" $(bc -l <<< "$best_effort_num / $planner_frames_num * 100.")
printf "%.2f %%\t" $(bc -l <<< "$shallow_failed_num / $planner_frames_num * 100.")
printf "\n"

echo

done
