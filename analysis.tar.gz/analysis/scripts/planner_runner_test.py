import argparse

from subdivision_learning.analysis.data_layer.canonic_sequence_pubsub_parser import PubSubCanonicSequenceParser
from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
from subdivision_learning.utils.planner import plan_exists
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.test.data_structures.test_canonic_action import canonic_action_compare


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--path', help="Path to load recordings from")
    parser.add_argument('-s', '--skip-deep-search', action='store_true', help='Skip deep search')

    args = parser.parse_args()

    return args


if __name__ == "__main__":
    args = parse_args()
    skip_deep_search = args.skip_deep_search
    path = args.path

    logger = get_logger()

    parser = PubSubCanonicSequenceParser(path=path)

    planner_runner = PlannerRunner(logger=logger, parser=parser)

    for frame_id in parser.get_frame_ids():
        print(f"Frame: {frame_id}")
        frame = parser[frame_id]
        canonic_state, planner_internal_state, canonic_action = frame.state, frame.internal_state, frame.action
        if not plan_exists(canonic_action):
            continue

        canonic_action_result = planner_runner.plan(frame_id, skip_deep_search=skip_deep_search)

        # Go over internal fields and make sure they are generated so that comparison can be done
        for action in canonic_action.driving_plan.actions:
            action.cartesian_states
            action.lane_segment_ids
            action.times
        canonic_action.driving_plan.to_samplable_trajectory()
        for action in canonic_action_result.driving_plan.actions:
            action.cartesian_states
            action.lane_segment_ids
            action.times
        canonic_action_result.driving_plan.to_samplable_trajectory()
        assert canonic_action_compare(canonic_action_result, canonic_action, compare_ids=False), "Frame: {}".format(frame_id)
