import subprocess
import traceback
from datetime import datetime
import os
import re
from operator import itemgetter
from typing import List
import argparse
import concurrent.futures

from DaVinci.data import DaVinciClient

# This script can be used to download recorded data from da vinci easily.

# Download all files that have these strings in the name
topics_to_copy = [
    # Useful for visualize_event
    "UC_PLANNING_INTERNAL_CANONIC_STATE",
    "UC_PLANNING_INTERNAL_CANONIC_ACTION",
    "UC_PLANNING_INTERNAL_PLANNER_INTERNAL_STATE",
    "UC_PLANNING_INTERNAL_PLANNER_EXECUTION_INFO",
    "UC_SYSTEM_VEHICLE_TEST_EVENTS",
    "UC_SYSTEM_HOST_SEMANTIC_POSE",
    "UC_SYSTEM_PERCEIVED_OBJECT_DATA",
    "UC_SYSTEM_PERCEIVED_ROAD_GEOMETRY",
    "FEATURE_MONITOR_RETURN_CODE",
    "FEATURE_MONITOR_VIZ",
    "UC_SYSTEM_TAKEOVER",
    "UC_SYSTEM_FUSED_SCENE_REPACK",

    "UC_SYSTEM_SCENE_OG",
    "UC_SYSTEM_MAP_ATTRIBUTES",
    "UC_SYSTEM_SCENE_DYNAMIC",
    "events",
    "pubsub",
    "lba_main",
    "PubSub",
    "UC_SYSTEM_GPS_DATA_SERVICE",
    "UC_SYSTEM_ROUTE_PLAN",
    "UC_SYSTEM_TRAJECTORY_PLAN",
    "Event_",
    "logs.zip",
    "CameraDefinition",
    "CoordinateFrame",
    "LOGG",
    "UC_Versions",
    # "UC_SYSTEM_CAMERA_4MB_IMAGE_RF_BEHIND_WINDSHIELD",
    # "UC_SYSTEM_CAMERA_4MB_IMAGE_EXTWIDE_FRONT_WS",
    # "UC_SYSTEM_CAMERA_2MB_IMAGE_WIDE_REAR_LIFT_GATE",

    # Planner subscriptions
    "UC_SYSTEM_PREDICTED_OBJECTS",
    "UC_SYSTEM_PEDAL_POSITION",
    "UC_SYSTEM_TURN_SIGNAL",
    "UC_SYSTEM_GAP_SETTING",
    "UC_SYSTEM_SET_SPEED",
    "UC_SYSTEM_DRIVER_OVERRIDE_STATUS",
    "UC_SYSTEM_CONTROL_STATUS",
    "UC_SYSTEM_SCENE_TRAFFIC_CONTROL",
    "UC_SYSTEM_LANE_CHANGE_FOR_TIME_AND_ROUTE",
    "UC_SYSTEM_SCENE_ROAD_GEOMETRY",
    "UC_SYSTEM_PLANNER_SERVICE_OUTPUTS",
    "UC_SYSTEM_DRVR_DIR_REQ"
]


def safe_download_attachment(client, attachment_id, folder: str = '', file_name: str = None):
    try:
        file_path = folder + '/' + file_name

        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            if not os.path.exists(folder):
                os.makedirs(folder)
        attachment = client.get_attachment_by_id(attachment_id)

        print('... Downloading', file_path, '...')
        client.download_attachment(attachment, file_path)
        print('Successfully downloaded', file_path)
    except Exception as ex:
        traceback.print_exception(type(ex), ex, ex.__traceback__)
        print("Failed downloading... " + str(ex))


def download_data(tonic: str, recording_id: str, dst_path: str, str_filters: List[str], perform_download: bool, max_workers: int):
    """
    Downloads specific recording from da vinci
    :param tonic:
    :param recording_id:
    :param dst_path: This is the base path to download to, an additional folder will be generated inside that folder,
                     based on the date and internal directory that is stored on da vinci
    :param str_filters: String filters for data to be downloaded. All files containing any of these strings will be
                        downloaded
    :param perform_download: If True, download of data will be done, else, only the destination dir will be returned
    :param max_workers: maximum number of allowed workers in parallel to download data
    :return: Main directory the data was downloaded to
    """
    client = DaVinciClient(tonic, 'prod')
    all_attachments = client.get_all_attachments_by_recording_id(recording_id)

    # Append to path a folder with the test date
    test_date_str = datetime.fromtimestamp(all_attachments[0]['createdDate']/1000).strftime("%Y_%m_%d")
    dst_path = os.path.join(dst_path, test_date_str)

    if not os.path.isdir(dst_path):
        os.makedirs(dst_path)
        subprocess.call(['chmod', '-R', '777', dst_path])

    files_to_download = []
    files_without_path = []

    for attachment in all_attachments:
        if any(topic in attachment['fileName'] for topic in str_filters) and attachment['fileName'] not in os.listdir(dst_path):
            if re.match(".*EN.*", attachment['path']):
                dst_file = re.findall("EN.*", attachment['path'])[0].split('/', maxsplit=1)[1]
                if not os.path.isdir(os.path.dirname(os.path.join(dst_path, dst_file))):
                    os.makedirs(os.path.dirname(os.path.join(dst_path, dst_file)))
                files_to_download.append((attachment['id'], dst_file))
            else:
                dst_file = attachment['fileName']
                files_without_path.append((attachment['id'], dst_file))

    main_folder = files_to_download[0][1].split('/', maxsplit=1)[0]


    # perform_download = False
    if perform_download:

        # Generate a file with the recording id as file name for easy access later
        with open(os.path.join(dst_path, main_folder.split('/')[0], recording_id), 'wb') as f:
            pass

        files_to_download = [(rec_id, file)
                             for rec_id, file in files_to_download
                             if not os.path.isfile(os.path.join(dst_path, file))
                             or os.path.getsize(os.path.join(dst_path, file)) == 0]
        files_without_path = [(rec_id, os.path.join(main_folder, file))
                              for rec_id, file in files_without_path]

        files_to_download = files_to_download + files_without_path
        print("Downloading the following files: {}".format(files_to_download))

        max_workers = min(max_workers, os.cpu_count() + 4)

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {}
            # send downloads to thread pool
            for attachment_id, dst_file in files_to_download:
                futures[executor.submit(safe_download_attachment, client, attachment_id, dst_path, dst_file)] = dst_file
            # wait for downloads to finish
            for f in concurrent.futures.as_completed(futures):
                # print("ThreadPool downloaded", futures[f])
                pass

    return os.path.join(dst_path, main_folder)


if __name__ == "__main__":

    ##### Parameters #####
    # Acquire tonic from: https://davinci-tonic.cpi.gm.com/
    tonic = "eyJ0eXAiOiJKV1QiLCJjdHkiOm51bGwsImFsZyI6IkhTMjU2In0.eyJzdWIiOnsiZ21pbiI6bnVsbCwiZ21pZCI6IlhaMldLRiIsImFjY291bnR0eXBlIjoiVXNlciIsImFwcFJvbGUiOlsiRU5HX0FETUlOIl19LCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC81ZGUxMTBmOC0yZTBmLTRkNDUtODkxZC1iY2YyMjE4ZTI1M2QvIiwiYXVkIjoiMTAuNjYuNjUuNzksIDEzMC4xNzIuMTI1LjIxNiIsImV4cCI6MTc3MDcwMDcwMCwiaWF0IjoxNTk3OTAwNzAwLCJqdGkiOiJmNDk1NjBmOS1jYTYxLTQzYjItODI1OC0yMTgzZDNlYjNmMmUifQ.yTHVdKDYKXhcXkGx6FZFFOA3t91x2MPyG1wx7hASdes"

    # Add parameters here if not using args

    # That's the base path for the recording. Each recording will be downloaded to a separate folder, so better group
    # recordings from the same day in the same folder
    dst_path = "/data2/recordings/usa_integ/"
    recording_ids = ["123599738"]

    parser = argparse.ArgumentParser(description='Download recordings from DaVinci')

    parser.add_argument('--ids', action="store", nargs='+', dest='recording_ids', type=str, default=recording_ids)
    parser.add_argument('--dst', action="store", dest='dst_path', type=str, default=dst_path)
    args = parser.parse_args()

    dst_path = args.dst_path
    recording_ids = args.recording_ids

    ##### End parameters #####

    for recording_id in recording_ids:
        download_data(tonic=tonic, recording_id=recording_id, dst_path=dst_path, str_filters=topics_to_copy, perform_download=True, max_workers=12)
