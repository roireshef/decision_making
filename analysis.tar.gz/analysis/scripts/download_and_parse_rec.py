import argparse
import glob
import json
import os
import shutil
import subprocess
from functools import partial
from typing import Dict
import multiprocessing as mp

import yaml
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.scripts.da_vinci_download import download_data
from subdivision_learning.analysis.scripts.parse_image_data import parse_images
from subdivision_learning.analysis.scripts.run_maps_validation import validate_map_attributes_recording

"""
This script unifies all download and parsing done on recorded data to ease up handling of it before analysis.
It performs the following tasks:
1. Download data from DaVinci (configurable if camera images are required)
2. Parses image data if required and delete pubsub image data
3. Parse and create caches for data so analysis tools can be loaded quickly
4. Copy data to a specified location (e.g. network drive) if required
"""


def download_all_recordings(cfg: Dict, queue: mp.Queue):

    for recording_params in cfg['recording_params']:
        print(f"Downloading {recording_params['recording_id']}")
        str_filters = cfg["str_download_filters"]

        if recording_params["download_and_parse_images"]:
            str_filters.extend(cfg["image_str_filters"])

        # Download recording
        recording_dir = download_data(tonic=cfg['tonic'],
                                      recording_id=recording_params["recording_id"],
                                      dst_path=cfg['dst_path'],
                                      str_filters=str_filters,
                                      perform_download=recording_params["perform_download"],
                                      max_workers=cfg['max_workers'])
        print(f"Finished downloading {recording_params['recording_id']}")

        queue.put((recording_params, recording_dir))
    queue.put((None, None))
    queue.close()
    queue.join_thread()


def parse_all_recordings(cfg: Dict, queue: mp.Queue):
    while True:
        recording_params, recording_dir = queue.get()
        if recording_params is None:
            break
        if recording_params["download_and_parse_images"]:
            print("Parsing images")
            if not parse_images(base_path=recording_dir):
                print("Images not found")
                return
            print("Done")

            print("Deleting pubsub data")
            for image_str_filter in cfg["image_str_filters"]:
                file_list = glob.glob(os.path.join(recording_dir, "recordings", image_str_filter + "*"))
                for f in file_list:
                    os.remove(f)
            print("Done")

        if recording_params["fix_corrupted"]:
            print("Validating pubsub")
            pubsub_validator_path = os.path.join(recording_dir, 'bin', 'PubSubValidator')
            subprocess.call(['chmod', '+x', pubsub_validator_path])
            subprocess.run([pubsub_validator_path, recording_dir])
            print("Done")

        if recording_params["generate_caches"]:
            print("Generating caches")
            master_parser = PubSubRecordingMasterParser(base_recording_path=recording_dir,
                                                        relative_start_time=1.,
                                                        duration=1e30)

            perceived_lanes_data_loader = master_parser.get_data_loader(domain="UC_SYSTEM",
                                                                        topic="PERCEIVED_ROAD_GEOMETRY",
                                                                        is_quick_parse=True)
            perceived_objects_data_loader = master_parser.get_data_loader(domain="UC_SYSTEM",
                                                                          topic="PERCEIVED_OBJECT_DATA",
                                                                          is_quick_parse=True)
            hsp_data_loader = master_parser.get_data_loader(domain="UC_SYSTEM", topic="HOST_SEMANTIC_POSE")

            canonic_sequence_parser = master_parser.canonic_sequence_parser
            print("Done")

        if cfg['maps_validation']['is_run']:
            maps_validation_cfg = cfg['maps_validation']
            report = validate_map_attributes_recording(path=recording_dir,
                                                     is_aggregated=maps_validation_cfg['is_aggregated'],
                                                     mnp_mode=maps_validation_cfg['mnp_mode'],
                                                     min_frame=maps_validation_cfg['min_frame'],
                                                     max_frame=maps_validation_cfg['max_frame'])
            with open(os.path.join(recording_dir, "maps_validation_report.json"), 'w') as f:
                json.dump(report, f)

        if cfg["post_parsing_dir"] != "None":
            rel_path = os.path.relpath(recording_dir, cfg['dst_path'])
            dst_folder = os.path.join(cfg['post_parsing_dir'], rel_path)
            if not os.path.isdir(dst_folder):
                print(f"Copying data to {dst_folder}")
                subprocess.call(['chmod', '-R', '777', recording_dir])
                shutil.copytree(recording_dir, dst_folder)
                subprocess.call(['chmod', '-R', '777', dst_folder])
                print("Done")
            else:
                print(f"Folder exists, skipping copy - {dst_folder}")


def main(cfg: Dict):
    queue = mp.Queue()

    proc1 = mp.Process(target=partial(download_all_recordings, cfg, queue))
    proc1.start()

    proc2 = mp.Process(target=partial(parse_all_recordings, cfg, queue))
    proc2.start()

    proc1.join()
    proc2.join()


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Data downloader')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/downloader_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    main(cfg)

