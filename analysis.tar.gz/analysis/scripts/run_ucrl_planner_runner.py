import argparse
import os
import timeit
from logging import Logger

import matplotlib.pyplot as plt
import yaml
from rte.python.logger.log_utils import LOG_DIRECTORY
from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.scripts.show_summary_plots import generate_plot
from subdivision_planner.src.common.recorder import DummyRecorder, Recorder
from subdivision_planner.src.config.lane_merge_agent_config import RIGHT_LANE_MREGE_ENV_PARAMS
from subdivision_planner.src.data_structures.canonic_action import CanonicAction
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.lba_main import ModuleInitialization, POLICY_CHECKPOINT
from subdivision_planner.src.utils.algo_timer import AlgoTimer
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.src.utils.recording_parser import RecordingParser


class PlannerRunner:
    """
    This class runs the planner with the correct mocks and data such that it will run exactly the same as in the
    recording
    """
    def __init__(self,
                 logger: Logger,
                 parser: ICanonicSequenceParser,
                 recording_parser: RecordingParser,
                 use_recorder: bool = False):
        """
        ctr
        :param logger: logger
        :param parser: parser that is used to read frames to be reproduced by planner
        :param use_recorder: if True, use the old planner recorder (e.g. for streamlit)
        """
        if use_recorder:
            planner_recorder = Recorder(output_dir=os.path.join(recording_parser.output_dir, 'planner_runner'),
                                        batch_size=1)
        else:
            planner_recorder = DummyRecorder()

        from subdivision_planner.src.config.lane_merge_agent_config import LEFT_LANE_MREGE_ENV_PARAMS, MODEL_CFG

        self._planners = {
            "ModelFreePlannerForLeftLaneMerge": ModuleInitialization.create_model_free_planner(
                name="ModelFreePlannerForLeftLaneMerge",
                logger=logger,
                planner_recorder=planner_recorder,
                agent_config=LEFT_LANE_MREGE_ENV_PARAMS,
                model_config=MODEL_CFG,
                policy_path=POLICY_CHECKPOINT
            ),
            "ModelFreePlannerForRightLaneMerge": ModuleInitialization.create_model_free_planner(
                name="ModelFreePlannerForRightLaneMerge",
                logger=logger,
                planner_recorder=planner_recorder,
                agent_config=RIGHT_LANE_MREGE_ENV_PARAMS,
                model_config=MODEL_CFG,
                policy_path=POLICY_CHECKPOINT
            ),
        }

        self.parser = parser
        self.recording_parser = recording_parser

    def plan(self, frame: int) -> CanonicAction:
        """
        Perform the actual planning in a specific frame
        :param frame:
        :return: canonic action
        """
        # Read the correct frame from the parser
        canonic_frame = self.parser[frame]
        canonic_state, planner_internal_state, canonic_action, execution_info = \
            canonic_frame.state, canonic_frame.internal_state, canonic_frame.action, canonic_frame.execution_info

        recorder_frame = self.recording_parser.get_by_frame_id(frame)

        if not canonic_state:
            raise ValueError(f"Missing canonic state for frame {frame}")
        if not planner_internal_state:
            raise ValueError(f"Missing planner internal state for frame {frame}")
        if not execution_info:
            raise ValueError(f"Missing planner execution info for frame {frame}")

        planner_name = recorder_frame['PlanningModule']['planner']['active_planner']
        planner = self._planners[str(planner_name)]

        # Set the state of the planner and all its internals (from recordings also)
        planner.set_state(planner_internal_state=planner_internal_state, map=canonic_state.map)
        planner.set_state_from_recorder(recorder_frame=recorder_frame[planner_name])

        # Perform the planning
        planner.init_frame(canonic_state)
        canonic_action_result = planner.plan(canonic_state)

        return canonic_action_result


def main(cfg: dict):
    logger = get_logger()

    # load pubsub messages
    master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["path"])

    existing_frames = master_parser.canonic_sequence_parser.get_frame_ids()
    frame_ids = range(max(cfg["start_frame_id"], existing_frames[0]),
                      min(cfg["end_frame_id"], existing_frames[-1]) + 1)

    # Find missing frames in canonic sequence parser
    missing_frames = [frame_id
                      for frame_id in frame_ids
                      if frame_id not in existing_frames]
    assert len(missing_frames) == 0, f"Missing frames in canonic sequence, {missing_frames},\n existing from {min(existing_frames)} to {max(existing_frames)}"

    # load recorder messages
    # default_base_log_dir = LOG_DIRECTORY
    default_base_log_dir = os.path.expanduser("~/projects/uc_workspace/ultracruise/build/python/logs")  # LOG_DIRECTORY
    recorder_path = cfg["recorder_path"] or os.path.join(default_base_log_dir, 'sd_recorded_data', cfg["path"].split('/')[-1])
    recording_parser = RecordingParser(output_dir=recorder_path)

    planner_runner = PlannerRunner(logger=logger, parser=master_parser.canonic_sequence_parser,
                                   recording_parser=recording_parser)

    canonic_sequence = []

    # run planner
    for frame_id in frame_ids:
        print("frame id", frame_id)
        original_frame = master_parser.canonic_sequence_parser[frame_id]
        new_frame = CanonicFrame(state=original_frame.state,
                                 action=None,
                                 internal_state=original_frame.internal_state,
                                 execution_info=original_frame.execution_info)

        # # for debugging map_attributes message (ofek map fix)
        # from subdivision_planner.src.messages.map_attributes_message import MapAttributes
        # from subdivision_planner.src.map.map_provider import MapProvider
        # map_data_loader = master_parser._pubsub_data_loaders[("UC_SYSTEM", "MAP_ATTRIBUTES")]
        # fixed_map_attributes = MapAttributes.deserialize(list(map_data_loader._messages_dict.values())[0])

        try:
            st = timeit.default_timer()
            action_result = planner_runner.plan(frame_id)
            print('planner_runner.plan took %f secs' % (timeit.default_timer() - st))
            print(action_result.driving_plan if action_result.driving_plan is not None else "planner produced no action")
            new_frame.action = action_result
        except Exception:
            logger.exception(f"Exception when running frame {frame_id}")
        finally:
            logger.debug(str(AlgoTimer()))
            AlgoTimer().reset()

        canonic_sequence.append(new_frame)

    # generate plots
    if cfg["show_summary_plots"]:
        for figure_cfg in cfg["figures"]:
            recorder_frames = {frame: contents[contents['PlanningModule']['planner']['active_planner']]
                               for frame, contents in planner_runner.recording_parser.get_frames_iter()
                               if frame in set(frame_ids)}
            generate_plot(figure_cfg, canonic_sequence=canonic_sequence, master_parser=master_parser,
                          record_data=recorder_frames)

        plt.show(block=True)


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Planner runner')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/planner_runner_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    main(cfg)
