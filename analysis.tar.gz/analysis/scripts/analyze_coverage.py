import argparse
import traceback

import matplotlib.pyplot as plt
import numpy as np
import os
import pickle
from os import getenv

import yaml
from colorama import Fore
from matplotlib.offsetbox import AnchoredText
from subdivision_learning.utils.planner import plan_exists

from tqdm import tqdm
from typing import Dict, List, NamedTuple, Optional, Tuple, Callable, Union

from subdivision_learning.analysis.utils.utils import TimestampFrameIdConverter
from subdivision_planner.src.common.exceptions import OutOfSegmentFront
from subdivision_planner.src.common import types
from rte.python.logger.log_utils import LOG_DIRECTORY
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
from subdivision_learning.analysis.utils.searcher_mock import SearcherMock
from subdivision_learning.analysis.utils.search_tree import traverse_tree
from subdivision_learning.analysis.scripts.show_summary_plots import generate_plot
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.recorder import DummyRecorder
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.data_structures.canonic_state import CanonicState
from subdivision_planner.src.mcts.searcher import Searcher
from subdivision_planner.src.mcts.uct_node import UCTNode
from subdivision_planner.src.mdp.determinizer import Determinizer
from subdivision_planner.src.mdp.iaction import IMDPAction
from subdivision_planner.src.mdp.iaction_spec import IMDPActionSpec
from subdivision_planner.src.mdp.mdp_node import MDPNode
from subdivision_planner.src.mdp.state import MDPContext, MDPState
from subdivision_planner.src.mdp.werling.action_spec import GeneratedWerlingActionSpec, WerlingMDPActionSpec
from subdivision_planner.src.mdp.werling.action_type import LongitudinalComponentType, LateralComponentType
from subdivision_planner.src.mdp.werling.aggregate_action_validators import AggregateWerlingActionValidator, \
    AggregateWerlingComponentValidator
from subdivision_planner.src.mdp.werling.component_spec import WerlingComponentSpec
from subdivision_planner.src.mdp.werling.debug_probe import ActionDebugProbe, ActionValidityCheck, ComponentDebugProbe,\
    ComponentValidityCheck
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.src.utils.recording_parser import RecordingParser
from subdivision_planner.test.utils.dummy_action import get_dummy_action

DEFAULT_CONFIG_PATH = 'config/analyze_coverage_cfg.yml'


class InvalidReasons:
    def __init__(self, invalid_action_reasons: Optional[List[str]] = None, invalid_state_reason: Optional[str] = None):
        self.invalid_action_reasons = invalid_action_reasons or []
        self.invalid_state_reason = invalid_state_reason

    def is_empty(self) -> bool:
        return not self.invalid_action_reasons and self.invalid_state_reason is None


class FrameData(NamedTuple):
    time: float
    is_engaged: bool
    is_engagement_possible: Optional[bool]
    invalid_reasons: Optional[InvalidReasons]
    validity_status: Optional[str]
    exception: Optional[str]


class DisengagedPeriod(NamedTuple):
    start: float
    end: float


def get_action_spec_trials(action_spec: IMDPActionSpec) -> Tuple[Optional[List[ComponentValidityCheck]],
                                                                 Optional[List[ComponentValidityCheck]],
                                                                 Optional[List[ActionValidityCheck]]]:
    """
    Get validator results after components and actions have been reset and revaldiated
    :param action_spec:
    :return: longitudinal_trials, lateral_trials, action_trials
             Returns None, None, None if action revalidation fails
    """
    assert isinstance(action_spec, (WerlingMDPActionSpec, GeneratedWerlingActionSpec))

    # set debug probes and call necessary reset methods
    longitudinal_component_debug_probe = ComponentDebugProbe()
    longitudinal_component_validator = action_spec.longitudinal_component_spec.validator
    assert isinstance(longitudinal_component_validator, AggregateWerlingComponentValidator)
    longitudinal_component_validator.set_debug_probe(longitudinal_component_debug_probe)
    action_spec.longitudinal_component_spec.reset(validator=longitudinal_component_validator)
    longitudinal_component_trials = longitudinal_component_debug_probe.trials

    lateral_component_debug_probe = ComponentDebugProbe()
    lateral_component_validator = action_spec.lateral_component_spec.validator
    assert isinstance(lateral_component_validator, AggregateWerlingComponentValidator)
    lateral_component_validator.set_debug_probe(lateral_component_debug_probe)
    action_spec.lateral_component_spec.reset(validator=lateral_component_validator)
    lateral_component_trials = lateral_component_debug_probe.trials

    action_debug_probe = ActionDebugProbe()
    action_validator = action_spec.validator
    assert isinstance(action_validator, AggregateWerlingActionValidator)
    action_validator.set_debug_probe(debug_probe=action_debug_probe)
    action_spec.reset(validator=action_validator)
    action_trials = action_debug_probe.trials

    # call action spec action property so that the components and action are revalidated
    try:
        _ = action_spec.action
    except Exception as e:
        traceback.print_exc()
        return None, None, None

    return longitudinal_component_trials, lateral_component_trials, action_trials


def determine_action_spec_failure_reason(action_spec: IMDPActionSpec) -> str:

    longitudinal_component_trials, lateral_component_trials, action_trials = get_action_spec_trials(action_spec)

    if longitudinal_component_trials is None and lateral_component_trials is None and action_trials is None:
        return 'ErrorOccurredWhileRevalidatingAction'

    # return failure reason if one is recorded in the trials
    for component_trials in [longitudinal_component_trials, lateral_component_trials]:
        if component_trials:
            relevant_goal_check = component_trials[-1].goal_checks[-1]
            if not relevant_goal_check.result:
                return relevant_goal_check.validator.__class__.__name__ + ": " + relevant_goal_check.failure_mode

            # If the motion_plan_checks list is empty but the goal_checks list is not, that means we exited in between calling
            # is_goal_state_valid and is_valid. Return a corresponding failure reason.
            if component_trials[-1].motion_plan_checks:
                relevant_motion_plan_check = component_trials[-1].motion_plan_checks[-1]
            else:
                return 'ComponentIsValidNotRun'

            if not relevant_motion_plan_check.result:
                return relevant_motion_plan_check.validator.__class__.__name__ + ": " + relevant_motion_plan_check.failure_mode

    if action_trials:
        relevant_validity_check = action_trials[-1].validity_checks[-1]
        if not relevant_validity_check.result:
            return relevant_validity_check.validator.__class__.__name__ + ": " + relevant_validity_check.failure_mode

    # determine failure reason based on one not being recorded in trials
    if isinstance(action_spec, WerlingMDPActionSpec):
        if not longitudinal_component_trials and isinstance(action_spec.longitudinal_component_spec, WerlingComponentSpec):
            return 'WerlingLongitudinalComponentValidatorsNotRun'   # as opposed to 'GeneratedLongitudinalComponentValidatorsNotRun'
        elif not action_trials:
            return 'NoActionGeneratedFromValidComponents'

    # If we reach here, an action spec is valid even though all action specs are supposed to be invalid. This can happen when a valid
    # action can be found from the root node but it leads to a node where all actions are invalid. During a search, this is accounted for
    # during backup, and the action spec will be invalidated at the root node. However, when we're validating action specs here, we are
    # not doing this.
    return 'RevalidatedActionSpecIsValid'


def determine_state_failure_reason(node: MDPNode, action_trials: List[ActionValidityCheck]) -> str:
    # return if no action specs were actually generated
    if node.is_action_specs_generated and not node.action_specs:
        return 'NoActionSpecsGenerated'

    # return failure reason if one is recorded in the trials
    if action_trials:
        relevant_validity_check = action_trials[-1].validity_checks[-1]
        if not relevant_validity_check.result:
            return relevant_validity_check.validator.__class__.__name__ + ": " + relevant_validity_check.failure_mode
    else:
        # If the list is empty, the validators were not run.
        return 'ValidatorsNotRun'

    # We shouldn't reach here. If this is seen, investigate and add more reasons above.
    return 'StateIsValid'


def is_state_valid(cfg, node: MDPNode, action_validator: AggregateWerlingActionValidator, action_debug_probe: ActionDebugProbe) -> bool:
    # first, check if any action specs were actually generated
    if node.is_action_specs_generated and not node.action_specs:
        return False

    # second, determine states validity based on dummy action
    action_validator.set_debug_probe(debug_probe=action_debug_probe)
    action = get_dummy_action(node.state, cfg["dummy_action_duration"], cfg["dummy_action_interval"])

    return action_validator.is_valid(state=node.state, action=action, revalidate=False).is_valid


def is_engagement_possible(state: MDPState) -> bool:
    # If our lane is not in the map, we should not be engaged.
    # TODO: This is incorrect. It could have existed in the map in the original run even if it isn't in the offline runner map
    try:
        lane_segment = MDPContext().map.get_lane_segment_by_id(state.lane_id)
    except KeyError:
        return False

    # check whether we're on a nondrivable lane
    if not lane_segment.is_drivable:
        return False

    # check whether we're too close to the end of our GFF
    stop_dist = (state.frenet_state[types.FS_SV] ** 2) / (-2. * Config().driving.nominal_deceleration)

    if (state.frenet_state[types.FS_SX] + stop_dist) >= state.gff.s_max - Config().ego.size[0] / 2.:
        return False

    # If we reach here, engaging should be possible.
    return True


def determine_failure_reason(cfg, node: MDPNode, action_validator: AggregateWerlingActionValidator,
                             is_action_spec_relevant: Callable[[IMDPActionSpec], bool] = None) -> InvalidReasons:
    action_debug_probe = ActionDebugProbe()
    invalid_reasons = InvalidReasons()

    # If state is invalid, determine why.
    try:
        if not is_state_valid(cfg, node, action_validator, action_debug_probe):
            invalid_reasons.invalid_state_reason = determine_state_failure_reason(node, action_debug_probe.trials)
    except OutOfSegmentFront:
        # We're catching this exception and proceeding because we shouldn't get this here. If we do, the validators are
        # likely not the reason that all actions are invalid.
        pass

    # If action specs are invalid, determine why.
    for i, action_spec in enumerate(node.action_specs):
        if not action_spec.is_action_valid:
            assert isinstance(action_spec, (GeneratedWerlingActionSpec, WerlingMDPActionSpec))
            invalid_reasons.invalid_action_reasons.append(determine_action_spec_failure_reason(action_spec))

    return invalid_reasons


def main(cfg):
    # a list of tuples where the first element is the searcher name and the second element is the parser
    searcher_parsers: List[Tuple[str, RecordingParser]] = []

    # a dictionary where the keys are the searcher names and the values are dictionaries where the keys are the frame IDs where failures
    # occurred and the values are InvalidReasons class instances holding the reasons why the state and action specs are invalid
    analysis_data: Dict[str, Dict[int, InvalidReasons]] = {}

    if cfg["analyze_deep_searcher_recording"] or cfg["analyze_shallow_searcher_recording"]:
        planner_directory = os.path.join(cfg["sd_recorded_data_directory"], 'planner')
        try:
            planner_parser = RecordingParser(output_dir=planner_directory)
        except FileNotFoundError:
            print(f"{Fore.RED}ERROR{Fore.RESET}: Either the {planner_directory} directory does not exist or it is empty.")

    if cfg["analyze_deep_searcher_recording"]:
        deep_searcher_directory = os.path.join(cfg["sd_recorded_data_directory"], 'deep_searcher')
        try:
            searcher_parsers.append(('deep_searcher', RecordingParser(output_dir=deep_searcher_directory)))
            analysis_data['deep_searcher'] = {}
        except FileNotFoundError:
            print(f"{Fore.RED}ERROR{Fore.RESET}: Either the {deep_searcher_directory} directory does not exist or it is empty.")

    if cfg["analyze_shallow_searcher_recording"]:
        shallow_searcher_directory = os.path.join(cfg["sd_recorded_data_directory"], 'shallow_searcher')
        try:
            searcher_parsers.append(('shallow_searcher', RecordingParser(output_dir=shallow_searcher_directory)))
            analysis_data['shallow_searcher'] = {}
        except FileNotFoundError:
            print(f"{Fore.RED}ERROR{Fore.RESET}: Either the {shallow_searcher_directory} directory does not exist or it is empty.")

    action_validator = Searcher.create_action_validator()
    assert isinstance(action_validator, AggregateWerlingActionValidator)

    num_frames = 0
    time_based_data: List[FrameData] = []

    # =============================================================================================
    # collect data

    # statistics plot
    for searcher_name, searcher_parser in searcher_parsers:
        existing_frames = searcher_parser.get_frames_id_list()
        frame_ids = range(cfg["start_frame_id"] or min(existing_frames), 1 + (cfg["end_frame_id"] or max(existing_frames)))

        # Find missing frames in canonic sequence parser
        missing_frames = [frame_id
                          for frame_id in frame_ids
                          if frame_id not in existing_frames]
        assert len(missing_frames) == 0, f"Missing frames in recording, {missing_frames},\n existing from {min(existing_frames)} to {max(existing_frames)}"

        for frame_id in frame_ids:
            num_frames += 1

            try:
                planner_frame_data = planner_parser.get_by_frame_id(frame_id)
                planner_frame_data = planner_frame_data.get('PlanningModule', planner_frame_data.get('SubdivisionBTPlanner'))
                canonic_state: CanonicState = planner_frame_data['state']
                is_engaged = canonic_state.is_ttc_engaged
            except IndexError:
                is_engaged = True
                print(f"{Fore.LIGHTYELLOW_EX}WARNING{Fore.RESET}: Frame ID {frame_id} was not found in the recorded planner data so we "
                      f"cannot check whether the system was engaged. We are relying on the is_engagement_possible method for this frame.")

            searcher_frame_data = searcher_parser.get_by_frame_id(frame_id)['Searcher']
            root_node: UCTNode = searcher_frame_data['root_node']
            context: MDPContext = searcher_frame_data['context']

            MDPContext().from_other(context)

            # filter states as desired
            if ((cfg["filter_disengaged_states"] and not is_engaged)
                    or (cfg["filter_states_where_engaging_should_not_be_possible"] and not is_engagement_possible(root_node.mdp_node.state))):
                continue

            # If all actions are invalid, determine why.
            if root_node.mdp_node.is_all_actions_invalid:
                invalid_reasons = determine_failure_reason(cfg, root_node.mdp_node, action_validator)

                if invalid_reasons.is_empty():
                    print(f"{Fore.RED}ERROR{Fore.RESET}: In the {searcher_name}'s frame {frame_id}, something is wrong. All actions were "
                          f"recorded as invalid, but the state is valid and no invalid action specs were found. This frame should be "
                          f"investigated, and a new failure reason should be defined and added.")
                    continue

                analysis_data[searcher_name][frame_id] = invalid_reasons

    canonic_sequence = []

    # time plot
    if cfg["produce_time_based_plot"]:
        if not cfg["pubsub_data_directory"]:
            print(f"{Fore.LIGHTYELLOW_EX}WARNING{Fore.RESET}: The pubsub data directory was not provided so a time-based plot will not be "
                  f"produced.")
        else:
            logger = get_logger()

            deep_searcher = SearcherMock(recorder=DummyRecorder(), logger=logger, name="DeepSearcherMock")
            shallow_searcher = SearcherMock(recorder=DummyRecorder(), logger=logger, name="ShallowSearcherMock")

            master_parser = PubSubRecordingMasterParser(base_recording_path=cfg["pubsub_data_directory"])
            parser = master_parser.canonic_sequence_parser

            planner_runner = PlannerRunner(logger=logger,
                                           parser=parser,
                                           deep_searcher_mock=deep_searcher,
                                           shallow_searcher_mock=shallow_searcher)

            # Find missing frames in canonic sequence parser
            existing_frames = parser.get_frame_ids()
            start_frame_id = cfg["start_frame_id"] or 0
            end_frame_id = cfg["end_frame_id"] or existing_frames[-1]
            frame_ids = [frame_id for frame_id in existing_frames if start_frame_id <= frame_id <= end_frame_id]
            print(f"Found {len(existing_frames)} frames in canonic sequence from {existing_frames[0]} to {existing_frames[-1]}")
            assert len(frame_ids) > 0, "No frames found"
            print(f"Parsing {len(frame_ids)} frames")

            num_frames = 0
            for frame_id in tqdm(frame_ids, desc="Evaluating states"):
                num_frames += 1
                # If there is an error while parsing frame data, continue to the next frame.
                try:
                    canonic_state = parser[frame_id].state
                    planner_internal_state = parser[frame_id].internal_state
                    execution_info = parser[frame_id].execution_info
                except Exception as inst:
                    print(f"\n{Fore.RED}{inst.__class__.__name__}{Fore.RESET}: While parsing data for frame {frame_id}, got the following "
                          f"error: {inst}\n")
                    traceback.print_exc()
                    continue

                # If we don't have input data for this frame, we need to continue to the next frame because we do not have sufficient
                # information.
                if canonic_state is None or planner_internal_state is None or execution_info is None:
                    print(f"\n{Fore.RED}ERROR{Fore.RESET}: Missing input data in frame {frame_id}.\n")
                    continue

                if cfg["analyze_previous_driving_plan"]:
                    canonic_sequence.append(parser[frame_id])

                if cfg["filter_disengaged_states"] and not canonic_state.is_ttc_engaged:
                    continue

                if cfg["analyze_previous_driving_plan"]:
                    if not planner_internal_state.s_Data.e_b_IsDrivingPlanInvalid:
                        continue
                    if planner_internal_state.s_Data.e_b_IsReplan:
                        continue

                    try:
                        planner_runner._planner.set_state(planner_internal_state, canonic_state.map)
                        determinized_state, root_mdp_state, planner_params = planner_runner._planner._pre_plan(canonic_state)
                    except Exception as inst:
                        print(f"\n{Fore.RED}{inst.__class__.__name__}{Fore.RESET}: Got the following error in frame {frame_id}: {inst}\n")
                        traceback.print_exc()
                        time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                         is_engaged=canonic_state.is_ttc_engaged,
                                                         is_engagement_possible=None,   # None because can't determine without root node
                                                         invalid_reasons=None,
                                                         exception=inst.__class__.__name__))
                        continue

                    failure_modes = planner_runner._planner._dp_validation.get_driving_plan_failure_modes(
                        planner_runner._planner.driving_plan, root_mdp_state, revalidate=True)

                    failure_getters = (
                        lambda failure: failure.longitudinal_component_failure_modes.is_goal_state_valid_failure_modes,
                        lambda failure: failure.longitudinal_component_failure_modes.is_valid_failure_modes,
                        lambda failure: failure.lateral_component_failure_modes.is_goal_state_valid_failure_modes,
                        lambda failure: failure.lateral_component_failure_modes.is_valid_failure_modes,
                        lambda failure: failure.is_valid_failure_modes,
                    )
                    invalid_reasons = [
                        getter(failure)[0].failure_mode for failure in failure_modes
                        for getter in failure_getters if getter(failure) and not getter(failure)[0].is_valid
                    ]

                    print("InvalidReasons", frame_id, list(set(invalid_reasons)))
                    if len(invalid_reasons) == 0:
                        if planner_internal_state.s_Data.e_b_IsDrivingPlanInvalid:
                            print(f"{Fore.RED}ERROR{Fore.RESET}: In the pubsub frame {frame_id}, something is wrong. "
                                  f"Previous driving plan was recorded as invalid, but no failure modes were found. "
                              f"This frame should be investigated.")
                        invalid_reasons = None
                    else:
                        if cfg['show_all_failure_modes']:
                            invalid_reasons = InvalidReasons(invalid_reasons)
                        else:
                            invalid_reasons = InvalidReasons([invalid_reasons[0]])

                    time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                     is_engaged=canonic_state.is_ttc_engaged,
                                                     is_engagement_possible=is_engagement_possible(root_mdp_state),
                                                     invalid_reasons=invalid_reasons,
                                                     validity_status=None,
                                                     exception=None))
                else:
                    # run plan so the MDP context and root node are set
                    try:
                        canonic_action = planner_runner.plan(frame=frame_id, skip_deep_search=False, set_iterations=cfg['set_iterations'])
                        execution_info = planner_runner._planner.get_execution_info()
                        canonic_sequence.append(CanonicFrame(canonic_state, canonic_action, planner_runner._planner.get_state(), execution_info))
                    except Exception as inst:
                        print(f"\n{Fore.RED}{inst.__class__.__name__}{Fore.RESET}: Got the following error in frame {frame_id}: {inst}\n")
                        traceback.print_exc()
                        time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                         is_engaged=canonic_state.is_ttc_engaged,
                                                         is_engagement_possible=None,   # None because can't determine without root node
                                                         invalid_reasons=None,
                                                         validity_status=None,
                                                         exception=inst.__class__.__name__))
                        continue

                    # If a shallow search was initiated in this frame, we get the root node from there. If a shallow search wasn't initiated
                    # and a deep search finished, we get the root node from the deep searcher. We're looking for a finished deep search
                    # because that means a another deep search was triggered on this iteration (per the PlannerRunner setup). Since the deep
                    # searcher is synchronous here, the search was run with the current MDP state, and we can access the root node at the end
                    # of the search. If neither of these scenarios occur, we do not have a root node to investigate so we continue to the
                    # next frame.
                    if execution_info.s_Data.e_b_IsShallowSearchInitiated:
                        relevant_searcher = shallow_searcher
                    elif execution_info.s_Data.e_b_IsDeepSearchFinished:
                        relevant_searcher = deep_searcher
                    else:
                        print(f"No search in frame {frame_id}")
                        time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                         is_engaged=canonic_state.is_ttc_engaged,
                                                         is_engagement_possible=None,
                                                         invalid_reasons=None,
                                                         validity_status='SearchNotRun',
                                                         exception=None))
                        continue
                    if relevant_searcher.uct.root is None:
                        print(f"No search in frame {frame_id}")
                        time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                         is_engaged=canonic_state.is_ttc_engaged,
                                                         is_engagement_possible=None,
                                                         invalid_reasons=None,
                                                         validity_status='SearchNotRun',
                                                         exception=None))
                        continue
                    root_mdp_node = relevant_searcher.uct.root.mdp_node
                    root_mdp_state = root_mdp_node.state

                    engagement_possible = is_engagement_possible(root_mdp_state)
                    if cfg["analyze_specific_action_type"] and not root_mdp_node.is_all_actions_invalid and plan_exists(canonic_action):
                        def is_action_spec_relevant(action: Union[IMDPActionSpec, IMDPAction]):
                            return cfg['relevant_action_type_lon'] in (None, action.action_type.longitudinal.name) \
                                and cfg['relevant_action_type_lat'] in (None, action.action_type.lateral.name)

                        if any(is_action_spec_relevant(action) for action in canonic_action.driving_plan.actions):
                            time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                             is_engaged=canonic_state.is_ttc_engaged,
                                                             is_engagement_possible=engagement_possible,
                                                             invalid_reasons=None,
                                                             validity_status='RelevantActionInBestExperience',
                                                             exception=None))
                        else:
                            any_valid_relevant_exp = False
                            has_relevant_ancestor = {}
                            any_node_relevant = False
                            is_trajectory_too_short = False
                            try:
                                tree_analysis_data = []
                                det_start_time = Determinizer.determinize_time(time=relevant_searcher.uct.root.mdp_node.state.timestamp)
                                for tree_node in traverse_tree(root_node=relevant_searcher.uct.root, explore_invalid=True, explore_non_generated=True):
                                    tmp_node = tree_node
                                    has_relevant_ancestor[tree_node.curr_node_id] = \
                                        has_relevant_ancestor.get(tree_node.parent_node_id) or \
                                        tmp_node.action_spec is not None and is_action_spec_relevant(tmp_node.action_spec)

                                    if not has_relevant_ancestor[tree_node.curr_node_id]:
                                        continue
                                    any_node_relevant = True

                                    if tree_node.curr_node is None:
                                        # Leaf node
                                        if tree_node.action_spec.is_action_valid:
                                            any_valid_relevant_exp = True
                                            is_trajectory_too_short = not Searcher.is_experience_duration_adequate(
                                                start_time=det_start_time,
                                                end_time=tree_node.action_spec.action.end_time)
                                            if is_trajectory_too_short:
                                                continue

                                            # Found a valid experience that contains a relevant action. No need to look for any others
                                            break
                                        invalid_reasons = InvalidReasons(invalid_action_reasons=[determine_action_spec_failure_reason(tree_node.action_spec)])
                                    else:
                                        # Internal node
                                        invalid_reasons = determine_failure_reason(cfg, tree_node.curr_node.mdp_node,
                                                                                   action_validator, is_action_spec_relevant)
                                    if not invalid_reasons.is_empty():
                                        # Store invalid reasons separately from time_based_data, and decide whether to show it after traversing the entire tree
                                        tree_analysis_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                                            is_engaged=canonic_state.is_ttc_engaged,
                                                                            is_engagement_possible=engagement_possible,
                                                                            invalid_reasons=invalid_reasons,
                                                                            validity_status=None,
                                                                            exception=None))
                                if any_valid_relevant_exp:
                                    # There exists a valid experience that contains a relevant action type
                                    time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                                     is_engaged=canonic_state.is_ttc_engaged,
                                                                     is_engagement_possible=engagement_possible,
                                                                     invalid_reasons=None,
                                                                     validity_status='ExperienceTooShort' if is_trajectory_too_short else 'RelevantActionInTree',
                                                                     exception=None))
                                else:
                                    # All experiences containing relevant action types are invalid
                                    time_based_data.extend(tree_analysis_data)
                            except Exception as e:
                                traceback.print_exc()
                                continue
                            if not any_node_relevant:
                                # Tree does not contain any relevant action type
                                time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                                 is_engaged=canonic_state.is_ttc_engaged,
                                                                 is_engagement_possible=engagement_possible,
                                                                 invalid_reasons=None,
                                                                 validity_status='NoRelevantActionSpecsGenerated',
                                                                 exception=None))

                    else:  # Analyze no valid actions from root
                        # record frame data
                        if root_mdp_node.is_all_actions_invalid:
                            invalid_reasons = determine_failure_reason(cfg, root_mdp_node, action_validator)

                            if invalid_reasons.is_empty():
                                print(f"{Fore.RED}ERROR{Fore.RESET}: In the pubsub frame {frame_id}, something is wrong. All actions were "
                                      f"recorded as invalid, but the state is valid and no invalid action specs were found. This frame should "
                                      f"be investigated, and a new failure reason should be defined and added.")
                                invalid_reasons = None
                        else:
                            invalid_reasons = None

                        time_based_data.append(FrameData(time=canonic_state.timestamp_in_seconds,
                                                         is_engaged=canonic_state.is_ttc_engaged,
                                                         is_engagement_possible=engagement_possible,
                                                         invalid_reasons=invalid_reasons,
                                                         validity_status=None,
                                                         exception=None))

    print(f"Analyzed {num_frames} frames")
    # If no failure modes were recorded, print 100% coverage message and return.
    if all([not data for data in analysis_data.values()]) and not time_based_data:
        print(f"\n{Fore.GREEN}100% Coverage!{Fore.RESET}")
        return None

    # =============================================================================================
    # post process data for plotting

    # statistics plot
    num_invalid_action_frames = 0
    num_invalid_state_frames = 0
    invalid_action_summary: Dict[str, int] = {}
    invalid_state_summary: Dict[str, int] = {}

    all_invalid_reasons = ((frame_data.invalid_reasons for frame_data in time_based_data if frame_data.invalid_reasons) if time_based_data else
                      (frame_results for searcher_data in analysis_data.values() for frame_results in searcher_data.values()))
    for invalid_reasons in all_invalid_reasons:
        # If the state is invalid, record the reason and continue to the next frame. We do not want to record the action failure
        # reasons in this case.
        if invalid_reasons.invalid_state_reason is not None:
            num_invalid_state_frames += 1

            if invalid_reasons.invalid_state_reason in invalid_state_summary:
                invalid_state_summary[invalid_reasons.invalid_state_reason] += 1
            else:
                invalid_state_summary[invalid_reasons.invalid_state_reason] = 1

            # continue to distinguish between an invalid state and a valid state with all actions invalid
            continue

        # determine the most common failure among the action specs and record it
        num_invalid_action_frames += 1
        invalid_action_spec_reasons: Dict[str, int] = {}     # key: failure reason, value: number of occurrences

        for reason in invalid_reasons.invalid_action_reasons:
            if reason in invalid_action_spec_reasons:
                invalid_action_spec_reasons[reason] += 1
            else:
                invalid_action_spec_reasons[reason] = 1

        most_common_invalid_action_spec_reason = max([(k, v) for k, v in invalid_action_spec_reasons.items()], key=lambda x: x[1])[0]

        if most_common_invalid_action_spec_reason in invalid_action_summary:
            invalid_action_summary[most_common_invalid_action_spec_reason] += 1
        else:
            invalid_action_summary[most_common_invalid_action_spec_reason] = 1

    validity_status_summary: Dict[str, int] = {}
    all_validity_status = [frame_data.validity_status for frame_data in time_based_data if frame_data.validity_status] if time_based_data else []
    for validity_status in all_validity_status:
        if validity_status in validity_status_summary:
            validity_status_summary[validity_status] += 1
        else:
            validity_status_summary[validity_status] = 1

    # time plot
    start_time = None
    disengaged_period_start_time = None
    previous_time = None
    disengaged_periods: List[DisengagedPeriod] = []
    exception_times = []
    exception_values = []
    should_not_be_engaged_times = []
    should_not_be_engaged_values = []
    state_failure_reason_times = []
    state_failure_reason_values = []
    validity_status_times = []
    validity_status_values = []
    main_action_failure_reason_times = []
    main_action_failure_reason_values = []
    remaining_action_failure_reason_times = []
    remaining_action_failure_reason_values = []
    y_tick_labels: Dict[str, int] = {}  # key: failure reason, value: y value for plotting

    if cfg["produce_time_based_plot"] and time_based_data:
        for data in time_based_data:
            if start_time is None or data.time < start_time:
                start_time = data.time

            # record exception
            if data.exception is not None:
                if data.exception not in y_tick_labels:
                    y_tick_labels[data.exception] = len(y_tick_labels.keys())

                exception_times.append(data.time)
                exception_values.append(y_tick_labels[data.exception])

            if data.is_engaged:
                # If we're engaged but we shouldn't be, record it.
                if data.is_engagement_possible == False:    # checking False specifically is needed because this can be None
                    should_not_be_engaged_times.append(data.time)

                # If a disengaged period has ended, record it and reset the start time.
                if disengaged_period_start_time is not None:
                    disengaged_periods.append(DisengagedPeriod(disengaged_period_start_time, previous_time))
                    disengaged_period_start_time = None
            else:
                # If we're not engaged, check to see if this is the beginning of a new disengaged period.
                if disengaged_period_start_time is None:
                    disengaged_period_start_time = data.time

            # record the validity status
            if data.validity_status is not None:
                if data.validity_status not in y_tick_labels:
                    y_tick_labels[data.validity_status] = len(y_tick_labels.keys())

                validity_status_times.append(data.time)
                validity_status_values.append(y_tick_labels[data.validity_status])

            # record state or actions failure reason(s)
            if data.invalid_reasons is not None:
                # record the reason(s) and time the state is invalid or all actions are invalid
                if data.invalid_reasons.invalid_state_reason is not None:
                    if data.invalid_reasons.invalid_state_reason not in y_tick_labels:
                        y_tick_labels[data.invalid_reasons.invalid_state_reason] = len(y_tick_labels.keys())

                    state_failure_reason_times.append(data.time)
                    state_failure_reason_values.append(y_tick_labels[data.invalid_reasons.invalid_state_reason])
                else:
                    invalid_action_spec_reasons: Dict[str, int] = {}  # key: failure reason, value: number of occurrences

                    for reason in data.invalid_reasons.invalid_action_reasons:
                        if reason not in y_tick_labels:
                            y_tick_labels[reason] = len(y_tick_labels.keys())

                        if reason in invalid_action_spec_reasons:
                            invalid_action_spec_reasons[reason] += 1
                        else:
                            invalid_action_spec_reasons[reason] = 1

                    most_common_invalid_action_spec_reason = max([(k, v) for k, v in invalid_action_spec_reasons.items()],
                                                                 key=lambda x: x[1])[0]

                    main_action_failure_reason_times.append(data.time)
                    main_action_failure_reason_values.append(y_tick_labels[most_common_invalid_action_spec_reason])

                    for key, value in invalid_action_spec_reasons.items():
                        if key != most_common_invalid_action_spec_reason:
                            remaining_action_failure_reason_times.append(data.time)
                            remaining_action_failure_reason_values.append(y_tick_labels[key])

            # record previous time
            previous_time = data.time

        # add tick marks for when we shouldn't be engaged here so it's at the top of the plot
        if len(should_not_be_engaged_times) > 0:
            should_not_be_engaged_value = len(y_tick_labels.keys())
            y_tick_labels['ShouldNotBeEngaged'] = should_not_be_engaged_value
            should_not_be_engaged_values.extend([should_not_be_engaged_value for _ in range(len(should_not_be_engaged_times))])

        # If we remained disengaged until the end of the recording, we will not have a re-engagement that causes the disengaged period to
        # end and be stored. We account for this by storing such disengaged periods here.
        if disengaged_period_start_time is not None:
            disengaged_periods.append(DisengagedPeriod(disengaged_period_start_time, previous_time))

    # =============================================================================================
    # plot data

    # statistics plot
    if cfg["produce_statistics_plot"]:
        fig = plt.figure(1)
        fig.set_tight_layout(True)
        if cfg["maximize_window"]:
            fig_manager = plt.get_current_fig_manager()
            fig_manager.window.showMaximized()

        num_plots = bool(invalid_action_summary) + bool(invalid_state_summary) + bool(validity_status_summary)
        plot_i = 1
        # If action summary data is available, create plot; otherwise, print message so that it's known.
        if invalid_action_summary:
            plt.subplot(num_plots, 1, plot_i)
            plot_i += 1

            if cfg["analyze_previous_driving_plan"]:
                plt.title('Previous driving plan invalid')
            else:
                plt.title('Valid State, All Actions Invalid')
            plt.xlabel('Number of Occurrences')
            sorted_invalid_action_summary_keys, sorted_invalid_action_summary_values = \
                zip(*sorted([(k, v) for k, v in invalid_action_summary.items()], key=lambda x: x[1]))
            plt.barh(sorted_invalid_action_summary_keys, sorted_invalid_action_summary_values)
            for i, num in enumerate(sorted_invalid_action_summary_values):
                plt.text(num, i, f'{round(num / num_invalid_action_frames * 100, 1)}%')
            summary = f"# of states evaluated: {num_frames}\n" \
                      f"# of valid states w/ no valid actions: {num_invalid_action_frames} " \
                      f"({round(num_invalid_action_frames / num_frames * 100, 1)}%)"
            anchored_text = AnchoredText(summary, loc='lower right')
            plt.gca().add_artist(anchored_text)
        else:
            print(f"\n{Fore.GREEN}There are no occurrences of all actions being invalid due to the actions themselves and not the state."
                  f"{Fore.RESET}")

        # If state summary data is available, create plot; otherwise, print message so that it's known.
        if invalid_state_summary:
            plt.subplot(num_plots, 1, plot_i)
            plot_i += 1

            plt.title('Invalid State, All Actions Invalid')
            plt.xlabel('Number of Occurrences')
            sorted_invalid_state_summary_keys, sorted_invalid_state_summary_values = \
                zip(*sorted([(k, v) for k, v in invalid_state_summary.items()], key=lambda x: x[1]))
            plt.barh(sorted_invalid_state_summary_keys, sorted_invalid_state_summary_values)
            for i, num in enumerate(sorted_invalid_state_summary_values):
                plt.text(num, i, f'{round(num / num_invalid_state_frames * 100, 1)}%')
            summary = f"# of states evaluated: {num_frames}\n" \
                      f"# of invalid states w/ no valid actions: {num_invalid_state_frames} " \
                      f"({round(num_invalid_state_frames / num_frames * 100, 1)}%)"
            anchored_text = AnchoredText(summary, loc='lower right')
            plt.gca().add_artist(anchored_text)
        else:
            print(f"\n{Fore.GREEN}There are no occurrences of all actions being invalid due to an invalid state.{Fore.RESET}")

        # If validity status summary data is available, create plot; otherwise, print message so that it's known.
        if validity_status_summary:
            plt.subplot(num_plots, 1, plot_i)
            plot_i += 1

            plt.title('Validity statuses')
            plt.xlabel('Number of Occurrences')
            sorted_validity_status_keys, sorted_validity_status_values = \
                zip(*sorted([(k, v) for k, v in validity_status_summary.items()], key=lambda x: x[1]))
            plt.barh(sorted_validity_status_keys, sorted_validity_status_values)
            num_validity_status_frames = len(all_validity_status)
            for i, num in enumerate(sorted_validity_status_values):
                plt.text(num, i, f'{round(num / num_validity_status_frames * 100, 1)}%')
            summary = f"# of states evaluated: {num_frames}\n" \
                      f"# of states w/ any validity status: {num_validity_status_frames} " \
                      f"({round(num_validity_status_frames / num_frames * 100, 1)}%)"
            anchored_text = AnchoredText(summary, loc='lower right')
            plt.gca().add_artist(anchored_text)

        if cfg["pickle_figures"]:
            pickle.dump(fig, open(os.path.join(cfg["pubsub_data_directory"], 'coverage_statistics.pickle'), 'wb'))

    # time plot
    if cfg["produce_time_based_plot"]:
        fig = plt.figure(2)
        fig.set_tight_layout(True)
        if cfg["maximize_window"]:
            fig_manager = plt.get_current_fig_manager()
            fig_manager.window.showMaximized()
        timestamp2frame = TimestampFrameIdConverter(canonic_sequence, relative_time=False)

        for start, end in disengaged_periods:
            plt.axvspan(start - start_time, end - start_time, alpha=0.1, facecolor='red')

        plt.plot([time - start_time for time in exception_times], exception_values, 'rx')
        plt.plot([time - start_time for time in should_not_be_engaged_times], should_not_be_engaged_values, 'r.')
        plt.plot([time - start_time for time in state_failure_reason_times], state_failure_reason_values, 'g.')
        plt.plot([time - start_time for time in validity_status_times], validity_status_values, 'm.')
        plt.plot([time - start_time for time in main_action_failure_reason_times], main_action_failure_reason_values, 'b*')
        plt.plot([time - start_time for time in remaining_action_failure_reason_times], remaining_action_failure_reason_values, 'c.')
        plt.xlabel('Time [sec]')
        plt.yticks(np.arange(len(y_tick_labels)), y_tick_labels)
        plt.grid(True)

        if cfg["pickle_figures"]:
            pickle.dump(fig, open(os.path.join(cfg["pubsub_data_directory"], 'coverage_time_plot.pickle'), 'wb'))

        plt.gca().format_coord = lambda x, y: f"t={x:.3f}   y={y:.3f}  (frame={timestamp2frame.convert_to_frame_id(x+start_time)})"

    plt.show(block=False)

    if cfg["show_summary_plots"]:
        for figure_cfg in cfg["figures"]:
            generate_plot(figure_cfg, canonic_sequence=canonic_sequence, master_parser=master_parser)

    plt.show()

    return analysis_data or time_based_data


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Analyze Coverage')
    parser.add_argument('-cfg', help='path to the config file', type=str, default=DEFAULT_CONFIG_PATH)

    return parser.parse_args()


def load_config(path=DEFAULT_CONFIG_PATH):
    if os.path.isabs(path):
        full_path = path
    else:
        full_path = os.path.join(getenv('UC_WORKSPACE'), f"ultracruise/subdivision_learning/analysis/scripts/{path}")
    with open(full_path, 'r') as f:
        return yaml.load(f, Loader=yaml.FullLoader)


if __name__ == "__main__":

    args = parse_args()
    cfg = load_config(args.cfg)

    if not cfg["sd_recorded_data_directory"]:
        cfg["sd_recorded_data_directory"] = os.path.join(LOG_DIRECTORY, 'sd_recorded_data')

    assert 1 == (cfg["analyze_no_valid_actions"] +
                cfg["analyze_previous_driving_plan"] +
                cfg["analyze_specific_action_type"]), "Choose one analysis mode"

    assert cfg["relevant_action_type_lon"] in [None] + [x.name for x in LongitudinalComponentType], \
        f'relevant_action_type_lon: Invalid LongitudinalComponentType "{cfg["relevant_action_type_lon"]}"'
    assert cfg["relevant_action_type_lat"] in [None] + [x.name for x in LateralComponentType], \
        f'relevant_action_type_lat: Invalid LateralComponentType "{cfg["relevant_action_type_lat"]}"'
    assert not cfg["analyze_specific_action_type"] or cfg["relevant_action_type_lon"] is not None or cfg["relevant_action_type_lat"] is not None, \
        f'Pick longitudinal and/or lateral component type'

    data = main(cfg)
    # In PyCharm, Run - Edit Configurations - Run with python console
    # Variable 'data' has the analyzed data
