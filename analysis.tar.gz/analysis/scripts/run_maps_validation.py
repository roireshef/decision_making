import argparse

import yaml
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_planner.analysis.maps_validation.map_validation_mnp import validate_map_attributes as validate_map_attributes_mnp


def validate_map_attributes_recording(path: str, is_aggregated: bool, mnp_mode: bool, min_frame: int, max_frame: int):
    master_parser = PubSubRecordingMasterParser(base_recording_path=path)
    map_attributes_data_loader = master_parser.get_data_loader("UC_SYSTEM", "MAP_ATTRIBUTES")

    report = dict()
    for timestamp, map_attributes_msg in map_attributes_data_loader:
        if not min_frame <= map_attributes_msg.s_Header.e_Cnt_SeqNum <= max_frame:
            continue
        if not is_aggregated:
            report = dict()

        validate_map_attributes_mnp(map_attributes=map_attributes_msg, report=report)

        if not is_aggregated and len(report) > 0:
            print(f"Found issues in map_attributes id: {map_attributes_msg.s_Header.e_Cnt_SeqNum}")
            print(report)

    if is_aggregated:
        if len(report) > 0:
            print(f"Found issues in map_attributes")
            print(report)

    return report


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Maps validation')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/maps_validation_cfg.yml")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    validate_map_attributes_recording(path=cfg['path'],
                                    is_aggregated=cfg['is_aggregated'],
                                    mnp_mode=cfg['mnp_mode'],
                                    min_frame=cfg['min_frame'],
                                    max_frame=cfg['max_frame'])
