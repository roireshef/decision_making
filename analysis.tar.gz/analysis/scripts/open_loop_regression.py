"""
Run planner in open loop from recorded states and compare the output to the recorded action.
Useful for regression tests, by making it easy to compare the planner output with some code change
to its output without that change.
"""
import argparse
from typing import Dict

import yaml
from tqdm import tqdm

from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.test.compare_pubsub import compare_pubsub
from subdivision_planner.test.data_structures.test_canonic_action import canonic_action_compare


def main(cfg: Dict):
    logger = get_logger()

    master_parser = PubSubRecordingMasterParser(base_recording_path=cfg['path'])
    canonic_sequence_parser = master_parser.canonic_sequence_parser

    frame_ids = range(cfg["start_frame_id"], cfg["end_frame_id"] + 1)

    # Find missing frames in canonic sequence parser
    existing_frames = canonic_sequence_parser.get_frame_ids()
    missing_frames = [frame_id
                      for frame_id in frame_ids
                      if frame_id not in existing_frames]
    assert len(missing_frames) == 0, f"Missing frames in canonic sequence, {missing_frames},\n existing from {min(existing_frames)} to {max(existing_frames)}"

    planner_runner = PlannerRunner(logger=logger,
                                   parser=canonic_sequence_parser)

    for frame_id in tqdm(frame_ids[1:]):
        original_frame = master_parser.canonic_sequence_parser[frame_id]
        if original_frame.action is None and frame_id == frame_ids[-1]:
            continue

        internal_state = planner_runner._planner.get_state()
        canonic_action = planner_runner.plan(frame_id, cfg["skip_deep_search"], cfg["skip_shallow_search"])
        execution_info = planner_runner._planner.get_execution_info()

        canonic_action_compare(original_frame.action, canonic_action, compare_ids=False)
        compare_pubsub(original_frame.internal_state.s_Data, internal_state.s_Data)
        compare_pubsub(original_frame.execution_info.s_Data, execution_info.s_Data)
    print("Finished regression test")


def parse_args():
    """
    Parse command line arguments
    """
    parser = argparse.ArgumentParser(description='Open Loop Regression')
    parser.add_argument('-cfg', help='path to the config file', type=str, default="config/open_loop_regression_cfg.yml")

    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    with open(args.cfg, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)
    main(cfg)
