import matplotlib.pyplot as plt
import os
import pickle


pubsub_data_directory = ''

statistics_plot = os.path.join(pubsub_data_directory, 'coverage_statistics.pickle')
time_plot = os.path.join(pubsub_data_directory, 'coverage_time_plot.pickle')

if os.path.exists(statistics_plot):
    fig = pickle.load(open(statistics_plot, 'rb'))
    fig.set_tight_layout(True)
    fig_manager = plt.get_current_fig_manager()
    fig_manager.window.showMaximized()

if os.path.exists(time_plot):
    fig = pickle.load(open(time_plot, 'rb'))
    fig.set_tight_layout(True)
    fig_manager = plt.get_current_fig_manager()
    fig_manager.window.showMaximized()

plt.show()
