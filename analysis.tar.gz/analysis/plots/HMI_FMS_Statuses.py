from enum import Enum
from typing import Dict, Tuple, Union, List, Optional

import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot

from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence


class ActiveActorTimePlot(ITimePlot):

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        active_actor_id_dict = {}
        return_dict = {}
        counter = 0
        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
            if frame.action is not None:
                if frame.action.hmi_statuses.active_actor.is_active_actor_valid:
                    active_actor_id = str(frame.action.hmi_statuses.active_actor.active_actor_id)
                    if active_actor_id in active_actor_id_dict:
                        active_actor_id_dict[active_actor_id].append(now)
                    else:
                        active_actor_id_dict[active_actor_id] = [now]
        for key, val in active_actor_id_dict.items():
            return_dict[key] = (np.array(val), np.ones(len(val))*counter, 'o')
            counter += 1
        return return_dict

    @property
    def title(self) -> str:
        return "Active Actor"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Active Actor ID"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None



class HMIStatusesTimePlot(ITimePlot):

    class HMIFlag(Enum):
        is_valid = 0
        near_or_in_intersection = 1
        short_dim = 2
        long_dim = 3
        stopped_for_attentiveness = 4
        should_blink = 5
        blink_direction = 6
        approaching_intersection_maneuver = 7
        lane_change_direction = 8

    """
    Plots different HMI boolean or enum elements - 
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        is_valid = []
        should_blink = []
        near_or_in_intersection = []
        short_dim = []
        long_dim = []
        stopped_for_attentiveness = []
        blink_direction = {'HMI_NoBlink': [], 'HMI_BlinkLeft': [], 'HMI_BlinkRight': []}
        approaching_intersection_maneuver = []
        lane_change_direction = {'HMI_NoLaneChange': [], 'HMI_Left': [], 'HMI_Right': []}

        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
            if frame.action is not None:
                if frame.action.hmi_statuses.is_valid:
                    is_valid.append(now)
                if frame.action.hmi_statuses.near_or_in_intersection:
                    near_or_in_intersection.append(now)
                if frame.action.hmi_statuses.short_dim:
                    short_dim.append(now)
                if frame.action.hmi_statuses.long_dim:
                    long_dim.append(now)
                if frame.action.hmi_statuses.stopped_for_attentiveness:
                    stopped_for_attentiveness.append(now)
                if frame.action.hmi_statuses.should_blink:
                    should_blink.append(now)
                if frame.action.hmi_statuses.intersection_maneuver.approaching_intersection_maneuver:
                    approaching_intersection_maneuver.append(now)
                blink_direction[frame.action.hmi_statuses.blink_direction.name].append(now)
                lane_change_direction[frame.action.hmi_statuses.lane_change_direction.name].append(now)

        return {
            "is_valid": (np.array(is_valid), np.ones(len(is_valid)) * HMIStatusesTimePlot.HMIFlag.is_valid.value, 'o'),
            "near_or_in_intersection": (np.array(near_or_in_intersection), np.ones(len(near_or_in_intersection)) * HMIStatusesTimePlot.HMIFlag.near_or_in_intersection.value, 'o'),
            "short_dim": (np.array(short_dim), np.ones(len(short_dim)) * HMIStatusesTimePlot.HMIFlag.short_dim.value, 'o'),
            "long_dim": (np.array(long_dim), np.ones(len(long_dim)) * HMIStatusesTimePlot.HMIFlag.long_dim.value, 'o'),
            "stopped_for_attentiveness": (np.array(stopped_for_attentiveness), np.ones(len(stopped_for_attentiveness)) * HMIStatusesTimePlot.HMIFlag.stopped_for_attentiveness.value, 'o'),
            "should_blink": (np.array(should_blink), np.ones(len(should_blink)) * HMIStatusesTimePlot.HMIFlag.should_blink.value, 'o'),
            "approaching_intersection_maneuver": (np.array(approaching_intersection_maneuver), np.ones(len(approaching_intersection_maneuver)) * HMIStatusesTimePlot.HMIFlag.approaching_intersection_maneuver.value, 'o'),
            "no_blink": (np.array(blink_direction['HMI_NoBlink']), np.ones(len(blink_direction['HMI_NoBlink'])) * HMIStatusesTimePlot.HMIFlag.blink_direction.value, 'xk'),
            "blink_left": (np.array(blink_direction['HMI_BlinkLeft']), np.ones(len(blink_direction['HMI_BlinkLeft'])) * HMIStatusesTimePlot.HMIFlag.blink_direction.value, '<r'),
            "blink_right": (np.array(blink_direction['HMI_BlinkRight']), np.ones(len(blink_direction['HMI_BlinkRight'])) * HMIStatusesTimePlot.HMIFlag.blink_direction.value, '>g'),
            "no_lane_change": (np.array(lane_change_direction['HMI_NoLaneChange']), np.ones(len(lane_change_direction['HMI_NoLaneChange'])) * HMIStatusesTimePlot.HMIFlag.lane_change_direction.value, 'xk'),
            "left_lane_change": (np.array(lane_change_direction['HMI_Left']), np.ones(len(lane_change_direction['HMI_Left'])) * HMIStatusesTimePlot.HMIFlag.lane_change_direction.value, '<r'),
            "right_lane_change": (np.array(lane_change_direction['HMI_Right']), np.ones(len(lane_change_direction['HMI_Right'])) * HMIStatusesTimePlot.HMIFlag.lane_change_direction.value, '>g'),
               }

    @property
    def title(self) -> str:
        return "HMI Statuses"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "HMI Statuses"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [flag.name for flag in HMIStatusesTimePlot.HMIFlag], None


class FMSStatuses_1_TimePlot(ITimePlot):

    class FMS_1_Flags(Enum):
        is_valid = 0
        traj_avail = 1
        stable_in_lane = 2
        best_effort_traj = 3
        best_effort_collision = 4
        point_no_return = 5
        inside_intersection = 6
        towards_merge = 7
        driver_not_attentive = 8
        stopped_auto_resume = 9

    """
    Plots different FMS boolean or enum elements -
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        is_valid = []
        traj_avail = []
        stable_in_lane = []
        best_effort_traj = []
        best_effort_collision = []
        point_no_return = []
        inside_intersection = []
        towards_merge = []
        driver_not_attentive = []
        stopped_auto_resume = []

        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
            if frame.action is not None:
                if frame.action.fms_statuses.is_valid:
                    is_valid.append(now)
                if frame.action.fms_statuses.traj_avail:
                    traj_avail.append(now)
                if frame.action.fms_statuses.stable_in_lane:
                    stable_in_lane.append(now)
                if frame.action.fms_statuses.best_effort_traj:
                    best_effort_traj.append(now)
                if frame.action.fms_statuses.best_effort_collision:
                    best_effort_collision.append(now)
                if frame.action.fms_statuses.point_no_return:
                    point_no_return.append(now)
                if frame.action.fms_statuses.inside_intersection:
                    inside_intersection.append(now)
                if frame.action.fms_statuses.towards_merge:
                    towards_merge.append(now)
                if frame.action.fms_statuses.driver_not_attentive:
                    driver_not_attentive.append(now)
                if frame.action.fms_statuses.stopped_auto_resume:
                    stopped_auto_resume.append(now)

        return {
            "is_valid": (np.array(is_valid), np.ones(len(is_valid)) * FMSStatuses_1_TimePlot.FMS_1_Flags.is_valid.value, 'o'),
            "traj_avail": (np.array(traj_avail), np.ones(len(traj_avail)) * FMSStatuses_1_TimePlot.FMS_1_Flags.traj_avail.value, 'o'),
            "stable_in_lane": (np.array(stable_in_lane), np.ones(len(stable_in_lane)) * FMSStatuses_1_TimePlot.FMS_1_Flags.stable_in_lane.value, 'o'),
            "best_effort_traj": (np.array(best_effort_traj), np.ones(len(best_effort_traj)) * FMSStatuses_1_TimePlot.FMS_1_Flags.best_effort_traj.value, 'o'),
            "best_effort_collision": (np.array(best_effort_collision), np.ones(len(best_effort_collision)) * FMSStatuses_1_TimePlot.FMS_1_Flags.best_effort_collision.value, 'o'),
            "point_no_return": (np.array(point_no_return), np.ones(len(point_no_return)) * FMSStatuses_1_TimePlot.FMS_1_Flags.point_no_return.value, 'o'),
            "inside_intersection": (np.array(inside_intersection), np.ones(len(inside_intersection)) * FMSStatuses_1_TimePlot.FMS_1_Flags.inside_intersection.value, 'o'),
            "towards_merge": (np.array(towards_merge), np.ones(len(towards_merge)) * FMSStatuses_1_TimePlot.FMS_1_Flags.towards_merge.value, 'o'),
            "driver_not_attentive": (np.array(driver_not_attentive), np.ones(len(driver_not_attentive)) * FMSStatuses_1_TimePlot.FMS_1_Flags.driver_not_attentive.value, 'o'),
               }

    @property
    def title(self) -> str:
        return "FMS Statuses"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "FMS Statuses"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [flag.name for flag in FMSStatuses_1_TimePlot.FMS_1_Flags], None



class FMSStatuses_2_TimePlot(ITimePlot):

    class FMS_2_Flags(Enum):
        gmfa_non_urgent = 0
        gmfa_urgent = 1
        gmfa_control_point_avail = 2
        stopped_outside_gmfa = 3
        inside_gmfa = 4
        end_of_route_urgent = 5
        end_of_route_non_urgent = 6
        t_junction_infinite_route_urgent = 7
        t_junction_infinite_route_non_urgent = 8
        MapInvalid = 9
        GasNavPlan = 10
        InfiniteRoutePlan = 11

    """
    Plots different FMS boolean or enum elements -
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        gmfa_non_urgent = []
        gmfa_urgent = []
        gmfa_control_point_avail = []
        stopped_outside_gmfa = []
        inside_gmfa = []
        end_of_route_urgent = []
        end_of_route_non_urgent = []
        t_junction_infinite_route_urgent = []
        t_junction_infinite_route_non_urgent = []
        nav_plan_type = {"MapInvalid": [], "GasNavPlan": [], "InfiniteRoutePlan": []}

        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
            if frame.action is not None:
                if frame.action.fms_statuses.gmfa_non_urgent:
                    gmfa_non_urgent.append(now)
                if frame.action.fms_statuses.gmfa_urgent:
                    gmfa_urgent.append(now)
                if frame.action.fms_statuses.gmfa_control_point_avail:
                    gmfa_control_point_avail.append(now)
                if frame.action.fms_statuses.stopped_outside_gmfa:
                    stopped_outside_gmfa.append(now)
                if frame.action.fms_statuses.inside_gmfa:
                    inside_gmfa.append(now)
                if frame.action.fms_statuses.end_of_route_urgent:
                    end_of_route_urgent.append(now)
                if frame.action.fms_statuses.end_of_route_non_urgent:
                    end_of_route_non_urgent.append(now)
                if frame.action.fms_statuses.t_junction_infinite_route_urgent:
                    t_junction_infinite_route_urgent.append(now)
                if frame.action.fms_statuses.t_junction_infinite_route_non_urgent:
                    t_junction_infinite_route_non_urgent.append(now)
                nav_plan_type[frame.action.fms_statuses.gas_nav_plan_type.name].append(now)

        return {
            "gmfa_non_urgent": (np.array(gmfa_non_urgent), np.ones(len(gmfa_non_urgent)) * FMSStatuses_2_TimePlot.FMS_2_Flags.gmfa_non_urgent.value, 'o'),
            "gmfa_urgent": (np.array(gmfa_urgent), np.ones(len(gmfa_urgent)) * FMSStatuses_2_TimePlot.FMS_2_Flags.gmfa_urgent.value, 'o'),
            "gmfa_control_point_avail": (np.array(gmfa_control_point_avail), np.ones(len(gmfa_control_point_avail)) * FMSStatuses_2_TimePlot.FMS_2_Flags.gmfa_control_point_avail.value, 'o'),
            "stopped_outside_gmfa": (np.array(stopped_outside_gmfa), np.ones(len(stopped_outside_gmfa)) * FMSStatuses_2_TimePlot.FMS_2_Flags.stopped_outside_gmfa.value, 'o'),
            "inside_gmfa": (np.array(inside_gmfa), np.ones(len(inside_gmfa)) * FMSStatuses_2_TimePlot.FMS_2_Flags.inside_gmfa.value, 'o'),
            "end_of_route_urgent": (np.array(end_of_route_urgent), np.ones(len(end_of_route_urgent)) * FMSStatuses_2_TimePlot.FMS_2_Flags.end_of_route_urgent.value, 'o'),
            "end_of_route_non_urgent": (np.array(end_of_route_non_urgent), np.ones(len(end_of_route_non_urgent)) * FMSStatuses_2_TimePlot.FMS_2_Flags.end_of_route_non_urgent.value, 'o'),
            "t_junction_infinite_route_urgent": (np.array(t_junction_infinite_route_urgent), np.ones(len(t_junction_infinite_route_urgent)) * FMSStatuses_2_TimePlot.FMS_2_Flags.t_junction_infinite_route_urgent.value, 'o'),
            "t_junction_infinite_route_non_urgent": (np.array(t_junction_infinite_route_non_urgent), np.ones(len(t_junction_infinite_route_non_urgent)) * FMSStatuses_2_TimePlot.FMS_2_Flags.t_junction_infinite_route_non_urgent.value, 'o'),
            "MapInvalid": (np.array(nav_plan_type['MapInvalid']), np.ones(len(nav_plan_type['MapInvalid'])) * FMSStatuses_2_TimePlot.FMS_2_Flags.MapInvalid.value, 'o'),
            "GasNavPlan": (np.array(nav_plan_type['GasNavPlan']), np.ones(len(nav_plan_type['GasNavPlan'])) * FMSStatuses_2_TimePlot.FMS_2_Flags.GasNavPlan.value, 'o'),
            "InfiniteRoutePlan": (np.array(nav_plan_type['InfiniteRoutePlan']), np.ones(len(nav_plan_type['InfiniteRoutePlan'])) * FMSStatuses_2_TimePlot.FMS_2_Flags.InfiniteRoutePlan.value, 'o')
               }

    @property
    def title(self) -> str:
        return "FMS Statuses"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "FMS Statuses"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [flag.name for flag in FMSStatuses_2_TimePlot.FMS_2_Flags], None


class FMSStatuses_3_TimePlot(ITimePlot):

    class FMS_3_Flags(Enum):
        map_invalid = 0
        scene_provider_invalid = 1
        trajectory_loss_escalation = 2
        below_safety_distance = 3
        curve_speed_exceeded_escalation = 4
        driver_exceeded_acceleration_limit = 5
        driver_exceeded_uc_max_speed = 6
        driver_override_red_light_stop = 7
        extreme_stop = 8


    """
    Plots different FMS boolean or enum elements -
    """

    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        map_invalid = []
        scene_provider_invalid = []
        trajectory_loss_escalation = []
        below_safety_distance = []
        curve_speed_exceeded_escalation = []
        driver_exceeded_acceleration_limit = []
        driver_exceeded_uc_max_speed = []
        driver_override_red_light_stop = []
        extreme_stop = []

        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
            if frame.action is not None:
                if frame.action.fms_statuses.map_invalid:
                    map_invalid.append(now)
                if frame.action.fms_statuses.scene_provider_invalid:
                    scene_provider_invalid.append(now)
                if frame.action.fms_statuses.trajectory_loss_escalation:
                    trajectory_loss_escalation.append(now)
                if frame.action.fms_statuses.below_safety_distance:
                    below_safety_distance.append(now)
                if frame.action.fms_statuses.curve_speed_exceeded_escalation:
                    curve_speed_exceeded_escalation.append(now)
                if frame.action.fms_statuses.driver_exceeded_acceleration_limit:
                    driver_exceeded_acceleration_limit.append(now)
                if frame.action.fms_statuses.driver_exceeded_uc_max_speed:
                    driver_exceeded_uc_max_speed.append(now)
                if frame.action.fms_statuses.driver_override_red_light_stop:
                    driver_override_red_light_stop.append(now)
                if frame.action.fms_statuses.extreme_stop:
                    extreme_stop.append(now)

        return {
            "map_invalid": (np.array(map_invalid),
                            np.ones(len(map_invalid)) * FMSStatuses_3_TimePlot.FMS_3_Flags.map_invalid.value,
                            'o'),
            "scene_provider_invalid": (np.array(scene_provider_invalid), np.ones(
                len(scene_provider_invalid)) * FMSStatuses_3_TimePlot.FMS_3_Flags.scene_provider_invalid.value,
                                       'o'),
            "trajectory_loss_escalation": (np.array(trajectory_loss_escalation), np.ones(len(
                trajectory_loss_escalation)) * FMSStatuses_3_TimePlot.FMS_3_Flags.trajectory_loss_escalation.value,
                                           'o'),
            "below_safety_distance": (np.array(below_safety_distance), np.ones(
                len(below_safety_distance)) * FMSStatuses_3_TimePlot.FMS_3_Flags.below_safety_distance.value,
                                      'o'),
            "curve_speed_exceeded_escalation": (np.array(curve_speed_exceeded_escalation), np.ones(len(
                curve_speed_exceeded_escalation)) * FMSStatuses_3_TimePlot.FMS_3_Flags.curve_speed_exceeded_escalation.value,
                                                'o'),
            "driver_exceeded_acceleration_limit": (np.array(driver_exceeded_acceleration_limit), np.ones(len(
                driver_exceeded_acceleration_limit)) * FMSStatuses_3_TimePlot.FMS_3_Flags.driver_exceeded_acceleration_limit.value,
                                                   'o'),
            "driver_exceeded_uc_max_speed": (np.array(driver_exceeded_uc_max_speed), np.ones(len(
                driver_exceeded_uc_max_speed)) * FMSStatuses_3_TimePlot.FMS_3_Flags.driver_exceeded_uc_max_speed.value,
                                             'o'),
            "driver_override_red_light_stop": (np.array(driver_override_red_light_stop), np.ones(len(
                driver_override_red_light_stop)) * FMSStatuses_3_TimePlot.FMS_3_Flags.driver_override_red_light_stop.value,
                                               'o'),
            "extreme_stop": (np.array(extreme_stop),
                             np.ones(len(extreme_stop)) * FMSStatuses_3_TimePlot.FMS_3_Flags.extreme_stop.value,
                             'o')
        }

    @property
    def title(self) -> str:
        return "FMS Statuses"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "FMS Statuses"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [flag.name for flag in FMSStatuses_3_TimePlot.FMS_3_Flags], None
