from typing import Dict, Tuple, Union, List, Optional

import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
from subdivision_planner.src.messages.scene_traffic_control_enums import TrafficLightState


class TrafficLightStatesTimePlot(ITimePlot):
    def __init__(self):
        self._id_list = []

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser) -> Dict[str, Union[Tuple, List]]:
        red_dict = {}
        green_dict = {}
        unknown_dict = {}
        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
                if frame.internal_state is not None:
                    if "s_StopBarEnforcementManagerState" in frame.internal_state.s_Data._dic:
                        sbem_state = frame.internal_state.s_Data.s_StopBarEnforcementManagerState
                        for i in range(sbem_state.e_Cnt_TrafficLights):
                            traffic_light_id = sbem_state.a_i_TrafficLightsID[i]
                            if traffic_light_id not in self._id_list:
                                self._id_list.append(traffic_light_id)

                            traffic_light_state = TrafficLightState(sbem_state.a_e_TrafficLightsState[i])
                            if traffic_light_state == TrafficLightState.GREEN:
                                color_dict = green_dict
                            elif traffic_light_state == TrafficLightState.NOT_GREEN:
                                color_dict = red_dict
                            else:
                                color_dict = unknown_dict

                            if traffic_light_id in color_dict:
                                color_dict[traffic_light_id].append(now)
                            else:
                                color_dict[traffic_light_id] = [now]

        plot_data = {}

        for idx in range(len(self._id_list)):
            id = self._id_list[idx]
            if id in red_dict:
                plot_data[f"{idx}_red"] = (np.array(red_dict[id]), np.ones(len(red_dict[id])) * idx, 'rx')
            if id in green_dict:
                plot_data[f"{idx}_green"] = (np.array(green_dict[id]), np.ones(len(green_dict[id])) * idx, 'gx')
            if id in unknown_dict:
                plot_data[f"{idx}_unknown"] = (np.array(unknown_dict[id]), np.ones(len(unknown_dict[id])) * idx, 'kx')

        return plot_data

    @property
    def title(self) -> str:
        return "Traffic Lights States"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Traffic Lights States"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return self._id_list, None

