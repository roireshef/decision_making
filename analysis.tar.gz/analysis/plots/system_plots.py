from collections import defaultdict
from enum import Enum
from typing import Dict, Union, Tuple, List, Optional

import numpy as np
from interface.Rte_Types.python.enums.TeSYS_ReturnCode import TeSYSReturnCode
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
from active_safety_integration.active_safety_integration.FMS_Parser.ADSC_Parser.disengagement_reasons import FMS_Disengagement_Reasons


class FeatureMonitorVizTimePlot(ITimePlot):
    """
    Time plot that shows the Feature Monitor Status vs. time
    """

    # define the UC_EXECStat enum
    class UC_ExecStEnum(Enum):
        OFF = 0 # system is turned off
        DISABLED_WARNING = 1 # system is disabled and faulted
        DISABLED_OK = 2 # system is disabled and requires button press to enable
        ENABLED_INACTIVE = 3 # driver takeover, system ready for engagement
        ENGAGED_NORMAL = 4 # system is engaged
        LEVEL_ONE = 5
        LEVEL_TWO = 6
        LEVEL_THREE = 7
        LEVEL_FOUR = 8
        TERMINATED = 9
        LOCKOUT = 10
        LOCKOUT_SDA = 11

    def __init__(self):
        self.feature_monitor_viz_loader = None
        self.disengagement_reasons = []
        self.available_reasons = []

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        self.feature_monitor_viz_loader = master_parser.get_data_loader("FEATURE_MONITOR", "VIZ")

        if not self.feature_monitor_viz_loader:
            return {}

        last_inhib_or_escltn_cond = []
        uc_exec_status = []

        fm_viz_timestamps = np.array(self.feature_monitor_viz_loader.header_timestamps)

        relevant_timestamps = fm_viz_timestamps[
            (fm_viz_timestamps >= canonic_sequence[0].state.timestamp_in_seconds) &
            (fm_viz_timestamps <= canonic_sequence[-1].state.timestamp_in_seconds)
            ]

        for time in relevant_timestamps:
            msg = self.feature_monitor_viz_loader.get_by_header_timestamp(time)

            last_inhib_or_escltn_cond.append(msg.s_Data.VeVGCR_e_LastInhbOrEscltnCond)
            uc_exec_status.append(msg.s_Data.VeVGCR_e_UC_ExecSt)

        # normalize the normal state of the system - system state is normal when uc_exec_status == 4
        uc_exec_stat_normal_flag = [True if stat == self.UC_ExecStEnum.ENGAGED_NORMAL.value else False for stat in uc_exec_status]

        # identify times at which a disengagement occurred
        times_disengagement = [relevant_timestamps[i] for i, edge in enumerate(uc_exec_stat_normal_flag) if not edge]
        # get the UC status and the last inhibit or escalation condition
        uc_exec_status_disengagement = [uc_exec_status[i] for i, edge in enumerate(uc_exec_stat_normal_flag) if not edge]
        last_inhib_or_escltn_cond_disengagement = [last_inhib_or_escltn_cond[i] for i, edge in enumerate(uc_exec_stat_normal_flag) if not edge]

        # get disengagement reasons
        count_7 = 0
        count = 0
        for i, disengagement in enumerate(uc_exec_status_disengagement):
            if disengagement == self.UC_ExecStEnum.LEVEL_THREE.value:  # level 3 escalation
                reason = str(FMS_Disengagement_Reasons[last_inhib_or_escltn_cond_disengagement[i]])
                count_7 = count_7 + 1

            else:
                reason = self.UC_ExecStEnum(disengagement).name
                count = count + 1

            self.disengagement_reasons.append(reason)

        self.available_reasons = list(
            set(self.disengagement_reasons))  # unique by moving to set fluctuation_name.sort()
        self.available_reasons.append(self.UC_ExecStEnum(4).name)
        engaged_status = [self.UC_ExecStEnum(4).name if status == True else np.nan for status in uc_exec_stat_normal_flag]
        self.available_reasons.sort()
        enumerated_available_fluctuations = {k: v for v, k in enumerate(self.available_reasons)}
        enumerated_fluctuations = list(map(enumerated_available_fluctuations.get, self.disengagement_reasons))
        enumerated_system_status = list(map(enumerated_available_fluctuations.get, engaged_status))

        return {"disable_reasons": (np.array(times_disengagement), np.array(enumerated_fluctuations), 'x'),
                "normal_status": (np.array(relevant_timestamps), np.array(enumerated_system_status), 'x')}

    @property
    def title(self) -> str:
        if self.feature_monitor_viz_loader:
            return "Feature Monitor Disengagement Reasons vs time"
        else:
            return "Feature Monitor Disengagement Reasons vs time - Missing topic UC_SYSTEM_FEATURE_MONITOR_RETURN_CODE"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        if self.feature_monitor_viz_loader:
            return "FMS disable reason"
        else:
            return "FMS disable reason - Missing topic"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        reasons = self.available_reasons
        return reasons, None


class FeatureMonitorReturnCodeTimePlot(ITimePlot):
    """
    Time plot that shows the Feature Monitor Status vs. time
    """
    LocalizationErrorsOffset = 256

    class LocalizationErrors(Enum):
        CloseToLaneLine = 1
        FailureToAssociate = 2
        LocalizationErrorReserved = 63
        # UC_Enabled_or_not_active = 0
        # Overriden_longitudinal = 1
        # Overriden_Lateral = 2
        # No_override = 3
    type_to_val_mapper = {}

    def __init__(self):
        self.feature_monitor_return_code_loader = None

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        self.feature_monitor_return_code_loader = master_parser.get_data_loader("FEATURE_MONITOR", "RETURN_CODE")

        if not self.feature_monitor_return_code_loader:
            return {}

        times = []
        feature_monitor_return_code = []
        return_code_counter = 0
        for frame in canonic_sequence:
            time = frame.state.timestamp_in_seconds
            times.append(time)

            msg = self.feature_monitor_return_code_loader.get_by_physical_timestamp(time)
            feature_monitor_return_code.append(msg.s_Data.e_e_Code)
            if msg.s_Data.e_e_Code not in FeatureMonitorReturnCodeTimePlot.type_to_val_mapper:
                FeatureMonitorReturnCodeTimePlot.type_to_val_mapper[msg.s_Data.e_e_Code] = return_code_counter
                return_code_counter +=1

        feature_monitor_return_code = np.array(feature_monitor_return_code)
        for key in FeatureMonitorReturnCodeTimePlot.type_to_val_mapper.keys():
            feature_monitor_return_code[feature_monitor_return_code == key] = FeatureMonitorReturnCodeTimePlot.type_to_val_mapper[key]

        return {"FMS return code": (np.array(times), np.array(feature_monitor_return_code), 'x')}

    @property
    def title(self) -> str:
        if self.feature_monitor_return_code_loader:
            return "Feature Monitor return code vs time"
        else:
            return "Feature Monitor return code vs time - Missing topic UC_SYSTEM_FEATURE_MONITOR_RETURN_CODE"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        if self.feature_monitor_return_code_loader:
            return "FMS ret. code"
        else:
            return "FMS ret. code - Missing topic"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        keys = FeatureMonitorReturnCodeTimePlot.type_to_val_mapper.keys()
        tags = []
        for key in keys:
            for name, value in vars(TeSYSReturnCode).items():
                if value == key:
                    tags.append(name)
        return tags, None
        # return [self.type_to_val_mapper[key] for key in keys], None


class FeatureMonitorStateTimePlot(ITimePlot):
    """
    Plots feature monitor state
    """

    def __init__(self):
        self._feature_monitor_data_loader = None

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        self._feature_monitor_data_loader = master_parser.get_data_loader("FEATURE_MONITOR", "STATE")

        # If data doesn't exist, no plot can be generated
        if not self._feature_monitor_data_loader:
            return {}

        msg_timestamps = np.array(self._feature_monitor_data_loader.data_timestamps)

        # Find messages that have timestamp within the canonic sequence
        relevant_timestamps = msg_timestamps[
            (msg_timestamps >= canonic_sequence[0].state.timestamp_in_seconds) &
            (msg_timestamps <= canonic_sequence[-1].state.timestamp_in_seconds)
        ]

        # Go over messages within the correct time range and extract relevant data
        times = []
        d = defaultdict(list)
        names = [
            ("e_b_LateralControlActive", 'o-'),
            ("e_b_LimitedCapabilityHighwayOnlyActive", '.-'),
            ("e_b_LimitedCapabilityStraightOnlyActive", '.-'),
            ("e_b_LongitudinalControlActive", 'x-'),
            ("e_b_LongitudinalOverride", '.-'),
            ("e_b_UltracruiseEnabled", '.-'),
            ("e_e_EscalationThreshold", '.-'),
        ]
        for timestamp in relevant_timestamps:
            msg = self._feature_monitor_data_loader.get_by_data_timestamp(timestamp)
            times.append(timestamp)
            for name, marker in names:
                if name in ["e_DrvrIntndAxlTrq", "e_AxlTorqueCmd"]:
                    d[(name, marker)].append(msg.s_Data._dic[name] / 1000)
                else:
                    d[(name, marker)].append(msg.s_Data._dic[name])

        return {
            name: (np.array(times), l, marker)
            for (name, marker), l in d.items()
        }

    @property
    def title(self) -> str:
        if self._feature_monitor_data_loader:
            return "Feature monitor state"
        else:
            return "Feature monitor state - Missing FeatureMonitorState topic"

    @property
    def x_label(self) -> str:
        return "Timestamp [sec]"

    @property
    def y_label(self) -> str:
        return "Feature monitor state"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class DriverOverrideTimePlot(ITimePlot):
    """
    Plots driver override
    """

    def __init__(self):
        self._driver_override_data_loader = None

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        self._driver_override_data_loader = master_parser.get_data_loader("UC_SYSTEM", "DRIVER_OVERRIDE_STATUS")

        # If data doesn't exist, no plot can be generated
        if not self._driver_override_data_loader:
            return {}

        driver_override_timestamps = np.array(self._driver_override_data_loader.data_timestamps)

        # Find messages that have timestamp within the canonic sequence
        relevant_timestamps = driver_override_timestamps[
            (driver_override_timestamps >= canonic_sequence[0].state.timestamp_in_seconds) &
            (driver_override_timestamps <= canonic_sequence[-1].state.timestamp_in_seconds)
        ]

        # Go over messages within the correct time range and extract relevant data
        times = []
        d = defaultdict(list)
        names = [
            ("e_e_ACCATCS_RqStat", 'o-'),
            ("e_DrvrIntndAxlTrq", '.-'),
            ("e_AxlTorqueCmd", '.-'),
            ("e_b_DrvOvrDet", 'x-'),
            ("e_b_AccPdlOvrrdAtv", '.-'),
        ]
        for timestamp in relevant_timestamps:
            msg = self._driver_override_data_loader.get_by_data_timestamp(timestamp)
            times.append(timestamp)
            for name, marker in names:
                if name in ["e_DrvrIntndAxlTrq", "e_AxlTorqueCmd"]:
                    d[(name, marker)].append(msg.s_Data._dic[name] / 1000)
                else:
                    d[(name, marker)].append(msg.s_Data._dic[name])

        return {
            name: (np.array(times), l, marker)
            for (name, marker), l in d.items()
        }

    @property
    def title(self) -> str:
        if self._driver_override_data_loader:
            return "Driver override status"
        else:
            return "Driver override status - Missing DriverOverride topic"

    @property
    def x_label(self) -> str:
        return "Timestamp [sec]"

    @property
    def y_label(self) -> str:
        return "Driver override"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None
