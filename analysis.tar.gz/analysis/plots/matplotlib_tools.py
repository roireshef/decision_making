from typing import Type, Sequence

import matplotlib.pyplot as plt
from matplotlib.backend_tools import ToolBase
from PyQt5.QtWidgets import QInputDialog


plt.rcParams['toolbar'] = 'toolmanager'

CUSTOM_GROUP = 'custom_group'


def add_tools(figure, tool_types: Sequence[Type]):
    """
    Add tools to the figure's toolbar
    """
    for tool_type in tool_types:
        figure.canvas.manager.toolmanager.add_tool(tool_type.name, tool_type)
        figure.canvas.manager.toolbar.add_tool(tool_type.name, CUSTOM_GROUP)


class TitleTool(ToolBase):
    """
    Set window title
    """
    description = "Set Title"
    name = "Title"
    default_keymap = "t"

    def trigger(self, *args, **kwargs):
        try:
            current_title = self.figure.canvas.get_window_title()
            text, okPressed = QInputDialog.getText(self.figure.canvas.parent(), "Set Title", "Title:", text=current_title)
            if okPressed and text != '':
                self.figure.canvas.set_window_title(text)
        except Exception as e:
            print("Error in set title:", e)


class ToggleLegendTool(ToolBase):
    """
    Show and hide all legends
    """
    description = "Toggle legends"
    name = "Legends"
    default_keymap = "l"

    def trigger(self, *args, **kwargs):
        for ax in self.figure.axes:
            if ax.legend_ is not None:
                ax.legend_.set_visible(not ax.legend_.get_visible())
        plt.draw()
