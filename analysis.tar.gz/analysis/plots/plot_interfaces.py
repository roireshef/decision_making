import numpy as np

from abc import ABC, abstractmethod
from typing import Dict, Tuple, Union, List, Optional, Callable, Any

from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
import matplotlib.pyplot as plt


class ITimePlot(ABC):
    """
    Interface for plots that their x axis is time
    """
    @abstractmethod
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        """
        Given a canonic sequence retrieves a dictionary of plots. Keys are the name of each plot, value is either a
        tuple of x values, y values and additional arguments or a list of such tuples so that all plots have the same
        label
        :param canonic_sequence:
        :param master_parser: PubSubRecordingMasterParser that can be used to extract additional data from recording
        :return:
        """
        raise NotImplementedError

    @property
    def kwargs(self) -> Dict:
        return {}

    @property
    def ax_postprocessor(self) -> Optional[Callable[[plt.Axes], None]]:
        return None

    @property
    @abstractmethod
    def title(self) -> str:
        """
        Title of the plot
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def x_label(self) -> str:
        """
        :return: Label of x axis
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def y_label(self) -> str:
        """
        :return: Label of y axis
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def show_legend(self) -> bool:
        """
        :return: If true a legend will be shown
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        """
        list of ticks to place on y-axes. Mainly for plotting enums
        :return:
        """
        raise NotImplementedError


class ITopViewData(ABC):
    """
    Interface for top view data to be overlaid
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser) -> Dict[str, Union[Tuple, List]]:
        raise NotImplementedError


class UnifiedPlot(ITimePlot):
    """
    Overlay multiple plots on the same axes
    The first plot determines the plot properties
    """
    def __init__(self, *plots: ITimePlot):
        self._plots = plots

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        unified_dict = {}
        for plot in self._plots:
            data = plot.get_data_to_plot(canonic_sequence=canonic_sequence, master_parser=master_parser)
            unified_dict.update(data)
        return unified_dict

    @property
    def title(self) -> str:
        return self._plots[0].title

    @property
    def x_label(self) -> str:
        return self._plots[0].x_label

    @property
    def y_label(self) -> str:
        return self._plots[0].y_label

    @property
    def show_legend(self) -> bool:
        return self._plots[0].show_legend

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return self._plots[0].y_tick


class RecordingsBasedPlot(ITimePlot, ABC):
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        pass

    @abstractmethod
    def get_data_from_recordings(self, record_data: Dict[int, Dict]) -> Dict[str, Union[Tuple, List]]:
        raise NotImplementedError

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @staticmethod
    def _get_time_based_metric_tuple(data: Dict, extractor: Callable[[Dict], Any], *args):
        return (np.array([contents['PlanningModule']['state'].timestamp_in_seconds for frame, contents in data.items()]),
                np.array([extractor(contents) for frame, contents in data.items()]), *args)

    @staticmethod
    def _filter_recorded_data_by_field(data: Dict, path: str):
        def find_path(dict, fields):
            if not fields:
                return True

            if fields[0] == '*':
                return max(find_path(v, fields[1:]) for v in dict.values())

            if fields[0] in dict:
                return find_path(dict[fields[0]], fields[1:])

            return False

        return dict(filter(lambda tup: find_path(tup[1], path.split('/')), data.items()))

    @staticmethod
    def _get_planner_name(data: Dict):
        return data['PlanningModule']['planner']['active_planner']
