from traceback import format_exc
from typing import List, Optional, Dict

import matplotlib.pyplot as plt
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot, ITopViewData
from subdivision_learning.analysis.plots.matplotlib_plotter import MatplotlibPlotter
from subdivision_learning.analysis.plots.matplotlib_tools import add_tools, TitleTool, ToggleLegendTool
from subdivision_learning.analysis.utils.utils import TimestampFrameIdConverter
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence


def summary_plot_vs_time(canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser,
                         graphs: List[ITimePlot],
                         num_horizontal_plots: int,
                         relative_time: bool = True,
                         title_addition: Optional[str] = None,
                         record_data: Dict = None):
    """
    Summary time plot. Generates a matplotlib figure with a matrix of plots on it
    :param canonic_sequence: Canonic sequence used to draw
    :param master_parser: PubSubRecordingMasterParser that can be used to extract additional data from recording
    :param graphs: Different graphs to generate
    :param num_horizontal_plots: Number of horizontal plots in this summary plot
    :param relative_time: If true, time will be shown relative to beginning
    :param title_addition: added to title
    :param record_data: the dict unpickled from the recordings of the specific planner for which signals are plotted
    :return:
    """

    f = plt.figure()
    add_tools(f, (TitleTool, ToggleLegendTool))
    plt.subplots_adjust(top=0.92, bottom=0.05, right=0.98, left=0.1, hspace=0.7, wspace=0.4)

    shared_axis = None

    if relative_time:
        reference_time = canonic_sequence[0].state.timestamp_in_seconds
    else:
        reference_time = 0.

    timestamp2frame = TimestampFrameIdConverter(canonic_sequence, relative_time=True)

    num_vertical_plots, mod = divmod(len(graphs), num_horizontal_plots)
    num_vertical_plots += 1 if mod > 0 else 0
    for i, graph in enumerate(graphs):
        try:
            plt.subplot(num_vertical_plots, num_horizontal_plots, i+1, sharex=shared_axis)
            if i == 0:
                shared_axis = plt.gca()

            MatplotlibPlotter.plot_time_graph(
                axes=plt.gca(),
                canonic_sequence=canonic_sequence,
                master_parser=master_parser,
                record_data=record_data,
                plot=graph,
                title_per_plot=True,
                reference_time=reference_time,
                **graph.kwargs
            )

            if graph.ax_postprocessor:
                graph.ax_postprocessor(plt.gca())

            plt.gca().format_coord = lambda x, y: f"t={x:.3f}   y={y:.3f}  (frame={timestamp2frame.convert_to_frame_id(x)})"
        except Exception:
            print("Exception raised while trying to plot %s: %s" % (graph.__class__, format_exc()))

    title = "Summary plot"
    if relative_time:
        title += "  (Initial timestamp: {})".format(reference_time)
    if title_addition is not None:
        title += title_addition
    plt.suptitle(title)

    plt.show(block=False)


def summary_plot_top_view(canonic_sequence: CanonicSequence,
                          master_parser: PubSubRecordingMasterParser,
                          top_view_data: List[ITopViewData],
                          ):
    """
    Plot all top view data overlaid
    :param canonic_sequence: canonic sequence used to draw
    :param master_parser: PubSubRecordingMasterParser that can be used to extract additional data from recording
    :param top_view_data: List of top view data
    :return:
    """
    f = plt.figure()
    add_tools(f, (TitleTool, ToggleLegendTool))
    for i in range(len(top_view_data)):
        MatplotlibPlotter.plot_top_view_graph(
            axes=plt.gca(),
            canonic_sequence=canonic_sequence,
            master_parser=master_parser,
            top_view_data=top_view_data[i],
            show_legend=True
        )
