from abc import ABC
from enum import Enum
from typing import Dict, Union, Tuple, List, Optional

import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot
from subdivision_planner.src.common.global_constants import TRAJECTORY_TIME_RESOLUTION
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
from subdivision_planner.src.messages.scene_common_messages import Timestamp


class ControlTTCEngagedPlot(ITimePlot):

    """
    Plots control engaged status
    """

    def __init__(self):
        self._control_status_loader = None

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        self._control_status_loader = master_parser.get_data_loader("UC_SYSTEM", "CONTROL_STATUS")

        # If data doesn't exist, no plot can be generated
        if not self._control_status_loader:
            return {}

        control_status_timestamps = np.array(self._control_status_loader.data_timestamps)

        # Find messages that have timestamp within the canonic sequence
        relevant_timestamps = control_status_timestamps[
            (control_status_timestamps >= canonic_sequence[0].state.timestamp_in_seconds) &
            (control_status_timestamps <= canonic_sequence[-1].state.timestamp_in_seconds)
        ]

        # Go over messages within the correct time range and extract relevant data
        data = []
        for timestamp in relevant_timestamps:
            msg = self._control_status_loader.get_by_data_timestamp(timestamp)
            data.append((timestamp, msg.s_Data.e_b_TTCEnabled))


        return {"ttc_engaged": (np.array([time for time, _ in data]), np.zeros(
                len(data)) + [ttc_engaged for _, ttc_engaged, in data] , 'x'),}

    @property
    def title(self) -> str:
        if self._control_status_loader:
            return "TTC Engaged from ControlStatus topic "
        else:
            return "TTC Engaged from ControlStatus topic - Missing ControlStatus topic"

    @property
    def x_label(self) -> str:
        return "Timestamp [sec]"

    @property
    def y_label(self) -> str:
        return "Is TTC engaged"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None




class ControlInterpTrjTimePlot(ITimePlot, ABC):
    """
    Plots different fields
    """
    class ControlInterpTrjField(Enum):
        LonPosition = 0
        LatPosition = 1
        Curvature = 2
        Heading = 3
        Velocity = 4
        Acceleration = 5

    def __init__(self, field: ControlInterpTrjField):
        self._field_map = {
            self.ControlInterpTrjField.LonPosition: "a_heading",
            self.ControlInterpTrjField.LatPosition: "a_latPosition",
            self.ControlInterpTrjField.Curvature: "a_lonPosition",
            self.ControlInterpTrjField.Heading: "a_curvature",
            self.ControlInterpTrjField.Velocity: "a_vx",
            self.ControlInterpTrjField.Acceleration: "a_ax",
        }
        self._field = field
        self._field_id = self._field_map[field]

        self._control_status_loader = None

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        data = []
        self._control_status_loader = master_parser.get_data_loader("UC_SYSTEM", "CONTROL_STATUS")

        # No data available, plot can't be generated
        if not self._control_status_loader:
            return {}

        control_status_timestamps = np.array(self._control_status_loader.data_timestamps)

        # Find messages that have timestamp within the canonic sequence
        relevant_timestamps = control_status_timestamps[
            (control_status_timestamps >= canonic_sequence[0].state.timestamp_in_seconds) &
            (control_status_timestamps <= canonic_sequence[-1].state.timestamp_in_seconds)
            ]

        # Go over messages within the correct time range and extract relevant data
        for timestamp in relevant_timestamps:
            msg = self._control_status_loader.get_by_data_timestamp(timestamp)
            timestamp = Timestamp.deserialize(msg.s_Header.s_Timestamp).timestamp_in_seconds
            if timestamp < canonic_sequence[0].state.timestamp_in_seconds or \
                timestamp > canonic_sequence[-1].state.timestamp_in_seconds:
                continue

            current_trj_data = msg.s_Data.s_InterpTraj._dic[self._field_id]
            timestamps_for_current_trj = timestamp + np.arange(current_trj_data.shape[0]) * TRAJECTORY_TIME_RESOLUTION
            data.append((timestamps_for_current_trj, current_trj_data, '-'))

        return {self._field.name: data}

    @property
    def title(self) -> str:
        if self._control_status_loader:
            return "Control interpolated trajectory"
        else:
            return "Control interpolated trajectory - Missing ControlStatus topic"

    @property
    def x_label(self) -> str:
        return "Timestamp [sec]"

    @property
    def y_label(self) -> str:
        return self._field.name

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None
