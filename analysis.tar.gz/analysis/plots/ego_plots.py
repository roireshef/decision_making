import re
from abc import abstractmethod
from collections import defaultdict
from enum import Enum
from typing import Dict, Tuple, Union, List, Optional

import numpy as np
from interface.Rte_Types.python.enums.TeSYS_FeatureMonitorEscalation import TeSYSFeatureMonitorEscalation
from interface.Rte_Types.python.sub_structures.TsSYS_DataPlannerInternalState import TsSYSDataPlannerInternalState
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot, ITopViewData
from subdivision_learning.utils.planner import plan_exists
from subdivision_planner.src.common import types
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.global_constants import TRAJECTORY_TIME_RESOLUTION, TRAJECTORY_NUM_POINTS
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence, CanonicFrame
from subdivision_planner.src.data_structures.driver_initiated_motion import DriverInitiatedMotionStatus
from subdivision_planner.src.data_structures.driving_plan_deserializer import DrivingPlanDeserializer
from subdivision_planner.src.data_structures.escalation import EscalationType
from subdivision_planner.src.data_structures.lane_change import LaneChangeStatus, LaneChangeReason, LaneChangeIntent
from subdivision_planner.src.mdp.determinizer import ReplanType, Determinizer
from subdivision_planner.src.mdp.iaction import IMDPAction
from subdivision_planner.src.mdp.werling.action import WerlingMDPAction
from subdivision_planner.src.mdp.werling.action_type import LongitudinalComponentType, LateralComponentType
from subdivision_planner.src.mdp.werling.concepts.physicality import FRENET_NEGLIGIBLE_CURVATURE, EPS_CURVE
from subdivision_planner.src.mdp.werling.utils import acceleration_profile


class PlannerStateTimePlot(ITimePlot):
    class PlannerProblems(Enum):
        FullReplan = 0
        LongitudinalReplan = 1
        ZeroVelocityReplan = 2
        NotEngaged = 3
        EngagedForReplan = 4
        Failed = 5
        InvalidTraj = 6
        LongitudinalOverride = 7
        DriverInitiatedMotion = 8
        Escalation = 9

    """
    Plots different state boolean or enum elements - engaged, engaged for replan, failure, replan, longitudinal override,dim_state
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        not_engaged = []
        is_engaged_for_replan = []
        is_full_replan = []
        is_longitudinal_replan = []
        is_zero_velocity_replan = []
        is_failed = []
        invalid_dp = []
        is_longitudinal_override = []
        dim_waiting = []
        dim_pending = []
        dim_confirmed = []
        escalation_coast = []
        escalation_slow_safely = []
        for frame in canonic_sequence:
            if frame.state is not None:
                now = frame.state.timestamp_in_seconds
                if not frame.state.is_ttc_engaged:
                    not_engaged.append(now)
                if not frame.state.is_engaged_for_replan:
                    is_engaged_for_replan.append(now)
                if frame.state.feature_monitor_escalation == TeSYSFeatureMonitorEscalation.CeSYS_escalation_Coast:
                    escalation_coast.append(now)
                if frame.state.feature_monitor_escalation == TeSYSFeatureMonitorEscalation.CeSYS_escalation_SlowSafely:
                    escalation_slow_safely.append(now)

                if frame.internal_state is not None:
                    dim_status = frame.internal_state.s_Data.s_DriverInitiatedMotionInfo.e_e_DriverInitiatedMotionStatus
                    if dim_status != DriverInitiatedMotionStatus.Inactive.value:
                        if dim_status == DriverInitiatedMotionStatus.WaitingForDriverInput.value:
                            dim_waiting.append(now)
                        if dim_status == DriverInitiatedMotionStatus.Pending.value:
                            dim_pending.append(now)
                        if dim_status == DriverInitiatedMotionStatus.Confirmed.value:
                            dim_confirmed.append(now)

                if frame.execution_info is not None:
                    if frame.execution_info.s_Data.e_b_IsLongitudinalDriverOverride:
                        is_longitudinal_override.append(now)
                    if 'e_e_ReplanType' in frame.execution_info.s_Data._dic:
                        replan_type = frame.execution_info.s_Data.e_e_ReplanType
                        if ReplanType(replan_type) == ReplanType.Full:
                            is_full_replan.append(now)
                        elif ReplanType(replan_type) == ReplanType.Longitudinal:
                            is_longitudinal_replan.append(now)
                        elif ReplanType(replan_type) == ReplanType.ZeroVelocity:
                            is_zero_velocity_replan.append(now)
                    elif frame.execution_info.s_Data.e_b_IsReplan:
                        is_full_replan.append(now)
                    failed = bool(frame.execution_info.s_Data.e_b_IsPlannerFailed)
                    if not plan_exists(frame.action):
                        failed = True
                    if failed:
                        is_failed.append(now)
                    is_invalid_dp = bool(frame.execution_info.s_Data.e_b_IsDrivingPlanInvalid)
                    if is_invalid_dp:
                        invalid_dp.append(now)
        return {
            "is_engaged": (np.array(not_engaged), np.ones(len(not_engaged)) * PlannerStateTimePlot.PlannerProblems.NotEngaged.value, 'x'),
            "is_engaged_for_replan": (np.array(is_engaged_for_replan), np.ones(len(is_engaged_for_replan)) * PlannerStateTimePlot.PlannerProblems.EngagedForReplan.value, 'x'),
            "is_full_replan": (np.array(is_full_replan), np.ones(len(is_full_replan)) * PlannerStateTimePlot.PlannerProblems.FullReplan.value, 'x'),
            "is_longitudinal_replan": (np.array(is_longitudinal_replan), np.ones(len(is_longitudinal_replan)) * PlannerStateTimePlot.PlannerProblems.LongitudinalReplan.value, 'x'),
            "is_zero_vel_replan": (np.array(is_zero_velocity_replan), np.ones(len(is_zero_velocity_replan)) * PlannerStateTimePlot.PlannerProblems.ZeroVelocityReplan.value, 'x'),
            "is_longitudinal_override": (np.array(is_longitudinal_override), np.ones(len(is_longitudinal_override)) * PlannerStateTimePlot.PlannerProblems.LongitudinalOverride.value, 'x'),
            "is_failed": (np.array(is_failed), np.ones(len(is_failed)) * PlannerStateTimePlot.PlannerProblems.Failed.value, 'x'),
            "invalid_dp": (np.array(invalid_dp), np.ones(len(invalid_dp)) * PlannerStateTimePlot.PlannerProblems.InvalidTraj.value, 'x'),
            "dim_waiting": (np.array(dim_waiting), np.ones(
                len(dim_waiting)) * PlannerStateTimePlot.PlannerProblems.DriverInitiatedMotion.value, 'o'),
            "dim_pending": (np.array(dim_pending), np.ones(
                len(dim_pending)) * PlannerStateTimePlot.PlannerProblems.DriverInitiatedMotion.value, '^'),
            "dim_confirmed": (np.array(dim_confirmed), np.ones(
                len(dim_confirmed)) * PlannerStateTimePlot.PlannerProblems.DriverInitiatedMotion.value, 'x'),
            "escalation_coast": (np.array(escalation_coast),
                                 np.ones(len(escalation_coast)) * PlannerStateTimePlot.PlannerProblems.Escalation.value, 'o'),
            "escalation_slow_safely": (np.array(escalation_slow_safely),
                                       np.ones(len(escalation_slow_safely)) * PlannerStateTimePlot.PlannerProblems.Escalation.value, 'x')
        }

    @property
    def title(self) -> str:
        return "Planner State"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Planner State"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [problem.name for problem in PlannerStateTimePlot.PlannerProblems], None


class LaneChangeStatusPlot(ITimePlot):
    """
    Plots LaneChangeStatus along with LaneChangeIntent as marker shape and LaneChangeReason as color.
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        all_times = defaultdict(list)
        all_lc_status = defaultdict(list)
        for frame in canonic_sequence:
            if frame.state is not None and frame.internal_state is not None \
                    and frame.internal_state.s_Data.s_LaneChangeManagerState.s_LaneChangeInfo.e_b_Valid:
                intent = LaneChangeIntent(frame.internal_state.s_Data.s_LaneChangeManagerState.s_LaneChangeInfo.e_e_Intent)
                reason = LaneChangeReason(frame.internal_state.s_Data.s_LaneChangeManagerState.s_LaneChangeInfo.e_e_Reason)
                status = frame.internal_state.s_Data.s_LaneChangeState.e_e_Status

                all_times[(intent, reason)].append(frame.state.timestamp_in_seconds)
                all_lc_status[(intent, reason)].append(status)

        marker = {
            LaneChangeIntent.Left: '<',
            LaneChangeIntent.Right: '>',
            LaneChangeIntent.KeepLane: '|',
        }

        return {
            f"{intent.name} {reason.name}":
                (np.array(times), np.array(all_lc_status[(intent, reason)]), marker[intent])
            for (intent, reason), times in all_times.items()
        }

    @property
    def title(self) -> str:
        return "LaneChangeStatus"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "LaneChangeStatus"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [status.name for status in LaneChangeStatus], None


class PedalPositionPlot(ITimePlot):

    """
    Plots strength of press on acceleration pedal as it's represented in canonic state, with 2 time represertations:
    - timestamp of current CanonicState (if  a new Pedal Position Message wasn't published, the contents of the previous
        one will be in the graph for all the frames since.
    - Original Timestamp from PedalPosition message - omly times that appeared in PedalPosition messages
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        accel_pedal_pressed = []
        accel_pedal_pressed_from_pedal = []
        for frame in canonic_sequence:
            if frame.state is not None:
                now_canonic = frame.state.timestamp_in_seconds
                now_pedal = frame.state.pedal_position.s_RecvTimestamp.timestamp_in_seconds
                if frame.state.pedal_position.e_b_Valid and frame.state.pedal_position.e_Pct_AcceleratorPedalPosition >=\
                        Config().driving.driver_initiated_motion_min_pedal_strength:
                    accel_pedal_pressed.append((now_canonic, frame.state.pedal_position.e_Pct_AcceleratorPedalPosition))
                    accel_pedal_pressed_from_pedal.append((now_pedal, frame.state.pedal_position.e_Pct_AcceleratorPedalPosition))
        return {

            "accel_pedal_pressed": (np.array([time for time, _ in accel_pedal_pressed]), np.zeros(
                len(accel_pedal_pressed)) + [accelpedal for _, accelpedal, in accel_pedal_pressed] , 'x'),
            "accel_pedal_pressed_from_pedal position msg": (np.array([time for time, _ in accel_pedal_pressed_from_pedal]), np.zeros(
                len(accel_pedal_pressed_from_pedal)) + [accelpedal for _, accelpedal, in accel_pedal_pressed_from_pedal], 'x'),

        }

    @property
    def title(self) -> str:
        return "Pedal Position Acceleration State"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Acceleration pedal position"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class PlannerActionEscalationTimePlot(ITimePlot):
    def __init__(self):
        self._escalations_dict: Dict[EscalationType, List[float]] = defaultdict(list)

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        for frame in canonic_sequence:
            if frame.action is not None:
                now = frame.action.timestamp
                for escalation_type in frame.action.escalation_types:
                    self._escalations_dict[escalation_type].append(now)

        return {k.name: (np.array(v), np.ones(len(v)) * idx, 'x') for idx, (k, v) in enumerate(self._escalations_dict.items())}

    @property
    def title(self) -> str:
        return "Escalation type"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Escalation type"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [escalation.name for escalation in self._escalations_dict], None


class PlannerRuntime(ITimePlot):
    """
    Plots runtime of planner, difference is between beginnings of planning time that have produced actions
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        state_times = []
        for frame in canonic_sequence:
            if frame.state is not None and frame.action is not None:
                state_times.append(frame.state.timestamp_in_seconds)
        return {
            "time_diff": (np.array(state_times[1:]), np.diff(state_times), '.-'),
        }

    @property
    def title(self) -> str:
        return "Planner Runtime"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Planner Runtime"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class SearchIterationsPlot(ITimePlot):
    """
    Plots search number of iterations
    """
    @classmethod
    def get_data_to_plot(cls,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        state_times_shallow = []
        search_iterations_shallow = []
        state_times_deep = []
        search_iterations_deep = []

        _, finish_to_start = master_parser.canonic_sequence_parser.get_deep_search_connections()

        for frame in canonic_sequence:
            if frame.state is not None and frame.execution_info is not None:
                if frame.execution_info.s_Data.e_b_IsShallowSearchInitiated:
                    state_times_shallow.append(frame.state.timestamp_in_seconds)
                    search_iterations_shallow.append(frame.execution_info.s_Data.e_i_ShallowSearchIterations)

                if frame.execution_info.s_Data.e_b_IsDeepSearchFinished:
                    deep_search_start_frame = finish_to_start[frame.state.frame_id]
                    if deep_search_start_frame is not None:
                        start_frame = master_parser.canonic_sequence_parser[deep_search_start_frame]
                        if start_frame.state:
                            state_times_deep.append(start_frame.state.timestamp_in_seconds)
                            search_iterations_deep.append(frame.execution_info.s_Data.e_i_DeepSearchIterations)
        return {
            "search_iterations_shallow": (np.array(state_times_shallow), np.array(search_iterations_shallow), '.'),
            "search_iterations_deep": (np.array(state_times_deep), np.array(search_iterations_deep), '.'),
        }

    @property
    def title(self) -> str:
        return "Search Iterations"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Search Iterations"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class LocalizationErrorTimePlot(ITimePlot):
    """
    Plots the localization error of a plot (helps understanding if a replan should occur)
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        diff = []
        for frame_idx, frame in enumerate(canonic_sequence):
            if frame.state is not None:
                actual_loc = frame.state.cartesian_state[[types.C_X, types.C_Y]]

                expected_trj = None
                if frame.internal_state is not None:
                    internal_state_data: TsSYSDataPlannerInternalState = frame.internal_state.s_Data
                    if internal_state_data.e_b_InitialDrivingPlanValid:
                        if frame_idx > 0:
                            prev_map = canonic_sequence[frame_idx-1].state.map
                        else:
                            continue
                        try:
                            expected_trj = DrivingPlanDeserializer.deserialize(internal_state_data.s_InitialDrivingPlan, prev_map).to_samplable_trajectory()
                        except Exception:
                            pass

                if expected_trj is not None:
                    try:
                        determinized_time = Determinizer.determinize_time(frame.state.timestamp_in_seconds)
                        expected_cstate = expected_trj.sample(np.array([determinized_time]))[0]
                        times.append(determinized_time)
                        loc_error = expected_cstate[[types.C_X, types.C_Y]] - actual_loc
                        cos_yaw, sin_yaw = np.cos(expected_cstate[types.C_YAW]), np.sin(expected_cstate[types.C_YAW])
                        direction = np.array([cos_yaw, sin_yaw])
                        normal = np.array([-sin_yaw, cos_yaw])
                        loc_error = np.array([np.dot(loc_error, direction), np.dot(loc_error, normal)])

                        diff.append(loc_error)
                    except Exception:
                        pass

        diff = np.array(diff).reshape((-1, 2))
        return {
            "Longitudinal": (np.array(times), diff[:, 0], '.-'),
            "Lateral": (np.array(times), diff[:, 1], '.-'),
        }

    @property
    def title(self) -> str:
        return "Localization error"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "LocDiffToExpected"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class ExpectedActualTrjPlotType(Enum):
    SinglePoint = 0             # Plots a single point (current timestamp) per trajectory output
    MultiplePoints = 1          # Plots multiple points in the future for each trajectory
    Trajectory = 2              # Plots the entire trajectory up to 3 seconds


class ExpectedActualTrjTimePlot(ITimePlot):
    """
    Plots comparison between actual and expected trajectory. This is a base class for different plots for each field in
    the cartesian state of the host
    """
    def __init__(self, plot_type: ExpectedActualTrjPlotType = ExpectedActualTrjPlotType.SinglePoint):
        self._plot_type = plot_type

    @property
    @abstractmethod
    def field_name(self) -> Union[str, List[str]]:
        raise NotImplementedError

    @property
    @abstractmethod
    def field_idx(self) -> Union[str, List[str]]:
        raise NotImplementedError

    @property
    def is_frenet(self) -> bool:
        return False

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        return self.get_data(canonic_sequence)

    def get_data(self,
                 canonic_sequence: CanonicSequence,
                 ) -> Dict[str, Union[Tuple, List]]:

        plot_desc_dict = {}
        field_idxs = [self.field_idx] if isinstance(self.field_idx, int) else self.field_idx
        field_names = [self.field_name] if isinstance(self.field_name, str) else self.field_name
        assert len(field_idxs) == len(field_names)
        for (field_idx, field_name) in zip(field_idxs, field_names):
            actual = []
            actual_times = []
            offsets = [0, 5, 10, 15]
            expected = []
            expected_times = []
            expected_offsets_plots = [[] for _ in offsets]
            expected_trajectory_plots = []
            expected_trj = None
            for frame_idx, frame in enumerate(canonic_sequence):
                if frame.state is not None:
                    # Add to actual data
                    if self.is_frenet:
                        actual.append(frame.state.lane_center_frenet_state[field_idx])
                    else:
                        actual.append(frame.state.cartesian_state[field_idx])
                    determinized_time = Determinizer.determinize_time(frame.state.timestamp_in_seconds)
                    actual_times.append(determinized_time)

                    # If expected trajectory exists, generate expected data as well
                    if expected_trj is not None:
                        # In case a single point is desired, sample the trajectory at the required location and add to
                        # expected data
                        if self._plot_type == ExpectedActualTrjPlotType.SinglePoint:
                            if self.is_frenet:
                                expected.append(expected_trj.sample_frenet(np.array([determinized_time]))[0, field_idx])
                            else:
                                expected.append(expected_trj.sample(np.array([determinized_time]))[0, field_idx])
                            expected_times.append(determinized_time)
                        elif self._plot_type == ExpectedActualTrjPlotType.MultiplePoints:
                            expected_times.append(determinized_time)
                            for offset_idx, offset in enumerate(offsets):
                                t = determinized_time + TRAJECTORY_TIME_RESOLUTION * offset
                                if expected_trj.timestamp_in_sec < t < expected_trj.max_sample_time:
                                    if self.is_frenet:
                                        field = (expected_trj.sample_frenet(np.array([t]))[0, field_idx])
                                    else:
                                        field = (expected_trj.sample(np.array([t]))[0, field_idx])
                                    expected_offsets_plots[offset_idx].append(field)
                                else:
                                    expected_offsets_plots[offset_idx].append(np.nan)
                        elif self._plot_type == ExpectedActualTrjPlotType.Trajectory:
                            t = determinized_time + np.arange(TRAJECTORY_NUM_POINTS) * TRAJECTORY_TIME_RESOLUTION
                            t = t[t < expected_trj.max_sample_time]
                            t = t[t > expected_trj.timestamp_in_sec]
                            if self.is_frenet:
                                expected_trajectory_plots.append((t, expected_trj.sample_frenet(t)[:, field_idx], '-'))
                            else:
                                expected_trajectory_plots.append((t, expected_trj.sample(t)[:, field_idx], '-'))

                    if plan_exists(frame.action):
                        try:
                            expected_trj = frame.action.trajectory
                        except Exception:
                            expected_trj = None
                    else:
                        expected_trj = None

            plot_desc_dict[f"actual_{field_name}"] = (np.array(actual_times), np.array(actual), '.-')

            if self._plot_type == ExpectedActualTrjPlotType.SinglePoint:
                plot_desc_dict[f"expected_{field_name}"] = (np.array(expected_times), np.array(expected), '.-')

            elif self._plot_type == ExpectedActualTrjPlotType.MultiplePoints:
                expected_times = np.array(expected_times)
                for idx, offset in enumerate(offsets):
                    plot_desc_dict["expected_{}_{}".format(field_name, offset)] = (np.array(expected_times),
                                                                    np.array(expected_offsets_plots[idx]),
                                                                    '.-'
                                                                    )

            elif self._plot_type == ExpectedActualTrjPlotType.Trajectory:
                plot_desc_dict[f"expected_{field_name}"] = expected_trajectory_plots

        return plot_desc_dict

    @property
    def title(self) -> str:
        return self.field_name

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return self.field_name

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class LocationXPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Location X [m]"

    @property
    def field_idx(self) -> int:
        return types.C_X


class LocationYPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Location Y [m]"

    @property
    def field_idx(self) -> int:
        return types.C_Y


class VelocityPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Velocity [m/s]"

    @property
    def field_idx(self) -> int:
        return types.C_V


class AccelerationPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Acceleration [m/ss]"

    @property
    def field_idx(self) -> int:
        return types.C_A


class CurvaturePlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Curvature [1/m]"

    @property
    def field_idx(self) -> int:
        return types.C_K


class YawPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Yaw [rad]"

    @property
    def field_idx(self) -> int:
        return types.C_YAW


class EgoCurveSpeedLimitPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "curvature"

    @property
    def field_idx(self) -> int:
        return types.C_K

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        desc_dict = self.get_data(canonic_sequence=canonic_sequence)
        abs_k = np.abs(desc_dict["expected_curvature"][1])
        max_lateral_accel = Config().ego.max_lateral_acceleration_interpolator(1. / (abs_k + EPS_CURVE))
        curv_max_v = np.sqrt(max_lateral_accel / (abs_k + EPS_CURVE))
        curv_max_v = np.where(curv_max_v < 50., curv_max_v, np.nan)

        plot_desc_dict = {"expected_curv_max_speed": (desc_dict["expected_curvature"][0], curv_max_v, '.-')
                          }

        return plot_desc_dict

    @property
    def title(self) -> str:
        return "Curve Speed Control Limit"

    @property
    def y_label(self) -> str:
        return "Curve Speed Control Limit"


class LateralOffsetPlot(ExpectedActualTrjTimePlot):
    @property
    def field_name(self) -> str:
        return "Lateral Offset [m]"

    @property
    def field_idx(self) -> int:
        return types.FS_DX

    @property
    def is_frenet(self) -> bool:
        return True


class LateralAccelerationPlot(ExpectedActualTrjTimePlot):

    @property
    def field_name(self) -> List[str]:
        return ["curvature", "velocity"]

    @property
    def field_idx(self) -> List[int]:
        return [types.C_K, types.C_V]

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        data_dict = self.get_data(canonic_sequence)

        lat_acc_actual = data_dict["actual_velocity"][1]**2 * data_dict["actual_curvature"][1]
        lat_acc_expected = data_dict["expected_velocity"][1]**2 * data_dict["expected_curvature"][1]

        # linear interpolate the config table
        abs_k = np.abs(data_dict["expected_curvature"][1])
        max_lat_acc = Config().ego.max_lateral_acceleration_interpolator(1. / (abs_k + EPS_CURVE))
        max_lat_acc *= np.sign(lat_acc_expected)

        plot_desc_dict = {"actual": (data_dict["actual_velocity"][0], lat_acc_actual, '.-'),
                          "expected": (data_dict["expected_velocity"][0], lat_acc_expected, '.-'),
                          "limit": (data_dict["expected_curvature"][0], max_lat_acc, '--')
                          }

        return plot_desc_dict

    @property
    def title(self) -> str:
        return "Lateral Acceleration"

    @property
    def y_label(self) -> str:
        return "Lateral Acceleration"


class LateralJerkPlot(ExpectedActualTrjTimePlot):

    @property
    def field_name(self) -> List[str]:
        return ["curvature", "velocity"]

    @property
    def field_idx(self) -> List[int]:
        return [types.C_K, types.C_V]

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        data_dict = self.get_data(canonic_sequence)

        lat_acc_actual = data_dict["actual_velocity"][1] ** 2 * data_dict["actual_curvature"][1]
        actual_times = data_dict["actual_velocity"][0]

        lat_acc_expected = data_dict["expected_velocity"][1] ** 2 * data_dict["expected_curvature"][1]
        expected_times = data_dict["expected_velocity"][0]

        lat_jerk_actual = np.diff(lat_acc_actual) / np.diff(actual_times)
        lat_jerk_expected = np.diff(lat_acc_expected) / np.diff(expected_times)

        plot_desc_dict = {"actual": (actual_times[1:], lat_jerk_actual, '.-'),
                          "expected": (expected_times[1:], lat_jerk_expected, '.-'),
                          }

        return plot_desc_dict

    @property
    def title(self) -> str:
        return "Lateral Jerk"

    @property
    def y_label(self) -> str:
        return "Lateral Jerk"


class JerkPlot(ExpectedActualTrjTimePlot):

    @property
    def field_name(self) -> str:
        return "acceleration"

    @property
    def field_idx(self) -> int:
        return types.C_A

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        data_dict = self.get_data(canonic_sequence)

        jerk_actual = np.diff(data_dict["actual_acceleration"][1]) / np.diff(data_dict["actual_acceleration"][0])
        jerk_expected = np.diff(data_dict["expected_acceleration"][1]) / np.diff(data_dict["expected_acceleration"][0])

        plot_desc_dict = {"actual": (data_dict["actual_acceleration"][0][1:], jerk_actual, '.-'),
                          "expected": (data_dict["expected_acceleration"][0][1:], jerk_expected, '.-')
                          }

        return plot_desc_dict

    @property
    def title(self) -> str:
        return "Jerk"

    @property
    def y_label(self) -> str:
        return "Jerk"


class DriverPathTopViewData(ITopViewData):
    """
    Top view additional information that overlays the driver path
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser) -> Dict[str, Union[Tuple, List]]:
        engaged_locations = []
        disengaged_locations = []

        for frame in canonic_sequence:
            if frame.state is not None:
                state = frame.state
                if state.is_ttc_engaged:
                    engaged_locations.append(state.cartesian_state[[types.C_X, types.C_Y]])
                else:
                    disengaged_locations.append(state.cartesian_state[[types.C_X, types.C_Y]])

        out_dict = {}

        if engaged_locations:
            engaged_locations = np.array(engaged_locations)
            out_dict["engaged_location"] = (engaged_locations[:, 0], engaged_locations[:, 1], 'g.-')
        if disengaged_locations:
            disengaged_locations = np.array(disengaged_locations)
            out_dict["disengaged_location"] = (disengaged_locations[:, 0], disengaged_locations[:, 1], 'r.-')

        return out_dict


class FrameIDTimePlot(ITimePlot):
    """
    Time plot that shows the frame id per time
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        frame_ids = []
        for frame in canonic_sequence:
            if frame.state is not None:
                times.append(frame.state.timestamp_in_seconds)
                frame_ids.append(frame.state.frame_id)

        return {
            "frame_id": (np.array(times), np.array(frame_ids), '.-'),
        }

    @property
    def title(self) -> str:
        return "Frame ID"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Frame ID"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class PlannerActionTypeTimePlot(ITimePlot):
    """
    Time plot that shows the planner action per time
    """
    def __init__(self):
        self._type_to_val_mapper = {}

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        action_type_composite = []
        next_int = 0
        for frame in canonic_sequence:
            if plan_exists(frame.action):
                for action in self._get_actions_to_plot(frame):
                    now = frame.state.timestamp_in_seconds
                    times.append(now)
                    composite_value = action.action_type.longitudinal.value * 100 + action.action_type.lateral.value
                    action_type_composite.append(composite_value)
                    if composite_value not in self._type_to_val_mapper:
                        self._type_to_val_mapper[composite_value] = next_int
                        next_int += 1

        action_type_composite = np.array(action_type_composite)
        for key in sorted(self._type_to_val_mapper.keys()):
            # sorting is required to start from value of 0 (Default).
            # otherwise another type will be mapped to 0 and then 0 will be mapped to something else
            action_type_composite[action_type_composite == key] = self._type_to_val_mapper[key]

        return {
            "action_type_composite": (np.array(times), np.array(action_type_composite), self.marker_type + 'b'),
        }

    @classmethod
    def _get_actions_to_plot(cls, frame: CanonicFrame) -> List[IMDPAction]:
        now = frame.state.timestamp_in_seconds
        action = frame.action.driving_plan.get_action(now)
        return [] if action is None else [action]

    @property
    def marker_type(self) -> str:
        return '.-'

    @property
    def title(self) -> str:
        return "Action type"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "ActionType"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        full_lon_names = [t.name for t in LongitudinalComponentType]
        pattern = "[aeiu]"
        short_lon_names = [re.sub(pattern, "", full_name) for full_name in full_lon_names]
        shorter_lon_names = [n[0:6] for n in short_lon_names]
        full_lat_names = [t.name for t in LateralComponentType]
        short_lat_names = [re.sub(pattern, "", full_name) for full_name in full_lat_names]
        shorter_lat_names = [n[0:6] for n in short_lat_names]
        keys = self._type_to_val_mapper.keys()
        return [shorter_lon_names[int(key/100)] for key in keys], [shorter_lat_names[int(key % 100)] for key in keys]


class PlannerAllActionTypesTimePlot(PlannerActionTypeTimePlot):
    """
    Time plot that shows all planner action types in driving plan per time
    """
    @classmethod
    def _get_actions_to_plot(cls, frame: CanonicFrame) -> List[IMDPAction]:
        return frame.action.driving_plan.actions

    @property
    def marker_type(self) -> str:
        return '.'

    @property
    def title(self) -> str:
        return "All Action types"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "AllActionTypes"

    @property
    def show_legend(self) -> bool:
        return False


class PlannerActionVelocityDurationTimePlot(ITimePlot):
    """
    Time plot that shows the planner action target velocity per time
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        action_velocity = []
        action_duration = []
        time_since_generation = []
        for frame in canonic_sequence:
            if plan_exists(frame.action):
                now = frame.state.timestamp_in_seconds
                action = frame.action.driving_plan.get_action(now)
                if action is None:
                    continue
                assert isinstance(action, WerlingMDPAction)
                times.append(now)
                action_velocity.append(action.longitudinal_component.motion_plan.v_T)
                action_duration.append(action.longitudinal_component.duration + action.longitudinal_component.start - now)
                time_since_generation.append(now - action.generation_time)

        return {
            "action_velocity": (np.array(times), np.array(action_velocity), '.-r'),
            "action_duration": (np.array(times), np.array(action_duration), '.-g'),
            "time_since_generation": (np.array(times), np.array(time_since_generation), '.-b')
        }

    @property
    def title(self) -> str:
        return "Action Velocity [m/s], Duration [sec]"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Velocity/Horizon"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class LaneSpeedPlot(ITimePlot):
    """
    Time plot that shows the lane speed and goal speed (lane speed+driver set speed) per time, based on ego lane
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        lane_speeds = []
        goal_speeds = []
        curv_max_speeds = []
        for frame in canonic_sequence:
            state = frame.state
            if state is None:
                continue
            fstate = state.lane_center_frenet_state        # [FS_SX, FS_SV, FS_SA, FS_DX, FS_DV, FS_DA]
            current_lane_id, frenet_state = state.lane_center_frenet_frame.convert_to_segment_state(fstate)
            lane_segment = state.map.get_lane_segment_by_id(current_lane_id)
            lane_speed = lane_segment.lane_max_speed
            goal_speed = state.get_goal_speed(current_lane_id)

            abs_k = np.abs(state.cartesian_state[types.C_K])
            max_lateral_accel = Config().ego.max_lateral_acceleration_interpolator(1. / (abs_k + EPS_CURVE))
            curv_max_v = np.sqrt(max_lateral_accel / (abs_k + EPS_CURVE))
            curv_max_v = np.where(abs_k > FRENET_NEGLIGIBLE_CURVATURE, curv_max_v, np.nan)

            times.append(state.timestamp_in_seconds)
            lane_speeds.append(lane_speed)
            goal_speeds.append(goal_speed)
            curv_max_speeds.append(curv_max_v)

        return {'lane_speed': (np.array(times), np.array(lane_speeds), ':'),
                'goal_speed': (np.array(times), np.array(goal_speeds), '--'),
                'curv_max_speed': (np.array(times), np.array(curv_max_speeds), '--')}

    @property
    def title(self) -> str:
        return 'lane speed'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Lane speed"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class AccelerationLimitPlot(ITimePlot):
    """
    Time plot that shows the maximum allowed acceleration per time, as derived from curvature and goal speed
    Acceleration specification is also shown, sampled from the spec table according to goal speed
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        acc_limits = []
        acc_specs = []
        for frame in canonic_sequence:
            state = frame.state
            if state is None:
                continue
            times.append(state.timestamp_in_seconds)
            curr_v = state.cartesian_state[types.C_V]
            ego_segment_id = state.lane_center_frenet_frame.get_segment_ids_from_s(state.lane_center_frenet_state[[types.FS_SX]])[0]
            is_subdivision = state.map.get_lane_segment_by_id(ego_segment_id).is_subdivision
            if is_subdivision:
                acc_limit = Config().ego.max_longitudinal_acceleration_sd_interpolator(curr_v)
            else:
                acc_limit = Config().ego.max_longitudinal_acceleration_default_interpolator(curr_v)
            acc_limits.append(acc_limit)

            # TODO: Sample by action target velocity instead of by goal speed
            fstate = state.lane_center_frenet_state        # [FS_SX, FS_SV, FS_SA, FS_DX, FS_DV, FS_DA]
            current_lane_id, frenet_state = state.lane_center_frenet_frame.convert_to_segment_state(fstate)
            goal_speed = state.get_goal_speed(current_lane_id)
            a_spec = acceleration_profile.sample_a_spec(curr_v, goal_speed, is_subdivision)
            acc_specs.append(a_spec)

        return {'acc_limit': (np.array(times), np.array(acc_limits), '--'),
                'acc_spec': (np.array(times), np.array(acc_specs), ':')}

    @property
    def title(self) -> str:
        return 'acceleration limit'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Acceleration limit"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class TrajectoryDurationTimePlot(ITimePlot):
    """
    Time plot that shows the trajectory duration
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        times = []
        trj_duration = []
        for frame in canonic_sequence:
            state = frame.state
            if state is None:
                continue
            if plan_exists(frame.action):
                times.append(state.timestamp_in_seconds)
                trj_duration.append(frame.action.driving_plan.end_time - frame.action.driving_plan.start_time)

        return {'trj_duration': (np.array(times), np.array(trj_duration), '-'),
                'minimum': (np.array([times[0], times[-1]]), np.ones(2) * Config().mcts.handoff_trajectory_min_duration, '-r'),
                }

    @property
    def title(self) -> str:
        return 'lane trj_duration'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Trj Duration"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None
