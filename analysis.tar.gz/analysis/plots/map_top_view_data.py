from typing import Dict, Union, Tuple, List

import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITopViewData
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence


class MapTopViewData(ITopViewData):
    """
    Overlays the map in a top view image
    """
    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        left_border = np.empty((0, 2))
        right_border = np.empty((0, 2))

        drawn_lane_ids = set()
        for frame in canonic_sequence:
            if frame.state is not None:
                state = frame.state
                fstate = state.lane_center_frenet_state
                current_lane_id, lane_frenet_state = state.lane_center_frenet_frame.convert_to_segment_state(fstate)
                lane_segment = state.map.get_lane_segment_by_id(current_lane_id)
                if current_lane_id not in drawn_lane_ids:
                    drawn_lane_ids.add(current_lane_id)
                    left_border = np.concatenate((left_border, lane_segment.left_border), axis=0)
                    right_border = np.concatenate((right_border, lane_segment.right_border), axis=0)

        out_dict = {}

        out_dict.update({
            "left_border": (left_border[:, 0], left_border[:, 1], 'k-'),
            "right_border": (right_border[:, 0], right_border[:, 1], 'k-'),
        })

        return out_dict