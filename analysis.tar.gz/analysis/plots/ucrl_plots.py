import numpy as np

from typing import Dict, Tuple, List, Optional

from decision_making.src.rl_agent.global_types import LateralDirection
from subdivision_learning.analysis.plots.plot_interfaces import RecordingsBasedPlot
from subdivision_planner.src.common.types import FS_DX, FS_SA, FS_SV
from subdivision_planner.src.lba_main import PLANNING_MODULE_PERIOD


class ValueFunctionTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        filtered_data = self._filter_recorded_data_by_field(record_data, '*/debug_info')
        return {'v(s)': self._get_time_based_metric_tuple(
            filtered_data, lambda d: d[self._get_planner_name(d)]['debug_info']['value'], '.-')
        }


    @property
    def title(self) -> str:
        return 'Value function'

    @property
    def y_label(self) -> str:
        return "Value"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class LateralPositionTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        filtered_data = self._filter_recorded_data_by_field(record_data, '*/debug_info')
        return {'lateral_offset': self._get_time_based_metric_tuple(
            filtered_data, lambda d: d[self._get_planner_name(d)]['debug_info']['ego_fstate'][FS_DX], '.-')
        }

    @property
    def ax_postprocessor(self):
        return lambda ax: ax.set_ylim(-3, 3)

    @property
    def title(self) -> str:
        return 'Lateral State'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "dx [m]"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class LateralDirectionEventTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        filtered_data = self._filter_recorded_data_by_field(record_data, '*/debug_info')

        return {
            'lateral_direction': self._get_time_based_metric_tuple(
                filtered_data, lambda d: d[self._get_planner_name(d)]['debug_info']['nudge_dir']+1, 'k*')
        }

    @property
    def title(self) -> str:
        return 'Lateral State'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Direction"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [str(val).split('.')[-1] for val in LateralDirection], None


class PlannedAccelerationTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        times = []
        accs = []
        for frame, contents in self._filter_recorded_data_by_field(record_data, '*/debug_info').items():
            planner = self._get_planner_name(contents)
            trajectory = contents[planner]['debug_info']['trajectory']
            timestamp = contents[planner]['debug_info']['current_sim_time']

            samples_times = np.arange(timestamp, timestamp + PLANNING_MODULE_PERIOD, 0.1)
            for time, acc in zip(samples_times, trajectory.sample_frenet(samples_times)[:, FS_SA]):
                times.append(time)
                accs.append(acc)

        return {'planned_acc': (np.array(times), np.array(accs), 'g-')}

    @property
    def ax_postprocessor(self):
        return lambda ax: ax.set_ylim(-6, 3.5)

    @property
    def title(self) -> str:
        return 'Planned Acceleration'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Acceleration [m/s^2]"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class PlannedVelocityTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        times = []
        vels = []
        for frame, contents in self._filter_recorded_data_by_field(record_data, '*/debug_info').items():
            planner = contents['PlanningModule']['planner']['active_planner']
            trajectory = contents[planner]['debug_info']['trajectory']
            timestamp = contents[planner]['debug_info']['current_sim_time']

            samples_times = np.arange(timestamp, timestamp + PLANNING_MODULE_PERIOD, 0.1)
            for time, vel in zip(samples_times, trajectory.sample_frenet(samples_times)[:, FS_SV]):
                times.append(time)
                vels.append(vel)

        return {'planned_vel': (np.array(times), np.array(vels), 'g-')}

    @property
    def ax_postprocessor(self):
        return lambda ax: ax.set_ylim(-2, 30)

    @property
    def title(self) -> str:
        return 'Planned Velocity'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Velocity [m/s]"

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class ActionSpecInfoTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        filtered_data = self._filter_recorded_data_by_field(record_data, '*/debug_info')

        return {
            'spec_t [s]': self._get_time_based_metric_tuple(
                filtered_data, lambda d: d[self._get_planner_name(d)]['debug_info']['action_horizon'], '.-'),
            'spec_v [m/s]': self._get_time_based_metric_tuple(
                filtered_data, lambda d: d[self._get_planner_name(d)]['debug_info']['action_target_velocity'], '.-')
        }

    @property
    def kwargs(self) -> Dict:
        return {'alpha': 0.7}

    @property
    def ax_postprocessor(self):
        def postprocess(ax):
            ax.set_ylim(-2, 37)
            ax.yaxis.set_ticks(np.arange(0, 37, 5))
        return postprocess

    @property
    def title(self) -> str:
        return 'Action spec information'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return ''

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class LaneChangeStateTimePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        def extract_status_value(data):
            planner = self._get_planner_name(data)
            return data[planner]['debug_info']['lane_change_state'].is_committing * 3 + \
                   data[planner]['debug_info']['lane_change_state'].is_aborting * 2 + \
                   data[planner]['debug_info']['lane_change_state'].is_negotiating * 1

        filtered_data = self._filter_recorded_data_by_field(record_data, '*/debug_info/current_sim_time')
        return {'lane_change_state': self._get_time_based_metric_tuple(filtered_data, extract_status_value, 'k*-')}
    
    @property
    def title(self) -> str:
        return 'Lane Change State'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return 'States'

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return ['Lane Centering', 'Negotiating', 'Aborting', 'Committing'], None


class LaneChangeTimeSincePlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        timestamps = []
        time_since_vector = []
        for frame, contents in self._filter_recorded_data_by_field(record_data, '*/debug_info').items():
            planner = self._get_planner_name(contents)
            timestamp = contents[planner]['debug_info']['current_sim_time']
            timestamps.append(timestamp)
            time_since_vector.append(contents[planner]['debug_info']['lane_change_state'].time_since_vector(timestamp))

        return {'negotiating': (np.array(timestamps), np.array(time_since_vector)[:, 0], '*-'),
                'committing': (np.array(timestamps), np.array(time_since_vector)[:, 1], 'o-'),
                'aborting': (np.array(timestamps), np.array(time_since_vector)[:, 2], '.-')}

    @property
    def title(self) -> str:
        return 'Lane Change Time-Since'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return 'Time Passed [sec]'

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class ActivePlannerPlot(RecordingsBasedPlot):
    """ """

    def get_data_from_recordings(self, record_data: Dict):
        filtered_data = self._filter_recorded_data_by_field(record_data, 'PlanningModule/planner')
        return {'active_planner': self._get_time_based_metric_tuple(
            filtered_data, lambda d: self._get_planner_name(d), 'k*-')
        }

    @property
    def title(self) -> str:
        return 'Active Planner'

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return 'Planner'

    @property
    def show_legend(self) -> bool:
        return False

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None
