from abc import abstractmethod
from typing import Dict, Tuple, Union, List, Optional
import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot
from subdivision_planner.src.common import types
from subdivision_planner.src.mdp.state import MDPState, MDPContext
from subdivision_planner.src.mdp.werling.utils.follow_utils import get_min_safe_dist_front_from_dynamic_interpolator
from subdivision_planner.src.planners.concepts.actor_preprocessor import ActorPreprocessor
from subdivision_planner.src.utils.actor_utils import ActorUtils
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence

EPS = 1.e-5


class ActorTimeCartesianPlot(ITimePlot):
    @property
    @abstractmethod
    def field_name(self) -> Union[str, List[str]]:
        raise NotImplementedError

    @property
    @abstractmethod
    def field_idx(self) -> Union[str, List[str]]:
        raise NotImplementedError

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        return self.get_data(canonic_sequence)

    def get_data(self,
                 canonic_sequence: CanonicSequence,
                 ) -> Dict[str, Union[Tuple, List]]:
        time_horizon = 3.
        plot_desc_dict = {}
        field_idxs = np.atleast_1d(self.field_idx)
        field_names = np.atleast_1d(self.field_name)
        assert len(field_idxs) == len(field_names)
        for (field_idx, field_name) in zip(field_idxs, field_names):
            actual = {'ego': []}
            actual_times = {'ego': []}
            predicted_trajectory = {}
            actor_id = None
            times_value = []
            min_val, max_val = np.nan, np.nan
            for frame_idx, frame in enumerate(canonic_sequence):
                if frame.state is not None and frame.action is not None and frame.action.driving_plan is not None:
                    if frame.state.actors:
                        actors = frame.state.actors
                        actual['ego'].append(frame.state.cartesian_state[field_idx])
                        actual_times['ego'].append(frame.state.timestamp_in_seconds)
                    else:
                        continue
                    context = MDPContext()
                    mdp_state = MDPState.from_canonic_state(frame.state)
                    ActorPreprocessor().mark_actors_relative_longitudinal_position(actors, mdp_state)
                    ActorPreprocessor().mark_invasion(actors, context.gffs)
                    MDPContext().from_canonic_state(canonic_state=frame.state, driving_plan=frame.action.driving_plan)
                    constraining_actors_ahead, _, _ = \
                        ActorUtils.get_closest_k_constraining_dynamic_actors_at_root_state(context=MDPContext(),
                                                                                           actors=tuple(actors),
                                                                                           gff=frame.state.lane_center_frenet_frame,
                                                                                           k_ahead=1,
                                                                                           k_behind=0,
                                                                                           include_intersecting=False)

                    if len(constraining_actors_ahead) > 0:
                        if constraining_actors_ahead[0].id != actor_id and actor_id is not None and time_horizon > 0:
                            times_value.append(constraining_actors_ahead[0].start_time)
                        if actor_id != constraining_actors_ahead[0].id and str(constraining_actors_ahead[0].id) in actual:
                            t_complete = np.mean([actual_times[str(constraining_actors_ahead[0].id)][-1], constraining_actors_ahead[0].start_time])
                            actual[str(constraining_actors_ahead[0].id)].append(np.nan)
                            actual_times[str(constraining_actors_ahead[0].id)].append(t_complete)
                        actor_id = constraining_actors_ahead[0].id
                        start_time = constraining_actors_ahead[0].start_time
                        times = constraining_actors_ahead[0].times[:]
                        horizon = times[times < start_time + time_horizon]
                        if str(actor_id) in actual:
                            actual[str(actor_id)].append(constraining_actors_ahead[0].cstates[0, field_idx])
                            actual_times[str(actor_id)].append(start_time)
                            if time_horizon > 0:
                                predicted = constraining_actors_ahead[0].cstates[0:len(horizon), field_idx]
                                predicted_times = horizon
                                predicted_trajectory[str(actor_id)].append(tuple([predicted_times, predicted]))
                                max_val = max(max(predicted), max_val)
                                min_val = min(min(predicted), min_val)
                        else:
                            actual[str(actor_id)] = [constraining_actors_ahead[0].cstates[0, field_idx]]
                            actual_times[str(actor_id)] = [constraining_actors_ahead[0].start_time]
                            if time_horizon > 0:
                                predicted = constraining_actors_ahead[0].cstates[0:len(horizon), field_idx]
                                predicted_times = horizon
                                predicted_trajectory[str(actor_id)] = [tuple([predicted_times, predicted])]
                                max_val = max(max(predicted), max_val)
                                min_val = min(min(predicted), min_val)
            for key in actual.keys():
                max_val = max(max(actual[key]), max_val)
                min_val = min(min(actual[key]), min_val)
                plot_desc_dict[key] = (np.array(actual_times[key]), np.array(actual[key]), '.-')
                if key in predicted_trajectory:
                    plot_desc_dict[key + "predicted"] = predicted_trajectory[key]
            for time in times_value:
                dt = (max_val - min_val) * 1.e-4
                vertical_values = np.arange(min_val-dt, max_val+dt, dt)
                plot_desc_dict[str(time)] = (np.array(np.ones(len(vertical_values))*time), np.array(vertical_values), '--')

        return plot_desc_dict

    @property
    def title(self) -> str:
        return self.field_name

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return self.field_name

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class ActorLocationXPlot(ActorTimeCartesianPlot):
    @property
    def field_name(self) -> str:
        return "Location X [m]"

    @property
    def field_idx(self) -> int:
        return types.C_X


class ActorLocationYPlot(ActorTimeCartesianPlot):
    @property
    def field_name(self) -> str:
        return "Location Y [m]"

    @property
    def field_idx(self) -> int:
        return types.C_Y


class ActorVelocityPlot(ActorTimeCartesianPlot):
    @property
    def field_name(self) -> str:
        return "Velocity [m/s]"

    @property
    def field_idx(self) -> int:
        return types.C_V


class ActorAccelerationPlot(ActorTimeCartesianPlot):
    @property
    def field_name(self) -> str:
        return "Acceleration [m/ss]"

    @property
    def field_idx(self) -> int:
        return types.C_A


class ActorCurvaturePlot(ActorTimeCartesianPlot):
    @property
    def field_name(self) -> str:
        return "Curvature [1/m]"

    @property
    def field_idx(self) -> int:
        return types.C_K


class ActorYawPlot(ActorTimeCartesianPlot):
    @property
    def field_name(self) -> str:
        return "Yaw [rad]"

    @property
    def field_idx(self) -> int:
        return types.C_YAW


class ActorIDPlot(ITimePlot):
    def __init__(self):
        self._values_dict = {}

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:

        actor_id_dict = {}
        return_dict = {}
        counter = 0
        for frame in canonic_sequence:
            if frame.state is not None and frame.action is not None and frame.action.driving_plan is not None:
                now = frame.state.timestamp_in_seconds
                if frame.state.actors:
                    actors = frame.state.actors
                else:
                    continue
                context = MDPContext()
                mdp_state = MDPState.from_canonic_state(frame.state)
                ActorPreprocessor().mark_actors_relative_longitudinal_position(actors, mdp_state)
                ActorPreprocessor().mark_invasion(actors, context.gffs)
                MDPContext().from_canonic_state(canonic_state=frame.state, driving_plan=frame.action.driving_plan)
                constraining_actors_ahead, _, _ = \
                    ActorUtils.get_closest_k_constraining_dynamic_actors_at_root_state(context=MDPContext(),
                                                                                       actors=tuple(actors),
                                                                                       gff=frame.state.lane_center_frenet_frame,
                                                                                       k_ahead=1,
                                                                                       k_behind=0,
                                                                                       include_intersecting=False)
                if len(constraining_actors_ahead) > 0:
                    actor_id = str(constraining_actors_ahead[0].id)
                    if actor_id in actor_id_dict:
                        actor_id_dict[actor_id].append(now)
                    else:
                        actor_id_dict[actor_id] = [now]

        for key, val in actor_id_dict.items():
            return_dict[key] = (np.array(val), np.ones(len(val)) * counter, 'o')
            counter += 1

        self._values_dict = return_dict

        return return_dict

    @property
    def title(self) -> str:
        return "Actor"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return "Actor ID"

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return [key for key in self._values_dict.keys()], None


class ActorEgoRelationPlot(ITimePlot):

    def get_data_to_plot(self,
                         canonic_sequence: CanonicSequence,
                         master_parser: PubSubRecordingMasterParser
                         ) -> Dict[str, Union[Tuple, List]]:
        plot_desc_dict = {}
        dist_d = {}
        headway_d = {}
        time_d = {}
        relative_v_d = {}
        actor_id = 0
        for frame_idx, frame in enumerate(canonic_sequence):
            if frame.state is not None and frame.action is not None and frame.action.driving_plan is not None:
                if frame.state.actors:
                    actors = frame.state.actors
                    now = frame.state.timestamp_in_seconds
                else:
                    continue
                context = MDPContext()
                mdp_state = MDPState.from_canonic_state(frame.state)
                ActorPreprocessor().mark_actors_relative_longitudinal_position(actors, mdp_state)
                ActorPreprocessor().mark_invasion(actors, context.gffs)
                MDPContext().from_canonic_state(canonic_state=frame.state, driving_plan=frame.action.driving_plan)
                constraining_actors_ahead, _, _ = \
                    ActorUtils.get_closest_k_constraining_dynamic_actors_at_root_state(context=MDPContext(),
                                                                                       actors=tuple(actors),
                                                                                       gff=frame.state.lane_center_frenet_frame,
                                                                                       k_ahead=1,
                                                                                       k_behind=0,
                                                                                       include_intersecting=False)

                if len(constraining_actors_ahead) > 0:
                    actor = constraining_actors_ahead[0]
                    actor_fstate = actor.get_fstate(frenet_frame=frame.state.lane_center_frenet_frame, t=now)
                    current_dist = actor_fstate[types.FS_SX] - frame.state.lane_center_frenet_state[types.FS_SX]
                    actor_v = actor_fstate[types.FS_SV]
                    relative_v = actor_v - frame.state.lane_center_frenet_state[types.FS_SV]

                    # "bumper to bumper" distance
                    actor_lengths = actor.sizes[0, 0]
                    ego_lengths = Config().ego.size[0]
                    base_margin = (ego_lengths + actor_lengths) / 2.0
                    current_dist = current_dist - base_margin

                    # velocity dependent distance
                    min_safe_dist_front_from_dynamic_interpolator = \
                        get_min_safe_dist_front_from_dynamic_interpolator(frame.state.driver_options.headway)
                    bias_margin = min_safe_dist_front_from_dynamic_interpolator(actor_v)
                    headway = (current_dist - bias_margin)/(frame.state.lane_center_frenet_state[types.FS_SV] + EPS)

                    # this condition is to avoid connecting the points for different actors
                    if actor_id != actor.id and str(actor.id) in dist_d:
                        t_complete = np.mean([time_d[str(actor.id)][-1], now])
                        dist_d[str(actor.id)].append(np.nan)
                        headway_d[str(actor.id)].append(np.nan)
                        relative_v_d[str(actor.id)].append(np.nan)
                        time_d[str(actor.id)].append(t_complete)

                    actor_id = actor.id
                    if str(actor_id) not in dist_d:
                        dist_d[str(actor_id)] = []
                        headway_d[str(actor_id)] = []
                        relative_v_d[str(actor_id)] = []
                        time_d[str(actor_id)] = []

                    dist_d[str(actor_id)].append(current_dist)
                    headway_d[str(actor_id)].append(headway)
                    relative_v_d[str(actor_id)].append(relative_v)
                    time_d[str(actor_id)].append(now)

        for key in dist_d.keys():
            if self.field_name == "Longitudinal Distance [m]":
                plot_desc_dict[key] = (np.array(time_d[key]), np.array(dist_d[key]), '.-')
            elif self.field_name == "Headway [s]":
                plot_desc_dict[key] = (np.array(time_d[key]), np.array(headway_d[key]), '.-')
            elif self.field_name == "Relative V_s [m/s]":
                plot_desc_dict[key] = (np.array(time_d[key]), np.array(relative_v_d[key]), '.-')

        return plot_desc_dict

    @property
    def title(self) -> str:
        return "Actor Ego Relations"

    @property
    def x_label(self) -> str:
        return "Time [sec]"

    @property
    def y_label(self) -> str:
        return self.field_name

    @property
    def show_legend(self) -> bool:
        return True

    @property
    def y_tick(self) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        return None, None


class ActorDistancePlot(ActorEgoRelationPlot):
    @property
    def field_name(self) -> str:
        return "Longitudinal Distance [m]"


class ActorHeadwayPlot(ActorEgoRelationPlot):
    @property
    def field_name(self) -> str:
        return "Headway [s]"


class ActorRelativeVelocityPlot(ActorEgoRelationPlot):
    @property
    def field_name(self) -> str:
        return "Relative V_s [m/s]"
