import numpy as np
import matplotlib.pyplot as plt
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser

from subdivision_learning.analysis.plots.plot_interfaces import ITimePlot, ITopViewData, RecordingsBasedPlot
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
from typing import Dict


class MatplotlibPlotter:
    """
    This class performs plotting as defined by different plot interfaces into a matplotlib frontend. It currently
    supports time based graph and top view based graph. The actual graphs are defined in a separate interface
    """
    @classmethod
    def plot_time_graph(cls,
                        axes: plt.Axes,
                        canonic_sequence: CanonicSequence,
                        master_parser: PubSubRecordingMasterParser,
                        plot: ITimePlot,
                        title_per_plot: bool = True,
                        reference_time: float = None,
                        record_data: Dict = None,
                        **kwargs):
        """
        Plots a time based graph according to an ITimePlot received
        :param axes: axes to plot on
        :param canonic_sequence: CanonicSequence to get data from
        :param master_parser: PubSubRecordingMasterParser that can be used to extract additional data from recording
        :param plot: Actual plot to use for plotting. This is what defines the plot
        :param title_per_plot: if True, a title will be generated for every plot
        :param reference_time: if this is not None, plots will be generated with time relative to reference time
        :param record_data: data recorded from planner for plots based on Recorder outputs
        :param kwargs: additional keyword arguments to pass to matplotlib plot
        """
        data_dict = plot.get_data_from_recordings(record_data) if isinstance(plot, RecordingsBasedPlot) else \
            plot.get_data_to_plot(canonic_sequence=canonic_sequence, master_parser=master_parser)

        use_legend = True
        for label, plot_data in data_dict.items():
            if isinstance(plot_data, tuple) and isinstance(plot_data[0], np.ndarray):
                if reference_time is not None:
                    t = plot_data[0]
                    t -= reference_time
                axes.plot(*plot_data, label=label, **kwargs)
            elif isinstance(plot_data, list) and len(plot_data) and isinstance(plot_data[0], tuple):
                use_legend = False
                for plot_tup in plot_data:
                    if reference_time is not None:
                        t = plot_tup[0]
                        t -= reference_time
                    axes.plot(*plot_tup, **kwargs)
        if use_legend and plot.show_legend:
            legend = axes.legend()
            legend.set_draggable(True)
        axes.grid()
        if title_per_plot:
            axes.set_title(plot.title)
        axes.set_xlabel(xlabel=plot.x_label)
        axes.set_ylabel(ylabel=plot.y_label)
        tick_1, tick_2 = plot.y_tick
        len1 = len(tick_1) if tick_1 is not None else 0
        len2 = len(tick_2) if tick_2 is not None else 0
        max_len = max(len1, len2)
        min_len = min(len1, len2)
        if max_len > 0:
            ticks = [val1 + "," + val2 for val1, val2 in zip(tick_1[:min_len], tick_2[:min_len])] if min_len > 0 else []
            if len1 > len2:
                ticks += tick_1[min_len:max_len]
            else:
                ticks += tick_2[min_len:max_len]
            plt.yticks(np.arange(max_len), ticks)

    @classmethod
    def plot_top_view_graph(cls,
                            axes: plt.Axes,
                            canonic_sequence: CanonicSequence,
                            master_parser: PubSubRecordingMasterParser,
                            top_view_data: ITopViewData,
                            show_legend: bool,
                            **kwargs):
        """
        This method adds data to top view image according to top_view_data and additional input data
        :param axes: axes to plot on
        :param canonic_sequence: CanonicSequence to extract data from
        :param master_parser: PubSubRecordingMasterParser that can be used to extract additional data from recording
        :param top_view_data: Abstracts extraction of top view data from canonic sequence
        :param show_legend: If True a legend will be shown
        :param kwargs: All additional kwargs will be passed to plot
        """
        # Extract data from top_view_data
        data_dict = top_view_data.get_data_to_plot(canonic_sequence=canonic_sequence, master_parser=master_parser)
        for label, plot_tup in data_dict.items():
            axes.plot(*plot_tup, label=label, **kwargs)
        axes.set_aspect("equal")
        if show_legend:
            legend = axes.legend()
            legend.set_draggable(True)

        # Set width to be the same on both axes
        axes = plt.gca()
        min_x, max_x = axes.get_xlim()
        center_x = (min_x + max_x) / 2
        width_x = max_x - min_x
        min_y, max_y = axes.get_ylim()
        center_y = (min_y + max_y) / 2
        width_y = max_y - min_y

        width = max(width_x, width_y)
        min_x, max_x = center_x - width / 2, center_x + width / 2
        min_y, max_y = center_y - width / 2, center_y + width / 2
        axes.set_xlim(min_x, max_x)
        axes.set_ylim(min_y, max_y)
        axes.grid('True')

