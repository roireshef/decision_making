#! /bin/bash
sudo jupyter nbextension enable --py --sys-prefix bqplot
sudo jupyter nbextension enable --py widgetsnbextension --sys-prefix
sudo jupyter serverextension enable voila --sys-prefix

export PATH=$PATH:~/.local/bin

voila tree_visualizer.ipynb

