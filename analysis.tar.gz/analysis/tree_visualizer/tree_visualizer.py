import copy
import functools
import traceback
from logging import Logger
from typing import Union, Tuple, Optional, List, Callable

import ipywidgets as widgets
import networkx as nx
import numpy as np
import pandas as pd
from IPython.display import display, clear_output
from bqplot import LinearScale, Graph, Tooltip, Figure, Toolbar, OrdinalScale, ColorScale, Axis, GridHeatMap
from networkx.drawing.nx_agraph import graphviz_layout
from subdivision_planner.src.reward import calc_discount_factors
from subdivision_planner.src.mdp.state import MDPState
from subdivision_planner.src.mdp.werling.action import WerlingMDPAction
from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_learning.analysis.scripts import analyze_coverage
from subdivision_learning.analysis.scripts.analyze_coverage import get_action_spec_trials, is_state_valid, \
    determine_state_failure_reason, determine_action_spec_failure_reason
from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
from subdivision_learning.analysis.utils.search_tree import traverse_tree, TreeNode
from subdivision_learning.analysis.utils.searcher_mock import SearcherMock
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.recorder import DummyRecorder
from subdivision_planner.src.data_structures.motion_plan.poly1d_solutions import PolyType
from subdivision_planner.src.mcts.searcher import Searcher
from subdivision_planner.src.mcts.uct_node import UCTNode
from subdivision_planner.src.mdp.experience import MDPExperience
from subdivision_planner.src.mdp.iaction import IMDPAction
from subdivision_planner.src.mdp.iaction_spec import IMDPActionSpec
from subdivision_planner.src.mdp.state import MDPContextImp, MDPContext
from subdivision_planner.src.mdp.werling.action_spec import WerlingMDPActionSpec, GeneratedWerlingActionSpec
from subdivision_planner.src.mdp.werling.aggregate_action_validators import AggregateWerlingActionValidator
from subdivision_planner.src.mdp.werling.component_spec import GeneratedWerlingComponentSpec
from subdivision_planner.src.mdp.werling.debug_probe import ActionDebugProbe
from subdivision_planner.src.mdp.werling.return_calculator import WerlingMDPReturnCalculator
from subdivision_planner.src.utils.debug import get_logger
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame

COLOR_NODE_ROOT = 'deepskyblue'
COLOR_NODE_PREV_SEARCH_BEST_EXP = 'blue'
COLOR_NODE_PREV_SEARCH = 'darkturquoise'
COLOR_NODE_BEST_EXP = 'pink'
COLOR_NODE_VALID = 'green'
COLOR_NODE_INVALID = 'red'
COLOR_ACTION_SPEC_VALID_NO_CHILDREN = 'yellow'
COLOR_NODE_NO_PARENT = 'orange'
COLOR_NODE_UNGENERATED = 'gray'


def alternative_get_result(self) -> Tuple[MDPExperience, float, int]:
    """
    This is an alternative implementation of the get result method that doesn't delete the root node of the searcher
    :return: best results, change best result to None so we don't think there are results waiting
    """
    exp, ret, iterations = self._best_experience, self._best_return, self._iterations_run
    self._best_experience, self._best_return, self._iterations_run = None, None, None

    return exp, ret, iterations


class InteractiveTreeLoader:
    """
    This class allows interactively regenerate search tree using a canonic sequence parser. It allows registration of
    callbacks to be run after a new tree was loaded
    """
    def __init__(self, canonic_sequence_parser: ICanonicSequenceParser, logger: Logger = None):
        """
        :param canonic_sequence_parser: ICanonicSequenceParser to be used to read data
        :param logger: Optional logger, if one is not given, a logger is generated
        """
        self.parser = canonic_sequence_parser

        if logger is None:
            logger = get_logger()

        self.deep_searcher = SearcherMock(recorder=DummyRecorder(), logger=logger, name="DeepSearcher")
        self.deep_searcher.get_result = functools.partial(alternative_get_result, self=self.deep_searcher)
        self.shallow_searcher = SearcherMock(recorder=DummyRecorder(), logger=logger, name="ShallowSearcher")
        self.shallow_searcher.get_result = functools.partial(alternative_get_result, self=self.shallow_searcher)
        # Provide an alternative get result function so that root node is not deleted once we get the new results so that
        # we can later use the searcher's root node and visualize it
        self.planner_runner = PlannerRunner(logger=logger,
                                            parser=self.parser,
                                            use_recorder=False,
                                            deep_searcher_mock=self.deep_searcher,
                                            shallow_searcher_mock=self.shallow_searcher)

        # The canonic frame that is currently used
        self._canonic_frame = None

        # This variable will hold the tree
        self._root_node = None

        # This variable will hold the best experience the search found
        self._best_experience = None

        # Callbacks to be called after a canonic frame is loaded
        self._canonic_frame_update_callbacks: List[Callable[[CanonicFrame], None]] = []

        # Callbacks to be called after a root node is updated
        self._search_update_callbacks: List[Callable[[UCTNode, MDPExperience], None]] = []

        # Widget for choice of frame to be loaded
        self.frame_slider_widget = widgets.interactive(lambda frame_num: self._load_data(frame_num),
                                                       frame_num=widgets.Select(options=self.parser.get_frame_ids(),)
                                                       )
        display(self.frame_slider_widget)

    def register_canonic_frame_update_callback(self, cb: Callable[[CanonicFrame], None]):
        """
        Registers a callback to be run after a new frame is loaded.
        :param cb: Callback
        """
        if cb not in self._canonic_frame_update_callbacks:
            self._canonic_frame_update_callbacks.append(cb)

    def register_search_update_callback(self, cb: Callable[[UCTNode], None]):
        """
        Registers a callback to be run after the root node is updated. This happens if the corresponding frame triggered
        a Shallow or Deep search
        :param cb: Callback
        """
        if cb not in self._search_update_callbacks:
            self._search_update_callbacks.append(cb)

    def _load_data(self, frame_id: int) -> None:
        """
        Reads relevant data from recordings and reruns planner runner to produce search result
        """

        # Reset canonic frame and root node
        self._canonic_frame = None
        self._root_node = None

        self._canonic_frame = self.parser[frame_id]
        if self._canonic_frame.state is not None:
            print(f"Loaded frame #{frame_id}, timestamp: {self._canonic_frame.state.timestamp_in_seconds}")
        else:
            print(f"Loaded frame #{frame_id} without valid canonic state")
            return

        _ = self.planner_runner.plan(frame_id, False)

        updated_searcher = None
        if self._canonic_frame.execution_info.s_Data.e_b_IsDeepSearchInitiated:
            print("Loaded root node for deep searcher")
            updated_searcher = self.deep_searcher

        if self._canonic_frame.execution_info.s_Data.e_b_IsShallowSearchInitiated:
            print("Loaded root node for shallow searcher")
            updated_searcher = self.shallow_searcher

        if updated_searcher is not None:
            self._root_node = updated_searcher._root_node
            assert self._root_node is not None, "Got an empty root node from searcher"
            self._best_experience, _ = updated_searcher.find_best_experience(self._root_node)

            for cb in self._search_update_callbacks:
                cb(self._canonic_frame, self._root_node, self._best_experience)

        else:
            print("Frame without search initialization")


class TreeVisualizer:
    def __init__(self):
        # Collect validator names from subdivision_planner
        self.longitudinal_validator_names = [type(validator).__name__ for validator in Searcher.create_longitudinal_component_validator()._validators]
        self.lateral_validator_names = [type(validator).__name__ for validator in Searcher.create_lateral_component_validator()._validators]
        self.action_validator_names = [type(validator).__name__ for validator in Searcher.create_action_validator()._validators]

        # Set analyze_coverage config path
        self._analyze_coverage_cfg = analyze_coverage.load_config()

        # Initialize ipython widgets
        self.heatmap_lon, self.heatmap_lat, self.heatmap_action = self._init_heatmap()
        self.rewards_table_hbox = self._init_rewards_table()
        self.search_table_hbox = self._init_search_table()
        self.trial_slider_hbox = self._init_trial_slider_hbox()
        self.tree_fig = self._init_tree_figure()
        self.failure_reason_hbox = widgets.HBox(children=(widgets.Label("Failure Reason: "), widgets.Label("")))

        # Save tree related objects for use by widgets
        self.G = None
        self._canonic_frame: CanonicFrame = None
        self._root_node: UCTNode = None
        self._selected_action_spec = None
        self._best_experience: MDPExperience = None

        # Draw widgets
        self._display_widgets()

    def update_search_result(self,
                             canonic_frame: CanonicFrame,
                             root_node: UCTNode,
                             best_experience: Optional[MDPExperience] = None,
                             hide_invalid: bool = False):
        """
        Updates visualization with new search results
        :param canonic_frame: current frame
        :param root_node: root node to hold the tree
        :param best_experience: Winning experience
        :param hide_invalid: If true, invalid actions won't be visualizaed
        :return: None
        """
        self._canonic_frame = canonic_frame
        self._root_node = root_node
        self._best_experience = best_experience
        self._update_tree_fig(hide_invalid=hide_invalid)

    def _init_tree_figure(self):
        """
        Create a figure that holds the graph that will be used for the tree
        :return: Figure
        """
        graph = Graph(link_type='line')

        # highlight selected nodes
        graph.hovered_style = {'stroke': 'orange'}
        graph.selected_style = {'opacity': '1', 'stroke': 'Coral', 'stroke-width': '2.5'}

        # create figure to hold graph
        tree_fig = Figure(marks=[graph])
        return tree_fig

    def _init_heatmap(self):
        """
        Initializes the three heatmap figures - longitudinal, lateral, action
        :return: Figure (goal_state, motion_plan_s), Figure (final is_valid checks)
        """

        # Create empty data for GridHeatMaps
        longitudinal_validity_data = np.full([2, len(self.longitudinal_validator_names)], np.nan)
        lateral_validity_data = np.full([2, len(self.lateral_validator_names)], np.nan)
        final_validity_data = np.full([2, len(self.action_validator_names)], np.nan)

        # define scales and axis for longitudinal gridheatmap
        x_sc_lon = OrdinalScale()
        y_sc_lon = OrdinalScale(reverse=True)
        col_sc_lon = ColorScale()
        ax_x_lon = Axis(scale=x_sc_lon, tick_rotate=-15, side='bottom', tick_style={'font-size': 11, 'white-space': 'pre'})
        ax_y_lon = Axis(scale=y_sc_lon, orientation='vertical')

        # define scales and axis for lateral gridheatmap
        x_sc_lat = OrdinalScale()
        y_sc_lat = OrdinalScale(reverse=True)
        col_sc_lat = ColorScale()
        ax_x_lat = Axis(scale=x_sc_lat, tick_rotate=-15, side='bottom', tick_style={'font-size': 11, 'white-space': 'pre'})
        ax_y_lat = Axis(scale=y_sc_lat, orientation='vertical')

        # define scales and axis for final gridheatmap
        x_sc_f = OrdinalScale()
        y_sc_f = OrdinalScale(reverse=True)
        col_sc_f = ColorScale()
        ax_x_f = Axis(scale=x_sc_f, tick_rotate=-15, side='bottom', tick_style={'font-size': 11, 'white-space': 'pre'})
        ax_y_f = Axis(scale=y_sc_f, orientation='vertical')

        grid_map_lat = GridHeatMap(color=lateral_validity_data,
                                   scales={'column': x_sc_lat, 'row': y_sc_lat, 'color': col_sc_lat},
                                   row=['is_goal_state_valid', 'is_component_valid'],
                                   column=self.lateral_validator_names, column_align='end', stroke='white')
        grid_map_lat.tooltip = Tooltip(fields=['column'], labels=['Validator'])

        grid_map_lon = GridHeatMap(color=longitudinal_validity_data,
                                   scales={'column': x_sc_lon, 'row': y_sc_lon, 'color': col_sc_lon},
                                   row=['is_goal_state_valid', 'is_component_valid'],
                                   column=self.longitudinal_validator_names, column_align='end', stroke='white')
        grid_map_lon.tooltip = Tooltip(fields=['column'], labels=['Validator'])

        # create separate gridmap for final validator results
        grid_map_final = GridHeatMap(color=final_validity_data,
                                     scales={'column': x_sc_f, 'row': y_sc_f, 'color': col_sc_f},
                                     row=['is_action_valid'],
                                     column=self.action_validator_names, column_align='end', stroke='white')
        grid_map_final.tooltip = Tooltip(fields=['column'], labels=['Validator'])

        width = 750
        height = 200
        layout = widgets.Layout(width=f'{width}px', height=f'{height}px')

        # create figures to hold gridheatmaps
        grid_fig_lat = Figure(title="Lateral validators",
                              marks=[grid_map_lat],
                              layout=layout,
                              axes=[ax_x_lat, ax_y_lat],
                              fig_margin={'top': 60, 'bottom': 60, 'left': 150, 'right': 60}
                              )

        grid_fig_lon = Figure(title="Longitudinal validators",
                              marks=[grid_map_lon],
                              layout=layout,
                              axes=[ax_x_lon, ax_y_lon],
                              fig_margin={'top': 60, 'bottom': 60, 'left': 150, 'right': 60}
                              )

        grid_fig_final = Figure(title="Action validators",
                                marks=[grid_map_final],
                                layout=layout,
                                axes=[ax_x_f, ax_y_f],
                                fig_margin={'top': 80, 'bottom': 80, 'left': 150, 'right': 60})

        return grid_fig_lon, grid_fig_lat, grid_fig_final

    def _init_rewards_table(self):
        table = widgets.Output()
        total_reward_hbox = widgets.HBox(children=(widgets.Label("Total Reward"),
                                                   widgets.Label("0")))

        return widgets.HBox(children=(table, total_reward_hbox))

    def _init_search_table(self):
        table = widgets.Output()
        return widgets.HBox(children=(table,))

    def _init_trial_slider_hbox(self):
        """
        Create a hbox that holds a widget that will update the selected action_spec trial
        :return:
        """
        trial_slider = widgets.interactive(self._update_heatmap_trial_cb,
                                           trial_num=widgets.IntSlider(min=1, max=1, step=1, value=1))
        max_trial_label = widgets.Label(value=f"of {trial_slider.children[0].max}")

        return widgets.HBox(children=(trial_slider, max_trial_label))

    @property
    def action_specs(self):
        """
        Get action specs from the selected frame
        The index of the action_spec corresponds to the label on the tree graph
        :return:
        """
        if self.G:
            return list(nx.get_node_attributes(self.G, 'action_spec').values())
        else:
            return []

    @property
    def uct_nodes(self):
        """
        Get uct_nodes from the selected frame
        The index of the uct_node corresponds to the label on the graph
        :return:
        """
        if self.G:
            return list(nx.get_node_attributes(self.G, 'uct_node').values())
        else:
            return []

    def _create_node(self, G: nx.DiGraph, tree_node: TreeNode):
        """
        Create a node in the directed graph using NetworkX
        """
        if tree_node.curr_node is None:
            if tree_node.action_spec.is_action_generated:
                if tree_node.action_spec.is_action_valid:
                    color = COLOR_ACTION_SPEC_VALID_NO_CHILDREN
                else:
                    color = COLOR_NODE_INVALID
            else:
                color = COLOR_NODE_UNGENERATED
            G.add_node(tree_node.curr_node_id, uct_node=None,
                       color=color,
                       value=0, action_spec=tree_node.action_spec, valid=False)
            G.add_edge(tree_node.parent_node_id, tree_node.curr_node_id)
            return

        action_spec = tree_node.action_spec
        if tree_node.curr_node == tree_node.root_node:
            color = COLOR_NODE_ROOT
            # valid node
        elif action_spec and isinstance(action_spec, WerlingMDPActionSpec):
            color = COLOR_NODE_VALID
            if action_spec.is_action_generated and action_spec.action in self._best_experience.actions:
                color = COLOR_NODE_BEST_EXP
        # Previous search action tree_node.action_spec
        elif action_spec and isinstance(action_spec, GeneratedWerlingActionSpec):
            color = COLOR_NODE_PREV_SEARCH
            if action_spec.is_action_generated and action_spec.action in self._best_experience.actions:
                color = COLOR_NODE_PREV_SEARCH_BEST_EXP
        # Node without a valid parent - this shouldn't happen, possibly a bug in the visualization
        else:
            color = COLOR_NODE_NO_PARENT

        G.add_node(tree_node.curr_node_id,
                   uct_node=tree_node.curr_node,
                   color=color,
                   value=tree_node.curr_node.value,
                   action_spec=tree_node.action_spec,
                   valid=True)

        # add edge to parent
        if tree_node.curr_node != tree_node.root_node:
            G.add_edge(tree_node.parent_node_id, tree_node.curr_node_id)

    @staticmethod
    def _get_action_spec_data(action_specs: List[WerlingMDPActionSpec]) \
            -> Tuple[
                List[Tuple[str, str]], List[Tuple[str, str]], List[float], List[float], List[float],
                List[float]]:
        """

        :param action_specs:
        :return: lists containing: action types, motion plan names, durations, target velocities, target s, target d
        """

        longitudinal_action_types = []
        lateral_action_types = []
        lon_motion_plans = []
        lat_motion_plans = []

        for spec in action_specs:
            if spec and isinstance(spec, WerlingMDPActionSpec):
                lon_spec = spec.longitudinal_component_spec
                if isinstance(lon_spec, GeneratedWerlingComponentSpec):
                    if lon_spec.components:
                        longitudinal_action_types.append(lon_spec.components[0][0].component_type.name)
                        lon_motion_plans.append(TreeVisualizer._poly_type_str(lon_spec.components[0][0].motion_plan.poly_type))
                    else:
                        longitudinal_action_types.append(lon_spec.component_type.name)
                        lon_motion_plans.append(lon_spec.fluctuation_num)
                else:
                    longitudinal_action_types.append(lon_spec.component_type.name)
                    lon_motion_plans.append(lon_spec.fluctuation_name_list[lon_spec.fluctuation_num - 1])

                lat_spec = spec.lateral_component_spec
                if isinstance(lat_spec, GeneratedWerlingComponentSpec):
                    if lat_spec.components:
                        lateral_action_types.append(lat_spec.components[0][0].component_type.name)
                        lat_motion_plans.append(TreeVisualizer._poly_type_str(lat_spec.components[0][0].motion_plan.poly_type))
                    else:
                        lateral_action_types.append(lat_spec.component_type.name)
                        lat_motion_plans.append(lat_spec.fluctuation_num)
                else:
                    lateral_action_types.append(lat_spec.component_type.name)
                    lat_motion_plans.append(lat_spec.fluctuation_name_list[lat_spec.fluctuation_num - 1])
            elif spec and isinstance(spec, GeneratedWerlingActionSpec):
                longitudinal_action_types.append(spec.longitudinal_component_spec.component_type.name)
                lateral_action_types.append(spec.lateral_component_spec.component_type.name)
                if spec.longitudinal_component_spec.components and spec.lateral_component_spec.components:
                    lon_motion_plans.append(
                        TreeVisualizer._poly_type_str(spec.longitudinal_component_spec.components[0][0].motion_plan.poly_type))
                    lat_motion_plans.append(
                        TreeVisualizer._poly_type_str(spec.lateral_component_spec.components[0][0].motion_plan.poly_type))
                else:
                    lon_motion_plans.append("")
                    lat_motion_plans.append("")
            else:
                longitudinal_action_types.append(None)
                lateral_action_types.append(None)
                lon_motion_plans.append(None)
                lat_motion_plans.append(None)

        action_types = list(zip(longitudinal_action_types, lateral_action_types))
        motion_plans = list(zip(lon_motion_plans, lat_motion_plans))

        v_list = []
        t_list = []
        d_list = []
        s_list = []

        for spec in action_specs:
            if not spec:
                v_list.append(None)
                t_list.append(None)
                d_list.append(None)
                s_list.append(None)
                continue

            if isinstance(spec, GeneratedWerlingActionSpec):
                if not spec.action:
                    v_list.append(None)
                    t_list.append(None)
                    d_list.append(None)
                    s_list.append(None)
                    continue
                # TODO: check if this logic is correct
                v_list.append(f'{spec.action.motion_plan_s.v_T:.2f}')
                t_list.append(f'{spec.action.motion_plan_s.T:.2f}')
                d_list.append(f'{spec.action.motion_plan_d.x_T:.2f}')
                s_list.append(f'{spec.action.motion_plan_d.T:.2f}')
                continue

            lon_spec = spec.longitudinal_component_spec
            lat_spec = spec.lateral_component_spec
            if isinstance(spec.longitudinal_component_spec, GeneratedWerlingComponentSpec):
                if lon_spec.components:
                    v_list.append(f'{lon_spec.components[-1][0].motion_plan.v_T:.2f}')
                    t_list.append(f'{lon_spec.components[-1][0].duration:.2f}')
                else:
                    v_list.append("")
                    t_list.append("")
            else:
                v_list.append([f'{v:.2f}' for v in spec.longitudinal_component_spec._v_list])
                t_list.append([f'{t:.2f}' for t in spec.longitudinal_component_spec._duration_list])

            if isinstance(lat_spec, GeneratedWerlingComponentSpec):
                if lat_spec.components:
                    d_list.append(f'{lat_spec.components[-1][0].motion_plan.x_T:.2f}')
                    s_list.append(f'{lat_spec.components[-1][0].motion_plan.T:.2f}')
                else:
                    d_list.append("")
                    s_list.append("")
            else:
                d_list.append([f'{d:.2f}' for d in spec.lateral_component_spec._x_list])
                s_list.append([f'{s:.2f}' for s in spec.lateral_component_spec._duration_list])

        return action_types, motion_plans, t_list, v_list, s_list, d_list

    @staticmethod
    def _get_validity_data(action_spec: Optional[WerlingMDPActionSpec],
                           num_lon_validators: int,
                           num_lat_validators: int,
                           num_action_validators: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str]:
        """
        Extracts validator results from action_spec DebugProbe trials into a numpy array format
        :action_spec
        :return: Tuple of three ndarrays and a str: lon_data, lat_data, final_data, failure reason
        """

        if action_spec is not None:
            lon_trials, lat_trials, action_trials = get_action_spec_trials(copy.deepcopy(action_spec))
        else:
            lon_trials, lat_trials, action_trials = None, None, None

        # Get validator data from DebugProbes and pad with nan's
        if lon_trials and len(lon_trials) > 0:
            lon_trial = lon_trials[-1]
            is_goal_state_valid_lon = [validator_result.result if validator_result is not None else np.nan for
                                       validator_result in
                                       lon_trial._goal_checks]
            is_goal_state_valid_lon.extend(np.full([num_lon_validators - len(is_goal_state_valid_lon)], np.nan))

            is_motion_plan_valid_lon = [validator_result.result if validator_result is not None else np.nan for
                                        validator_result in
                                        lon_trial._motion_plan_checks]
            is_motion_plan_valid_lon.extend(np.full([num_lon_validators - len(is_motion_plan_valid_lon)], np.nan))

            validity_data_lon = np.vstack((is_goal_state_valid_lon, is_motion_plan_valid_lon))
        else:
            validity_data_lon = np.full([2, num_lon_validators], np.nan)

        if lat_trials and len(lat_trials) > 0:
            lat_trial = lat_trials[-1]
            is_goal_state_valid_lat = [validator_result.result if validator_result is not None else np.nan for
                                       validator_result in
                                       lat_trial._goal_checks]
            is_goal_state_valid_lat.extend(np.full([num_lat_validators - len(is_goal_state_valid_lat)], np.nan))

            is_motion_plan_valid_lat = [validator_result.result if validator_result is not None else np.nan for
                                        validator_result in
                                        lat_trial._motion_plan_checks]
            is_motion_plan_valid_lat.extend(np.full([num_lat_validators - len(is_motion_plan_valid_lat)], np.nan))

            validity_data_lat = np.vstack((is_goal_state_valid_lat, is_motion_plan_valid_lat))
        else:
            validity_data_lat = np.full([2, num_lat_validators], np.nan)

        # TODO: add selection for trials
        if action_trials and len(action_trials) > 0:
            final_trial = action_trials[-1]
            is_valid_final = [validator_result.result if validator_result is not None else np.nan for validator_result
                              in
                              final_trial._validity_checks]
            is_valid_final.extend(np.full([num_action_validators - len(is_valid_final)], np.nan))

            # bqplot heatmaps require at least two rows, so a blank row is inserted below the action_validator results
            validity_data_final = np.vstack((is_valid_final, np.full([1, num_action_validators], np.nan)))
        else:
            validity_data_final = np.full([2, num_action_validators], np.nan)

        # write reason for failure if any
        failure_reason = ""
        if action_spec and action_spec.is_action_generated and not action_spec.is_action_valid:
            failure_reason = determine_action_spec_failure_reason(copy.deepcopy(action_spec))

        return validity_data_lon, validity_data_lat, validity_data_final, failure_reason

    def calculate_features(self, model, features, context: MDPContext, state: MDPState, action: WerlingMDPAction) -> np.ndarray:

        res_features = list()
        for feature in features:

            val = feature.calculate(context=context, state=state, action=action)

            res_features.append(val)

        features_batch = np.stack(res_features, axis=0).astype(dtype=np.float32)

        discount_factors = calc_discount_factors(times=action.times)[1:].reshape((1, -1))
        res = np.sum(features_batch * discount_factors, axis=1)
        return res

    def _get_reward_data(self, action_spec: WerlingMDPActionSpec) -> pd.DataFrame:

        # Get reward calculator from subdivision_planner
        reward_calculator = WerlingMDPReturnCalculator()._reward_calculator
        reward_model = reward_calculator._model;
        features_to_weights = reward_model.get_feature_weights_dict()
        feature_names = list(features_to_weights.keys())
        weights = list(features_to_weights.values())
        reward_features = reward_calculator.get_reward_features_by_name(feature_names)
        # feature_names = [feature.name for feature in reward_calculator.features]
        # weights = reward_calculator.weights

        # Create empty dataframe to fill in
        default_data = np.hstack((np.array(feature_names).reshape((-1, 1)),
                                  np.zeros(shape=(len(feature_names), 3))))
        df = pd.DataFrame(default_data, columns=['Name', 'Reward Value', 'Weight', 'Weighted Value'])
        df.set_index('Name', inplace=True)

        # Set weights since they don't change for different action specs
        df = df.assign(Weight=weights)

        if action_spec is not None and action_spec.is_action_generated and action_spec.is_action_valid:
            # Calculate reward values for valid actions
            mdp_state = action_spec._state
            mdp_context = MDPContext()
            results = self.calculate_features(reward_model, reward_features, mdp_context, mdp_state, action_spec.action)
            df = df.assign(**{"Reward Value": results})

            # Multiply reward values by weights
            weighted_results = results * weights
            df = df.assign(**{"Weighted Value": weighted_results})

        return df

    def _get_search_data_ucb(self, uct_node: UCTNode) -> pd.DataFrame:
        measured_qsa = []
        is_generated = []
        num_visits = []
        normalized_action_specs_values = []
        exploration_terms = []
        total_ucb_term = []
        child_index = []
        if uct_node is not None and uct_node.mdp_node.is_action_specs_generated:
            for action_spec in uct_node.mdp_node.action_specs:
                is_generated.append(action_spec.is_action_generated)
                if action_spec.is_action_generated:
                    if action_spec.action is None:
                        measured_qsa.append(-1e6)
                        num_visits.append(np.nan)
                    elif action_spec.is_action_valid and action_spec.action in uct_node.q_sa:
                        measured_qsa.append(uct_node.q_sa[action_spec.action])
                        num_visits.append(uct_node.get_child(action_spec.action).num_visits)
                    else:
                        measured_qsa.append(np.nan)
                        num_visits.append(0)
                else:
                    measured_qsa.append(np.nan)
                    num_visits.append(0)

            # Create an array of indices of action specs corresponding to all actions in uct_node
            indices_of_actions_in_action_specs = np.array([uct_node.mdp_node.get_action_spec_idx_from_action(action)
                                                           for action in uct_node.actions])
            children_values = np.array([uct_node.q_sa[action] for action in uct_node.actions])
            if len(children_values) > 0:
                children_max_value = np.abs(np.max(children_values))
                children_normalized_values = children_values / (children_max_value + 1e-3)

                # Non generated actions are viewed as having inf values
                normalized_action_specs_values = np.full(len(uct_node.mdp_node.action_specs), np.inf)
                normalized_action_specs_values[indices_of_actions_in_action_specs] = children_normalized_values

                for idx, action_spec in enumerate(uct_node.mdp_node.action_specs):
                    if action_spec.is_action_generated and not action_spec.is_action_valid:

                        # Show invalid actions as actions with value of -1e6
                        normalized_action_specs_values[idx] = -1e6

            children_nodes = [uct_node.get_child(action=action) for action in uct_node.actions]
            children_default_exp_terms = np.array([UCTNode.exploration_term(parent_node=uct_node, node=child_node)
                                                   for child_node in children_nodes])
            exploration_terms = np.zeros_like(normalized_action_specs_values)
            exploration_terms[indices_of_actions_in_action_specs] = children_default_exp_terms * Config().mcts.exploration_factor
            total_ucb_term = normalized_action_specs_values + exploration_terms

            child_index = []
            for action_spec in uct_node.mdp_node.action_specs:
                if action_spec.is_action_generated and action_spec.is_action_valid:
                    child_node = uct_node.get_child(action_spec.action)
                    child_index.append(self.uct_nodes.index(child_node))
                else:
                    child_index.append(np.nan)

        df = pd.DataFrame(data={"Measured Qsa": measured_qsa,
                                "Child Index": child_index,
                                "Is generated": is_generated,
                                "Num Visits": num_visits,
                                "Normalized values": normalized_action_specs_values,
                                "Exploration terms": exploration_terms,
                                "Total UCB": total_ucb_term
                                })
        df = df.sort_values("Total UCB", ascending=False)

        return df

    def _get_search_data_pucb(self, uct_node: UCTNode) -> pd.DataFrame:
        measured_qsa = []
        predicted_qsa = []
        predicted_prob = []
        is_generated = []
        num_visits = []
        order = []
        normalized_action_specs_values = []
        exploration_terms = []
        extracted_probs = []
        total_pucb_term = []
        child_index = []
        predicted_validity = []
        if uct_node is not None:
            for action_spec in uct_node.mdp_node.action_specs:
                is_generated.append(action_spec.is_action_generated)
                if action_spec.is_action_generated:
                    if action_spec.action is None:
                        measured_qsa.append(-1e6)
                        num_visits.append(np.nan)
                    elif action_spec.is_action_valid and action_spec.action in uct_node.q_sa:
                        measured_qsa.append(uct_node.q_sa[action_spec.action])
                        num_visits.append(uct_node.get_child(action_spec.action).num_visits)
                    else:
                        measured_qsa.append(np.nan)
                        num_visits.append(0)
                else:
                    measured_qsa.append(np.nan)
                    num_visits.append(0)

            predicted_qsa = uct_node._predicted_qsa
            predicted_prob = uct_node.prior_probabilities
            predicted_validity = uct_node._validity_outputs
            action_likes = []
            possibly_valid_action_likes_indices = []
            invalid_action_specs_indices = []
            for idx, action_spec in enumerate(uct_node.mdp_node.action_specs):
                if not action_spec.is_action_generated:
                    if uct_node.fully_expanded and Config().mcts.enable_progressive_widening: # If using progressive widening and node is fully expanded, skip and consider only the already generated actions
                        continue
                    else:
                        action_likes.append(action_spec)
                        possibly_valid_action_likes_indices.append(idx)

                elif action_spec.is_action_valid:
                    if action_spec.action not in uct_node.q_sa:
                        action_likes.append(action_spec)
                    else:
                        action_likes.append(action_spec.action)
                    possibly_valid_action_likes_indices.append(idx)
                else:
                    invalid_action_specs_indices.append(idx)

            sorted_action_likes = uct_node._sort_action_likes_by_pucb(action_likes)

            sorted_action_specs = [action_like if isinstance(action_like, IMDPActionSpec)
                                   else uct_node.mdp_node.get_action_spec_from_action(action_like)
                                   for action_like in sorted_action_likes]

            order = 1000 * np.ones(len(uct_node.mdp_node.action_specs), dtype=np.int64) # Initialize with 1000 to make invalid action specs last in line
            for idx, action_like in enumerate(sorted_action_specs):
                order[uct_node.mdp_node.action_specs.index(action_like)] = idx

            # calculate normalized action values
            action_likes_values = np.array([uct_node.q_sa[action_like] if isinstance(action_like, IMDPAction) else np.nan
                                            for action_like in action_likes])

            action_likes_normalized_values = UCTNode.normalize_action_likes_qsa(action_likes_values=action_likes_values)

            normalized_action_specs_values = np.full(len(uct_node.mdp_node.action_specs), fill_value=np.nan)
            normalized_action_specs_values[possibly_valid_action_likes_indices] = action_likes_normalized_values

            # calculate exploration term
            action_likes_probs = uct_node._nn_flow.extract_prior_probabilities_for_action_likes(
                mdp_node=uct_node.mdp_node,
                action_likes=action_likes,
                all_prior_probabilities=uct_node.prior_probabilities
            )
            extracted_probs = np.zeros(len(uct_node.mdp_node.action_specs))
            extracted_probs[possibly_valid_action_likes_indices] = action_likes_probs
            # Extract the number of visits for each action-like

            action_likes_num_visits = np.array(
                [uct_node.get_child(action=action_like).num_visits if isinstance(action_like, IMDPAction) else 0
                 for action_like in action_likes])

            # Calculate exploration term, based on prior probability and number of visits, for each action-like.
            exploration_terms = np.zeros(len(uct_node.mdp_node.action_specs))
            exploration_terms[possibly_valid_action_likes_indices] = UCTNode.calculate_exploration_terms_pucb(action_likes_probs, uct_node.num_visits, action_likes_num_visits)
            total_pucb_term = exploration_terms + normalized_action_specs_values

            child_index = []
            for action_spec in uct_node.mdp_node.action_specs:
                if action_spec.is_action_generated and action_spec.is_action_valid and action_spec.action in uct_node.q_sa:
                    child_node = uct_node.get_child(action_spec.action)
                    child_index.append(self.uct_nodes.index(child_node))
                else:
                    child_index.append(np.nan)

        df = pd.DataFrame(data={"Measured Qsa": measured_qsa,
                                "Child Index": child_index,
                                "Predicted Qsa": predicted_qsa,
                                "Predicted Prob": predicted_prob,
                                "Predicted Validity": predicted_validity,
                                "Is generated": is_generated,
                                "Order": order,
                                "Num Visits": num_visits,
                                "Normalized values": normalized_action_specs_values,
                                "Exploration terms": exploration_terms,
                                "Extract Prob.": extracted_probs,
                                "Total PUCB": total_pucb_term
                                })
        df = df.sort_values("Order")
        return df

    @staticmethod
    def _poly_type_str(poly_type: Union[PolyType, Tuple[PolyType]]) -> str:
        return poly_type.name if isinstance(poly_type, PolyType) else "MultiPoly({})".format(
            ",".join(p.name for p in poly_type))

    def _set_tree_graph_data(self, G):
        """
        Set the bqplot graph data based on a networkx object
        :param G: NetworkX graph containing tree data
        :return:
        """

        pos = graphviz_layout(G, prog='dot')
        xs = LinearScale()
        ys = LinearScale()

        # set x and y positions based on layout from graphviz
        x_pos = [int(pos[n][0]) for n in range(len(pos))]
        y_pos = [int(pos[n][1]) for n in range(len(pos))]

        # get attributes from values stored in networkx nodes
        uct_nodes = list(nx.get_node_attributes(G, 'uct_node').values())
        mdp_nodes = [uct_node.mdp_node if uct_node else None for uct_node in uct_nodes]
        action_specs = list(nx.get_node_attributes(G, 'action_spec').values())
        values = list(nx.get_node_attributes(G, 'value').values())

        # put action spec info into lists
        action_types, motion_plans, t_list, v_list, s_list, d_list = TreeVisualizer._get_action_spec_data(action_specs)

        # create nodes and edges for bqplot
        node_data = [{'label': node,
                      'action_type': action_type,
                      'motion_plan': motion_plan,
                      't': t,
                      'v': v,
                      's': s,
                      'd': d,
                      'value': value}
                     for node, action_type, motion_plan, t, v, s, d, value
                     in zip(list(G.nodes), action_types, motion_plans, t_list, v_list, s_list, d_list, values)]
        edges = list(G.edges)
        colors = list(nx.get_node_attributes(G, 'color').values())
        link_data = [{'source': s, 'target': t} for s, t in edges]

        # Test root node state validity
        action_debug_probe = ActionDebugProbe()
        action_validator = Searcher.create_action_validator()
        assert isinstance(action_validator, AggregateWerlingActionValidator)
        # If state is invalid, determine why.
        try:
            if not is_state_valid(self._analyze_coverage_cfg, mdp_nodes[0], action_validator, action_debug_probe):
                invalid_state_reason = determine_state_failure_reason(mdp_nodes[0], action_debug_probe.trials)
                # set root node to be red
                colors[0] = COLOR_NODE_INVALID
                node_data[0]['action_type'] = invalid_state_reason
        except:
            pass

        # graph = self.tree_fig.marks[0]
        graph = Graph(link_type='line')

        graph.node_data = node_data
        graph.link_data = link_data
        graph.scales = {'x':xs, 'y':ys}
        graph.x = x_pos
        graph.y = y_pos
        graph.link_type = 'line'
        graph.colors = colors

        # highlight selected nodes
        graph.hovered_style = {'stroke': 'orange'}
        graph.selected_style = {'opacity': '1', 'stroke': 'Coral', 'stroke-width': '2.5'}

        # add tooltips (the fields are the keys of node_data)
        tooltip = Tooltip(fields=['label', 'action_type', 'motion_plan', 't', 'v', 's', 'd', 'value'],
                          formats=['', '', '', '', '', '', '', ''])
        graph.tooltip = tooltip

        self.tree_fig.marks = [graph]

    def _update_tree_fig(self, hide_invalid: bool):
        """
        Redraw tree graph based on new loaded_data
        :param hide_invalid:
        :return:
        """
        if self._root_node:
            self.G = nx.DiGraph()
            print("Start traverse tree")
            for tree_node in traverse_tree(root_node=self._root_node, explore_invalid=not hide_invalid, explore_non_generated=True):
                self._create_node(self.G, tree_node)
            print("end traverse tree")
            # update frame info based on new loaded data
            self._update_frame_stats()
            # update tree graph
            self._set_tree_graph_data(self.G)
            self.tree_fig.marks[0].on_hover(self._select_node_cb)
            self.tree_fig.marks[0].on_element_click(self._select_node_cb)
            self.tree_fig.marks[0].on_background_click(self._select_node_cb)
        else:
            self.tree_fig.marks = []

    def _update_frame_stats(self):
        timestamp = self._root_node.mdp_node.state.timestamp

        # TODO fix tree stats
        # num_valid, num_invalid, num_nodes, \
        # num_failed_goal_state, num_failed_motion_s, num_failed_final = self._get_tree_stats()
        #
        # # update timestamp label
        # self.frame_info_vbox.children[0].value = f"Timestamp: {timestamp}"
        # # update num_node label
        # self.frame_info_vbox.children[1].value = f"Num Nodes: {num_nodes}, " \
        #     f"Valid: {num_valid} ({np.floor(num_valid/num_nodes * 100)}%), " \
        #     f"Invalid: {num_invalid} ({np.floor(num_invalid/num_nodes * 100)}%)"
        # # update num_fail label
        # self.frame_info_vbox.children[2].value = \
        #     f"Failed Goal State: {num_failed_goal_state} ({np.floor(num_failed_goal_state/num_invalid * 100)}%) " \
        #     f"Failed Motion S: {num_failed_motion_s} ({np.floor(num_failed_motion_s/num_invalid * 100)}%) " \
        #     f"Failed Final: {num_failed_final} ({np.floor(num_failed_final/num_invalid * 100)}%)"

    def _get_tree_stats(self):
        num_failed_goal_state = 0
        num_failed_motion_s = 0
        num_failed_final = 0
        num_valid = 0
        num_invalid = 0
        num_nodes = 0

        # if self.loaded_data.root_node:
        #     root_node = self.loaded_data.root_node
        #     # get tree with all nodes
        #     G = create_digraph_tree(root_node, explore_invalid=True)
        #     # get attributes from values stored in networkx nodes
        #     uct_nodes = list(nx.get_node_attributes(G, 'uct_node').values())
        #     validity = list(nx.get_node_attributes(G, 'valid').values())
        #     action_specs = list(nx.get_node_attributes(G, 'action_spec').values())
        #
        #     for action_spec in action_specs:
        #         if isinstance(action_spec, WerlingMDPActionSpec):
        #             trials = get_trials(action_spec)
        #             if trials:
        #                 trial_num = len(trials) - 1
        #                 validity_data, final_validity_data = get_validity_data(trials, trial_num)
        #
        #                 # convert nan's to 0's
        #                 validity_data[validity_data==np.nan] = 0
        #                 final_validity_data[final_validity_data==np.nan] = 0
        #                 final_validity_data = np.atleast_2d(final_validity_data)
        #
        #                 if not np.any(validity_data[0,:]) or not np.all(validity_data[0,:]):
        #                     num_failed_goal_state += 1
        #                 elif not np.any(validity_data[1,:]) or not np.all(validity_data[1,:]):
        #                     num_failed_motion_s += 1
        #                 elif not np.any(final_validity_data) or not np.any(np.all(final_validity_data, axis=1)):
        #                     num_failed_final += 1
        #
        #
        #     num_valid = np.sum(validity)
        #     num_invalid = np.sum(np.logical_not(validity))
        #     num_nodes = len(uct_nodes)

        return num_valid, num_invalid, num_nodes, num_failed_goal_state, num_failed_motion_s, num_failed_final

    def _update_heatmap(self, action_spec=None, trial_num=None):
        """
        Set the values for the heatmaps based on the selected action_spec and trial number
        :param action_spec:
        :param trial_num:
        :return:
        """
        validity_data_lon, validity_data_lat, validity_data_final, failure_reason = \
            self._get_validity_data(action_spec, num_lon_validators=len(self.longitudinal_validator_names),
                                    num_lat_validators=len(self.lateral_validator_names),
                                    num_action_validators=len(self.action_validator_names))

        # pad data so heatmap will scale colors correctly
        validity_data_lon = np.hstack((validity_data_lon, [[1], [0]]))
        validity_data_lat = np.hstack((validity_data_lat, [[1], [0]]))
        validity_data_final = np.hstack((validity_data_final, np.ones((validity_data_final.shape[0], 1))))

        self.heatmap_lon.marks[0].color = validity_data_lon
        self.heatmap_lat.marks[0].color = validity_data_lat
        self.heatmap_action.marks[0].color = validity_data_final

        # update failure reason
        self.failure_reason_hbox.children[1].value = failure_reason

        # TODO: fix trial num
        # self.trial_slider_hbox.children[0].children[0].max = max(len(trials), 1)
        self.trial_slider_hbox.children[0].children[0].max = 1
        # self.trial_slider_hbox.children[1].value = f"of {len(trials)}"
        self.trial_slider_hbox.children[1].value = "1"

    def _update_heatmap_trial_cb(self, trial_num):
        """
        Callback for the heatmap trial selector widget
        Updates the heatmap values based on the currently selected action_spec
        :param trial_num:
        :return:
        """
        if self._selected_action_spec:
            self._update_heatmap(action_spec=self._selected_action_spec, trial_num=trial_num-1)

    def _update_rewards_table(self, action_spec=None):
        """
        Sets the value for the rewards table if a valid action spec is selected
        """
        df = self._get_reward_data(action_spec)
        with self.rewards_table_hbox.children[0]:
            clear_output()
            display(df)

        # Display the total reward
        self.rewards_table_hbox.children[1].children[1].value = str(df["Weighted Value"].sum())

    def _update_search_table(self, uct_node=None):
        """
        Sets the value for the rewards table if a valid action spec is selected
        """
        if uct_node is not None and uct_node.prior_probabilities is not None:
            df = self._get_search_data_pucb(uct_node)
        else:
            df = self._get_search_data_ucb(uct_node)
        with self.search_table_hbox.children[0]:
            clear_output()
            pd.set_option('display.max_rows', df.shape[0] + 1)
            display(df)

    def _select_node_cb(self, obj, target):
        """
        Callback for the selection of nodes on the tree figure
        Updates the validator heatmap's value
        Updates the rewards table values
        :param obj:
        :param target:
        :return:
        """
        # disable changing the gridfigs on hover if a node has been clicked
        if target['event'] == 'element_click':
            obj.on_hover(self._select_node_cb, remove=True)
        # reenable hover if empty space is clicked
        elif target['event'] == 'background_click':
            obj.on_hover(self._select_node_cb)

        # update the heatmap based on the chosen action spec
        if target['event'] == 'hover' or target['event'] == 'element_click':
            try:
                node_id = target['data']['label']
                # root node has no action spec data
                if node_id == 'N0':
                    self._update_heatmap(None)
                    self._update_rewards_table(None)
                    self._update_search_table(self._root_node)
                    self._selected_action_spec = None
                    self.trial_slider_hbox.children[0].children[0].max = 1

                else:
                    action_spec = self.action_specs[node_id]
                    self._selected_action_spec = action_spec
                    self._update_heatmap(action_spec)
                    self._update_rewards_table(action_spec)
                    self._update_search_table(self.uct_nodes[node_id])

                    if isinstance(action_spec, WerlingMDPActionSpec):
                        trials = get_action_spec_trials(copy.deepcopy(action_spec))
                        # set slider to be the last trial, since that will be displayed on hover
                        self.trial_slider_hbox.children[0].children[0].value = len(trials)
                    else:
                        self.trial_slider_hbox.children[0].children[0].value = 1

            except Exception as e:
                print(e)
                traceback.print_exc()

    def _display_widgets(self):
        """
        Draws all the widgets when called within Jupyter notebook
        :return:
        """
        toolbar = Toolbar(figure=self.tree_fig)
        tree_fig_vbox = widgets.VBox(children=(self.tree_fig, toolbar))

        validator_vbox = widgets.VBox(children=(
            self.failure_reason_hbox,
            self.heatmap_lon,
            self.heatmap_lat,
            self.heatmap_action
        ))

        tab = widgets.Tab()
        tab.children = [self.search_table_hbox, validator_vbox, self.rewards_table_hbox]
        tab_titles = ['Search', 'Validators', 'Rewards']
        [tab.set_title(i, title) for i, title in enumerate(tab_titles)]

        main_vbox = widgets.VBox(children=(tree_fig_vbox, tab))

        # self.trial_slider_hbox))
        display(main_vbox)
