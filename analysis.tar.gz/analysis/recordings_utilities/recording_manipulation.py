import os
import shutil
import subprocess
import xml.etree.ElementTree as ET


def split_pubsub(splitter_path, src_folder: str, dst_folder: str, duration: float = None, start_time: float = None):
    """
    Splits pubsub recordings according to relative starting time
    :param splitter_path: Path to pubsub splitter
    :param src_folder: Folder which has the recordings
    :param dst_folder: Destination folder for output
    :param duration:
    :param start_time: start time relative to beginning of the recording
    :return:
    """
    # configure recorder times
    if start_time is None:
        start_time = 0

    start_time_ms = str(int(start_time) * 1000)  # convert s to [ms]
    duration_ms = str(int(duration) * 1000)  # in [s]

    FNULL = open(os.devnull, 'w')

    print("Starting PubSubSplitter...")
    print(" ".join([splitter_path, src_folder, dst_folder, start_time_ms, duration_ms]))
    p_split = subprocess.call([splitter_path, src_folder, dst_folder, start_time_ms, duration_ms],
                              stdout=FNULL,
                              stderr=FNULL)
    print("PubSubSplitter has finished.")


def create_rec2sim(scenario_name: str, src_dir: str, dst_dir: str, ):
    xodr_relative_path = "Projects/vires_project/Databases/linked/dsi_subdivision.dsi_subdivision.xodr"
    osgb_relative_path = "Projects/vires_project/Databases/linked/dsi_subdivision.dsi_subdivision.opt.osgb"
    os.makedirs(dst_dir, exist_ok=True)

    simulation_path = os.path.join(os.environ["ULTRACRUISE"], "simulation")
    # get folders in metrics output
    rec2sim_output_dir = os.path.join(simulation_path, "vires_project", "Scenarios", "Recorded")

    abs_path = os.path.join(simulation_path, "interfaces", "rec2sim", "gen_scenario_from_pubsub.py")
    python_cmd = "python " + abs_path + " --from-sd " + "--input " + src_dir + " --scenario-name " + scenario_name
    p = subprocess.call(python_cmd, stdin=None, stdout=None, stderr=None, shell=True)

    scenario_file_name = scenario_name + ".xml"
    scenario_file_path = os.path.join(rec2sim_output_dir, scenario_file_name)
    if os.path.isfile(scenario_file_path):
        dst_file_path = os.path.join(dst_dir, scenario_file_name)
        shutil.copy(scenario_file_path, dst_file_path)
        tree = ET.parse(dst_file_path)
        root = tree.getroot()
        layout = next(root.iter("Layout"))
        layout.set("Database", osgb_relative_path)
        layout.set("File", xodr_relative_path)
        tree.write(dst_file_path, encoding='UTF-8', xml_declaration=True)

    # copy xosc
    xosc_name = scenario_name + '.xosc'
    xosc_output_dir = os.path.join(simulation_path, "vires_project", "Recordings")
    xosc_file_path = os.path.join(xosc_output_dir, xosc_name)
    if os.path.isfile(xosc_file_path):
        shutil.copy(xosc_file_path, os.path.join(dst_dir, xosc_name))
