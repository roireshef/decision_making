import os
import shutil

from infrastructure.Python.utils.PubSubReader import pub_sub_reader
from interface.Rte_Types.python.Rte_Types_pubsub import PubSubMessageTypes
from subdivision_learning.analysis.recordings_utilities.recording_manipulation import split_pubsub, create_rec2sim


def get_events(path: str):
    """
    Retrieves events from a specific recording path
    :param path:
    :return: list of tuples of (event_timestamp, event_msg)
    """
    cfg = pub_sub_reader.PubSubMultiReaderConfig()
    cfg.add_channel_filter(pub_sub_channel=pub_sub_reader.PubSubChannel(domain="UC_SYSTEM", topic="HOST_SEMANTIC_POSE"))
    reader = pub_sub_reader.PubSubMultiReader(path_to_rec=path, config=cfg, layout_file_name=PubSubMessageTypes)
    start_time = reader.first_frame_timestamp_nano_sec * 1e-9

    cfg = pub_sub_reader.PubSubMultiReaderConfig()
    cfg.add_channel_filter(pub_sub_channel=pub_sub_reader.PubSubChannel(domain="UC_SYSTEM", topic="VEHICLE_TEST_EVENTS"))
    reader = pub_sub_reader.PubSubMultiReader(path_to_rec=path, config=cfg, layout_file_name=PubSubMessageTypes)

    msg = reader.get_next()
    events = []
    while msg[0]:
        event_comment = msg[1].s_Data.comment
        event_comment = "".join(map(chr, event_comment))
        event_comment = event_comment.split('\x00', 1)[0]

        event_comment = event_comment.replace(" ", "_")
        event_comment = event_comment.replace("/", "_")
        event_absolute_time = msg[0]['data_nano_time'] * 1e-9
        event_relative_time = event_absolute_time - start_time

        events.append((event_relative_time, event_absolute_time, event_comment))

        msg = reader.get_next()

    return events


def crop_events(base_folder: str,
                time_offset: float = 30.,
                duration: float = 30.,
                gen_rec2sim_scenario: bool = False,
                overwrite: bool = False,
                events_folder_name: str = "cropped_events"
                ):
    """
    Crops pubsub around events. Recording data is copied, as well as config files and all binaries.
    :param base_folder: Base folder for the data. It should have bin, config, recordings as subfolders in it
    :param time_offset: Offset in seconds before event tag to start crop
    :param duration: Duration of crop in seconds
    :param gen_rec2sim_scenario: If true, a rec2sim scenario will be generated in a designated folder within the output
                                folder
    :param overwrite: if True, cropped events will be overwritten by new ones
    :param events_folder_name: Destination folder name for cropped events
    :return: None
    """
    bin_folder = os.path.join(base_folder, 'bin')
    config_folder = os.path.join(base_folder, 'config')
    pubsub_folder = os.path.join(base_folder, 'recordings')
    events_folder = os.path.join(base_folder, events_folder_name)

    if overwrite and os.path.isdir(events_folder):
        shutil.rmtree(events_folder)

    splitter_path = os.path.join(bin_folder, 'PubSubSplitter')

    events = get_events(pubsub_folder)

    for event_idx, (event_relative_time, event_absolute_time, event_comment) in enumerate(events):
        event_name = "Event_{}_{}".format(event_idx, event_comment)
        event_base_folder = os.path.join(events_folder, event_name)

        event_bin_folder = os.path.join(event_base_folder, 'bin')
        if overwrite or not os.path.isdir(event_bin_folder):
            shutil.copytree(bin_folder, event_bin_folder)

        event_config_folder = os.path.join(event_base_folder, 'config')
        if overwrite or not os.path.isdir(event_config_folder):
            shutil.copytree(config_folder, event_config_folder)

        event_pubsub_folder = os.path.join(event_base_folder, 'recordings')
        if overwrite or not os.path.isdir(event_pubsub_folder):
            os.makedirs(event_pubsub_folder, exist_ok=True)
            split_pubsub(splitter_path=splitter_path,
                         src_folder=pubsub_folder,
                         dst_folder=event_pubsub_folder,
                         duration=duration,
                         start_time=event_relative_time - time_offset
                         )

        if gen_rec2sim_scenario:
            rec2sim_folder = os.path.join(event_base_folder, "rec2sim")
            if overwrite or not os.path.isdir(rec2sim_folder):
                create_rec2sim(scenario_name=event_name,
                               src_dir=event_pubsub_folder,
                               dst_dir=rec2sim_folder)
