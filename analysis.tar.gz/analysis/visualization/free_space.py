from typing import Tuple, Union

import cv2
import numpy as np
from interface.Rte_Types.python.sub_structures.TsSYS_OccupancyData import TsSYSOccupancyData
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.visualization.image_visualizer import ImageAuxVisualizer, ImageVisualizer
from subdivision_learning.analysis.visualization.sequence_visualizer import PandaAuxVisualizer
from subdivision_planner.src.common import types
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.mdp.werling.concepts.free_space_reduction import get_free_space_origin
from subdivision_planner.src.utils.visualization.render_commands import UpdateBoxArrayColor
from subdivision_planner.src.utils.visualization.render_elements import RectangleRenderedImage
from subdivision_planner.src.utils.visualization.state_visualizer import StateVisualizer
from subdivision_planner.src.utils.visualization.window import Window


class PerceivedFreeSpacePandaAuxVisualizer(PandaAuxVisualizer):
    """
    This class visualizes free space over the panda3d visualization
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        super().__init__(master_parser=master_parser)
        self._free_space_data_loader = master_parser.get_data_loader("UC_SYSTEM", "PERCEIVED_OCCUPANCY_DATA")
        self._hsp_data_loader = master_parser.get_data_loader("UC_SYSTEM", "HOST_SEMANTIC_POSE")
        self._free_space_elements_ids = []

    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        # Don't do anything if this visualizer is not enabled or doesn't have one of the required inputs
        if not self._is_enabled or not self._free_space_data_loader or not self._hsp_data_loader:
            return

        state = canonic_frame.state
        # timestamp = state.free_space_grids.timestamp_nano/1e9 # time
        timestamp = state.prediction_timestamp_in_seconds

        perceived_free_space: TsSYSOccupancyData = \
            self._free_space_data_loader.get_by_physical_timestamp(timestamp=timestamp)

        # Location and orientation of host
        hsp_msg = self._hsp_data_loader.get_by_physical_timestamp(timestamp=timestamp)
        orientation = hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_yaw
        c_yaw, s_yaw = np.cos(orientation), np.sin(orientation)
        rot_mat = np.array([[c_yaw, -s_yaw],
                            [s_yaw, c_yaw]])
        priority = 1.2

        num_grids = len(perceived_free_space.s_Data.s_OccupancyGridInstances)
        for i in range(num_grids):
            perceived_grid_instance = perceived_free_space.s_Data.s_OccupancyGridInstances[i]
            free_space_image, enable_image = StateVisualizer.get_free_space_image(
                free_space_grid_instance=perceived_grid_instance)

            global_offset = perceived_grid_instance.s_OccupancyGridInstanceHeader.a_rear_right_corner

            global_offset = rot_mat.dot(global_offset)
            location = (hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_east + global_offset[0],
                        hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_north + global_offset[1])

            # Generate a new render element only for the first time, and then update its data to save compute
            if len(self._free_space_elements_ids) <= i:
                cell_size = perceived_grid_instance.s_OccupancyGridInstanceHeader.a_cell_size
                render_element = RectangleRenderedImage(image_data=free_space_image,
                                                        enable_image=enable_image,
                                                        cell_size=cell_size,
                                                        location=location,
                                                        orientation=orientation,
                                                        priority=priority,
                                                        )
                self._free_space_elements_ids.append(render_element.id)
                window.draw_element(render_element, view_name='perceived_free_space')
            else:
                update_cmd = UpdateBoxArrayColor(id=self._free_space_elements_ids[i],
                                                 image_data=free_space_image,
                                                 enable_image=enable_image,
                                                 location=location,
                                                 orientation=orientation,
                                                 priority=priority)
                window.add_command(update_cmd)

            if render:
                window.render()


class PerceivedFreeSpaceImageAuxVisualizer(ImageAuxVisualizer):
    """
    Visualizes free space on an image
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser, rtk_height: float = 0.7):
        super().__init__(master_parser=master_parser)
        self._rtk_height = rtk_height
        self._free_space_data_loader = master_parser.get_data_loader("UC_SYSTEM", "PERCEIVED_OCCUPANCY_DATA")
        self._free_space_element_id = None

    def visualize(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        if not self._is_enabled or not self._free_space_data_loader:
            return image
        state = canonic_frame.state
        copied_image = image.copy()
        # The time of the requested image is state.prediction_timestamp_in_seconds

        # Extract free space image
        timestamp = state.prediction_timestamp_in_seconds
        perceived_free_space = self._free_space_data_loader.get_by_physical_timestamp(timestamp)
        num_grids = len(perceived_free_space.s_Data.s_OccupancyGridInstances)
        for i in range(num_grids):
            perceived_grid_instance = perceived_free_space.s_Data.s_OccupancyGridInstances[i]
            free_space_image, enable_image = StateVisualizer.get_free_space_image(
                free_space_grid_instance=perceived_grid_instance)
            free_space_image = free_space_image[..., :3]

            # Generate points in 3d space and project them on image to understand the coordinates in which to draw free
            # space elements
            cell_size = perceived_grid_instance.s_OccupancyGridInstanceHeader.a_cell_size
            global_offset = perceived_grid_instance.s_OccupancyGridInstanceHeader.a_rear_right_corner
            x_coordinates = np.arange(free_space_image.shape[0]) * cell_size[0] + cell_size[0] / 2 + global_offset[0]
            y_coordinates = np.arange(free_space_image.shape[1]) * cell_size[1] + cell_size[1] / 2 + global_offset[1]
            x_coordinates, y_coordinates = np.meshgrid(x_coordinates, y_coordinates, indexing='ij')
            points = np.stack((x_coordinates, y_coordinates, -self._rtk_height * np.ones_like(x_coordinates)), axis=-1).reshape(-1, 3)

            points_projected, is_in_fov = image_visualizer.project_3d_points_on_image(timestamp=timestamp,
                                                                                      points=points,
                                                                                      is_ego_coordinates=True
                                                                                      )

            # draw circles at a copy of the image and then blend it with the original image
            points_projected = points_projected.T
            free_space_image = free_space_image.reshape(-1, 3)[is_in_fov]
            enable_image = enable_image.ravel()[is_in_fov]
            for idx, point in enumerate(points_projected):
                if enable_image[idx]:
                    copied_image = cv2.circle(copied_image, tuple(point), 5, tuple(free_space_image[idx]*255), -1)

        alpha = 0.7
        image = cv2.addWeighted(image, alpha, copied_image, 1 - alpha, 0)

        return image


class SceneProviderFreeSpacePandaAuxVisualizer(PandaAuxVisualizer):
    """
    This class visualizes free space over the panda3d visualization
    """

    def __init__(self, master_parser: PubSubRecordingMasterParser):
        super().__init__(master_parser=master_parser)
        self._free_space_elements_ids = []

    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        # Don't do anything if this visualizer is not enabled or doesn't have one of the required inputs
        # if not self._is_enabled or not self._free_space_data_loader or not self._hsp_data_loader:
        state = canonic_frame.state
        if not self._is_enabled or not state or not state.free_space_grids:
            return

        priority = 1.2
        num_grids = len(state.free_space_grids.occupancy_grid_data)
        for i in range(num_grids):
            occupancy_grid_data = state.free_space_grids.occupancy_grid_data[i]
            free_space_image, enable_image = StateVisualizer.get_free_space_image(occupancy_grid_data)
            location = occupancy_grid_data.cell_origin_location
            _, _, orientation = get_free_space_origin(occupancy_grid_data)
            cell_size = occupancy_grid_data.cell_size
            # Generate a new render element per occupancy grid  only for the first time, and then update its data to save compute
            if len(self._free_space_elements_ids) <= i:
                render_element = RectangleRenderedImage(image_data=free_space_image,
                                                        enable_image=enable_image,
                                                        cell_size=cell_size,
                                                        location=location,
                                                        orientation=orientation,
                                                        priority=priority,
                                                        )
                self._free_space_elements_ids.append(render_element.id)
                window.draw_element(render_element, view_name='free_space')
            else:
                update_cmd = UpdateBoxArrayColor(id=self._free_space_elements_ids[i],
                                                 image_data=free_space_image,
                                                 enable_image=enable_image,
                                                 location=location,
                                                 orientation=orientation,
                                                 priority=priority)
                window.add_command(update_cmd)

        if render:
            window.render()


class SceneProviderFreeSpaceImageAuxVisualizer(ImageAuxVisualizer):
    """
    Visualizes free space on an image as provided by Scene Provider
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser, rtk_height: float = 0.7):
        super().__init__(master_parser=master_parser)
        self._free_space_element_id = None
        self._rtk_height = rtk_height

    def visualize(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        state = canonic_frame.state
        if not self._is_enabled or not state or not state.free_space_grids:
            return image
        copied_image = image.copy()

        # Extract free space image
        num_grids = len(state.free_space_grids.occupancy_grid_data)
        for i in range(num_grids):
            free_space_data = state.free_space_grids.occupancy_grid_data[i]
            free_space_image, enable_image = StateVisualizer.get_free_space_image(free_space_grid_instance=free_space_data)
            free_space_image = free_space_image[..., :3]

            # Generate points in 3d space and project them on image to understand the coordinates in which to draw free
            # space elements
            cell_size = free_space_data.cell_size
            global_offset = free_space_data.cell_origin_location
            x_coordinates = np.arange(free_space_image.shape[0]) * cell_size[0] + cell_size[0] / 2 + global_offset[0]
            y_coordinates = np.arange(free_space_image.shape[1]) * cell_size[1] + cell_size[1] / 2 + global_offset[1]
            x_coordinates, y_coordinates = np.meshgrid(x_coordinates, y_coordinates, indexing='ij')
            points = np.stack((x_coordinates, y_coordinates, -self._rtk_height * np.ones_like(x_coordinates)), axis=-1).reshape(-1, 3)

            points_projected, is_in_fov = image_visualizer.project_3d_points_on_image(timestamp=state.prediction_timestamp_in_seconds,
                                                                                      points=points,
                                                                                      is_ego_coordinates=True
                                                                                      )

            # draw circles at a copy of the image and then blend it with the original image
            points_projected = points_projected.T
            free_space_image = free_space_image.reshape(-1, 3)[is_in_fov]
            enable_image = enable_image.ravel()[is_in_fov]
            for idx, point in enumerate(points_projected):
                if enable_image[idx]:
                    copied_image = cv2.circle(copied_image, tuple(point), 5, tuple(free_space_image[idx]*255), -1)

        alpha = 0.7
        image = cv2.addWeighted(image, alpha, copied_image, 1 - alpha, 0)

        return image
