from io import BytesIO as StringIO
from typing import Optional, Tuple

import cv2
import matplotlib.pyplot as plt
import pydotplus
from subdivision_planner.src.common import types
from graphviz import Digraph
from subdivision_planner.src.mcts.searcher import Searcher
from subdivision_planner.src.mcts.uct_node import UCTNode
from subdivision_planner.src.mdp.iaction import IMDPAction
from subdivision_planner.src.mdp.state import MDPContext
from subdivision_planner.src.mdp.werling.action import WerlingMDPAction


class GraphVizGenerator:
    def __init__(self):
        self._graph = None
        self._last_used_id = None

    def reset(self):
        self._graph = None
        self._last_used_id = None

    def _add_tree_to_graph(self, node: UCTNode, id: int, action_leading_to_node: Optional[IMDPAction]):
        """
        generate the tree graph to be displayed
        :param node: root node of tree to be added
        :param id: Graphviz id of the root node of the tree
        :param action_leading_to_node: Action leading to root node of the tree, could be None for the real root node
        :return: Tuple of generated graph and id of latest generated node (for recursion support)
        """
        if self._graph is None:
            self._graph = Digraph()

        # add current node to graph
        self._add_node_to_graph(node, id=id, action_leading_to_node=action_leading_to_node)
        self._graph.attr(overlap='true')

        # generate child nodes recursively
        for action in node.actions:
            child = node.get_child(action)
            child_id = self._get_new_id()
            self._add_edge_to_graph(action=action, src_id=id, dst_id=child_id)
            self._add_tree_to_graph(node=child, id=child_id, action_leading_to_node=action)

    @classmethod
    def _describe_node(cls, node: UCTNode, action_leading_to_node: Optional[WerlingMDPAction]) -> str:
        """
        Generates a textual description of a node in the tree
        :param node: the node to be described
        :param action_leading_to_node: the action leading up to that node
        :return: a string describing this node and the action leading up to it
        """
        state = node.mdp_node.state
        state_str = "(s,sv,sa,d)=({:.2f}, {:.2f}, {:.3f}, {:.2f})".format(
            state.frenet_state[types.FS_SX],
            state.frenet_state[types.FS_SV],
            state.frenet_state[types.FS_SA],
            state.frenet_state[types.FS_DX]
        )

        action_str = ""
        if action_leading_to_node is not None:
            action_str = "goal(t,s,sv,d,dv,da)=({:.3f}, {:.2f}, {:.2f}, {:.2f}, {:.2f}, {:.2f})\n{}\ns finished: {}, d finished: {}, is_prev: {}".format(
                action_leading_to_node.longitudinal_component.motion_plan.T,
                action_leading_to_node.longitudinal_component.motion_plan.x_T,
                action_leading_to_node.longitudinal_component.motion_plan.v_T,
                action_leading_to_node.lateral_component.motion_plan.x_T,
                action_leading_to_node.lateral_component.motion_plan.v_T,
                action_leading_to_node.lateral_component.motion_plan.a_T,
                str(action_leading_to_node.action_type),
                action_leading_to_node.is_longitudinal_component_finished,
                action_leading_to_node.is_lateral_component_finished,
                (action_leading_to_node.generation_time or 0) < (MDPContext().timestamp or 0),
            )

        node_str = "t={:.2f} Q={:.2f} R_a: {:.2f} N={}".format(
            node.mdp_node.state.timestamp,
            node.parent.q_sa[action_leading_to_node] if action_leading_to_node else (node.value or 0),
            node.parent.q_sa[action_leading_to_node] - (node.value or 0) if action_leading_to_node else 0.,
            node.num_visits or 0,
        )

        total_str = node_str + "\n" + state_str + "\n" + action_str

        return total_str

    def _add_edge_to_graph(self, action: IMDPAction, src_id: int, dst_id: int):
        """
        Generates an edge representation in graphviz dot language
        :param src_id: id of source node
        :param dst_id: id of dst node
        :param action: action to represent
        """
        assert isinstance(action, WerlingMDPAction)
        # Red edges for actions that finish the longitudinal plan
        if action.is_longitudinal_component_finished and action.is_lateral_component_finished:
            color = "Magenta"
        elif action.is_longitudinal_component_finished:
            color = "Red"
        # Blue edges for actions that finish the lateral plan
        elif action.is_lateral_component_finished:
            color = "Blue"
        else:
            color = "Black"

        self._graph.edge(str(src_id), str(dst_id), color=color)

    def _add_node_to_graph(self, node: UCTNode, id: int, action_leading_to_node: IMDPAction):
        """
        Generates a node representation in graphviz dot language
        :param id: node id
        :param node: Node to be represented
        :param action_leading_to_node: action leading up to that node
        :return:
        """
        assert action_leading_to_node is None or isinstance(action_leading_to_node, WerlingMDPAction)
        if len(node.actions) == 0:
            # this is a leaf, as it has no children
            node_timestamp = node.mdp_node.state.timestamp
            description = self._describe_node(node, action_leading_to_node)

            if len(node.mdp_node.state.previous_actions) > 0 and \
                    Searcher.is_experience_duration_adequate(start_time=node.mdp_node.state.previous_actions[0].start_time,
                                                             end_time=node_timestamp):
                color = "Black"  # normal
                style = "filled"
            else:
                color = "Red"  # indicate that does not meet restriction
                style = "filled,bold"

            self._graph.node(str(id), description, fillcolor="Green", style=style,
                             color=color, fontcolor="Black", shape='circle')
        else:
            description = self._describe_node(node, action_leading_to_node)
            self._graph.node(str(id), description, color="Gray", style='filled', shape='circle', margin="0")

    def _get_new_id(self) -> int:
        """
        Generate a new id for a node to be added to the graph
        """
        if self._last_used_id is None:
            self._last_used_id = 0
        else:
            self._last_used_id += 1
        return self._last_used_id

    def generate_graphviz(self, root_node: UCTNode) -> Digraph:
        """
        Generates a graphviz representation of a tree starting from a given root node
        :param root_node: Root node of the tree
        :return: Digraph representing the tree
        """
        self.reset()
        self._graph = Digraph()

        self._add_tree_to_graph(root_node, id=self._get_new_id(), action_leading_to_node=None)

        return self._graph


class TreeVisualizerOpenCV:
    """
    Performs visualization of a tree starting from a specific UCTNode using OpenCV image window
    """
    def __init__(self, window_name: str = "MCTS Tree", window_size: Tuple[int, int] = (800, 800)):
        self._window_name = window_name
        self._window_size = window_size
        cv2.namedWindow(self._window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self._window_name, 800, 800)
        self._graphviz_generator = GraphVizGenerator()

    def visualize_tree(self, root_node: UCTNode):
        """
        Perform visualization
        :param root_node: Root node of the tree to visualize
        :return: None
        """
        # Generate graphviz data structure containing the tree and convert it to png
        graph = self._graphviz_generator.generate_graphviz(root_node)
        dotgraph = pydotplus.graph_from_dot_data(graph.source)
        png_str = dotgraph.create_png(prog='dot')

        # render pydot by calling dot, no file saved to disk
        sio = StringIO()
        sio.write(png_str)
        sio.seek(0)
        img = plt.imread(sio)

        # Plot using open cv
        cv2.imshow(self._window_name, cv2.cvtColor(img, cv2.COLOR_RGB2BGR))


if __name__ == "__main__":
    from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
    from subdivision_learning.analysis.utils.planner_runner import PlannerRunner
    from subdivision_learning.analysis.utils.searcher_mock import SearcherMock
    from subdivision_planner.src.utils.debug import get_logger
    from subdivision_planner.src.common.recorder import DummyRecorder
    from subdivision_planner.src.mdp.experience import MDPExperience

    vis = TreeVisualizerOpenCV()

    frame_id = 1727
    path = '/data2/recordings/usa_integ/2020_09_11/Scenario_1_trial_1_host_1_t_12_06_10_sub_rtk'
    skip_deep_search = False

    logger = get_logger()

    master_parser = PubSubRecordingMasterParser(base_recording_path=path)

    searcher = SearcherMock(recorder=DummyRecorder(), logger=logger, name="Searcher")

    def alternative_get_result(self) -> Tuple[MDPExperience, float, int]:
        """
        This is an alternative implementation of the get result method that doesn't delete the root node of the searcher
        :return: best results, change best result to None so we don't think there are results waiting
        """
        exp, ret, iterations = self._best_experience, self._best_return, self._iterations_run
        self._best_experience, self._best_return, self._iterations_run = None, None, None

        return exp, ret, iterations

    # Provide an alternative get result function so that root node is not deleted once we get the new results so that
    # we can later use the searcher's root node and visualize it
    searcher.get_result = alternative_get_result

    planner_runner = PlannerRunner(logger=logger,
                                   parser=master_parser.canonic_sequence_parser,
                                   use_recorder=False,
                                   deep_searcher_mock=searcher,
                                   shallow_searcher_mock=searcher)

    action_result = planner_runner.plan(frame_id, skip_deep_search)

    if (master_parser.canonic_sequence_parser[frame_id].execution_info.s_Data.e_b_IsDeepSearchInitiated or
            master_parser.canonic_sequence_parser[frame_id].execution_info.s_Data.e_b_IsShallowSearchInitiated):
        vis.visualize_tree(searcher._root_node)
        cv2.waitKey(0)
    else:
        logger.warning("Searcher doesn't run in this frame")
