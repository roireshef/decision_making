import cv2
import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_planner.src.common import types
from subdivision_learning.analysis.visualization.image_visualizer import ImageVisualizer, ImageAuxVisualizer
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.utils.math_utils import get_boxes_corners


class StateImageAuxVisualizer(ImageAuxVisualizer):
    """
    This class draws data from CanonicState to image
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser, rtk_height: float = 0.7):
        """
        ctor
        :param master_parser: PubSubRecordingMasterParser used to generate data loaders
        :param host_height: Height of host to compensate for errors in calibration
        """
        super().__init__(master_parser=master_parser)
        self._rtk_height = rtk_height

    def visualize(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        """
        Draws objects and lanes from CanonicState, as planning receive them, to image
        """
        if self._is_enabled:
            image = self.visualize_objects(image_visualizer=image_visualizer, image=image, canonic_frame=canonic_frame)
            image = self.visualize_lanes(image_visualizer=image_visualizer, image=image, canonic_frame=canonic_frame)
        return image

    def visualize_objects(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame):
        """
        Draws bounding boxes for objects in state in red.
        """
        state = canonic_frame.state
        for actor in state.actors:
            z = -self._rtk_height
            height = 1.6
            corners = get_boxes_corners(actor.cstates[:1], actor.sizes[:1])
            corners_bottom = np.concatenate((corners, z + np.full((corners.shape[0], 1), 0.)), axis=1)
            corners_top = np.concatenate((corners, z + np.full((corners.shape[0], 1), +height)), axis=1)
            image = image_visualizer.draw_object_from_3d_corners(timestamp=state.prediction_timestamp_in_seconds,
                                                                 image=image,
                                                                 corners_top=corners_top,
                                                                 corners_bottom=corners_bottom,
                                                                 color=(255, 0, 0),
                                                                 is_ego_coordinates=False)
        return image

    def visualize_lanes(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame):
        """
        Draws lane lines from state on the image, in blue.
        """
        state = canonic_frame.state
        # Extract lane ids to draw
        s_values = state.lane_center_frenet_state[types.FS_SX] + np.arange(0, 50, 1)
        fstates = np.concatenate([s_values[:, None], np.zeros((s_values.shape[0], 5))], axis=1)
        lane_ids, _ = state.lane_center_frenet_frame.convert_to_segment_states(fstates)
        lane_ids = np.unique(lane_ids)
        for lane_id in lane_ids:
            # get lane segment from map
            lane = state.map.get_lane_segment_by_id(lane_id)

            # project left border points on the image
            projected_points = self.project_ground_points_on_image(image_visualizer=image_visualizer,
                                                                   timestamp=state.prediction_timestamp_in_seconds,
                                                                   points=lane.left_border)

            # Draw line of points
            if projected_points.size > 0:
                image = cv2.polylines(img=image, pts=[projected_points.T], isClosed=False, color=(0, 0, 255), thickness=4)

            # project right border points
            projected_points = self.project_ground_points_on_image(image_visualizer=image_visualizer,
                                                                   timestamp=state.prediction_timestamp_in_seconds,
                                                                   points=lane.right_border)

            # Draw line of points
            if projected_points.size > 0:
                image = cv2.polylines(img=image, pts=[projected_points.T], isClosed=False, color=(0, 0, 255), thickness=4)

        return image

    def project_ground_points_on_image(self, image_visualizer: ImageVisualizer, timestamp: float, points: np.ndarray) -> np.ndarray:
        """
        Project ground points on image
        :param timestamp: time stamp to extract host pose from
        :param points: points of dimension Nx2 on the ground plane
        :return: 2XM array of points projected on image. Only points that are within the image remain.
        """
        points_3d = np.concatenate((points, -self._rtk_height + np.zeros((points.shape[0], 1))), axis=1)
        return image_visualizer.project_3d_points_on_image(timestamp=timestamp, points=points_3d)[0]

