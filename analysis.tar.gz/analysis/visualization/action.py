import cv2
import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.utils.planner import plan_exists
from subdivision_planner.src.common import types
from subdivision_learning.analysis.visualization.image_visualizer import ImageVisualizer, ImageAuxVisualizer
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame


class ActionImageAuxVisualizer(ImageAuxVisualizer):
    """
    This class draws data from CanonicState to image
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser, host_height: float = 0.7):
        """
        ctor
        :param master_parser: PubSubRecordingMasterParser used to generate data loaders
        :param host_height: Height of host to compensate for errors in calibration
        """

        super().__init__(master_parser=master_parser)
        self._host_height = host_height

    def visualize(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        """
        Draws objects and lanes from CanonicState, as planning receive them, to image
        """
        if plan_exists(canonic_frame.action) and self._is_enabled:
            image = self.visualize_trajectory(image_visualizer=image_visualizer, image=image, canonic_frame=canonic_frame)
        return image

    def visualize_trajectory(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame):
        """
        Draws lane lines from state on the image, in blue.
        """
        action = canonic_frame.action
        traj = action.driving_plan.to_samplable_trajectory()
        cstates = traj.sample(np.arange(traj.timestamp_in_sec, traj.max_sample_time, 0.1))
        points = cstates[:, [types.C_X, types.C_Y]]
        # project trajectory points to image
        projected_points = self.project_ground_points_on_image(image_visualizer=image_visualizer,
                                                               timestamp=canonic_frame.state.prediction_timestamp_in_seconds,
                                                               points=points)

        # Draw line of points
        if projected_points.size > 0:
            image = cv2.polylines(img=image, pts=[projected_points.T], isClosed=False, color=(0, 0, 0), thickness=4)

        return image

    def project_ground_points_on_image(self, image_visualizer: ImageVisualizer, timestamp: float, points: np.ndarray) -> np.ndarray:
        """
        Project ground points on image
        :param timestamp: time stamp to extract host pose from
        :param points: points of dimension Nx2 on the ground plane
        :return: 2XM array of points projected on image. Only points that are within the image remain.
        """
        points_3d = np.concatenate((points, -self._host_height + np.zeros((points.shape[0], 1))), axis=1)
        return image_visualizer.project_3d_points_on_image(timestamp=timestamp, points=points_3d)[0]

