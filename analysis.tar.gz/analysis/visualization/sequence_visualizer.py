import time
import traceback
from abc import ABC, abstractmethod
from functools import partial
from typing import List, Dict, Sequence

from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.visualization.image_visualizer import ImageVisualizer
from subdivision_learning.utils.config_reader import YMLConfigurationReader
from subdivision_learning.utils.import_utils import dynamic_import_from_package
from subdivision_learning.utils.planner import plan_exists
from subdivision_planner.src.common.recorder import DummyRecorder
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.data_structures.driving_plan_deserializer import DrivingPlanDeserializer
from subdivision_planner.src.mdp.determinizer import Determinizer
from subdivision_planner.src.utils.visualization.gui_elements import SliderGuiElement
from subdivision_planner.src.utils.visualization.render_commands import AddGuiElement
from subdivision_planner.src.utils.visualization.state_visualizer import StateVisualizer
from subdivision_planner.src.utils.visualization.window import Window


def value_to_description(frame_ids: List[int], frame_ids_to_timestamps: Dict[int, float], value: int):
    frame_id = frame_ids[value]
    timestamp = frame_ids_to_timestamps[frame_id]
    initial_timestamp = frame_ids_to_timestamps[frame_ids[0]]
    relative_time = timestamp - initial_timestamp
    return f"frame: {frame_id}, timestamp: {timestamp:.2f} (+ {relative_time:.2f})"


class PandaAuxVisualizer(ABC):
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        """
        :param master_parser: master parser that can be used to load data from recordings
        """
        self._master_parser = master_parser
        self._is_enabled = False

    @abstractmethod
    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        """
        This is a visualizer method. It should add RenderElements to window so they are rendered
        :param window: Window object to display data
        :param canonic_frame: CanonicFrame to display data from
        :param render: If false, it shouldn't call window's render method so that the visualization won't start rendering
        :return: None
        """
        raise NotImplementedError

    def disable(self):
        """
        Run this method to disable the work of this visualizer
        """
        self._is_enabled = False

    def enable(self):
        """
        Run this method to enable the work of this visualizer
        """
        self._is_enabled = True


class SequenceVisualizer:
    """
    This visualizer gets a canonic sequence parser and visualizes it frame by frame. It has a slider bar that can change
    frames in the parser
    """

    def __init__(self,
                 master_parser: PubSubRecordingMasterParser,
                 config_path: str,
                 win_name: str = "default",
                 is_blocking: bool = False,
                 image_visualizers: Sequence[ImageVisualizer] = (),
                 visualize_free_space: bool = False,
                 visualize_fused_scene: bool = False
                 ):
        """
        ctor
        :param master_parser: Canonic sequence parser to load the canonic states and actions from
        :param win_name: Window name to be used
        :param is_blocking: if true visualization is blocking and no frames are dropped. This can cause latency issues
        """
        self._master_parser = master_parser
        self._parser = master_parser.canonic_sequence_parser
        self._visualizer = StateVisualizer(win_name=win_name, is_blocking=is_blocking, visualize_free_space=visualize_free_space, visualize_fused_scene=visualize_fused_scene)
        self._image_visualizers = image_visualizers

        self._configuration_reader = YMLConfigurationReader(path=config_path)

        self._aux_visualizers = self._init_aux_visualizers()

        frame_ids = self._parser.get_frame_ids()
        frame_ids_to_timestamps = self._parser.get_frame_ids_to_timestamps()
        slider = SliderGuiElement(name="frame_number",
                                  range=(0, len(self._parser) - 1),
                                  value=0,
                                  page_size=1,
                                  use_keyboard=True,
                                  value_to_text_fun=partial(value_to_description,
                                                            frame_ids=frame_ids,
                                                            frame_ids_to_timestamps=frame_ids_to_timestamps))
        self._visualizer.window.add_command(AddGuiElement(slider), render=True)

    @property
    def window(self):
        return self._visualizer.window

    def visualize(self, idx: int):
        """
        Visualizes the <idx> frame from the visualizer's parser
        :param idx: index of the frame to visualize. Note that this is not the frame id, but the <idx>th frame the
                    parser contains.
        """
        # Get the frame id of this frame
        frame_id = self._parser.get_frame_ids()[idx]
        # Retrieve the correct canonic frame from the parser
        frame = self._parser[frame_id]
        print(f"Loaded frame {frame_id}, timestamp: {frame.state.timestamp_in_seconds}")

        # If this frame contained a valid driving plan when planning started, we use it to perform determinization.
        # Otherwise, we visualize the state as is
        if frame.internal_state is not None and frame.internal_state.s_Data.e_b_InitialDrivingPlanValid:
            driving_plan = DrivingPlanDeserializer.deserialize(frame.internal_state.s_Data.s_InitialDrivingPlan, frame.state.map)
            det_state = Determinizer.determinize_state(frame.state, previous_driving_plan=driving_plan)
            self._visualizer.visualize(det_state, undeterminized_state=frame.state, render=False, internal_state=frame.internal_state)
        else:
            self._visualizer.visualize(frame.state, render=False)

        # If there is a CanonicAction for this frame, we visualize it's actions
        if plan_exists(frame.action):
            self._visualizer.visualize_actions(
                actions=frame.action.driving_plan.actions,
                render=False)
            self._visualizer.visualize_hmi_statuses(
                mdp_state=frame.state,
                hmi_statuses=frame.action.hmi_statuses,
                render=False)
        else:
            self._visualizer.window.clear("actions")

        # Go over all visualizers and let them visualize them one by one
        for aux_visualizer in self._aux_visualizers:
            aux_visualizer.visualize(window=self.window, canonic_frame=frame, render=False)

        # Call the render method of the window so that rendering will start
        self._visualizer.window.render()

        # Visualize the image part as well
        for image_visualizer in self._image_visualizers:
            image_visualizer.visualize(canonic_frame=frame)

    def run(self):
        """
        Runs the visualizer - this method doesn't stop
        """
        last_viewed_frame = -1
        while self._visualizer.window.is_alive():
            start_time = time.time()
            self._update_auxiliary_visualizers_state()
            gui_data = self.window.get_gui_data()
            if "frame_number" in gui_data:
                frame_number = int(gui_data["frame_number"])
                if last_viewed_frame != frame_number:
                    try:
                        self.visualize(frame_number)
                    except Exception as e:
                        print(f"skipping frame {self._parser.get_frame_ids()[frame_number]} due to {e.__class__.__name__} {e}")
                        traceback.print_exc()
                    last_viewed_frame = frame_number
            time.sleep(max(0, 0.1 - (time.time() - start_time)))

    def _update_auxiliary_visualizers_state(self):
        """
        Enable and disable auxiliary visualizers state according to the configuration file
        """
        if self._configuration_reader is None:
            return

        # Read configuration if it has changed since last time we read it
        cfg = self._configuration_reader.read_if_changed()
        if cfg is None:
            return

        # Extract all active auxiliary visualizers names
        aux_vis_names = []

        if "sequence_visualizer" in cfg and "auxiliary_visualizers" in cfg["sequence_visualizer"]:
            # Extract the relevant configuration only
            cfg = cfg["sequence_visualizer"]['auxiliary_visualizers']
            for aux_vis_info in cfg:
                if isinstance(aux_vis_info, dict):
                    assert len(aux_vis_info) == 1, "Assuming we have a dictionary with a single key"
                    aux_vis_names.append(list(aux_vis_info.keys())[0])
                else:
                    aux_vis_names.append(aux_vis_info)

        # Enable or disable visualizers according to config
        for aux_vis in self._aux_visualizers:
            if aux_vis.__class__.__name__ not in aux_vis_names:
                aux_vis.disable()
            else:
                aux_vis.enable()

    def _init_aux_visualizers(self) -> List[PandaAuxVisualizer]:
        """
        returns all auxiliary visualizers according to the configuration
        """
        # Read the configuration file to understand which visualizers exist
        cfg = self._configuration_reader.read()

        # Load all optional auxiliary visualizers that derive from PandaAuxVisualizer
        optional_aux_visualizers = dynamic_import_from_package(
            package_path='subdivision_learning.analysis.visualization',
            predicate=lambda t: issubclass(t, PandaAuxVisualizer))

        aux_visualizers: List[PandaAuxVisualizer] = []
        for aux_vis_info in cfg["sequence_visualizer"]["auxiliary_visualizers"]:
            assert isinstance(aux_vis_info, dict)
            assert len(aux_vis_info) == 1, "Assuming we have a dictionary with a single key"
            config_data = list(aux_vis_info.values())[0] or {}
            aux_vis_name = list(aux_vis_info.keys())[0]

            if aux_vis_name in optional_aux_visualizers:
                vis_init = optional_aux_visualizers.pop(aux_vis_name)
                aux_visualizers.append(vis_init(master_parser=self._master_parser, **config_data))
                aux_visualizers[-1].enable()

        # for vis_init in optional_aux_visualizers.values():
        #     aux_visualizers.append(vis_init(master_parser=self._master_parser))

        return aux_visualizers
