import CtmPython
import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.visualization.image_visualizer import ImageVisualizer, ImageAuxVisualizer
from subdivision_learning.analysis.visualization.sequence_visualizer import PandaAuxVisualizer
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.utils.math_utils import get_boxes_corners
from subdivision_planner.src.utils.visualization.render_elements import Rectangle
from subdivision_planner.src.utils.visualization.window import Window


class PerceivedObjectsPandaAuxVisualizer(PandaAuxVisualizer):
    """
    Visualizer to display perceived objects data on panda visualization
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        """
        ctor
        :param master_parser: pubsub recording master parser to be used to generate data loaders from
        """
        super().__init__(master_parser=master_parser)
        self._perceived_objects_data_loader = self._master_parser.get_data_loader(domain="UC_SYSTEM",
                                                                                  topic="PERCEIVED_OBJECT_DATA")
        self._hsp_data_loader = self._master_parser.get_data_loader(domain="UC_SYSTEM", topic="HOST_SEMANTIC_POSE")

    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        """
        WIP
        This visualization reads the relevant pubsub message, generates rectangles for every actor and displays them to
        view
        :param window:
        :param canonic_frame:
        :param render:
        :return:
        """
        if not self._is_enabled or not self._perceived_objects_data_loader or not self._hsp_data_loader:
            return

        timestamp = canonic_frame.state.prediction_timestamp_in_seconds
        # Get message from pubsub
        perceived_objects_data = self._perceived_objects_data_loader.get_by_image_capture_timestamp(timestamp=timestamp)
        hsp_msg = self._hsp_data_loader.get_by_data_timestamp(timestamp=timestamp)
        pose = CtmPython.GlobalPose(
            CtmPython.ENUposition(hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_east,
                                  hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_north,
                                  hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_up * 0,
                                  ),
            CtmPython.Orientation3D(yaw=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_yaw,
                                    pitch=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_pitch,
                                    roll=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_roll),
            CtmPython.Velocity3D(.0, .0, .0),
            CtmPython.Acceleration3D(.0, .0, .0),
            CtmPython.AngularVelocity3D(.0, .0, .0),
            CtmPython.AngularAcceleration3D(.0, .0, .0)
        )
        transform_ego_to_map = CtmPython.get_ego_to_map_transform(pose)

        perceived_objects = [perceived_objects_data.s_Data.as_DynamicObjects[i]
                             for i in range(perceived_objects_data.s_Data.e_Cnt_NumDynamicObjects)]

        # draw every object separately
        for perceived_object in perceived_objects:
            # perceived_object: TsSYSDynamicObjects
            x = perceived_object.s_Location.e_l_x
            y = perceived_object.s_Location.e_l_y
            z = perceived_object.s_Location.e_l_z
            yaw = perceived_object.s_Boundingbox.e_phi_yaw

            vx = perceived_object.s_Velocity.e_v_x
            vy = perceived_object.s_Velocity.e_v_y

            width = perceived_object.s_Boundingbox.s_BoundingBoxSize.e_l_width
            length = perceived_object.s_Boundingbox.s_BoundingBoxSize.e_l_length

            obj_location = transform_ego_to_map.transform_point(CtmPython.Point3D(x=x, y=y, z=z))
            obj_yaw = transform_ego_to_map.transform_orientation(CtmPython.Orientation3D(yaw=yaw, pitch=0., roll=0.)).yaw
            obj_v = transform_ego_to_map.transform_velocity(CtmPython.Velocity3D(x=vx, y=vy, z=0.))

            v = np.linalg.norm(np.array([obj_v.x, obj_v.y]))

            text = "id={}\nv={:.2f}".format(perceived_object.e_Cnt_id, v)

            color = (0., 0.8, 0., 0.5)

            rectangle = Rectangle(location=(obj_location.x, obj_location.y),
                                  size=(length, width),
                                  orientation=obj_yaw,
                                  color=color,
                                  priority=2.,
                                  text=text)

            window.draw_element(rectangle, view_name='default')

        if render:
            window.render()


class PerceivedObjectsImageAuxVisualizer(ImageAuxVisualizer):
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        super().__init__(master_parser=master_parser)
        self._perceived_objects_data_loader = self._master_parser.get_data_loader(domain="UC_SYSTEM",
                                                                                  topic="PERCEIVED_OBJECT_DATA")

    def visualize(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        """
        Draw bounding boxes on image according to data from perception (without AP in the middle). Bounding boxes are
        drawn in green
        """
        if not self._is_enabled or not self._perceived_objects_data_loader:
            return image

        state = canonic_frame.state
        # Get message from pubsub
        perceived_objects_data = \
            self._perceived_objects_data_loader.get_by_image_capture_timestamp(state.prediction_timestamp_in_seconds)
        perceived_objects = [perceived_objects_data.s_Data.as_DynamicObjects[i]
                             for i in range(perceived_objects_data.s_Data.e_Cnt_NumDynamicObjects)]

        # draw every object separately
        for perceived_object in perceived_objects:
            x = perceived_object.s_Location.e_l_x
            y = perceived_object.s_Location.e_l_y
            z = perceived_object.s_Location.e_l_z
            yaw = perceived_object.s_Boundingbox.e_phi_yaw
            width = perceived_object.s_Boundingbox.s_BoundingBoxSize.e_l_width
            length = perceived_object.s_Boundingbox.s_BoundingBoxSize.e_l_length
            height = perceived_object.s_Boundingbox.s_BoundingBoxSize.e_l_height

            corners_perception = get_boxes_corners(np.array([[x, y, yaw, 0., 0., 0.]]), np.array([[length, width]]))

            corners_bottom = np.concatenate((corners_perception, z + np.full((corners_perception.shape[0], 1), 0.)),
                                            axis=1)
            corners_top = np.concatenate(
                (corners_perception, z + np.full((corners_perception.shape[0], 1), +height)), axis=1)
            image = image_visualizer.draw_object_from_3d_corners(timestamp=state.prediction_timestamp_in_seconds,
                                                                 image=image,
                                                                 corners_top=corners_top,
                                                                 corners_bottom=corners_bottom,
                                                                 color=(0, 255, 0),
                                                                 is_ego_coordinates=True)

        return image

