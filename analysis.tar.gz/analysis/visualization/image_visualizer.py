from abc import ABC, abstractmethod
from typing import Tuple, List, Optional

import CtmPython
import cv2
import numpy as np
from subdivision_learning.analysis.data_layer.image_parsed_data_loader import ImageParsedDataLoader
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.utils.config_reader import YMLConfigurationReader
from subdivision_learning.utils.import_utils import dynamic_import_from_package
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame


class ImageAuxVisualizer(ABC):
    """
    This interface allows adding auxiliary information on top of the image
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        self._master_parser = master_parser
        self._is_enabled = False

    @abstractmethod
    def visualize(self, image_visualizer: 'ImageVisualizer', image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        """
        Performs actual visualization
        :param image_visualizer: ImageVisualizer object that can be used to perform projections and drawing.
        :param image: Image to draw on (numpy array)
        :param canonic_frame: CanonicFrame that should be used for drawing
        :return: Image that was input after manipulation
        """
        raise NotImplementedError

    def enable(self):
        self._is_enabled = True

    def disable(self):
        self._is_enabled = False


class ImageVisualizer:
    """
    Visualizes CanonicState on image data
    """
    def __init__(self,
                 name: str,
                 image_parsed_data_loader: ImageParsedDataLoader,
                 master_parser: PubSubRecordingMasterParser,
                 config_path: str,
                 image_downscale: int = 4,
                 ):
        """
        ctor
        :param name: Unique name for the window of display
        :param image_parsed_data_loader: Loader for image data
        :param master_parser: Master parser used to generate data loaders from
        :param config_path: Path for configuration file, data relevant for image visualizer should be located under
                            "image_visualizer".
        :param image_downscale: Amount by which to downscale visualized image, must be an int
        """
        self._name = name
        self._parsed_image_parser = image_parsed_data_loader
        self._master_parser = master_parser
        self._configuration_reader = YMLConfigurationReader(path=config_path)
        self._image_downscale = image_downscale

        self._hsp_data_loader = self._master_parser.get_data_loader("UC_SYSTEM", "HOST_SEMANTIC_POSE")
        self._aux_visualizers = self._init_aux_visualizers()

    def generate_window(self):
        """
        Generates an opencv window for display of the image
        """
        cv2.namedWindow(self._name)
        cv2.resizeWindow(self._name, 400, 700)

    def visualize(self, canonic_frame: CanonicFrame):
        """
        Visualizes the canonic state: Draws image, lane lines, state objects and perception objects on image
        """

        state = canonic_frame.state
        timestamp = state.prediction_timestamp_in_seconds

        self.generate_window()

        img = self._parsed_image_parser.get_by_timestamp(timestamp)
        if img is None:
            return

        self._update_auxiliary_visualizers_state()
        for aux_visualizer in self._aux_visualizers:
            img = aux_visualizer.visualize(image_visualizer=self, image=img, canonic_frame=canonic_frame)

        image_size = (img.shape[1] // self._image_downscale, img.shape[0] // self._image_downscale)
        resized_image = cv2.resize(cv2.cvtColor(img, cv2.COLOR_RGB2BGR), image_size)
        cv2.imshow(self._name, resized_image)
        cv2.waitKey(10)

    def draw_object_from_3d_corners(self,
                                    timestamp: float,
                                    image: np.ndarray,
                                    corners_top: np.ndarray,
                                    corners_bottom: np.ndarray,
                                    color: Tuple[int, int, int] = (255, 0, 0),
                                    is_ego_coordinates: bool = False
                                    ) -> np.ndarray:
        """
        Given 3d corners of a bounding box, draws the bounding box itself on the image
        :param timestamp: timestamp to extract host pose
        :param image: image to draw on
        :param corners_top: corners of top face of the bounding box
        :param corners_bottom: corners of bottom face of the bounding box
        :param color: color to use
        :param is_ego_coordinates: if True projection to ego coordinates is not needed
        :return: drawn image
        """
        projected_corners_bottom = self.project_3d_points_on_image(timestamp=timestamp,
                                                                   points=corners_bottom,
                                                                   is_ego_coordinates=is_ego_coordinates)[0].T
        projected_corners_top = self.project_3d_points_on_image(timestamp=timestamp,
                                                                points=corners_top,
                                                                is_ego_coordinates=is_ego_coordinates)[0].T
        rolled_projected_corners_bottom = np.roll(projected_corners_bottom, -1, axis=0)
        rolled_projected_corners_top = np.roll(projected_corners_top, -1, axis=0)

        # Draw top of the box
        lines = []
        if projected_corners_top.shape[0] == 4:
            lines_num = projected_corners_top.shape[0]
        else:
            lines_num = projected_corners_top.shape[0] - 1
        for idx in range(lines_num):
            lines.append(np.array([rolled_projected_corners_top[idx], projected_corners_top[idx]]))

        image = cv2.polylines(img=image, pts=lines, isClosed=False, color=color, thickness=4)

        # Draw bottom of the box
        lines = []
        if projected_corners_bottom.shape[0] == 4:
            lines_num = projected_corners_bottom.shape[0]
        else:
            lines_num = projected_corners_bottom.shape[0] - 1
        for idx in range(lines_num):
            lines.append(np.array([rolled_projected_corners_bottom[idx], projected_corners_bottom[idx]]))

        image = cv2.polylines(img=image, pts=lines, isClosed=False, color=color, thickness=4)

        # Draw vertical lines of the box
        lines = []
        for idx in range(min(projected_corners_bottom.shape[0], projected_corners_top.shape[0])):
            lines.append(np.array([projected_corners_bottom[idx], projected_corners_top[idx]]))

        image = cv2.polylines(img=image, pts=lines, isClosed=False, color=color, thickness=4)

        return image

    def project_3d_points_on_image(self, timestamp: float, points: np.ndarray, is_ego_coordinates: bool = False) -> Tuple[np.ndarray, np.ndarray]:
        """
        Project points from 3d to image
        :param timestamp: timestamp to extract host pose
        :param points: points to project [Nx3]
        :param is_ego_coordinates: if true, projection to ego coordinates is not required
        :return: numpy array of size Nx2 with projected points on image and numpy array of size N which is true if a pixel is within fov and False if not
        """
        if is_ego_coordinates:
            transformed_points = points.T
        else:
            hsp_msg = self._hsp_data_loader.get_by_data_timestamp(timestamp=timestamp)
            pose = CtmPython.GlobalPose(
                CtmPython.ENUposition(hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_east,
                                      hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_north,
                                      hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_up * 0,
                                      ),
                CtmPython.Orientation3D(yaw=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_yaw,
                                        pitch=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_pitch,
                                        roll=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_roll),
                CtmPython.Velocity3D(.0, .0, .0),
                CtmPython.Acceleration3D(.0, .0, .0),
                CtmPython.AngularVelocity3D(.0, .0, .0),
                CtmPython.AngularAcceleration3D(.0, .0, .0)
            )

            transform_map_to_ego = CtmPython.get_map_to_ego_transform(pose)
            transformed_points = transform_map_to_ego.transform_points_array(points.T)
        transformed_points = self._parsed_image_parser.ctm.get_transform("agent", self._parsed_image_parser.sensor_name)\
            .transform_points_array(transformed_points)
        is_in_fov = self._parsed_image_parser.camera.in_fov_points_array(transformed_points)
        transformed_points = transformed_points[:, is_in_fov]
        projected_points = self._parsed_image_parser.camera.project_points_array(transformed_points, ignore_distortion=False).astype(np.int)

        return projected_points, is_in_fov

    def _update_auxiliary_visualizers_state(self):
        """
        Enable and disable auxiliary visualizers state according to the configuration file
        """
        if self._configuration_reader is None:
            return

        # Read configuration if it has changed since last time we read it
        cfg = self._configuration_reader.read_if_changed()
        if cfg is None:
            return

        # Extract all active auxiliary visualizers names
        aux_vis_names = []

        # Extract the relevant configuration only
        if "image_visualizer" in cfg and "auxiliary_visualizers" in cfg["image_visualizer"]:
            cfg = cfg["image_visualizer"]['auxiliary_visualizers']
            for aux_vis_info in cfg:
                if isinstance(aux_vis_info, dict):
                    assert len(aux_vis_info) == 1, "Assuming we have a dictionary with a single key"
                    aux_vis_names.append(list(aux_vis_info.keys())[0])
                else:
                    aux_vis_names.append(aux_vis_info)

        # Enable or disable visualizers according to config
        for aux_vis in self._aux_visualizers:
            if aux_vis.__class__.__name__ not in aux_vis_names:
                aux_vis.disable()
            else:
                aux_vis.enable()

    def _init_aux_visualizers(self) -> List[ImageAuxVisualizer]:
        """
        returns all auxiliary visualizers according to the configuration
        """
        # Read the configuration file to understand which visualizers exist
        cfg = self._configuration_reader.read()

        # Load all optional auxiliary visualizers that derive from PandaAuxVisualizer
        optional_aux_visualizers = dynamic_import_from_package(
            package_path='subdivision_learning.analysis.visualization',
            predicate=lambda t: issubclass(t, ImageAuxVisualizer))

        aux_visualizers: List[ImageAuxVisualizer] = []
        for aux_vis_info in cfg["image_visualizer"]["auxiliary_visualizers"]:
            assert isinstance(aux_vis_info, dict)
            assert len(aux_vis_info) == 1, "Assuming we have a dictionary with a single key"
            config_data = list(aux_vis_info.values())[0] or {}
            aux_vis_name = list(aux_vis_info.keys())[0]

            if aux_vis_name in optional_aux_visualizers:
                vis_init = optional_aux_visualizers.pop(aux_vis_name)
                aux_visualizers.append(vis_init(master_parser=self._master_parser, **config_data))
                aux_visualizers[-1].enable()

        for vis_init in optional_aux_visualizers.values():
            aux_visualizers.append(vis_init(master_parser=self._master_parser))

        return aux_visualizers
