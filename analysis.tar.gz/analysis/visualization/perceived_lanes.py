import CtmPython
import cv2
import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.visualization.image_visualizer import ImageVisualizer, ImageAuxVisualizer
from subdivision_learning.analysis.visualization.sequence_visualizer import PandaAuxVisualizer
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.utils.visualization.render_elements import Curve
from subdivision_planner.src.utils.visualization.window import Window


class PerceivedLanesPandaAuxVisualizer(PandaAuxVisualizer):
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        """
        :param master_parser: PubSubRecordingMasterParser used to generate data loaders
        """
        super().__init__(master_parser=master_parser)
        self._lanes_data_loader = self._master_parser.get_data_loader(domain="UC_SYSTEM", topic="PERCEIVED_ROAD_GEOMETRY")
        self._hsp_data_loader = self._master_parser.get_data_loader(domain="UC_SYSTEM", topic="HOST_SEMANTIC_POSE")

    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        if not self._is_enabled or not self._lanes_data_loader or not self._hsp_data_loader:
            return

        timestamp = canonic_frame.state.prediction_timestamp_in_seconds

        # Get message from pubsub
        perceived_lane_lines = self._lanes_data_loader.get_by_image_capture_timestamp(timestamp=timestamp)
        hsp_msg = self._hsp_data_loader.get_by_data_timestamp(timestamp=timestamp)
        pose = CtmPython.GlobalPose(
            CtmPython.ENUposition(hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_east,
                                  hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_north,
                                  hsp_msg.s_Data.s_LocalizationPose.s_PoseLocation.e_l_up * 0,
                                  ),
            CtmPython.Orientation3D(yaw=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_yaw,
                                    pitch=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_pitch,
                                    roll=hsp_msg.s_Data.s_LocalizationPose.s_PoseAttitude.e_phi_roll),
            CtmPython.Velocity3D(.0, .0, .0),
            CtmPython.Acceleration3D(.0, .0, .0),
            CtmPython.AngularVelocity3D(.0, .0, .0),
            CtmPython.AngularAcceleration3D(.0, .0, .0)
        )

        transform_ego_to_map = CtmPython.get_ego_to_map_transform(pose)

        for curve_idx in range(perceived_lane_lines.s_Data.e_Cnt_CurveSegments):
            curve_segment = perceived_lane_lines.s_Data.as_CurveSegments[curve_idx]
            num_points = curve_segment.e_Cnt_CurvePoints
            curve_points = np.empty((num_points, 3))
            for point_idx in range(num_points):
                curve_points[point_idx, 0] = curve_segment.as_CurvePoints[point_idx].s_3DPoint.e_l_x
                curve_points[point_idx, 1] = curve_segment.as_CurvePoints[point_idx].s_3DPoint.e_l_y
                curve_points[point_idx, 2] = curve_segment.as_CurvePoints[point_idx].s_3DPoint.e_l_z

            transformed_points = transform_ego_to_map.transform_points_array(curve_points.T).T
            if transformed_points.shape[0] < 2:
                continue

            curve = Curve(points=transformed_points[:, :2],
                          thickness=3,
                          colors=np.tile(np.array([[0., 1., 0., 1.]]), (transformed_points.shape[0], 1)),
                          priority=10.)
            window.draw_element(curve, view_name='default')

        if render:
            window.render()


class PerceivedLanesImageAuxVisualizer(ImageAuxVisualizer):
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        """
        :param master_parser: PubSubRecordingMasterParser used to generate data loaders
        """
        super().__init__(master_parser=master_parser)
        self._perceived_lanes_data_loader = self._master_parser.get_data_loader(domain="UC_SYSTEM",
                                                                                topic="PERCEIVED_ROAD_GEOMETRY")

    def visualize(self, image_visualizer: ImageVisualizer, image: np.ndarray, canonic_frame: CanonicFrame) -> np.ndarray:
        """
        Draws perception lane lines on the image in green
        """
        if not self._is_enabled or not self._perceived_lanes_data_loader:
            return image

        state = canonic_frame.state
        # Get message from pubsub
        perceived_lane_lines = self._perceived_lanes_data_loader.get_by_physical_timestamp(
            state.prediction_timestamp_in_seconds)
        curve_segments = []
        for curve_idx in range(perceived_lane_lines.s_Data.e_Cnt_CurveSegments):
            curve_segment = perceived_lane_lines.s_Data.as_CurveSegments[curve_idx]
            num_points = curve_segment.e_Cnt_CurvePoints
            curve_points = np.empty((num_points, 3))
            for point_idx in range(num_points):
                curve_points[point_idx, 0] = curve_segment.as_CurvePoints[point_idx].s_3DPoint.e_l_x
                curve_points[point_idx, 1] = curve_segment.as_CurvePoints[point_idx].s_3DPoint.e_l_y
                curve_points[point_idx, 2] = curve_segment.as_CurvePoints[point_idx].s_3DPoint.e_l_z

            curve_segments.append(curve_points)

            # project right border points
            projected_points = image_visualizer.project_3d_points_on_image(timestamp=state.prediction_timestamp_in_seconds,
                                                                           points=curve_points,
                                                                           is_ego_coordinates=True)[0]

            if projected_points.size > 0:
                image = cv2.polylines(img=image, pts=[projected_points.T], isClosed=False, color=(0, 255, 0),
                                      thickness=4)

        return image
