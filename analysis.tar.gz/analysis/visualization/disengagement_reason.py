from typing import Tuple, Optional, Dict

from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.plots.system_plots import FeatureMonitorVizTimePlot
from subdivision_learning.analysis.visualization.sequence_visualizer import PandaAuxVisualizer
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.utils.visualization.gui_elements import TextBoxGuiElement
from subdivision_planner.src.utils.visualization.render_commands import AddGuiElement, UpdateTextBox
from subdivision_planner.src.utils.visualization.window import Window
from active_safety_integration.active_safety_integration.FMS_Parser.ADSC_Parser.disengagement_reasons import FMS_Disengagement_Reasons


class DisengagementReasonPandaAuxVisualizer(PandaAuxVisualizer):
    """
    This visualizer draws a text box and describes the disable reasons according to the control status message
    """
    def __init__(self,
                 master_parser: PubSubRecordingMasterParser,
                 text_box_params: Dict = None):
        super().__init__(master_parser=master_parser)
        self._feature_monitor_viz_loader = self._master_parser.get_data_loader("FEATURE_MONITOR", "VIZ")

        if text_box_params is None:
            text_box_params = {}

        # default location for text box position
        if "pos" not in text_box_params:
            text_box_params["pos"] = (-0.9, 0.9)

        # default color for text
        if "color" not in text_box_params:
            text_box_params["color"] = (1., 1., 1., 1.)

        self._text_box_params = text_box_params
        self._is_gui_element_added = False

        # Name of the gui element that this visualizer adds, so that it can change its values later
        self._gui_element_name = f"{self.__class__.__name__}_TextBox"

    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        if not self._is_enabled:
            return

        # If a gui element wasn't already generated, we generate one now.
        if not self._is_gui_element_added:
            textbox = TextBoxGuiElement(name=self._gui_element_name,
                                        text="",
                                        **self._text_box_params)
            window.add_command(AddGuiElement(textbox), render=False)
            self._is_gui_element_added = True

        # If we don't have control status data, we write that it wasn't found
        if self._feature_monitor_viz_loader is None:
            window.add_command(UpdateTextBox(name=self._gui_element_name, text=f"Feature Monitor VIZ topic wasn't found"))
            return

        # Extract the relevant message according to state timestamp
        timestamp = canonic_frame.state.prediction_timestamp_in_seconds
        msg = self._feature_monitor_viz_loader.get_by_header_timestamp(timestamp)

        # Extract all disable reasons in that frame
        disable_reason = ""
        uc_exec_status = msg.s_Data.VeVGCR_e_UC_ExecSt
        if uc_exec_status != FeatureMonitorVizTimePlot.UC_ExecStEnum.ENGAGED_NORMAL.value:
            last_inhib_or_escltn_cond = msg.s_Data.VeVGCR_e_LastInhbOrEscltnCond
            if uc_exec_status == FeatureMonitorVizTimePlot.UC_ExecStEnum.LEVEL_THREE.value:  # level 3 escalation
                disable_reason = str(FMS_Disengagement_Reasons[last_inhib_or_escltn_cond])
            else:
                disable_reason = FeatureMonitorVizTimePlot.UC_ExecStEnum(uc_exec_status).name

        # Send a command to update the gui element data
        window.add_command(UpdateTextBox(name=self._gui_element_name, text=f"Disable reasons: {disable_reason}"))
