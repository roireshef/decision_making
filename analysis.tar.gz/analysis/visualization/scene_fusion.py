import numpy as np
from subdivision_learning.analysis.data_layer.pubsub_recording_master_parser import PubSubRecordingMasterParser
from subdivision_learning.analysis.visualization.image_visualizer import ImageAuxVisualizer, ImageVisualizer
from subdivision_learning.analysis.visualization.sequence_visualizer import PandaAuxVisualizer
from subdivision_planner.src.data_structures.canonic_sequence import CanonicFrame
from subdivision_planner.src.map.map_provider import line_id_to_side
from interface.Rte_Types.python.enums.TeSYS_Side import TeSYSSide
from subdivision_planner.src.messages.scene_static_enums import LineSegmentType
from subdivision_planner.src.utils.visualization.render_elements import Curve, DottedCurve
from subdivision_planner.src.utils.visualization.window import Window

class FusedScenePandaAuxVisualizer(PandaAuxVisualizer):
    """
    This class visualizes the fused scene over the panda3d visualization
    """
    def __init__(self, master_parser: PubSubRecordingMasterParser):
        super().__init__(master_parser=master_parser)
        self._fused_scene_data_loader = master_parser.get_data_loader("UC_SYSTEM", "FUSED_SCENE_REPACK")

    def visualize(self, window: Window, canonic_frame: CanonicFrame, render: bool = False):
        # Don't do anything if this visualizer is not enabled or doesn't have one of the required inputs
        if not self._is_enabled or not self._fused_scene_data_loader:
            return

        state = canonic_frame.state

        scene_fusion_timestamp = state.fused_scene_timestamp_in_seconds
        scene_fusion_message = self._fused_scene_data_loader.get_by_data_timestamp(timestamp=scene_fusion_timestamp)

        fused_scene_repack = scene_fusion_message.s_Data

        num_line_segments = fused_scene_repack.e_Cnt_line_segment_count

        # loop through all line segments
        for line_index in range(num_line_segments):

            curr_line_segment = fused_scene_repack.as_line_segments[line_index]

            curr_line_id = curr_line_segment.e_i_line_segment_id
            curr_lane_id = curr_line_segment.e_i_lane_segment_id

            line_type = curr_line_segment.e_line_segment_type

            curr_num_points = curr_line_segment.e_Cnt_line_points_count
            curr_start_index = curr_line_segment.e_i_start_index
            curr_end_index = curr_start_index + curr_num_points

            if line_type == LineSegmentType.CeSYS_LineSegmentType_NominalPath:
                curr_nominal_path_points = np.array(fused_scene_repack.a_nominal_points[curr_start_index:curr_end_index, :])

                curr_nominal_path_points = [(points[0], points[1]) for points in curr_nominal_path_points]
                curr_nominal_path_points_arr = np.array([np.array(pts) for pts in curr_nominal_path_points])
                colors = np.tile(np.array([[1., 0., 0., 1.]]), (curr_nominal_path_points_arr.shape[0], 1))

                nominal_path_curve = DottedCurve(points=curr_nominal_path_points_arr,
                                           thickness=1.5,
                                           colors=colors,
                                           priority=10.,
                                           text=str(curr_lane_id))

                window.draw_element(nominal_path_curve)

                continue

            side = line_id_to_side(line_id=curr_line_id)

            curr_edge_points = list()

            for point_index in range(curr_start_index, curr_end_index):
                curr_point = fused_scene_repack.as_edge_points[point_index]
                curr_edge_points.append(np.array([curr_point.e_l_east, curr_point.e_l_north]))

            if side == TeSYSSide.CeSYS_Side_Right or side == TeSYSSide.CeSYS_Side_Left:
                curr_edge_points_arr = np.stack(curr_edge_points, axis=0)
                colors = np.tile(np.array([[1., 0., 0., 1.]]), (curr_edge_points_arr.shape[0], 1))

                curr_edge_points_curve = Curve(points=curr_edge_points_arr,
                                                 thickness=1.5,
                                                 colors=colors,
                                                 priority=10.)

                window.draw_element(curr_edge_points_curve)

        if render:
            window.render()



