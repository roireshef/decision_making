from collections import deque
from typing import NamedTuple, Optional, Iterable

from subdivision_planner.src.mcts.uct_node import UCTNode
from subdivision_planner.src.mdp.iaction_spec import IMDPActionSpec


class TreeNode(NamedTuple):
    root_node: UCTNode
    curr_node: Optional[UCTNode]
    curr_node_id: int
    parent_node_id: int
    action_spec: Optional[IMDPActionSpec]


def traverse_tree(root_node: UCTNode, explore_invalid: bool, explore_non_generated: bool) -> Iterable[TreeNode]:
    """
    Traverse the search tree by doing BFS from the root node
    :param root_node:
    :param explore_invalid: if True, all nodes will be considered.
            if False, only nodes with valid generated actions are considered.
    """
    node_to_id = {}
    to_explore = deque([root_node])

    curr_node_id = 0

    while len(to_explore) > 0:
        curr_node = to_explore.pop()
        node_to_id[curr_node] = curr_node_id

        # get parent -> find valid action specs -> get action from spec -> compare to previous action
        action_spec_leading_to_node = None
        if curr_node.parent:
            parent_node = curr_node.parent
            action_leading_to_node = parent_node.get_action_leading_to_child(curr_node)
            for action_spec in parent_node.mdp_node.action_specs:
                if action_spec.is_action_generated and \
                        action_spec.is_action_valid and \
                        action_spec.action == action_leading_to_node:
                    action_spec_leading_to_node = action_spec
                    break

        # add valid children to stack
        to_explore.extend([curr_node.get_child(action) for action in curr_node.actions])

        parent = curr_node.parent
        parent_id = node_to_id.get(parent)
        yield TreeNode(root_node, curr_node, curr_node_id, parent_id, action_spec_leading_to_node)

        if explore_non_generated or explore_invalid:
            invalid_parent_node_id = curr_node_id
            # invalid imaginary nodes
            if explore_non_generated or curr_node.mdp_node.is_action_specs_generated:
                invalid_action_specs = [spec for spec in curr_node.mdp_node.action_specs
                                        if spec.is_action_generated and not spec.is_action_valid]
                for spec in invalid_action_specs:
                    curr_node_id += 1
                    yield TreeNode(root_node, None, curr_node_id, invalid_parent_node_id, spec)

                # valid specs that did not lead to further states (may happen when code changes)
                if len(curr_node.actions) == 0:
                    valid_action_specs = [spec for spec in curr_node.mdp_node.action_specs
                                          if spec.is_action_generated and spec.is_action_valid]
                    for spec in valid_action_specs:
                        curr_node_id += 1
                        yield TreeNode(root_node, None, curr_node_id, invalid_parent_node_id, spec)

        curr_node_id += 1
