from logging import Logger
from typing import Tuple, Optional

from subdivision_planner.src.common.recorder import Recorder
from subdivision_planner.src.mcts.searcher import SearcherSync
from subdivision_planner.src.mcts.uct import UCT
from subdivision_planner.src.mdp.experience import MDPExperience
from subdivision_planner.src.mdp.state import MDPState


class SearcherMock(SearcherSync):
    """
    This class is used to mimic the behavior of a sync searcher but with the ability to preset its output when we want.
    In such cases that we set the output apriori the search will not run.
    This allows a deterministic flow of the planner.
    """

    def __init__(self,
                 recorder: Recorder,
                 logger: Logger,
                 name: str,
                 unlimited_search_time: bool = True):
        """
        ctr - same parameters as SearcherSync
        :param recorder:
        :param logger:
        :param name:
        :param unlimited_search_time:
        """
        super().__init__(logger, recorder, "Mock" + name)

        # This parameter can be set as part of the state of the searcher. If it is true, the search will not run. Note
        # this is decoupled from the fact that we set the result since, in case of a deep search, we don't have the
        # result of the search in the current frame but only after a few more frames.
        self._skip_search = True

        # If true, the search will report itself as idle. Used to mimic behavior of deep search as it was exposed to the
        # planner
        self._is_idle = False

        # The result of the search - this is the tuple of the best experience, the best return and the number of
        # iterations run.
        self._result = None, None, None

        # Number of iterations the search should run
        self._search_iterations = None

        self._unlimited_search_time = unlimited_search_time

    def set_state(self,
                  result: Tuple[Optional[MDPExperience], Optional[float], Optional[int]],
                  is_idle: Optional[bool],
                  search_iterations: Optional[int],
                  run_search: bool):
        """
        This method is used to set the current state of the searcher to match what it was at the corresponding time of
        the online run.
        :param result: The result of the search
        :param is_idle: True if the search reported itself as idle to the planner
        :param search_iterations: Number of iterations the search should run
        :param run_search: If true, the search will run, if false, search will simply output the result it is given as
                            part of the state without running first. Note that the result is always output when given.
                            We never output the result of the search so that there is no discrepancy between the online
                            and offline runs
        """
        self._best_experience, self._best_return, self._iterations_run = result
        self._is_idle = is_idle
        self._search_iterations = search_iterations
        self._skip_search = not run_search

    def init_new_search(self,
                        state: MDPState,
                        search_time: float,
                        min_search_iterations: int,
                        max_search_iterations: int) -> None:
        """
        Overload the parent init_new_search
        :param state:
        :param search_time:
        :param min_search_iterations:
        :param max_search_iterations:
        :return:
        """
        if not self._skip_search:
            super().init_new_search(state=state,
                                    search_time=1e30 if self._unlimited_search_time else search_time,
                                    min_search_iterations=min_search_iterations,
                                    max_search_iterations=self._search_iterations or max_search_iterations)

    @property
    def is_idle(self) -> bool:
        """
        :return: Returns true if search is not in the middle of a search job
        """
        if self._is_idle is not None:
            return self._is_idle
        else:
            return super().is_idle

    @property
    def uct(self) -> UCT:
        return self._uct
