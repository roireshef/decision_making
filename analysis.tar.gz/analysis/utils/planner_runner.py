import os
from logging import Logger
import gc

from rte.python.logger.log_utils import LOG_DIRECTORY
from subdivision_learning.analysis.data_layer.icanonic_sequence_parser import ICanonicSequenceParser
from subdivision_learning.analysis.utils.searcher_mock import SearcherMock
from subdivision_learning.utils.planner import plan_exists
from subdivision_planner.src.common.config import Config
from subdivision_planner.src.common.recorder import DummyRecorder, Recorder
from subdivision_planner.src.data_structures.canonic_action import CanonicAction
from subdivision_planner.src.lba_main import ModuleInitialization
from subdivision_planner.src.mdp.action_deserializer import MDPActionDeserializer
from subdivision_planner.src.mdp.experience import MDPExperience
from subdivision_planner.src.planners.driving_plan_validation import DrivingPlanValidation
from subdivision_planner.src.planners.search_based_planner import SearchBasedPlanner


class PlannerRunner:
    """
    This class runs the planner with the correct mocks and data such that it will run exactly the same as in the
    recording
    """
    def __init__(self,
                 logger: Logger,
                 parser: ICanonicSequenceParser,
                 deep_searcher_mock: SearcherMock = None,
                 shallow_searcher_mock: SearcherMock = None,
                 use_recorder: bool = False):
        """
        ctr
        :param logger: logger
        :param parser: parser that is used to read frames to be reproduced by planner
        :param deep_searcher_mock: SearcherMock for deep searcher
        :param shallow_searcher_mock: SearcherMock for shallow searcher
        :param use_recorder: if True, use the old planner recorder (e.g. for streamlit)
        """
        if use_recorder:
            planner_recorder = Recorder(output_dir=os.path.join(LOG_DIRECTORY, 'sd_recorded_data/planner'), batch_size=1)
            deep_searcher_recorder = Recorder(output_dir=os.path.join(LOG_DIRECTORY, 'sd_recorded_data/deep_searcher'), batch_size=1)
            shallow_searcher_recorder = Recorder(output_dir=os.path.join(LOG_DIRECTORY, 'sd_recorded_data/shallow_searcher'), batch_size=1)
        else:
            planner_recorder = deep_searcher_recorder = shallow_searcher_recorder = DummyRecorder()

        if deep_searcher_mock:
            self._deep_searcher = deep_searcher_mock
        else:
            self._deep_searcher = SearcherMock(recorder=deep_searcher_recorder, logger=logger, name="DeepSearcherMock")

        if shallow_searcher_mock:
            self._shallow_searcher = shallow_searcher_mock
        else:
            self._shallow_searcher = SearcherMock(recorder=shallow_searcher_recorder, logger=logger, name="ShallowSearcherMock")

        dp_validation = DrivingPlanValidation(logger)

        steps, concepts = ModuleInitialization.create_planner_concepts(logger, dp_validation)

        self._planner = SearchBasedPlanner(name="SearchBasedPlanner",
                                           logger=logger,
                                           recorder=planner_recorder,
                                           deep_searcher=self._deep_searcher,
                                           shallow_searcher=self._shallow_searcher,
                                           dp_validation=dp_validation,
                                           steps=steps,
                                           concepts=concepts)

        self._parser = parser

    @property
    def parser(self):
        return self._parser

    def plan(self, frame: int, skip_deep_search: bool = True, skip_shallow_search: bool = False,
             set_iterations: bool = True) -> CanonicAction:
        """
        Perform the actual planning in a specific frame
        :param frame:
        :param skip_deep_search: if true, deep search will be skipped if it was run in that frame. If false, deep search
                                 will be run
        :param skip_shallow_search: if true, shallow search will be skipped if it was run in that frame. If false, shallow search
                                 will be run
        :param set_iterations: if true, number of iterations run will be as in the recording.
                                If false, number of iterations will not be pre-set.
        :return: canonic action
        """
        # Read the correct frame from the parser
        canonic_frame = self._parser[frame]
        canonic_state, planner_internal_state, canonic_action, execution_info = \
            canonic_frame.state, canonic_frame.internal_state, canonic_frame.action, canonic_frame.execution_info

        if not canonic_state:
            raise ValueError(f"Missing canonic state for frame {frame}")
        if not planner_internal_state:
            raise ValueError(f"Missing planner internal state for frame {frame}")
        if not execution_info:
            raise ValueError(f"Missing planner execution info for frame {frame}")

        data_execution_info = execution_info.s_Data

        # If the deep search finished, we load the result of that search
        if data_execution_info.e_b_IsDeepSearchFinished:
            actions = [MDPActionDeserializer.deserialize(data_execution_info.as_DeepSearchResultActions[idx], canonic_state.map)
                       for idx in range(data_execution_info.e_Cnt_DeepSearchResultActionsNum)]
            deep_searcher_result = (MDPExperience(actions=actions), 0., data_execution_info.e_i_DeepSearchIterations)
            is_deep_search_idle = True
        else:
            deep_searcher_result = None, None, None
            is_deep_search_idle = None
            if not data_execution_info.e_b_IsDeepSearchInitiated:
                is_deep_search_idle = False

        deep_search_iterations = None
        # If the deep search was initiated in the frame, we get the number of iterations the deep search ran so it can
        # reproduce the search that was run from that frame
        if data_execution_info.e_b_IsDeepSearchInitiated:
            start_to_finish, _ = self.parser.get_deep_search_connections()
            if frame in start_to_finish:
                deep_search_finish_frame = start_to_finish[frame]
                if deep_search_finish_frame is not None:
                    future_planner_execution_info = self._parser[deep_search_finish_frame].execution_info
                    deep_search_iterations = future_planner_execution_info.s_Data.e_i_DeepSearchIterations

        # Set the relevant state of the deep searcher mock
        self._deep_searcher.set_state(result=deep_searcher_result,
                                      is_idle=is_deep_search_idle,
                                      search_iterations=deep_search_iterations if set_iterations else None,
                                      run_search=not skip_deep_search)

        if skip_shallow_search:
            # This driving plan is in fact different from the one returned by the searcher
            # But the planner would process and merge it again, so the final result should be the same.
            actions = canonic_action.driving_plan.actions if plan_exists(canonic_action) else []
            shallow_search_result = (MDPExperience(actions=actions), 0., data_execution_info.e_i_ShallowSearchIterations)
        else:
            shallow_search_result = (None, None, None)
        # Set the relevant state of the shallow searcher mock (we always run it)
        self._shallow_searcher.set_state(result=shallow_search_result,
                                         is_idle=None,
                                         search_iterations=data_execution_info.e_i_ShallowSearchIterations if set_iterations else None,
                                         run_search=not skip_shallow_search)

        # Set the state of the planner and all its internals
        self._planner.set_state(planner_internal_state=planner_internal_state, map=canonic_state.map)

        gc_enabled = gc.isenabled()
        if Config().system.manual_gc and gc_enabled:
            gc.disable()  # disable automatic garbage collector

        try:
            # Perform the planning
            self._planner.init_frame(canonic_state)
            canonic_action_result = self._planner.plan(canonic_state)
        finally:
            if Config().system.manual_gc and gc_enabled:
                gc.enable()  # enable automatic garbage collector

        return canonic_action_result
