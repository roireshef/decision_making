from typing import Tuple

from interface.Rte_Types.python.sub_structures.TsSYS_PlannerInternalState import TsSYSPlannerInternalState
from subdivision_planner.src.data_structures.canonic_sequence import CanonicSequence
from subdivision_planner.src.data_structures.canonic_state import CanonicState
from subdivision_planner.src.data_structures.driving_plan_deserializer import DrivingPlanDeserializer
from subdivision_planner.src.mdp.determinizer import Determinizer
from subdivision_planner.src.planners.concepts.lane_change_manager import LaneChangeManager
from subdivision_planner.src.mdp.state import MDPState, MDPContext, MDPContextImp


class TimestampFrameIdConverter:
    """
    Converts timestamp (absolute or relative) to the closest frame_id in a specific sequence, and frame_id to the corresponding timestamp.
    """

    def __init__(self, canonic_sequence: CanonicSequence, relative_time: bool = False):
        """
        Pre-calculate everything we need for the conversion from timestamp to frame_id
        :param canonic_sequence: The sequence to base the conversion on
        :param relative_time: Whether to use the absolute time system or relative to the first frame in the sequence
        """

        self._frame_ids = dict()  # Convert timestamps to frame ids
        self._timestamps = dict()  # Convert frame ids to timestamps
        reference_time = None

        for frame in canonic_sequence:
            if frame.state is not None:
                if reference_time is None:
                    reference_time = frame.state.timestamp_in_seconds if relative_time else 0.

                self._frame_ids[frame.state.timestamp_in_seconds - reference_time] = frame.state.frame_id
                self._timestamps[frame.state.frame_id] = frame.state.timestamp_in_seconds - reference_time

    def convert_to_frame_id(self, timestamp: float):
        """
        This method finds the closest timestamp in the sequence to a given timestamp, and returns the frame_id that matches it
        :param timestamp: The timestamp to convert
        :return: closest frame_id to that timestamp
        """
        return self._frame_ids.get(timestamp,
                                   self._frame_ids[min(self._frame_ids.keys(), key=lambda k: abs(k - timestamp))])

    def convert_to_timestamp(self, frame_id: int):
        """
        This method returns the timestamp that matches the given frame_id
        :param frame_id: The frame_id to convert
        :return: closest timestamp to that frame_id
        """
        return self._timestamps.get(frame_id,
                                    self._timestamps[min(self._timestamps.keys(), key=lambda k: abs(k - frame_id))])
